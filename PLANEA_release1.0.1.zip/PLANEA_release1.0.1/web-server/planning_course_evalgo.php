<?php 
function getRubricsTable( $ActID, $planea )
{
	//get the list of rubrics associated to the activity
	$sql = "SELECT rubrics_general.* FROM rubrics_general JOIN rubrics_assoc ON rubrics_general.ID=rubrics_assoc.RubricID
				WHERE rubrics_assoc.RapSkillID=".$ActID." AND rubrics_assoc.RapSkillType=4";	
	$result_list = $planea->conn->query($sql);
	if ($result_list->num_rows > 0)  { 
		$RubricTable = "<table class=\"planning\"><tr><th>Nombre</th><th>Descripción</th><th></th></tr>";
		while($row_list = $result_list->fetch_assoc()) {
			$RubricTable = $RubricTable."<tr id=\"rub".$row_list["ID"]."\"><td>".$row_list["Name"]."</td><td>".$row_list["Description"].
				"</td><td><button class=\"button btn_view\" type=\"button\" onclick=\"evalViewRubric(". $row_list["ID"].")\"></button>
				<button class=\"button btn_remove\" type=\"button\" onclick=\"evalRemoveRubric(". $row_list["ID"].",".$row_list["Scope"].")\"></button></td></tr>";
		}
		$RubricTable = $RubricTable."</table>";
		return $RubricTable;
	} 
	return "";
}

require('planea_basics.php');
$planea = new planea();
$planea->openConnection();

$action 	= $_GET["action"];
$CourseID 	= isset($_GET["CourseID"]) ? $_GET["CourseID"] : 0;
$UserID 	= isset($_GET["UserID"]) ? $_GET["UserID"] : 0;
$Semester 	= isset($_GET["SemesterID"]) ? $_GET["SemesterID"] : 0;


if ($action=="getEvalInfo") 
{	
	//Get description of the evaluation strategies
	$ActID = $_GET["ActID"];
	$sql = "SELECT Evaluation FROM teacher_activities WHERE ID=".$ActID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$Evaluation = $row["Evaluation"];
	
	//Get the first ILO associated to the activity
	$sql = "SELECT courses_ilos.Text,verb_list.StigginsCat FROM courses_ilos 
				INNER JOIN verb_list ON verb_list.ID=courses_ilos.VerbID
				WHERE courses_ilos.ID IN (SELECT RapSkillID FROM teacher_actassoc WHERE ActID=".$ActID." AND RapSkillType=0)";
	$result = $planea->conn->query($sql);
	if ($result->num_rows>0) {
		$row = $result->fetch_assoc();
		$RapText = $row["Text"];
		$RapCat  = $row["StigginsCat"];
	} else {
		$RapText = "";
		$RapCat  = 1;
	}

	//get the list of rubrics associated to the activity
	$ActivityRubrics = getRubricsTable( $ActID, $planea );
	
	//Send data using JSON encoding
	header('Content-type: application/json');
	$json_data = array();
	$json_data["Desc"] = $Evaluation;
	$json_data["RapText"] = $RapText;
	$json_data["RapCat"] = $RapCat;
	$json_data["TbAct"] = $ActivityRubrics;
	echo json_encode($json_data);
}


if ($action=="getActRubs") 
{	
	//get the list of rubrics associated to the activity
	$ActID = $_GET["ActID"];
	echo getRubricsTable( $ActID, $planea );
}

if ($action=="getSuggRubs") 
{	
	$ActID = $_GET["ActID"];
	$filter = $_GET["filter"];
	
	//get the list of suggested rubrics
	if ($filter=="all") {
		$sql = "SELECT * FROM rubrics_general WHERE ID IN 
			(SELECT RubricID FROM rubrics_assoc WHERE rubrics_assoc.CourseID=".$CourseID." 
				AND RapSkillType!=4 GROUP BY RubricID)";
	} else {
		$sql = "SELECT * FROM rubrics_general WHERE ID IN 
			(SELECT RubricID FROM rubrics_assoc 
				INNER JOIN teacher_actassoc ON teacher_actassoc.RapSkillID=rubrics_assoc.RapSkillID AND teacher_actassoc.RapSkillType=rubrics_assoc.RapSkillType
				WHERE rubrics_assoc.CourseID=".$CourseID." AND teacher_actassoc.ActID=".$ActID." GROUP BY RubricID)";
	}
	$result_list = $planea->conn->query($sql);
	if ($result_list->num_rows > 0)  { 
		$RubricTable = "<table class=\"planning\"><tr><th></th><th>Nombre</th><th>Descripción</th><th></th></tr>";
		while($row_list = $result_list->fetch_assoc()) {
			//check if the rubric is already selected for the given activity
			$sql = "SELECT ID FROM rubrics_assoc WHERE RubricID=".$row_list["ID"]." AND RapSkillID=".$ActID." AND RapSkillType=4";
			$result_chk = $planea->conn->query($sql);
			$checked = $result_chk->num_rows>0 ? " checked":"";
			//generate the table of the suggested rubrics
			$RubricTable = $RubricTable."<tr><td><input type=\"checkbox\" id=\"chk".$row_list["ID"]."\" ".$checked."></td><td>".
				$row_list["Name"]."</td><td>".$row_list["Description"].
				"</td><td><button class=\"button btn_view\" type=\"button\" onclick=\"evalViewRubric(". $row_list["ID"].")\"></button></td></tr>";
		}
		$RubricTable = $RubricTable."</table>";
		echo $RubricTable;
	} else 
		echo "<b>No hay rúbricas sugeridas</b>";
}


if ($action=="getGenRubs") 
{	
	//Get description of the evaluation strategies
	$ActID = $_GET["ActID"];
	$sql = "SELECT PlanID FROM teacher_activities WHERE ID=".$ActID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$PlanID = $row["PlanID"];
	//get the list of generic rubrics not currently associated to the activity
	$sql = "SELECT rubrics_general.* FROM rubrics_general JOIN rubrics_assoc ON rubrics_general.ID=rubrics_assoc.RubricID
				WHERE rubrics_assoc.PlanID=".$PlanID." AND rubrics_assoc.CourseID=0
				AND rubrics_assoc.RubricID NOT IN (SELECT RubricID FROM rubrics_assoc WHERE RapSkillID=".$ActID." AND RapSkillType=4)";	
	$result_list = $planea->conn->query($sql);
	if ($result_list->num_rows > 0)  { 
		$RubricTable = "<table class=\"planning\"><tr><th></th><th>Nombre</th><th>Descripción</th><th></th></tr>";
		while($row_list = $result_list->fetch_assoc()) {
			$RubricTable = $RubricTable."<tr><td><input type=\"checkbox\" id=\"chk".$row_list["ID"]."\"></td><td>".
				$row_list["Name"]."</td><td>".$row_list["Description"].
				"</td><td><button class=\"button btn_view\" type=\"button\" onclick=\"evalViewRubric(". $row_list["ID"].")\"></button></td></tr>";
		}
		$RubricTable = $RubricTable."</table>";
		echo $RubricTable;
	} else
		echo "<b>No existen rúbricas generales que puedan asociarse.</b>";
}


if ($action == "appendRubrics") {
	$ActID = $_GET["ActID"];
	$sql = "SELECT PlanID FROM courses_general WHERE ID=".$CourseID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$PlanID = $row["PlanID"];
	foreach ($_GET as $key=>$value) {
		if (substr($key,0,3)=="chk") {
			$RubricID = substr($key,3,strlen($key)-3);
			if ($value=="true") { //associate rubric. First check if it is already associated
				$sql = "SELECT ID FROM rubrics_assoc WHERE RubricID=".$RubricID." AND RapSkillID=".$ActID." AND RapSkillType=4";
				$result = $planea->conn->query($sql);
				if ($result->num_rows==0) {
					$sql = "INSERT INTO rubrics_assoc (RubricID,PlanID,CourseID,RapSkillID,RapSkillType) VALUES (".$RubricID.",".$PlanID.",".$CourseID.",".$ActID.",4)";
					$result = $planea->conn->query($sql);
				}
			} else {
				$sql = "DELETE FROM rubrics_assoc WHERE RubricID=".$RubricID." AND RapSkillID=".$ActID." AND RapSkillType=4";
				$result = $planea->conn->query($sql);
			}
		}
	}
}

if ($action == "removeRubric") {
	$ActID = $_GET["ActID"];
	$RubricID = $_GET["RubricID"];
	$sql = "DELETE FROM rubrics_assoc WHERE RubricID=".$RubricID." AND RapSkillID=".$ActID." AND RapSkillType=4";
	$result = $planea->conn->query($sql);
	$planea->purgeNotUsedRubrics();
}

if ($action == "saveEval") {
	$ActID = $_GET["ActID"];
	$sql = "UPDATE teacher_activities SET Evaluation='".$_GET["Text"]."' WHERE ID=". $ActID;
	$result = $planea->conn->query($sql);
	echo $planea->showPlanningCourseEvalInfo( $ActID, $_GET["Text"], $_GET["PlanID"], $CourseID, $UserID, $Semester, true ); 
}

if ($action == "cancelEval") {
	$ActID = $_GET["ActID"];
	$sql = "SELECT Name FROM teacher_activities WHERE ID=". $ActID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	echo $planea->showPlanningCourseEvalInfo( $ActID, $row["Name"], $_GET["PlanID"], $CourseID, $UserID, $Semester, true ); 
}


$planea->closeConnection();
?>