<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	
	//Borra el archivo
	$target_dir 	= "templates/";
	$target_file 	= $target_dir . $_GET["template"];
	unlink($target_file);
	
	//Elimina todas las referencias de la plantilla en la tabla de cursos
	$sql = "UPDATE courses_general SET Template='' WHERE Template='".$_GET["template"]."'";
	$result = $conn->query($sql);
	
	$sql = "UPDATE study_plan SET Template='' WHERE Template='".$_GET["template"]."'";
	$result = $conn->query($sql);
?>