<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li> 
<li><a <?php if (empty($subMenuName)) { echo "class=\"active\""; } ?> 
      href="<?php if ($_SESSION["RoleID"]==planea::roleCoord) echo "eval_coord.php"; else echo "eval_course.php";?>">
	  Evaluación Curricular</a>
</li>
<?php 
if (!empty($subMenuName)) {
	echo "<li><a class=\"active\" href=\"#\">".$subMenuName."</a></li>\n";
}
if (isset($_GET["PlanID"])) {
	$PlanID = $_GET["PlanID"];
	if ( isset($_GET["SemesterID"]) ) $SemesterID = $_GET["SemesterID"];
}
if (isset($_POST["PlanID"])) {
	$PlanID = $_POST["PlanID"];
	if ( isset($_POST["SemesterID"]) ) $SemesterID = $_POST["SemesterID"];
}
if (isset($PlanID)) {
	$sql = "SELECT * FROM study_plan WHERE ID=".$PlanID;
	$result = $conn->query($sql);
	$row = $result->fetch_assoc();
	$planName = $row["Program"]." (Plan ".$row["Code"].")";
	
	if (isset($SemesterID)) {
		$sql = "SELECT * FROM semesters WHERE ID=".$SemesterID;
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();
		$semesterName = $row["SemesterName"];
	}
} 
?>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#<?php echo $helptopic;?>" target="PLANEA-help">?</a></li>
</ul>