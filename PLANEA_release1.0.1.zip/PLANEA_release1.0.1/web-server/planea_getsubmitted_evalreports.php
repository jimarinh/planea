<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	$planea->showUserSubmittedEvalReports( $_GET["UserID"], $_GET["Semester"] );
	$planea->closeConnection();
?>