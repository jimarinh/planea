<?php
require('planea_basics.php');  

function duplicateRowCourseSpecs($table, $ID, $VersionNum, $conn)
{
	$qrystr = "SELECT * FROM ".$table." WHERE ID=" . $ID;
	$qryresult = $conn->query($qrystr);
	$result = $qryresult->fetch_assoc();
	unset($result["ID"]); //Remove ID from array
	$result["Version"] = $VersionNum;
	$result["EstadoVersion"] = planea::syllStateOpened;
	$result["VisVersion"] = 1; 
	$qrystr = "INSERT INTO ".$table;
	$qrystr .= " ( " .implode(", ",array_keys($result)).") ";
	$qrystr .= " VALUES ('".implode("', '",array_values($result)). "')";
	$result = $conn->query($qrystr);
	return $conn->insert_id;
}

function duplicateRow($table, $row, $replaceKey, $replaceVal, $conn)
{
	unset($row["ID"]); //Remove ID from array
	//Replace key value
	if (!empty($replaceKey)) {
		$row[$replaceKey] = $replaceVal;
	}
	$qrystr = "INSERT INTO ".$table;
	$qrystr .= " ( " .implode(", ",array_keys($row)).") ";
	$qrystr .= " VALUES ('".implode("', '",array_values($row)). "')";
	$result = $conn->query($qrystr);
	return $conn->insert_id;
}

function duplicateRows($table, $CourseID, $newCourseID, $Type, $mapIDs, $conn)
{
	$qrystr = "SELECT * FROM ".$table." WHERE CourseID=" . $CourseID;
	$qryresult = $conn->query($qrystr);
	if ($qryresult->num_rows>0)  {
		while($result = $qryresult->fetch_assoc()) {			
			$oldID = $result["ID"];
			unset($result["ID"]); //Remove ID from array
			$result["CourseID"] = $newCourseID;
			$qrystr = "INSERT INTO ".$table;
			$qrystr .= " ( " .implode(", ",array_keys($result)).") ";
			$qrystr .= " VALUES ('".implode("', '",array_values($result)). "')";
			$conn->query($qrystr);
			if ($Type!=-1) {
				array_push($mapIDs, [($oldID*4)+$Type, $conn->insert_id]);			
			}
		}
	}
	return $mapIDs;
}

function duplicateCourseRubrics( $CourseID, $newCourseID, $mapRubricIDs, $conn ) 
{
	//Duplica únicamente las rúbricas del curso dejando 
	//sin alterar las rúbricas genéricas asociadas al curso
	$qrystr = "SELECT rubrics_general.* FROM rubrics_general 
				JOIN rubrics_assoc ON rubrics_general.ID=rubrics_assoc.RubricID
				WHERE rubrics_assoc.CourseID=".$CourseID." AND rubrics_general.Scope=1 GROUP BY ID";
	
	$qryresult = $conn->query($qrystr);
	if ($qryresult->num_rows>0)  {
		while($row = $qryresult->fetch_assoc()) {
			//Duplicate rubric description
			$oldRubricID = $row["ID"];
			$newRubricID = duplicateRow("rubrics_general", $row, null, null, $conn);
			
			//Duplicate rubric entries
			$sql = "SELECT * FROM rubrics_entries WHERE RubricID=".$oldRubricID." ORDER BY Position";
			$result = $conn->query($sql);
			if ($result->num_rows > 0)  {
				while($row_rubric = $result->fetch_assoc()) {	
					duplicateRow("rubrics_entries", $row_rubric, "RubricID", $newRubricID, $conn);
				}
			}			
			array_push($mapRubricIDs, [$oldRubricID,$newRubricID]);
		}
	}
	return $mapRubricIDs;
}

function mapRubricID($mapRubricIDs, $RubricID) {
	foreach ($mapRubricIDs as list($old, $new)) {
		if ($RubricID == $old) {
			return $new;
		}		
	}
	return $RubricID;
}

function mapSkillID($mapIDs, $SkillID, $Type) {
	if ($SkillID == 0) 
		return 0;
	$entry = $SkillID*4+$Type;
	foreach ($mapIDs as list($old, $new)) {
		if ($entry == $old) {
			return $new;
		}		
	}
	return 0;
}

function duplicateRubricAssoc( $CourseID, $newCourseID, $mapRubricIDs, $mapIDs, $conn ) 
{
	//Duplica las asociaciones de la rúbrica, mapeando las habilidades a su nuevo valor.
	$qrystr = "SELECT * FROM rubrics_assoc WHERE CourseID=".$CourseID;
	$qryresult = $conn->query($qrystr);
	if ($qryresult->num_rows>0)  {
		while($row = $qryresult->fetch_assoc()) {
			$sql = "INSERT INTO rubrics_assoc(RubricID, PlanID, CourseID, RapSkillID, RapSkillType) 
				VALUES (".mapRubricID($mapRubricIDs, $row["RubricID"]).",".$row["PlanID"].",".$newCourseID.
				",".mapSkillID($mapIDs, $row["RapSkillID"], $row["RapSkillType"]).",".$row["RapSkillType"].")";
			$res = $conn->query($sql);
		}
	}	
}

$planea = new planea();
$conn = $planea->openConnection();	
$CourseID =  $_GET["ID"];
$CourseKeyID =  $_GET["CourseKeyID"];

$mapIDs = array();
$mapRubricIDs = array();

//Averigua si no hay otra versión abierta
$sql = "SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID." AND EstadoVersion=".planea::syllStateOpened;
$result = $conn->query($sql); 
if ($result->num_rows == 0)  { 
	$sql = "UPDATE courses_general SET VisVersion=0 WHERE CourseKeyID=".$CourseKeyID;
	$result = $conn->query($sql);
	$sql = "SELECT Version,Nombre FROM courses_general WHERE CourseKeyID=".$CourseKeyID." ORDER BY Version DESC";
	$result = $conn->query($sql);
	$row = $result->fetch_assoc();
	$newID = duplicateRowCourseSpecs("courses_general", $CourseID, $row["Version"]+1, $conn);
	$mapIDs = duplicateRows("courses_personal_skills", $CourseID, $newID, 1, $mapIDs, $conn);
	$mapIDs = duplicateRows("courses_interpersonal_skills", $CourseID, $newID, 2, $mapIDs, $conn);
	$mapIDs = duplicateRows("courses_cdio_skills", $CourseID, $newID, 3, $mapIDs, $conn);
	$mapIDs = duplicateRows("courses_ilos", $CourseID, $newID, 0, $mapIDs, $conn);
	$mapIDs = duplicateRows("courses_reqs", $CourseID, $newID, -1, $mapIDs, $conn);
	$mapIDs = duplicateRows("courses_contents", $CourseID, $newID, -1, $mapIDs, $conn);
	$sql = "UPDATE user_assignments SET CourseID=".$newID." WHERE CourseID=".$CourseID;
	$result = $conn->query($sql); 
	$mapRubricIDs = duplicateCourseRubrics( $CourseID, $newID, $mapRubricIDs, $conn );
	duplicateRubricAssoc( $CourseID, $newID, $mapRubricIDs, $mapIDs, $conn );
	echo "Una nueva versión del curso ".$row["Nombre"]." ha sido creada exitosamente";
} else {
	echo "ERROR: No pueden existir dos versiones como borradores, por favor apruebe o remueva la versión que actualmente se encuentra como borrador antes de ejecutar esta acción.";
}
$planea->closeConnection();
?>