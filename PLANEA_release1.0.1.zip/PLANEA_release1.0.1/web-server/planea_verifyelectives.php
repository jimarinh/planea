<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
//Verify each elective course
$sql = "SELECT courses_general.Nombre,courses_general.NumeroCreditos,courses_general.Semestre,
	    courses_electivecats.CategoryName,courses_electivecats.Credits,courses_electivecats.Semester,courses_electivecats.ForceSemester
		FROM ((courses_general INNER JOIN courses_elective ON courses_general.CourseKeyID=courses_elective.CourseID) 
		INNER JOIN courses_electivecats ON courses_elective.CategoryID = courses_electivecats.ID) 
		WHERE courses_general.PlanID=".$_GET["plan"]." AND courses_general.VisVersion=1 
		ORDER BY courses_electivecats.CategoryName";		
$result = $planea->conn->query($sql);
$bError = false;
if ($result->num_rows>0) {
	$error_cat = "";
	while ($row = $result->fetch_assoc()) {
		$error = "";
		//Verify credits
		if ($row["Credits"] != $row["NumeroCreditos"]) {
			$error = "&nbsp; &nbsp; &nbsp; Diferente número de créditos para el curso <b>".$row["Nombre"]."</b> (".$row["NumeroCreditos"]."), debe ser ".$row["Credits"]." <br>";
		}
		//Verify if force semester
		if ($row["ForceSemester"] && ($row["Semester"]!=$row["Semestre"])) {
			$error = "&nbsp; &nbsp; &nbsp; El semestre del curso <b>".$row["Nombre"]."</b> (".$row["Semestre"].") debe ser el mismo de la categoría (".$row["Semester"].") <br>";
		}
		if ($error) {
			if ($row["CategoryName"] != $error_cat) {
				$error_cat = $row["CategoryName"];
				echo "<br>Categoría <b><u>".$error_cat."</b></u> (".$row["Credits"]." créditos, Semestre ".$row["Semester"]."):<br>";
			}
			echo $error;
			$bError = true;
		}
	}
}
if (!$bError) {
	echo "No se encontraron inconsistencias en las electivas.";
}
$planea->closeConnection();
?>