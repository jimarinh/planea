<?php 
//PLANEA  v1.0
//
// This class defines all forms to modify a syllabus
//
//  (c)2020 	Jorge Iván Marín Hurtado
//				email: jorgemarin@uniquindio.edu.co
//				Programa de Ingeniería Electrónica, Universidad del Quindío
//				Cra 15 Calle 12N Armenia, Quindío, Colombia
require('planea_connection.php');

class planea extends planeaConnection 
{
	const roleNone  = 0;
	const roleAdmin = 1;
	const roleCoord = 2;
	const roleUser  = 3;

	const url = "http://ingelectuq.net/planea";
	const msg_passwordreset1 = "Hola,\nLa contraseña para acceder a PLANEA: \"Herramienta de gestión StudyPlanr\", ha sido reiniciada a tu número de documento: ";
	const msg_passwordreset2 = " Por favor accede a <a href=\"http://ingelectuq.net/planea\">PLANEA</a> y modifica tu contraseña en el panel de \"Perfil\".\n\nAtentamente,\nAdministrador";
	
	const syllStateDisabled = 0;
	const syllStateOpened   = 1;
	const syllStateApproved = 2;
	
	const taxonomySOLO  = 0;
	const taxonomyBloom = 1;
	
	var $defaultTaxonomy = planea::taxonomySOLO;
	
	function formHome( $name, $roleID, $roleList )
	{
		//Display applications according to user privileges
		switch($roleID) {
			case planea::roleAdmin: $rolename = "Administrador"; $helptopic = "admin"; break;
			case planea::roleCoord: $rolename = "Coordinador"; $helptopic = "coord"; break;
			case planea::roleUser:  $rolename = "Docente"; $helptopic = "teacher"; break;	
		}
		
		echo "<ul class=\"navbar navbar-help\"> <li><a class=\"active\" href=\"login.php\">Inicio</a></li>\n";
		if ( strlen($roleList)==1 ) {
			echo "<li><a>" . ($name) . " - " . $rolename . "</a></li>\n";
		} else {
			echo "<li class=\"dropdown\"><a class=\"dropbtn\">" . ($name) . " - " . $rolename . "</a>\n";
		
			echo "<div class=\"dropdown-content\">\n";
			$s = strstr($roleList,"D");
			if ( !empty($s) ) {
				echo "<a href=\"?role=" .planea::roleUser. "\">Cambiar rol a docente</a>";
			}
			$s = strstr($roleList,"C");
			if ( !empty($s) ) {
				echo "<a href=\"?role=" .planea::roleCoord. "\">Cambiar rol a coordinador</a>";
			}
			$s = strstr($roleList,"A");
			if ( !empty($s) )  {
				echo "<a href=\"?role=" .planea::roleAdmin. "\">Cambiar rol a administrador</a>";
			}   
			echo "</div>\n";		
			
			echo "</li>\n";
		}
		
		echo "<li><a href=\"logout.php\">Salir</a></li>\n";
		echo "<li><a href='doc/planea_userguide.html#".$helptopic."-guide' target='PLANEA-help'>?</a></li></ul>\n";
		
		switch($roleID) {
			case planea::roleAdmin: require('appsAdmin.html'); break;
			case planea::roleCoord: require('appsCoord.html'); break;
			case planea::roleUser:  require('appsUser.html'); break;	
		}	
	}
	
	
	function chooseDefaultRole($roleList)
	{
		//When multiple roles are allowed for an user, 
		//the lowest privilege is chosen by default
		$s = strstr($roleList,"D");
		if ( !empty($s) ) {
			return planea::roleUser; 
		} else {
			$s = strstr($roleList,"C");
			if ( !empty($s) ) {
				return planea::roleCoord;
			} else {
				$s = strstr($roleList,"A");
				if ( !empty($s) )  {
					return planea::roleAdmin;
				}
			}
		}
		return planea::roleNone;
	}
	
	function checkRole($roleID, $roleList)
	{
		//Check if role is allowed
		switch($roleID) {
			case planea::roleAdmin: $roleS = "A"; break;
			case planea::roleCoord: $roleS = "C"; break;
			case planea::roleUser:  $roleS = "D"; break;
			default: 
				return false;
		}
		$s = strstr($roleList,$roleS);
		if ( !empty($s) ) {
			return true;
		}
		return false;
	}
	
	function checkPermission( $userRole, $userID, $courseID, $permission ) {
		if (empty($userRole)||empty($userID)) {
			$canModify  = false; 
		} else { 
			$canModify = ($userRole!=planea::roleUser);
			if (!$canModify){
				$sql = "SELECT * FROM users_assignments WHERE userID=".$userID." AND courseID=". $courseID;
				$result = $this->conn->query($sql);
				if ($result->num_rows > 0)  {  
					$row = $result->fetch_assoc();
					if ( ($row["roleType"]==2) && (($row["permissions"]&$permission)==$permission) ) {
						$canModify = true;
					}
					if ( ($row["roleType"]==1) && ($permission==hexdec("8000")) ) {
						$canModify = true;
					}
				}
			}
		}
		return $canModify;
	}
		
	function registerLog( $UserID, $issue ){
	}
		
	function showCourseTitle( $row )
	{
		$CourseName = $row["Nombre"] . " (v".$row["Version"];
		if ($row["EstadoVersion"]==planea::syllStateApproved) $CourseName.=" Vigente";
		if ($row["EstadoVersion"]==planea::syllStateOpened) $CourseName.=" Borrador";
		$CourseName.=")";
		return $CourseName;
	}
	
	
	function showStudyPlan($defaultPlan = 0, $bFullName = false, $filterByCoord = 0)
	{
		if ($filterByCoord != 0) {
			$plan = 0;
			$sql = "SELECT planID FROM users_coordinators WHERE userID=".$filterByCoord;
			$result = $this->conn->query($sql);
			$num_plans = $result->num_rows; 
			if ($num_plans > 0)  {
				$sql = "SELECT * FROM study_plan WHERE ID in (";
				while($row = $result->fetch_assoc()) {	    	
					$num_plans--;
					$sql = $sql . $row["planID"];
					if ( $num_plans>0 ) { $sql = $sql . ","; }
					if ( $plan == 0 ) { $plan = $row["planID"]; }
					if ( $defaultPlan == 0 ) { $plan = $row["planID"]; }
					if ( $defaultPlan == $row["planID"] ) { $plan = $defaultPlan; }
				}
				$sql = $sql .") ORDER BY Code";
				$defaultPlan = $plan;
			} else {
				$sql = "SELECT * FROM study_plan ORDER BY Code";
			}
		} else {
			$sql = "SELECT * FROM study_plan ORDER BY Code";
		}
		$result_list = $this->conn->query($sql);
		while($row_list = $result_list->fetch_assoc()) {
			if ($defaultPlan == $row_list["ID"]) { $selected = "selected"; } else { $selected = ""; }
			$planName =  $row_list["Code"];
			if ($bFullName==true) $planName = $planName. " - ". $row_list["Description"];
			echo "<option value=\"" . $row_list["ID"] . "\"". $selected .">" .$planName. "</option>\n";
		}
		return $defaultPlan;
	}
	
	function showStudyPlanList()
	{
		$sql = "SELECT * FROM study_plan ORDER BY Code";
		$result_list = $this->conn->query($sql);
		while($row_list = $result_list->fetch_assoc()) {				
			echo "<tr id=\"row".$row_list["ID"]."\"><td>".$row_list["Code"]."</td><td>".$row_list["Faculty"]."</td><td>".$row_list["Program"]."</td><td>".$row_list["Description"]."</td>";
			echo "<td>";
			echo "<button class=\"button btn_edit\" type=\"button\" onclick=\"editStudyPlan(". $row_list["ID"]. ")\"></button>";
			echo "</td>";		
			echo "</tr>";
		}
	}

	function showCourseListByVersionState($plan,$state)
	{
		switch ($state) {
			case "Disabled": 
				$state = planea::syllStateDisabled;
				break;
				
			case "Opened": 
				$state = planea::syllStateOpened;
				break;
				
			case "Approved": 
				$state = planea::syllStateApproved;
				break;
		}
		$sql = "SELECT ID, Nombre FROM courses_general WHERE PlanID=".$plan." AND EstadoVersion=".$state." ORDER BY Nombre";
		$result_list = $this->conn->query($sql);
		while($row_list = $result_list->fetch_assoc()) {
			echo "<option value=\"" . $row_list["ID"] . "\">" . $row_list["Nombre"]. "</option>\n";
		}
	}

	function showCourseListByVersionState2($plan,$state)
	{
		switch ($state) {
			case "Disabled": 
				$state = planea::syllStateDisabled;
				break;
				
			case "Opened": 
				$state = planea::syllStateOpened;
				break;
				
			case "Approved": 
				$state = planea::syllStateApproved;
				break;
		}
		if ($state==planea::syllStateApproved) {
			$sql = "SELECT ID,Nombre FROM courses_general WHERE PlanID=".$plan." AND EstadoVersion=".$state." AND CourseKeyID NOT IN (SELECT CourseKeyID FROM courses_general WHERE EstadoVersion=".planea::syllStateOpened.") ORDER BY Nombre";
		} else {
			$sql = "SELECT ID, Nombre FROM courses_general WHERE PlanID=".$plan." AND EstadoVersion=".$state." ORDER BY Nombre";
		}
		$result_list = $this->conn->query($sql);
		while($row_list = $result_list->fetch_assoc()) {
			echo "<tr><td align=\"center\"><input type=\"checkbox\" id=\"chk".$row_list["ID"]."\" name=\"chk".$row_list["ID"]."\" value=1></td><td>".$row_list["Nombre"]."</td></tr>\n";
		}
	}
	
	function showCourseListByPlan($plan)
	{
		$sql = "SELECT ID, Nombre FROM courses_plan WHERE PlanID=".$plan." ORDER BY Nombre";
		$result_list = $this->conn->query($sql);
		while($row_list = $result_list->fetch_assoc()) {
			echo "<option value=\"" . $row_list["ID"] . "\">" . $row_list["Nombre"]. "</option>\n";
		}
	}
	
	function showVersionList($CourseKeyID)
	{
		$sql = "SELECT ID,Version,VisVersion,EstadoVersion FROM courses_general WHERE CourseKeyID=".$CourseKeyID." ORDER BY Version DESC";
		$result_list = $this->conn->query($sql);
		while($row_list = $result_list->fetch_assoc()) {
			switch ($row_list["EstadoVersion"]) {
				case 0: $state = "-Obsoleto"; break;
				case 1: $state = "-Borrador"; break;
				case 2: $state = "-Vigente"; break;
				default: $state = "";
			}
			if ($row_list["VisVersion"] == 1) { $selected = " selected"; } else { $selected = ""; }
			echo "<option value=\"".$row_list["ID"]."\"".$selected.">V" . $row_list["Version"]. $state."</option>\n";
		}
	}

	function showRequirementsList( $CourseID, $canModify )
	{
		$sql = "SELECT * FROM courses_reqs WHERE CourseID=" . $CourseID;
		$result = $this->conn->query($sql);		
		if ($result->num_rows > 0)  {      
			echo "<table>";
			while($row = $result->fetch_assoc()) {		
				$sql = "SELECT Nombre FROM courses_plan WHERE ID=" . $row["RequirementID"];
				$result_course = $this->conn->query($sql);
				$row_course = $result_course->fetch_assoc();			
				echo "<tr><td>". $row_course["Nombre"]. "</td>";
				if ($canModify) {
					echo "<td><button type=\"button\" onclick=\"removeReq(". $CourseID .",". $row["ID"] .")\">Remover</button></td>";
				}
				echo "</tr>";
			}
			echo "</table>\n";            
		}
	}

	function showRequirementsAddList( $CourseID )
	{
		$sql = "SELECT PlanID FROM courses_general WHERE ID=".$CourseID;
		$result = $this->conn->query($sql);
		$row_course =$result->fetch_assoc();
		echo "<select id=\"NuevoRequisito\">\n";
		echo "<option value=0>Seleccione uno...</option>\n";
		$this->showCourseListByPlan($row_course["PlanID"]);
		echo "</select>\n";
		echo "<button  onclick=\"addReq(". $CourseID. ")\" type=\"button\">Añadir Requisito</button>";
	}

	
	function showCourseCatCustomizableList()
	{
		$sql = "SELECT * FROM coursecat_sets";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {  
			echo "<option value=0>Seleccione uno...</option>\n";
			while($row = $result->fetch_assoc()) {	
				echo "<option value=".$row["ID"].">".$row["SetName"]."</option>\n";
			}
		}
	}
	
	function showCourseCatCustomizableSets()
	{
		$sql = "SELECT * FROM coursecat_sets";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {  
			echo "<tr><th>Nombre del Conjunto</th><th>Descripción</th><th></th></tr>";
			while($row = $result->fetch_assoc()) {	
				echo "<tr id=\"row".$row["ID"]."\"><td>".$row["SetName"]."</td><td>".$row["Description"]."</td><td>";
				echo "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeSet(".$row["ID"].")\"></button>"; 
				echo "<button class=\"button btn_edit\" type=\"button\" onclick=\"editSet(".$row["ID"].")\"></button>"; 
				echo "</td></tr>";	
			}
		}
	}
	
	function showCoursesCatEntries($setID)
	{
		$sql = "SELECT * FROM coursecat_values WHERE SetID=".$setID." ORDER BY Position";
		$result = $this->conn->query($sql);
		$strout = "<table>";
		if ($result->num_rows > 0)  { 
			while($row = $result->fetch_assoc()) {	
				$strout = $strout. "<tr id=\"cat".$row["ID"]."\">";
				$strout = $strout. "<td><input id=\"pos".$row["ID"]."\" name=\"pos".$row["ID"]."\" size=\"1\" style=\"width: 1.5em;\" readonly></td><td>";
				$strout = $strout. "<textarea name=\"txt".$row["ID"]."\" rows=1 cols=50 style=\"width: 100%;\" onchange=\"setModifiedFlag()\">".$row["Value"]."</textarea>";
				$strout = $strout. "</td><td>";
				$strout = $strout. "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeItem(".$row["ID"].")\"></button>";
				$strout = $strout. "<button class=\"button btn_up\" type=\"button\" onclick=\"moveItem(".$row["ID"].",-1)\"></button>";
				$strout = $strout. "<button class=\"button btn_down\" type=\"button\" onclick=\"moveItem(".$row["ID"].",1)\"></button>"; 
				$strout = $strout. "</td></tr>";
			}
		}
		$strout = $strout."</table>";
		return $strout;
	}
	
	function showCourseCatList( $PlanID, $selOption="")
	{
		$sql = "SELECT * FROM coursecat_values 
					WHERE SetID IN (SELECT CatSetID FROM study_plan WHERE ID=".$PlanID.") ORDER BY Position";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {  
			echo "<option value=0>Seleccione uno...</option>\n";
			while($row = $result->fetch_assoc()) {
				$sel = ($row["Value"] == $selOption) ? " selected" : "";
				echo "<option value=\"".$row["Value"]."\"".$sel.">".$row["Value"]."</option>\n";
			}
		}
	}
	
	
	function conjugateVerb( $verb ) {
		//Spanish conjugation of verbs
		$len = strlen($verb);
		if ( $verb[$len-1] == 'r' ) {
			return substr($verb,0,$len-1);
		} else {
			return $verb;
		}
	}
	
	function showVerbList() {
		$sql = "SELECT ID,VerbName FROM verb_list ORDER BY VerbName";
		$result = $this->conn->query($sql);		
		if ($result->num_rows > 0)  {
			while($row_verb = $result->fetch_assoc()) {
				echo "<option value=\"".$row_verb["ID"]."\">".$row_verb["VerbName"]."</option>\n";
			}
		}
	}
	
	function showRAPList( $CourseID, $bHighlightVerb, $canModify ) {
		$sql = "SELECT * FROM courses_ilos WHERE CourseID=".$CourseID." ORDER BY Position";
		$result = $this->conn->query($sql);		
		if ($result->num_rows > 0)  {
			//echo "<table> <col width=\"5%\" width=\"20%\" width=\"15%\" width=\"30%\" width=\"30%\">";
			echo "<table>";
			echo "<tr><th>#</th><th>RAP</th><th>Categoría</th><th>RAP de Programa <br>Asociado</th><th></th><th></th><th></th></tr>";
			while($row_rap = $result->fetch_assoc()) {
				//Highlight main verb
				if ($bHighlightVerb) {
					$sql = "SELECT VerbName FROM verb_list WHERE ID=".$row_rap["VerbID"];
					$result_verb = $this->conn->query($sql);
					$row_verb = $result_verb->fetch_assoc();
					$is = strpos(strtoupper($row_rap["Text"]), strtoupper($row_verb["VerbName"]));
					if ($is!==false) {
						$il = strlen($row_verb["VerbName"]);
						$text = substr($row_rap["Text"],0,$is)."<b><u>".substr($row_rap["Text"],$is,$il)."</u></b>".substr($row_rap["Text"],$is+$il);
					} else {
						$text = $row_rap["Text"];
					}
				} else {
					$text = $row_rap["Text"];
				}
				//Get RAP category and associated program RAP
				$sql = "SELECT Value FROM ilo_categories WHERE ID=".$row_rap["CategoryID"];
				$result_cat = $this->conn->query($sql);
				$row_cat = $result_cat->fetch_assoc();
				$sql = "SELECT Value,Position FROM ilo_program WHERE ID=".$row_rap["ProgramILOID"];
				$result_prog = $this->conn->query($sql);
				$row_prog = $result_prog->fetch_assoc();
				//Display row
				echo "<tr id=\"ilo".$row_rap["ID"]."\">";
				echo "<td><input id=\"pos".$row_rap["ID"]."\" name=\"pos".$row_rap["ID"]."\" size=1 value=\"".$row_rap["Position"]."\" style=\"width: 1.5em;\" readonly></td>";
				echo "<td>".$text."</td>";
				if ($row_cat!=null) { echo "<td>".$row_cat["Value"]."</td>"; } else { echo "<td></td>"; }
				if ($row_prog!=null) { echo "<td>(".$row_prog["Position"].") ".$row_prog["Value"]."</td>"; } else { echo "<td></td>"; }
				if ($canModify) {
					echo "<td><button class=\"button btn_edit\" type=\"button\" onclick=\"editItem(".$row_rap["ID"].")\"></button></td>";
					echo "<td><button class=\"button btn_remove\" type=\"button\" onclick=\"removeItem(".$row_rap["ID"].")\"></button></td>";
					$strbtns = "<button class=\"button btn_up\" type=\"button\" onclick=\"moveItem(".$row_rap["ID"].",-1)\"></button>";
					$strbtns = $strbtns. "<button class=\"button btn_down\" type=\"button\" onclick=\"moveItem(".$row_rap["ID"].",1)\"></button>";
					echo "<td>".$strbtns."</td>";
				} else {
					echo "<td></td><td></td><td></td>";
				}
				echo "</tr>";
			}
			echo "</table>";
		}
	}
	
	function showSkill( $CourseID, $type, $databasename, $row, $canModify )
	{
		$skillID = $row["ID"];
		$sql = "SELECT * FROM cdiosyllabus_".$databasename." WHERE ID=" . $row["SkillID"];
		$result_skill = $this->conn->query($sql);
		$row_skill = $result_skill->fetch_assoc();			
		
		echo "<tr id=\"row".$type.$skillID."\"><td id=\"nam".$type.$skillID."\">(".$row_skill["ref_syllabus"].")".$row_skill["description"]. "</td>";
		
		echo "<td><input type=\"radio\" name=\"chk".$type.$skillID ."\" value=\"I\" onchange=\"setModifiedFlag()\" "; 
		if ($row["Introduce"]==1) { echo "checked"; } 
		if (!$canModify) { echo " readonly"; } echo "></td>\n";
		
		echo "<td><input type=\"radio\" name=\"chk".$type.$skillID ."\" value=\"T\" onchange=\"setModifiedFlag()\" "; 
		if ($row["Teach"]==1) { echo "checked"; } 
		if (!$canModify) { echo " readonly"; } echo "></td>\n";
		
		echo "<td><input type=\"radio\" name=\"chk".$type.$skillID ."\" value=\"U\" onchange=\"setModifiedFlag()\" "; 
		if ($row["Utilize"]==1) { echo "checked"; } 
		if (!$canModify) { echo " readonly"; } echo "></td>\n";
		
		echo "<td>";
		if ($canModify) { echo "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeSkill(". $CourseID. ",'".$type."',".$skillID.")\"></button>"; }
		echo "</td></tr>";	
	}
	
	function showSkills( $type, $CourseID, $canModify )
	{
		switch ($type) {
			case "P":
				$databasename = "personal_skills";
				break;
			case "I":
				$databasename = "interpersonal_skills";
				break;
			case "C":
				$databasename = "cdio_skills";
				break;
		}		
		//Carga las habilidades para el respectivo espacio académico
		$sql = "SELECT * FROM courses_".$databasename." WHERE CourseID=" . $CourseID . " ORDER BY SkillID";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0) {
			$displaymode = "block";
		} else {
			$displaymode = "none";
		}
		echo "<table id=\"skillTable".$type."\" style=\"display:".$displaymode."\">";
		echo "<tr><th>Habilidad</th><th>Introduce</th><th>Enseña</th><th>Utiliza</th><th></th></tr>";
		if ($result->num_rows > 0)  {      	
			$numskill = 1;
			while($row = $result->fetch_assoc()) {	
				$this->showSkill( $CourseID, $type, $databasename, $row, $canModify );
				$numskill++;
			}           
		}
		echo "</table>\n"; 
		
		if ( $canModify ) {
			$sql = "SELECT * FROM cdiosyllabus_".$databasename;
			$result_list = $this->conn->query($sql);
			
			echo "<select id=\"".$type."Skill\">\n";
			echo "<option value=0>-------------------</option>\n";
			$bGroup = false;
			while($row_list = $result_list->fetch_assoc()) {
				if ($row_list["parentID"]==0) {
					if ($bGroup) { 
						echo "</optgroup>"; 
					}
					echo "<optgroup label=\"(".$row_list["ref_syllabus"].")".$row_list["description"]."\">";
					$bGroup = true;
				} else {
					echo "<option value=" . $row_list["ID"] .">(".$row_list["ref_syllabus"].")".$row_list["description"]. "</option>\n";
				}
			}
			if ($bGroup) { 
				echo "</optgroup>"; 
			}
			echo "</select>\n";
			echo "<button class=\"button btn_fancy\" onclick=\"addSkill(". $CourseID. ",'".$type."')\" type=\"button\">Añadir Habilidad <img src=\"images/btn_add1.png\"></button>";
		}
	}
	
	function saveSkills( $type, $CourseID )
	{
		switch ($type) {
			case "P":
				$databasename = "personal_skills";
				break;
			case "I":
				$databasename = "interpersonal_skills";
				break;
			case "C":
				$databasename = "cdio_skills";
				break;
		}	
		//Guarda las habilidades seleccionadas en la base de datos
		$sql = "SELECT * FROM courses_". $databasename ." WHERE CourseID=" . $CourseID;
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0) 
		{
			while($row = $result->fetch_assoc()) {
				$skillID = $row["ID"];
				$checkID = "chk".$type.$skillID;
				if (isset($_POST[$checkID])) {
					if ($_POST[$checkID]=="I") $I = 1; else $I = 0;
					if ($_POST[$checkID]=="T") $T = 1; else $T = 0;
					if ($_POST[$checkID]=="U") $U = 1; else $U = 0;
				} else {
					$I = 0;	$T = 0; $U = 0;
				}
				$sql = "UPDATE courses_".$databasename.
						" SET Introduce='".$I."',Teach='".$T."',`Utilize`='".$U."' " .
						"WHERE ID=" . $skillID;
				$this->conn->query($sql);       
			}  
		} 
	}
		
	function showUnit($CourseID, $numTopic, $numTopics, $row, $canModify) {
		$topicID = $row["ID"];
		echo "<div id=\"Unit".$topicID."\">";
		echo "No. <input type=\"number\" id=\"NumTopic".$topicID."\" name=\"NumTopic".$topicID."\" min=1 max=20 value=" . $numTopic. " style=\"width: 2.5em;\" readonly> \n";
		echo "<input type=\"text\" name=\"TopicName" . $topicID . "\"  size=60 value=\"" . $row["TopicName"]. "\"> \n";
		echo " No. Semanas <input type=\"number\" id=\"Weeks" . $topicID . "\"  name=\"Weeks" . $topicID . "\" min=1 max=20 style=\"width: 2.5em;\" onchange=\"analyzeWeeks()\" value=" . $row["Weeks"]. ">\n";
		if ($canModify) { 
			if ($numTopic>1) { $displayStyleUp = "inline"; } else { $displayStyleUp = "none"; }		
			if ($numTopic!=$numTopics) { $displayStyleDn = "inline"; } else { $displayStyleDn = "none"; }
			echo "<button class=\"button btn_up\" type=\"button\" style=\"display:".$displayStyleUp."\" id=\"BtnUp".$topicID."\" onclick=\"moveTopic(". $CourseID. ",".$topicID.",-1)\"></button>";
			echo "<button class=\"button btn_down\" type=\"button\" style=\"display:".$displayStyleDn."\" id=\"BtnDn".$topicID."\" onclick=\"moveTopic(". $CourseID. ",".$topicID.",1)\"></button>"; 
			echo "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeTopic(". $CourseID. ",".$topicID.")\"></button>"; 
		}
		echo "<br><textarea id=\"Contents" .$topicID. "\" name=\"Contents" .$topicID. "\" rows=6 style=\"width: 100%;\">" . $row["Contents"]. "</textarea> <br>\n";     
		echo "</div>";
		$numTopic++;
	}
	
	function showContents($CourseID, $canModify) {
		$sql = "SELECT * FROM courses_contents WHERE CourseID=" . $CourseID . " ORDER BY TopicNumber";
		$result = $this->conn->query($sql);
		$numTopics = $result->num_rows;
		echo "<div id=\"ConceptualConts\">";
		if ($numTopics > 0) {
			$numTopic = 1;
			while($row = $result->fetch_assoc()) {
				$this->showUnit($CourseID, $numTopic, $numTopics, $row, $canModify);
				$numTopic++;
			}  
		}
		echo "</div>";
	}
	
	function saveContents($CourseID) {
		$sql = "SELECT * FROM courses_contents WHERE CourseID=" . $CourseID;
		$result = $this->conn->query($sql);
		if ($result->num_rows> 0) {
			while($row = $result->fetch_assoc()) {
				$topicID = $row["ID"];
				$sql = "UPDATE courses_contents " .  
				  "SET TopicName='" . $_POST["TopicName".$topicID] . "'," .
				  "TopicNumber='" . $_POST["NumTopic".$topicID] . "'," . 
				  "Weeks='" . $_POST["Weeks".$topicID] . "'," . 
				  "Contents='" . $_POST["Contents".$topicID] . "' " .
				  "WHERE ID=" . $topicID;
				$this->conn->query($sql);          
			}  
		} 
	}
	
	function showElectiveCategories($planID) {	
		$sql = "SELECT * FROM courses_electivecats WHERE PlanID=".$planID." ORDER BY CategoryName";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {  
			echo "<tr><th>Categoría</th><th>Créditos</th><th>Semestre</th><th>Forzar semestre</th><th></th></tr>";
			while($row = $result->fetch_assoc()) {	    	
				echo "<tr id=\"row".$row["ID"]."\"><td>".$row["CategoryName"]."</td><td>".$row["Credits"]."</td><td>".$row["Semester"]."</td><td>".$this->MA($row["ForceSemester"])."</td>";
				echo "<td>";
				echo "<button class=\"button btn_edit\" type=\"button\" onclick=\"editCategory(". $row["ID"]. ")\"></button> &nbsp;";
				echo "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeCategory(". $row["ID"]. ",'".$row["CategoryName"]. "',".$planID.")\"></button>";
				echo "</td>";		
				echo "</tr>";				
			}
		}
	}
	
	function showElectives($planID) {	
		$sql = "SELECT courses_elective.ID, courses_electivecats.CategoryName, courses_plan.Nombre ". 
				"FROM courses_electivecats JOIN courses_elective ON courses_electivecats.ID = courses_elective.CategoryID ".
				"JOIN courses_plan ON courses_elective.CourseID = courses_plan.ID ".
				"WHERE courses_electivecats.PlanID = ".$planID." ORDER BY courses_electivecats.CategoryName";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {  
			echo "<tr><th>Categoría</th><th>Curso</th><th></th></tr>";
			while($row = $result->fetch_assoc()) {	    	
				echo "<tr id=\"row".$row["ID"]."\"><td>".$row["CategoryName"]."</td><td>".$row["Nombre"]."</td>";
				echo "<td>";
				echo "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeElective(". $row["ID"]. ",".$planID.")\"></button>";
				echo "</td>";		
				echo "</tr>";				
			}
		}
	}

	function showElectiveCategoryList($planID) {
		$sql = "SELECT ID, CategoryName FROM courses_electivecats WHERE PlanID=".$planID." ORDER BY CategoryName";
		$result_list = $this->conn->query($sql);
		while($row_list = $result_list->fetch_assoc()) {
			echo "<option value=\"" . $row_list["ID"] . "\">" . $row_list["CategoryName"]. "</option>\n";
		}
	}
	
	
	function showUserList( $filter = null )
	{
		if ( empty($filter) ) {
			$sql = "SELECT ID, name FROM users ORDER BY name";
		} else {
			$sql = "SELECT ID, name FROM users WHERE name LIKE '". str_replace(" ", "%", $filter) ."' ORDER BY name";
		}
		$result_list = $this->conn->query($sql);
		while($row_list = $result_list->fetch_assoc()) {
			echo "<option value=\"" . $row_list["ID"] . "\">" . $row_list["name"]. "</option>\n";
		}
	}
	
	function showUser( $row ){
		echo "<tr id=\"row".$row["ID"]."\"><td>".$row["name"]."</td><td>".$row["countryID"]."</td><td>".$row["email"]."</td><td>".$row["role"]."</td>";
		echo "<td>";
		echo "<button class=\"button btn_edit\" type=\"button\" onclick=\"editUser(". $row["ID"]. ")\"></button> &nbsp;";
		echo "<button class=\"button\" type=\"button\" onclick=\"resetPassword(". $row["ID"]. ")\">Reiniciar Contraseña</button> &nbsp;";
		echo "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeUser(". $row["ID"]. ",'".$row["name"]. "')\"></button>";
		echo "</td>";		
		echo "</tr>";	
	}
	
	function showUsers( $filter = null ) {
		if ( empty($filter) ) {
			$sql = "SELECT * FROM users ORDER BY name";
		} else {
			if ( is_numeric($filter) ) {
				$sql = "SELECT * FROM users WHERE countryID=" . $filter;
			} else {
				$sql = "SELECT * FROM users WHERE name LIKE '%" . str_replace(" ", "%", $filter) ."%'";
			}
		}
		echo "<tr><th>Nombre</th><th>Cédula</th><th>email</th><th>Rol</th><th></th></tr>";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {  
			while($row = $result->fetch_assoc()) {	    	
				$this->showUser( $row );
			}
		}
	}
	
	
	function showUserCoordinator( $row ){
		$sql = "SELECT * FROM study_plan WHERE ID=" . $row["planID"];
		$result_study_plan = $this->conn->query($sql);
		$row_study_plan = $result_study_plan->fetch_assoc();
		$sql = "SELECT name FROM users WHERE ID=" . $row["userID"];
		$result_user = $this->conn->query($sql);
		$row_user = $result_user->fetch_assoc();		
		echo "<tr id=\"row".$row["ID"]."\"><td>".$row_study_plan["Code"]."-".$row_study_plan["Description"]."</td><td>".$row_user["name"]."</td>";
		echo "<td><button class=\"button btn_remove\" type=\"button\" onclick=\"removeCoordinator(". $row["ID"]. ",". $row["userID"] .")\"></button></td>";
		echo "</tr>";	
	}
	
	function showUserCoordinators() {	
		$sql = "SELECT * FROM users_coordinators ORDER BY userID";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {  
			while($row = $result->fetch_assoc()) {	    	
				$this->showUserCoordinator( $row );
			}
		}
	}
	
	function MA($value) {
		if ($value==1) 
			return "X";
		else 
			return "";
	}
	
	function showUserAssignment( $row, $user_role ){
		$sql = "SELECT name FROM users WHERE ID=" . $row["userID"];
		$result_user = $this->conn->query($sql);
		$row_user = $result_user->fetch_assoc();
		$sql = "SELECT Code FROM study_plan WHERE ID=" . $row["PlanID"];
		$result_plan = $this->conn->query($sql);
		$row_plan = $result_plan->fetch_assoc();
		$permissions = $row["permissions"];
		$canGeneral = ($permissions & 1) == 1;
		$canDescrip = ($permissions & 2) == 2;
		$canRAPs 	= ($permissions & 4) == 4;
		$canActs 	= ($permissions & 8) == 8;
		$canEval	= ($permissions & 16) == 16;
		$canConts	= ($permissions & 32) == 32;
		$canRubrics	= ($permissions & 64) == 64;
		$canBiblio	= ($permissions & 128) == 128;
		echo "<tr id=\"row".$row["ID"]."\"><td>".$row_plan["Code"]."</td><td>".$row["Nombre"]."</td><td>".$row_user["name"]."</td>";
		if ($user_role==2) {
			echo "<td>".$this->MA($canGeneral)."</td><td>".$this->MA($canDescrip)."</td><td>".$this->MA($canRAPs).
					"</td><td>".$this->MA($canActs)."</td><td>".$this->MA($canEval)."</td><td>".$this->MA($canConts).
					"</td><td>".$this->MA($canRubrics)."</td><td>".$this->MA($canBiblio)."</td>";
		}
		echo "<td><button class=\"button btn_remove\" type=\"button\" onclick=\"removeAssignment(". $row["ID"]. ")\"></button></td>";
		echo "</tr>";	
	}
	
	function showUserAssignments($filterByCoord = 0, $user_role) {	
		$sql = "SELECT courses_general.Nombre, courses_general.PlanID, users_assignments.userID, users_assignments.roleType, users_assignments.permissions, users_assignments.ID ".
			   "FROM courses_general JOIN users_assignments ON courses_general.ID = users_assignments.courseID ";
		if ($filterByCoord != 0) {
			$tsql = "SELECT planID FROM users_coordinators WHERE userID=".$filterByCoord;
			$result = $this->conn->query($tsql);
			$num_plans = $result->num_rows; 
			if ($num_plans > 0)  {
				$sql = $sql . " WHERE courses_general.PlanID IN (";
				while($row = $result->fetch_assoc()) {	    	
					$num_plans--;
					$sql = $sql . $row["planID"];
					if ( $num_plans>0 ) { $sql = $sql . ","; }
					
				}
				$sql = $sql .")";
			}
			$sql = $sql ." AND users_assignments.roleType=".$user_role;
		}
		$sql = $sql." ORDER BY courses_general.Nombre";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {  
			while($row = $result->fetch_assoc()) {	    	
				$this->showUserAssignment( $row, $user_role );
			}
		}
	}
	
	function showUserAssignmentList( $userID, $action, $type ) {	
		$sql = "SELECT * FROM users_assignments WHERE userID=".$userID;
		$result = $this->conn->query($sql);
		echo "<ul>";
		if ($result->num_rows > 0)  {  
			while($row = $result->fetch_assoc()) {	
				$sql = "SELECT Nombre FROM courses_general WHERE ID=" . $row["courseID"];
				$result_course = $this->conn->query($sql);
				$row_course = $result_course->fetch_assoc();	
				if ($row["roleType"]==1) { $roleType = "Docente"; } else { $roleType = "Colaborador"; }
				$bDisplay = ( ($type==1) && ($row["roleType"]!=1) ) ? false : true;
				if ($bDisplay) {
					echo "<li><a href=\"".$action.".php?ID=".$row["courseID"]."\">".$row_course["Nombre"]." - ".$roleType. "</a></li>";
				}
			}
		} else {
			echo "<li>No tiene asignados espacios académicos</li>";
		}
		echo "</ul>";
	}
	
	function showUserEvalReportsSQL( $sql, $showSemester  )
	{
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {  
			while($row = $result->fetch_assoc()) {	
				$sql = "SELECT courses_plan.Nombre,study_plan.Program  
						FROM courses_plan JOIN study_plan ON courses_plan.PlanID = study_plan.ID 
						WHERE courses_plan.ID =". $row["CourseKeyID"];
				$result_course = $this->conn->query($sql);
				$row_course = $result_course->fetch_assoc();	
				echo "<li><a href=\"eval_course.php?ID=".$row["ID"]."&SemesterID=".$row["Semester"]."\">".$row_course["Nombre"]. " (".$row_course["Program"].")";
				if ($showSemester) echo " - ".$row["Semester"];
				echo "</a></li>";
			}
			return true;
		} else {
			return false;
		}
	}
	
	function showUserEvalReports( $userID ) {	
		$sql = "SELECT * FROM eval_courses WHERE UserID=".$userID." AND State=0";
		if ( !$this->showUserEvalReportsSQL( $sql, true ) )  {  
			echo "<li>No tiene pendientes evaluaciones de espacios académicos</li>";
		}
	}
	
	function showUserSubmittedEvalReports( $userID, $SemesterID ) {	
		$sql = "SELECT * FROM eval_courses WHERE UserID=".$userID." AND State=1 AND Semester='". $SemesterID."'";
		if ( !$this->showUserEvalReportsSQL( $sql, false ) ) {
			echo "<li>No tiene reportes de evaluación enviados para el semestre seleccionado.</li>";
		}
	}
	
	function showCollaboratorEvalReportsSQL( $sql, $showSemester ) {	
		$strout = "";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {  
			while($row = $result->fetch_assoc()) {	
				$sql = "SELECT Program FROM study_plan WHERE ID =". $row["PlanID"];
				$result_t = $this->conn->query($sql);
				$row_t = $result_t->fetch_assoc();	
				$program = $row_t["Program"];
				
				$sql = "SELECT ID FROM semesters WHERE SemesterName='". $row["Semester"]."'";
				$result_t = $this->conn->query($sql);
				$row_t = $result_t->fetch_assoc();	
				$SemesterID = $row_t["ID"];
				
				$strout = $strout. "<li><a href=\"eval_viewreports_area.php?PlanID=".$row["PlanID"]."&SemesterID=".$SemesterID."&AreaID=".
					urldecode($row["AreaName"])."\">".$row["AreaName"]. " (".$program.")";
					if ($showSemester) $strout.= " - ".$row["Semester"];
					$strout.="</a></li>";
			}
		} 
		return $strout;
	}
	
	function showCollaboratorEvalReports( $userID ) {	
		$sql = "SELECT * FROM eval_areas WHERE UserID=".$userID." AND State=0";
		$strout = $this->showCollaboratorEvalReportsSQL($sql, true);
		if ( empty($strout)  ) {
			$strout = "<li>No tiene pendientes evaluaciones de áreas o núcleos temáticos</li>";
		} 
		return $strout;
	}
	
	function showCollaboratorSubmittedEvalReports( $userID, $semesterName ) {	
		$sql = "SELECT * FROM eval_areas WHERE UserID=".$userID." AND State=1 AND Semester='".$semesterName."'";
		return $this->showCollaboratorEvalReportsSQL($sql, false);
	}
	
	function showAreasListByFilter( $filterType, $PlanID, $SemesterName ) {
		switch($filterType)
		{
			case 0: //All
				$sql = "SELECT NucleoTematico AS AreaName FROM courses_general WHERE PlanID=".$PlanID." AND VisVersion=1 GROUP BY NucleoTematico"; 
				break;	
			case 1: //Areas with completed evalutation reports 
				$sql = "SELECT AreaName FROM eval_areas WHERE PlanID=".$PlanID." AND Semester='".$SemesterName."' AND State=1 ORDER BY AreaName;"; 
				break;	
			case 2: //Areas with pending evalation reports
				$sql = "SELECT AreaName FROM eval_areas WHERE PlanID=".$PlanID." AND Semester='".$SemesterName."' AND State=0 ORDER BY AreaName;"; 
				break; 
			case 3:	//Areas with no collaborator to make the evaluation report 
				$sql = "SELECT NucleoTematico AS AreaName FROM courses_general WHERE PlanID=".$PlanID." AND VisVersion=1 
						AND NucleoTematico NOT IN (SELECT AreaName FROM eval_areas WHERE PlanID=".$PlanID." AND Semester='".$SemesterName."') GROUP BY NucleoTematico";
				break;
		}
		$result = $this->conn->query($sql);
		if ($result->num_rows>0) {
			while( $row_area = $result->fetch_assoc() ) {
				$area_name = $row_area["AreaName"];
				if ( empty($area_name) ) { $area_name = "(Sin definir)"; }
				echo "<option>".$area_name."</option>\n";			
			}
		}
	}
		
	function showAreasListByPlan( $PlanID ) {
		$this->showAreasListByFilter( 0, $PlanID, '' );
	}
	
	
	
	function showSemesterList( $SemesterName = "" ) {
		$sql = "SELECT * FROM semesters ORDER BY SemesterName DESC";
		$result = $this->conn->query($sql);
		$first = "";
		if ($result->num_rows > 0)  {  
			while($row = $result->fetch_assoc()) {	
				if (strlen($first)==0) { $first = $row["SemesterName"]; }
				if ( $row["SemesterName"] == $SemesterName ) { $selected = "selected"; } else { $selected = ""; }
				echo "<option value=\"" . $row["ID"] . "\" ".$selected.">" .$row["SemesterName"]. "</option>\n";
			}
		}
		if ( $SemesterName == "" )
			return $first;
		else return $SemesterName;
	}
	
	function getDefaultSemester() {
		$sql = "SELECT * FROM semesters ORDER BY SemesterName DESC";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {  
			$row = $result->fetch_assoc();
			return $row["SemesterName"]; 
		}
		return "";
	}
	
	function startEvalOfSemester( $planID, $SemName ) {
		if (!isset($SemName)) return -1;
		$sql = "SELECT users_assignments.*,courses_general.CourseKeyID
				FROM users_assignments JOIN courses_general 
				ON users_assignments.courseID = courses_general.ID 
				WHERE users_assignments.roleType=1 AND courses_general.PlanID=".$planID;
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  { 
			$n = 0;
			while($row = $result->fetch_assoc()) {
				//Verify that evaluation has not started
				$sql = "SELECT CourseID FROM eval_courses WHERE CourseID=".$row["courseID"]." AND Semester='".$SemName."' AND UserID=".$row["userID"];
				$result2 = $this->conn->query($sql);
				if ($result2->num_rows==0) {
					$sql = "INSERT INTO eval_courses (PlanID,CourseID,CourseKeyID,Semester,UserID,State)
							VALUES (".$planID.",".$row["courseID"].",".$row["CourseKeyID"].",'".$SemName."',".$row["userID"].",0)";
					$result2 = $this->conn->query($sql);
					if ($result2 == FALSE) { return -2; }
					$n++;
				}
			}
			if ($n == 0) { return -3; }
			return $n;
		}
		return 0;
	}
	
	function showAreaCollaboratorsForEval( $planID, $SemName ) {
		$sql = "SELECT eval_areas.ID,eval_areas.PlanID,eval_areas.AreaName,eval_areas.Semester,users.Name
				FROM eval_areas INNER JOIN users ON eval_areas.UserID=users.ID 
				WHERE eval_areas.PlanID=".$planID." AND eval_areas.Semester='".$SemName."'";
		echo "<tr><th>Área/Núcleo Temático</th><th>Colaborador</th><th></th></tr>";
		$result = $this->conn->query($sql);	
		if ($result->num_rows > 0)  { 
			while($row = $result->fetch_assoc()) {
				echo "<tr><td>".$row["AreaName"]."</td><td>".$row["Name"]."</td><td>";
				echo "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeAreaCollaborator(". $row["ID"].")\"></button></td></tr>";
			}
		}	
	}
	
	function showEvalReportListByCourse( $planID, $SemName, $state ) {
		$sql = "SELECT courses_general.Nombre,courses_general.PlanID,users.Name,eval_courses.ID 
				FROM eval_courses INNER JOIN courses_general ON eval_courses.CourseID=courses_general.ID 
				INNER JOIN users ON eval_courses.UserID=users.ID 
				WHERE courses_general.PlanID=".$planID." AND eval_courses.Semester='".$SemName."' AND eval_courses.State=".$state;
		$result = $this->conn->query($sql);
		echo "<tr><th>Curso</th><th>Docente Responsable</th><th></th></tr>";
		if ($result->num_rows > 0)  { 
			while($row = $result->fetch_assoc()) {
				echo "<tr id=\"row".$row["ID"]."\"><td>".$row["Nombre"]."</td><td>".$row["Name"]."</td><td>";
				if ($state==0) {
					echo "<button class=\"button btn_remove\" type=\"button\" onclick=\"removePendingReport(". $row["ID"]. ")\"></button>"; 
				} else {
					echo "<button class=\"button btn_view\" type=\"button\" onclick=\"viewReport(". $row["ID"]. ")\"></button>";
					echo "<button class=\"button btn_edit\" type=\"button\" onclick=\"editReport(". $row["ID"]. ")\"></button>"; 					
				}
				echo "</td></tr>";
			}
		}	
	}
	
	function showAllEvalReports( $planID, $SemName, $AreaName ) {
		$sql = "SELECT courses_general.Nombre,courses_general.NucleoTematico,users.Name,eval_courses.* 
				FROM eval_courses LEFT JOIN courses_general ON eval_courses.CourseID=courses_general.ID 
				LEFT JOIN users ON eval_courses.UserID=users.ID 
				WHERE eval_courses.State=1 AND eval_courses.PlanID=".$planID." AND eval_courses.Semester='".$SemName."'";
		if ( $AreaName != null) {
			$sql .= " AND courses_general.NucleoTematico='".$AreaName."'";
		}
		echo "<tr><th>Curso</th><th>Núcleo Temático</th><th>Docente</th><th>Porcentaje reprobados</th>";
		echo "<th>Habilidades previas inexistentes</th><th>Temas sin cubrir</th><th>Temas irrelevantes</th>";
		echo "<th>Problemas de estudiantes</th><th>Experiencias exitosas</th><th>Experiencias no exitosas</th><th>Acciones de mejora</th></tr>";
		$result = $this->conn->query($sql);	
		if ($result->num_rows > 0)  { 
			while($row = $result->fetch_assoc()) {
				echo "<tr><td>".$row["Nombre"]."</td><td>".$row["NucleoTematico"]."</td><td>".$row["Name"]."</td><td>".($row["NFailedStudents"]/$row["NStudents"])."</td>";
				echo "<td>".$row["UnknownPrevSkills"]."</td><td>".$row["UncoveredTopics"]."</td><td>".$row["IrrelevantTopics"]."</td>";
				echo "<td>".$row["StudentProblems"]."</td><td>".$row["SuccessfulExp"]."</td><td>".$row["UnsuccessfulExp"]."</td><td>".$row["ImprovMeasures"]."</td></tr>";
			}
		}	
	}
	
	function showEvalReportByArea( $planID, $SemName, $areaName, $attr ) {
		$sql = "SELECT courses_general.Nombre,courses_general.PlanID,eval_courses.".$attr. 
				" FROM eval_courses INNER JOIN courses_general ON eval_courses.CourseID=courses_general.ID 
				WHERE courses_general.PlanID=".$planID." AND eval_courses.Semester='".$SemName."' AND eval_courses.State=1 AND courses_general.NucleoTematico='".$areaName."'";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  { 
			$bOutput = false;
			$str = "";
			while($row = $result->fetch_assoc()) {
				if (strlen($row[$attr])>0) {
					$str.= "<tr><td>".$row["Nombre"]."</td><td>".$row[$attr]."</td></tr>\n";
					$bOutput=true;
				}
			}
			if ($bOutput) { echo $str; }
		}
	}
	
	function showEvalReportPercentByArea( $planID, $SemName, $areaName ) {
		$sql = "SELECT courses_general.Nombre,courses_general.PlanID,eval_courses.NStudents,eval_courses.NFailedStudents 
				FROM eval_courses INNER JOIN courses_general ON eval_courses.CourseID=courses_general.ID 
				WHERE courses_general.PlanID=".$planID." AND eval_courses.Semester='".$SemName."' AND eval_courses.State=1 AND courses_general.NucleoTematico='".$areaName."'";
		$result = $this->conn->query($sql);
		$nrows = $result->num_rows;
		if ($nrows > 0)  { 
			$array1 = "[";
			$array2 = "[";
			$n = 0;
			while($row = $result->fetch_assoc()) {				
				$array1.= "{ \"y\":".$row["NFailedStudents"].", \"label\":\"".$row["Nombre"]."\" }";
				$array2.= "{ \"y\":".($row["NStudents"]-$row["NFailedStudents"]).", \"label\":\"".$row["Nombre"]."\" }";
				$n++;
				if ($n!=$nrows) { $array1.=","; $array2.=","; }
			}
			$array1.="]";
			$array2.="]";
			return "{\"ds1\":".$array1.",\"ds2\":".$array2."}";
		}
		return null;
	}
	
	function showEvalReportByTopic( $planID, $SemName, $attr ) {
		$sql = "SELECT AreaName,".$attr." FROM eval_areas WHERE PlanID=".$planID." AND Semester='".$SemName."' AND State=1";
		$result = $this->conn->query($sql);
		$str = "<tr><th>Área/Núcleo Temático</th><th>Comentarios</th></tr>";
		if ($result->num_rows > 0)  { 
			$bOutput = false;
			while($row = $result->fetch_assoc()) {
				if (strlen($row[$attr])>0) {
					$str.= "<tr><td>".$row["AreaName"]."</td><td>".$row[$attr]."</td></tr>\n";
					$bOutput=true;
				}
			}
			if ($bOutput) { echo $str; }
			return $bOutput;
		}
		return false;
	}

	function saveEvalReportByCourse($userID, $State)
	{
		//is valid user?
		$EvalID = $_POST["ID"];
		if ($EvalID != -1) {			
			$sql = "SELECT UserID FROM eval_courses WHERE ID = ".$EvalID;
			$result = $this->conn->query($sql);
			if ($result->num_rows > 0)  {  
				$row = $result->fetch_assoc();	
				if ($row["UserID"]!=$userID) {
					$EvalID = -1;
				}
			} else {
				$EvalID = -1;
			}
		}
		//if the user is valid, save the form
		if ($EvalID != -1) {		
			$sql = "UPDATE eval_courses SET";
			foreach ($_POST as $key=>$value) {
				$sql = $sql. " ". $key . "='". $value ."', ";
			}
			$sql = $sql." Date='".date('Y-m-d')."',State=".$State." WHERE ID=". $EvalID;
			$this->conn->query($sql);
		}
	}
	
	function saveEvalReportByArea($PlanID, $AreaID, $semesterName, $UserID, $State)
	{	
		if ($_POST["ReportID"]==0) {				
			$sql = "INSERT INTO eval_areas(PlanID,AreaName,Semester,Date,UserID,State,UnknownPrevSkills,UncoveredTopics,IrrelevantTopics,StudentProblems,SuccessfulExp,UnsuccessfulExp,ImprovMeasures) 
					VALUES (".$PlanID.",'".$AreaID."','".$semesterName."','".date('Y-m-d')."',".$UserID.",".$State.",
					'".$_POST["TT1"]."','".$_POST["TT2"]."','".$_POST["TT3"]."','".$_POST["TT4"]."',
					'".$_POST["TT5"]."','".$_POST["TT6"]."','".$_POST["TT7"]."')";
		} else {
			$sql = "UPDATE eval_areas SET PlanID=".$PlanID.",AreaName='".$AreaID."',Semester='".$semesterName."',Date='".date('Y-m-d')."',State=".$State.",
				UnknownPrevSkills='".$_POST["TT1"]."',UncoveredTopics='".$_POST["TT2"]."',IrrelevantTopics='".$_POST["TT3"]."',StudentProblems='".$_POST["TT4"]."',
				SuccessfulExp='".$_POST["TT5"]."',UnsuccessfulExp='".$_POST["TT6"]."',ImprovMeasures='".$_POST["TT7"]."' WHERE ID=".$_POST["ReportID"];
		}
		$this->conn->query($sql);
	}
	
	
	
	
	function showRAPCustomizableList()
	{
		$sql = "SELECT * FROM ilo_sets";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {  
			echo "<option value=0>Seleccione uno...</option>\n";
			while($row = $result->fetch_assoc()) {	
				echo "<option value=".$row["ID"].">".$row["SetName"]."</option>\n";
			}
		}
	}
	
	
	function showRAPCustomizableSets()
	{
		$sql = "SELECT * FROM ilo_sets";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {  
			echo "<tr><th>Nombre del Conjunto</th><th>Descripción</th><th></th></tr>";
			while($row = $result->fetch_assoc()) {	
				echo "<tr id=\"row".$row["ID"]."\"><td>".$row["SetName"]."</td><td>".$row["Description"]."</td><td>";
				echo "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeRAPSet(".$row["ID"].")\"></button>"; 
				echo "<button class=\"button btn_edit\" type=\"button\" onclick=\"editRAPSet(".$row["ID"].")\"></button>"; 
				echo "</td></tr>";	
			}
		}
	}
	
	function showRAPCustomizableSetEntries($setID)
	{
		$sql = "SELECT * FROM ilo_categories WHERE SetID=".$setID." ORDER BY Position";
		$result = $this->conn->query($sql);
		$strout = "<table>";
		if ($result->num_rows > 0)  { 
			while($row = $result->fetch_assoc()) {	
				$strout = $strout. "<tr id=\"cat".$row["ID"]."\">";
				$strout = $strout. "<td><input id=\"pos".$row["ID"]."\" name=\"pos".$row["ID"]."\" size=\"1\" style=\"width: 1.5em;\" readonly></td><td>";
				$strout = $strout. "<textarea name=\"txt".$row["ID"]."\" rows=1 cols=50 style=\"width: 100%;\" onchange=\"setModifiedFlag()\">".$row["Value"]."</textarea>";
				$strout = $strout. "</td><td>";
				$strout = $strout. "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeItem(".$row["ID"].")\"></button>";
				$strout = $strout. "<button class=\"button btn_up\" type=\"button\" onclick=\"moveItem(".$row["ID"].",-1)\"></button>";
				$strout = $strout. "<button class=\"button btn_down\" type=\"button\" onclick=\"moveItem(".$row["ID"].",1)\"></button>"; 
				$strout = $strout. "</td></tr>";
			}
		}
		$strout = $strout."</table>";
		return $strout;
	}
	
	
	function showRAPProgram($PlanID)
	{
		$sql = "SELECT * FROM ilo_program WHERE PlanID=".$PlanID." ORDER BY Position";
		$result = $this->conn->query($sql);
		$strout = "<table>";
		if ($result->num_rows > 0)  { 
			while($row = $result->fetch_assoc()) {	
				$strout = $strout. "<tr id=\"ilo".$row["ID"]."\">";
				$strout = $strout. "<td><input id=\"pos".$row["ID"]."\" name=\"pos".$row["ID"]."\" size=1 style=\"width: 1.5em;\" readonly></td><td>";
				$strout = $strout. "<textarea name=\"txt".$row["ID"]."\" rows=1 cols=100 style=\"width: 100%;\" onchange=\"setModifiedFlag()\">".$row["Value"]."</textarea>";
				$strout = $strout. "</td><td>";
				$strout = $strout. "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeItem(".$row["ID"].")\"></button>";
				$strout = $strout. "<button class=\"button btn_up\" type=\"button\" onclick=\"moveItem(".$row["ID"].",-1)\"></button>";
				$strout = $strout. "<button class=\"button btn_down\" type=\"button\" onclick=\"moveItem(".$row["ID"].",1)\"></button>"; 
				$strout = $strout. "</td></tr>";
			}
		}
		$strout = $strout."</table>";
		return $strout;
	}
	
	function showRAPCategoryForCourse($CourseID)
	{
		//Get the SetID for the given CourseID
		$sql = "SELECT ILOSetID FROM study_plan 
				INNER JOIN courses_general ON study_plan.ID = courses_general.PlanID 
				WHERE courses_general.ID = ".$CourseID;
		$result = $this->conn->query($sql);
		$rtrn_ar["exist"] = false;
		$rtrn_ar["str"] = "";
		if ($result->num_rows > 0)  { 
			$strout = "<option value=0>[Escoja categoría...]</option>\n";
			$row_set = $result->fetch_assoc();
			$sql = "SELECT * FROM ilo_categories WHERE SetID=".$row_set["ILOSetID"]." ORDER BY Position";
			$result = $this->conn->query($sql);
			if ($result->num_rows > 0)  { 
				$rtrn_ar["exist"] = true;
				while($row = $result->fetch_assoc()) {	
					$strout = $strout. "<option value=".$row["ID"].">".$row["Value"]."</option>\n";
				}
			}
			$rtrn_ar["str"] = $strout;
		}
		return $rtrn_ar;
	}
	
	function showRAPProgramForCourse($CourseID)
	{
		//Get the PlanID for the given CourseID
		$sql = "SELECT PlanID FROM courses_general WHERE ID=".$CourseID;
		$result = $this->conn->query($sql);
		$rtrn_ar["exist"] = false;
		$rtrn_ar["str"] = "";
		if ($result->num_rows > 0)  { 
			$strout = "<option value=0>[Escoja RAP de programa asociado...]</option>\n";
			$row_set = $result->fetch_assoc();
			$sql = "SELECT * FROM ilo_program WHERE PlanID=".$row_set["PlanID"]." ORDER BY Position";
			$result = $this->conn->query($sql);
			if ($result->num_rows > 0)  {
				$rtrn_ar["exist"] = true;
				while($row = $result->fetch_assoc()) {	
					$strout = $strout. "<option value=".$row["ID"].">(".$row["Position"].") ".$row["Value"]."</option>\n";
				}
			}
			$rtrn_ar["str"] = $strout;
		}
		return $rtrn_ar;
	}
	
	function parseRubricCell($str) {
		return str_replace("\n", "<br>", $str);	
	}
	function showRubric($RubricID, $bReadOnly) {
		if ($RubricID==-1) return;
		$sql = "SELECT * FROM rubrics_general WHERE ID=".$RubricID;
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  { //If rubric exists...
			$row_specs = $result->fetch_assoc();
			$RubricType = $row_specs["Type"];
			$NumLevels = $row_specs["NumLevels"];
			
			$sql = "SELECT * FROM rubrics_entries WHERE RubricID=".$RubricID." ORDER BY Position";
			$result = $this->conn->query($sql);
			echo "<table class=\"rubrics\">\n";
			if ($result->num_rows > 0)  {
				$pos = $result->num_rows;
				while($row = $result->fetch_assoc()) {	
					echo "<tr id=\"row".$row["ID"]."\">";
					//display table header
					if ($pos == $result->num_rows) {
						switch ($RubricType) {
							case 1:
								echo "<th style=\"vertical-align: bottom;\" rowspan=2>Criterio</th>
									  <th colspan=".$NumLevels.">Niveles de desempeño</th>";
								if (!$bReadOnly) { echo "<th></th>"; }
								echo "</tr><tr>";
								for($i=$NumLevels;$i>=1;$i--) {
									if ($bReadOnly) {	
										echo "<th>".$i."<br>".$row["DescLevel".$i]."</th>";
									} else {
										echo "<th>".$i."<br>
												<input type=\"text\" name=\"cell".$row["ID"].$i."\" size=15 value=\"".
												$row["DescLevel".$i]."\"></th>";
									}
								}
								if (!$bReadOnly) {
									echo "<th><input id=\"pos".$row["ID"]."\" name=\"pos".$row["ID"]."\" size=1 readonly style=\"display:none\" value=0></th>";
								}
								break;
							case 2:
								echo "<th>Nivel</th><th>Descripción</th>";
								if (!$bReadOnly) { echo "<th></th>"; }
								break;
							case 3:
								for($i=1;$i<=$NumLevels;$i++) {
									echo "<th>".$i."<br>";
									if ($bReadOnly) {
										echo $row["DescLevel".$i];
									} else { 
										echo "<input type=\"text\" name=\"cell".$row["ID"].$i."\" size=15 value=\"".$row["DescLevel".$i]."\">";
									}
									echo "</th>";
								}
								if (!$bReadOnly) {
									echo "<th><input name=\"pos".$row["ID"]."\" size=1 readonly style=\"display:none\" value=0></th>";
								}
								break;
						}
					} else {  //display regular row
						switch ($RubricType) {
							case 1:
								if ($bReadOnly) {
									echo "<th>".$this->parseRubricCell($row["Criteria"])."</th>";
									for($i=$NumLevels;$i>=1;$i--) {
										echo "<td>".$this->parseRubricCell($row["DescLevel".$i])."</td>";
									}
								} else {
									echo "<th>
											<textarea name=\"Criteria".$row["ID"]."\" rows=2>".
											$row["Criteria"]."</textarea></th>";
									for($i=$NumLevels;$i>=1;$i--) {
										echo "<td>
											<textarea name=\"cell".$row["ID"].$i."\" rows=2>".
											$row["DescLevel".$i]."</textarea></td>";
									}
								}
								break;
							case 2:
								if ($bReadOnly) {
									echo "<th>".$pos."</th><td>".$this->parseRubricCell($row["DescLevel1"])."</td>";
								} else {
									echo "<th><label>".$pos."</label></th><td>
											<textarea name=\"cell".$row["ID"]."1\" rows=3 cols=60>".
											$row["DescLevel1"]."</textarea></td>";
								}
								break;
							case 3:
								for($i=1;$i<=$NumLevels;$i++) {
									if ($i >= ($NumLevels-$pos+1)) {										
										if ($bReadOnly || ($i<$NumLevels)) {
											echo "<td><label>".$this->parseRubricCell($row["DescLevel1"])."</label></td>";
										} else {
											echo "<td>
													<textarea name=\"cell".$row["ID"]."1\" rows=3 onblur=\"holisticCellUpdate()\">".
													$row["DescLevel1"]."</textarea></td>";
										}
									}
									else {
										echo "<td><label></label></td>"; 
									}
								}
								break;
						}
						if (!$bReadOnly) {
							$strbtns = "<input id=\"pos".$row["ID"]."\" name=\"pos".$row["ID"]."\" size=1 readonly style=\"display:none\">";
							$strbtns = $strbtns. "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeItem(".$row["ID"].")\"></button>";
							$strbtns = $strbtns. "<button class=\"button btn_up\" type=\"button\" onclick=\"moveItem(".$row["ID"].",-1)\"></button>";
							$strbtns = $strbtns. "<button class=\"button btn_down\" type=\"button\" onclick=\"moveItem(".$row["ID"].",1)\"></button>"; 
							echo "<td>".$strbtns."</td>";
						}
					}
					echo "</tr>\n";
					$pos--;
				}
			}
			echo "</table>";
			if (!$bReadOnly) {
				echo "<button class=\"button btn_fancy\" onclick=\"addEntry(". $RubricID. ")\" type=\"button\">Añadir nueva fila <img src=\"images/btn_add1.png\"></button>";
			}
		} 
	}
	
	
	function cloneRubric($RubricID, $bChangeScope) {
		$sql = "SELECT * FROM rubrics_general WHERE ID=".$RubricID;
		$result = $this->conn->query($sql);
		if ($result->num_rows == 0) {
			return 0;
		}
		$row = $result->fetch_assoc();
		$name = $row["Name"];
		$scope = $row["Scope"];
		
		//Change scope is available when forcing to duplicate a generic or course rubric.
		if ($bChangeScope) {
			if ($scope == 0) {
				//If a general rubric is duplicated for a course, the Scope is changed to 1 (course rubric).
				if (isset($_GET["CourseID"]) && !isset($_GET["ActID"])) $scope = 1;
				//If a general rubric is duplicated for an activity, the Scope is changed to 2 (activity rubric)
				if (isset($_GET["CourseID"]) &&  isset($_GET["ActID"])) $scope = 2;
			}
			if ($scope == 1) {
				//If a course rubric is duplicated for an activity, the Scope is changed to 2 (activity rubric)
				if (isset($_GET["ActID"])) $scope = 2;
			}
			$name = "Copia de ".$name;
		} 
		
		//Duplicate rubric specification
		$sql = "INSERT INTO rubrics_general(Name, Description, Type, NumLevels, Scope) VALUES ('".
			$name."','".$row["Description"]."',".$row["Type"].",".$row["NumLevels"].",".$scope.")";
		$result = $this->conn->query($sql);

		if ($result) {
			$NewRubricID = $this->conn->insert_id;
			//Duplicate rubric entries
			$sql = "SELECT * FROM rubrics_entries WHERE RubricID=".$RubricID." ORDER BY Position";
			$result = $this->conn->query($sql);
			if ($result->num_rows > 0)  {
				while(($row = $result->fetch_assoc())) {	
					$sql = "INSERT INTO rubrics_entries(RubricID, Criteria, DescLevel1, DescLevel2, DescLevel3, DescLevel4, Position) VALUES (".$NewRubricID.",'".
						$row["Criteria"]."','".$row["DescLevel1"]."','".$row["DescLevel2"]."','".$row["DescLevel3"]."','".$row["DescLevel4"]."',".$row["Position"].")";
					$res = $this->conn->query($sql);
				}
			}
			return $NewRubricID;
		}	
		return 0;
	}
	
	
	function showRubricAssociations($RubricID, $CourseID, $canModify) {
		$displayType = -1;
		$sql = "SELECT * FROM rubrics_assoc WHERE RubricID=".$RubricID." AND CourseID=".$CourseID." AND RapSkillType!=4 ORDER BY RapSkillType";
		$result_list = $this->conn->query($sql);
		if ($result_list->num_rows > 0)  { //Fetch ILOs and Skills associated to the given Rubric...
			while($row_list = $result_list->fetch_assoc()) {
				if ($row_list["RapSkillID"]==0) continue;
				$Type = $row_list["RapSkillType"];
				if ($displayType != $Type) {
					if ($displayType != -1) {
						echo "</ul>";
					}
					$displayType = $Type;
					switch ($Type) {
						case 0:
							echo "<b><u>RAPs asociados</u>:</b><ul>";
							break;
						case 1:
							echo "<b><u>Habilidades personales asociadas</u>:</b><ul>";
							break;
						case 2:
							echo "<b><u>Habilidades interpersonales asociadas</u>:</b><ul>";
							break;
						case 3:
							echo "<b><u>Habilidades CDIO asociadas</u>:</b><ul>";
							break; 
					}
				}
				switch ($Type) {
					case 0:
						$sqltable = "SELECT Text FROM courses_ilos WHERE ID=".$row_list["RapSkillID"];
						break;
					case 1:
						$sqltable = "SELECT cdiosyllabus_personal_skills.* FROM cdiosyllabus_personal_skills JOIN courses_personal_skills
							ON cdiosyllabus_personal_skills.ID = courses_personal_skills.SkillID WHERE courses_personal_skills.ID=".$row_list["RapSkillID"];
						break;
					case 2:
						$sqltable = "SELECT cdiosyllabus_interpersonal_skills.* FROM cdiosyllabus_interpersonal_skills JOIN courses_interpersonal_skills
							ON cdiosyllabus_interpersonal_skills.ID = courses_interpersonal_skills.SkillID WHERE courses_interpersonal_skills.ID=".$row_list["RapSkillID"];
						break;
					case 3:
						$sqltable = "SELECT cdiosyllabus_cdio_skills.* FROM cdiosyllabus_cdio_skills JOIN courses_cdio_skills
							ON cdiosyllabus_cdio_skills.ID = courses_cdio_skills.SkillID WHERE courses_cdio_skills.ID=".$row_list["RapSkillID"];
						break; 
				}
				if ($canModify) {
					$strbtns = "&nbsp; <button class=\"button btn_remove\" type=\"button\" onclick=\"removeAssoc(".$row_list["ID"].",".$RubricID.",".$CourseID.")\"></button>";		
				} else {
					$strbtns = "";
				}
				$result = $this->conn->query($sqltable);
				$row = $result->fetch_assoc();
				if ($Type == 0) {
					echo "<li id=\"as".$row_list["ID"]."\">".$row["Text"].$strbtns."</li>";
				} else {
					echo "<li id=\"as".$row_list["ID"]."\">(".$row["ref_syllabus"].")".$row["description"].$strbtns."</li>";
				}
			}
			echo "</ul>";
		}
	}
	
	function getSkillsDatabase( $Type, $CourseID, $SemesterID=0, $UserID=0 )
	{
		//Configure SQL query to fetch the list of RAP or Skills according to the category
		switch( $Type ) {
			case 0:
				$sCategoryName = "RAPs";
				$sqltable = "SELECT ID,Text FROM courses_ilos WHERE CourseID=".$CourseID." ORDER BY Position";
				break;
			case 1:
				$sCategoryName = "Habilidades Personales";
				$sqltable = "SELECT courses_personal_skills.ID, cdiosyllabus_personal_skills.ref_syllabus, cdiosyllabus_personal_skills.description 
					FROM courses_personal_skills 
					JOIN cdiosyllabus_personal_skills 
					ON courses_personal_skills.SkillID = cdiosyllabus_personal_skills.ID 
					WHERE courses_personal_skills.CourseID=".$CourseID." ORDER BY cdiosyllabus_personal_skills.ID";
				break;
			case 2:
				$sCategoryName = "Habilidades Interpersonales";
				$sqltable = "SELECT courses_interpersonal_skills.ID, cdiosyllabus_interpersonal_skills.ref_syllabus, cdiosyllabus_interpersonal_skills.description 
					FROM courses_interpersonal_skills 
					JOIN cdiosyllabus_interpersonal_skills 
					ON courses_interpersonal_skills.SkillID = cdiosyllabus_interpersonal_skills.ID 
					WHERE courses_interpersonal_skills.CourseID=".$CourseID." ORDER BY cdiosyllabus_interpersonal_skills.ID";
				break;
			case 3:
				$sCategoryName = "Habilidades CDIO";
				$sqltable = "SELECT courses_cdio_skills.ID, cdiosyllabus_cdio_skills.ref_syllabus, cdiosyllabus_cdio_skills.description 
					FROM courses_cdio_skills 
					JOIN cdiosyllabus_cdio_skills 
					ON courses_cdio_skills.SkillID = cdiosyllabus_cdio_skills.ID 
					WHERE courses_cdio_skills.CourseID=".$CourseID." ORDER BY cdiosyllabus_cdio_skills.ID";
				break; 
			case 4:
				$sCategoryName = "Actividades";
				$sqltable = "SELECT ID,Name,Position FROM teacher_activities WHERE CourseID=".$CourseID." AND UserID=".$UserID." AND Semester='".$SemesterID."' ORDER BY Position";
				break;
		}
		$ret["CatName"] = $sCategoryName;
		$ret["SQL"] = $sqltable;
		return $ret;
	}
	
	function showAvailableRubricAssocItem( $RubricID, $Type, $CourseID, $SemesterID=0, $UserID=0 )
	{
		//Configure SQL query to fetch the list of RAP or Skills according to the category
		$ret = $this->getSkillsDatabase( $Type, $CourseID, $SemesterID, $UserID );
		$sCategoryName = $ret["CatName"];
		$sqltable = $ret["SQL"];
		$result = $this->conn->query($sqltable);
		if ($result->num_rows>0) {
			echo "<p><b><u>".$sCategoryName."</u></b><p>";
			while( $row = $result->fetch_assoc() ) {
				//Check if RAP/Skill is already selected, in this case, the item is displayed as readonly 
				$sqlcheck = "SELECT ID FROM rubrics_assoc WHERE RubricID=".$RubricID." AND RapSkillID=".$row["ID"]." AND RapSkillType=".$Type;
				$result_chk = $this->conn->query($sqlcheck);
				if ($result_chk->num_rows>0) {
					$sreadonly = "checked";
					$sfont = "<font color=\"blue\">";
					$snfont = "</font>";
				} else {
					$sreadonly = "";
					$sfont = "";
					$snfont = "";
				}
				echo "<input type=\"checkbox\" id=\"chk".$Type.$row["ID"]."\" value=1 ".$sreadonly.">";
				if ($Type==0) {
					$strtxt = $row["Text"];
				} else if ($Type==4) {
					$strtxt = $row["Position"].". ".$row["Name"];
				} else {
					$strtxt = "(".$row["ref_syllabus"].")".$row["description"];
				}
				echo $sfont.$strtxt.$snfont."<br>";
			}
			echo "</p></p>";
		}
	}
	
	function showAvailableRubricAssociations($RubricID, $CourseID) {
		$this->showAvailableRubricAssocItem( $RubricID, 0, $CourseID );
		$this->showAvailableRubricAssocItem( $RubricID, 1, $CourseID );
		$this->showAvailableRubricAssocItem( $RubricID, 2, $CourseID );
		$this->showAvailableRubricAssocItem( $RubricID, 3, $CourseID );
	}

	function showNotAssociatedSkillItem( $Type, $CourseID )
	{
		//Configure SQL query to fetch the list of RAP or Skills according to the category
		$ret = $this->getSkillsDatabase( $Type, $CourseID );
		$sCategoryName = $ret["CatName"];
		$sqltable = $ret["SQL"];
		$result = $this->conn->query($sqltable);
		if ($result->num_rows>0) {
			echo "<p><b><u>".$sCategoryName."</u></b><ul>";
			while( $row = $result->fetch_assoc() ) {
				//Check if RAP/Skill is already selected, in this case, the item is omitted
				$sqlcheck = "SELECT ID FROM rubrics_assoc WHERE RapSkillID=".$row["ID"]." AND RapSkillType=".$Type;
				$result_chk = $this->conn->query($sqlcheck);
				if ($result_chk->num_rows==0) {	
					if ($Type==0) {
						$strtxt = $row["Text"];
					} else {
						$strtxt = "(".$row["ref_syllabus"].")".$row["description"];
					}
					echo "<li>".$strtxt."</li>";
				}
			}
			echo "</ul></p>";
		}
	}

	function showNotAssociatedSkillToAnyRubric($CourseID) {
		$this->showNotAssociatedSkillItem( 0, $CourseID );
		$this->showNotAssociatedSkillItem( 1, $CourseID );
		$this->showNotAssociatedSkillItem( 2, $CourseID );
		$this->showNotAssociatedSkillItem( 3, $CourseID );
	}
	
	function showGenericRubricListForCourse( $PlanID, $CourseID ) {
		//Display the list of available generic rubrics for the given PlanID.
		//Generic rubrics already appended to the course are omitted from the list. 
		$sql = "SELECT rubrics_general.* FROM rubrics_general JOIN rubrics_assoc ON rubrics_general.ID=rubrics_assoc.RubricID
					WHERE rubrics_assoc.PlanID=".$PlanID." AND rubrics_assoc.CourseID=0
					AND rubrics_assoc.RubricID NOT IN (SELECT RubricID FROM rubrics_assoc WHERE CourseID=".$CourseID." AND RapSkillType!=4)";
		
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {
			echo "<table>";
			echo "<tr><th align=\"center\">Nombre de la rúbrica</th><th align=\"center\">Descripción</th><th></th><th></th></tr>";
			while($row = $result->fetch_assoc()) {	
				echo "<tr><td>".$row["Name"]."</td><td>".$row["Description"]."</td>
					<td><button class=\"button btn_view\" type=\"button\" onclick=\"viewRubric(". $row["ID"].")\"></button></td>
					<td><button onclick=\"assocGenericRubric(".$row["ID"].",".$PlanID.",".$CourseID.")\">Asociar</button></td>
					</tr>";
			}
			echo "</table>";
		} else {
			echo "No existen rúbricas genéricas asociadas al plan de estudios.";
		}
	}
	
	function showRubricsByPlanItem( $RubricID, $PlanID )
	{
		$sql = "SELECT * FROM rubrics_general WHERE ID=".$RubricID;
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  { //If rubric specification is available...
			$row_specs = $result->fetch_assoc();					
			echo "<div class=\"planeaForm\" id=\"rub".$RubricID."\">";
			echo "<h3>".$row_specs["Name"]."</h3>";
			echo "<b>Descripción:</b> ".$row_specs["Description"]."<br><br>";
			$this->showRubric($RubricID,true); 
			echo "<br>";
			echo "<button onclick=\"window.open('rubrics_edit.php?RubricID=".$RubricID."&PlanID=".$PlanID."&backurl=rubrics.php?PlanID=".$PlanID."','_self')\">Editar</button> &nbsp;";
			echo "<button onclick=\"removeRubric(".$RubricID.")\">Eliminar</button> &nbsp;";
			echo "<button onclick=\"duplicateRubric(".$RubricID.",".$PlanID.")\">Duplicar</button> &nbsp;";
			echo "<button onclick=\"viewRubricUsage(".$RubricID.")\">Visualizar uso</button> &nbsp;";
			echo "</div>";
		}
	}
	
	function showRubricsByPlan( $PlanID ) {
		$sql = "SELECT RubricID FROM rubrics_assoc WHERE PlanID=".$PlanID." AND CourseID=0";
		$result_list = $this->conn->query($sql);
		if ($result_list->num_rows > 0)  { //If rubrics exists for the given planID...
			while($row_list = $result_list->fetch_assoc()) {
				$this->showRubricsByPlanItem( $row_list["RubricID"], $PlanID );
			}
		}
	}
		
	function showRubricsByCourseItem( $RubricID, $PlanID, $CourseID, $canModify=true ) 
	{
		$sql = "SELECT * FROM rubrics_general WHERE ID=".$RubricID;
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  { //If rubric specification is available...
			$row_specs = $result->fetch_assoc();					
			echo "<div class=\"".(($row_specs["Scope"]==0)?"genericRubricForm":"planeaForm")."\" id=\"rub".$row_specs["ID"]."\">";
			echo "<h3>".$row_specs["Name"]."</h3>";
			if ($row_specs["Scope"]==0) {
				echo "<p style=\"font-size:small\"><font color=\"green\">* Rúbrica genérica del plan de estudios.</font></p>";
			}
			echo "<b><u>Descripción:</u></b> ".$row_specs["Description"]."<br><br>";
			$this->showRubricAssociations($RubricID, $CourseID, $canModify);
			$this->showRubric($RubricID,true); 
			if ($canModify) {
				echo "<br>"; 
				echo "<button onclick=\"editRubric(".$RubricID.",".$row_specs["Scope"].",".$PlanID.",".$CourseID.")\">Editar</button> &nbsp;";
				echo "<button onclick=\"removeRubric(".$RubricID.",".$row_specs["Scope"].",".$PlanID.",".$CourseID.")\">Eliminar</button> &nbsp;";
				echo "<button onclick=\"duplicateRubric(".$RubricID.",".$PlanID.",".$CourseID.")\">Duplicar</button> &nbsp;";
				echo "<button onclick=\"associateRubric(".$RubricID.",".$PlanID.",".$CourseID.")\">Asociar RAPs o Habilidades</button> &nbsp;";
			}
			echo "</div>";
		}
	}
		
	function showRubricsByCourse( $CourseID, $canModify ) {
		$sql = "SELECT RubricID,PlanID FROM rubrics_assoc WHERE CourseID=".$CourseID." AND RapSkillType!=4 GROUP BY RubricID";
		$result_list = $this->conn->query($sql);
		if ($result_list->num_rows > 0)  { //If rubrics exists for the given courseID...
			while($row_list = $result_list->fetch_assoc()) {
				$this->showRubricsByCourseItem( $row_list["RubricID"], $row_list["PlanID"], $CourseID, $canModify );
			}
		}
	}
	
	function showRubricsByUserCourseItem($RubricID, $PlanID, $CourseID, $SemesterID, $UserID, $canModify=true) 
	{	
		$sql = "SELECT ID FROM teacher_activities WHERE CourseID=".$CourseID." AND UserID=".$UserID." AND Semester='".$SemesterID.
				"' AND ID IN (SELECT RapSkillID FROM rubrics_assoc WHERE RubricID=".$RubricID." AND CourseID=".$CourseID." AND RapSkillType=4)";
		$result_act = $this->conn->query($sql);
		$row_act = $result_act->fetch_assoc();
		$ActivityID = $row_act["ID"];

		$sql = "SELECT * FROM rubrics_general WHERE ID=".$RubricID;
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  { //If rubric specification is available...
			$row_specs = $result->fetch_assoc();
			$scope = $row_specs["Scope"]; 
			switch($scope) {
				case 0: $rclass = "genericRubricForm"; break;
				case 1: $rclass = "courseRubricForm"; break;
				case 2: $rclass = "planeaForm"; break;
			}
			echo "<div class=\"".$rclass."\" id=\"rub".$row_specs["ID"]."\">";
			echo "<h3>".$row_specs["Name"]."</h3>";
			if ($scope==0) {
				echo "<p style=\"font-size:small\"><font color=\"green\">* Rúbrica genérica del plan de estudios.</font></p>";
			}
			if ($scope==1) {
				echo "<p style=\"font-size:small\"><font color=\"blue\">* Rúbrica del sílabo.</font></p>";
			}
			echo "<b><u>Descripción:</u></b> ".$row_specs["Description"]."<br><br>";
			$this->showRubric($RubricID,true); 
			echo "<br>"; 
			if ($canModify) {
				echo "<button onclick=\"editRubric(".$RubricID.",".$scope.",".$PlanID.",".$CourseID.",".$UserID.",'".$SemesterID."',".$ActivityID.")\">Editar</button> &nbsp;";
				echo "<button onclick=\"removeRubric(".$RubricID.",".$scope.",".$PlanID.",".$CourseID.",".$UserID.",'".$SemesterID."')\">Eliminar</button> &nbsp;";
				echo "<button onclick=\"duplicateRubric(".$RubricID.",".$PlanID.",".$CourseID.",".$UserID.",'".$SemesterID."',".$ActivityID.")\">Duplicar</button> &nbsp;";
				echo "<button onclick=\"associateRubric(".$RubricID.",".$PlanID.",".$CourseID.",".$UserID.",'".$SemesterID."')\">Asociar Actividades</button> &nbsp;";
			}
			echo "</div>";
		}
	}
	
	function showRubricsByUserCourse( $CourseID, $SemesterID, $UserID, $canModify=true ) 
	{	
		$sql = "SELECT RubricID,PlanID FROM rubrics_assoc WHERE RapSkillType=4 AND RapSkillID IN 
					(SELECT ID FROM teacher_activities WHERE CourseID=".$CourseID." AND UserID=".
					$UserID." AND Semester='".$SemesterID."') GROUP BY RubricID";
		$result_list = $this->conn->query($sql);
		if ($result_list->num_rows > 0)  { //If rubrics exists for the given courseID...
			while($row_list = $result_list->fetch_assoc()) {
				$this->showRubricsByUserCourseItem($row_list["RubricID"], $row_list["PlanID"], $CourseID, $SemesterID, $UserID, $canModify) ;
			}
		}
	}
	
	function purgeNotUsedRubrics() {
		//Fetch RubricIDs from non-used rubrics, i.e. rubrics with no association.
		$sql = "SELECT ID FROM rubrics_general WHERE ID NOT IN (SELECT RubricID FROM rubrics_assoc GROUP BY RubricID)";
		$result_list = $this->conn->query($sql);
		if ($result_list->num_rows > 0)  { 
			while($row_list = $result_list->fetch_assoc()) {
				$sql = "DELETE FROM rubrics_entries WHERE RubricID=".$row_list["ID"];
				$this->conn->query($sql);
				$sql = "DELETE FROM rubrics_general WHERE ID=".$row_list["ID"];
				$this->conn->query($sql);
			}
		}
	}
	
	
	function showPlanningCoursesList($PlanID,$SemesterID) {
		//Display the list of available courses with planning for the given semester and PlanID.
		$sql = "SELECT teacher_activities.CourseID, teacher_activities.UserID, courses_general.Nombre, users.name 
				FROM teacher_activities 
				LEFT JOIN courses_general ON teacher_activities.CourseID=courses_general.ID
				LEFT JOIN users ON teacher_activities.UserID=users.ID
				WHERE teacher_activities.PlanID=".$PlanID." AND teacher_activities.Semester='".$SemesterID."' 
				GROUP BY teacher_activities.CourseID,teacher_activities.UserID";
		
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {
			echo "<table>";
			echo "<tr><th align=\"center\">Curso</th><th align=\"center\">Docente</th><th></th></tr>";
			while($row = $result->fetch_assoc()) {	
				echo "<tr><td>".$row["Nombre"]."</td><td>".$row["name"]."</td>
					<td><button class=\"button btn_view\" type=\"button\" onclick=\"viewPlanning(". $row["CourseID"]. 
					",". $row["UserID"]. ",'". $SemesterID. "')\"></button></td></tr>";
			}
			echo "</table>";
		} else {
			echo "No existe planeación de cursos para el semestre y plan de estudios.";
		}
	}
	
	function showPlanningCourseName( $CourseID, $UserID ) 
	{
		//Show course name and teacher
		$sql = "SELECT Nombre FROM courses_general WHERE ID=".$CourseID;
		$result = $this->conn->query($sql);
		$row = $result->fetch_assoc();
		echo "<b><u>Curso</u></b>: ".$row["Nombre"]."<br>";
		
		$sql = "SELECT name FROM users WHERE ID=".$UserID;
		$result = $this->conn->query($sql);
		$row = $result->fetch_assoc();
		echo "<b><u>Docente</u></b>: ".$row["name"]."<br>";
	}
	
	function showAssocRAPSkillsToPlanningCourse( $Type, $CourseID, $SemesterID, $UserID, $ActID=0 )
	{
		$retStr = "";
		$allAssoc = true;
		//Configure SQL query to fetch the list of RAP or Skills according to the category
		$ret = $this->getSkillsDatabase( $Type, $CourseID );
		$sCategoryName = $ret["CatName"];
		$sqltable = $ret["SQL"];
		$result = $this->conn->query($sqltable);
		if ($result->num_rows>0) {
			$retStr = "<p><b><u>".$sCategoryName."</u></b><p>";
			if ($ActID==0) {			
				if ($Type==0) { 
					$retStr = $retStr."<ol>"; 
				} else {
					$retStr = $retStr."<ul>";
				}
			}
			while( $row = $result->fetch_assoc() ) {				
				if ($ActID==0) {
					$sqlcheck = "SELECT * FROM teacher_actassoc WHERE RapSkillID=".$row["ID"]." AND RapSkillType=".$Type.
								" AND ActID IN (SELECT ID FROM teacher_activities WHERE CourseID=".$CourseID.
								" AND UserID=".$UserID." AND Semester='".$SemesterID."')";
				} else {
					$sqlcheck = "SELECT * FROM teacher_actassoc WHERE RapSkillID=".$row["ID"]." AND RapSkillType=".$Type." AND ActID=".$ActID;
				}
				$result_chk = $this->conn->query($sqlcheck);
				if ($result_chk->num_rows>0) {
					$sfont = "";
					$snfont = "";
					$checked = " checked";
				} else {
					$sfont = "<font color=\"red\">";
					$snfont = "</font>";
					$allAssoc = false;
					$checked = "";
				}
				if ($Type==0) {
					$strtxt = $row["Text"];
				} else {
					$strtxt = "(".$row["ref_syllabus"].")".$row["description"];
				}
				if ($ActID==0) {
					$retStr = $retStr."<li>".$sfont.$strtxt.$snfont."</li>";
				} else {
					$retStr = $retStr."<input type=\"checkbox\" name=\"chk".$row["ID"].$Type."\"".$checked.">".$strtxt."<br>";
				}
			}
			if ($ActID==0) {
				if ($Type==0) { 
					$retStr = $retStr."</ol>"; 
				} else {
					$retStr = $retStr."</ul>";
				}
			}
		}
		$retval["allAssoc"] = $allAssoc;
		$retval["str"] = $retStr;
		return $retval;
	}
		
	function showPlanningCourseRapsAndSkills( $CourseID, $SemesterID, $UserID ) 
	{
		//Show Course RAPs and Skills
		echo "<small>";
		$allAssoc = true;
		$Ret = $this->showAssocRAPSkillsToPlanningCourse( 0, $CourseID, $SemesterID, $UserID ); echo $Ret["str"]; $allAssoc &= $Ret["allAssoc"];
		$Ret = $this->showAssocRAPSkillsToPlanningCourse( 1, $CourseID, $SemesterID, $UserID ); echo $Ret["str"]; $allAssoc &= $Ret["allAssoc"];
		$Ret = $this->showAssocRAPSkillsToPlanningCourse( 2, $CourseID, $SemesterID, $UserID ); echo $Ret["str"]; $allAssoc &= $Ret["allAssoc"];
		$Ret = $this->showAssocRAPSkillsToPlanningCourse( 3, $CourseID, $SemesterID, $UserID ); echo $Ret["str"]; $allAssoc &= $Ret["allAssoc"];
		if (!$allAssoc) {
			echo "* <i>Los RAPs y/o habilidades en rojo no han sido asociados a ninguna actividad.</i><br><br>";
		}
		echo "</small>";
	}
	
	
	function showPlanningCourseRapOrSkill( $Type, $ActivityID, $viewStyle, $separator ) 
	{
		switch($Type) {
			case 0:
				$sql = "SELECT * FROM courses_ilos WHERE ID IN 
							(SELECT RapSkillID FROM teacher_actassoc WHERE ActID=".$ActivityID." AND RapSkillType=0) 
							ORDER BY Position";
				$fieldPos = "Position";
				$fieldText = "Text";
				break;
			case 1:
				$sql = "SELECT * FROM cdiosyllabus_personal_skills WHERE ID IN 
							(SELECT SkillID FROM courses_personal_skills  WHERE ID IN 
							(SELECT RapSkillID FROM teacher_actassoc WHERE ActID=".$ActivityID." AND RapSkillType=1)) ORDER BY ID";
				$fieldPos = "ref_syllabus";
				$fieldText = "description";
				break;
			case 2:
				$sql = "SELECT * FROM cdiosyllabus_interpersonal_skills WHERE ID IN 
							(SELECT SkillID FROM courses_interpersonal_skills  WHERE ID IN 
							(SELECT RapSkillID FROM teacher_actassoc WHERE ActID=".$ActivityID." AND RapSkillType=2)) ORDER BY ID";
				$fieldPos = "ref_syllabus";
				$fieldText = "description";
				break;
			case 3:
				$sql = "SELECT * FROM cdiosyllabus_cdio_skills WHERE ID IN 
							(SELECT SkillID FROM courses_cdio_skills  WHERE ID IN 
							(SELECT RapSkillID FROM teacher_actassoc WHERE ActID=".$ActivityID." AND RapSkillType=3)) ORDER BY ID";
				$fieldPos = "ref_syllabus";
				$fieldText = "description";
				break;				
		}
		$retstr = "";
		$result_rapskill = $this->conn->query($sql);
		$nrow = 1;
		while($row_rapskill = $result_rapskill->fetch_assoc()) {
			switch($viewStyle) {
				case 0: //show only reference
					$retstr = $retstr.$row_rapskill[$fieldPos]; 
					break;
				case 1: //show only reference with floating tip box
					$retstr = $retstr. "<div class=\"tooltip\">".$row_rapskill[$fieldPos]."<span class=\"tooltiptext\">".$row_rapskill[$fieldText]."</span></div>";
					break;
				case 2: //show full reference
					$retstr = $retstr. "(".$row_rapskill[$fieldPos].")".$row_rapskill[$fieldText]; 
					break;
			} 
			if ($nrow != $result_rapskill->num_rows) $retstr = $retstr.$separator;
			$nrow++;
		}
		return $retstr;
	}
	
	function showPlanningCourseEvalInfo( $ActivityID, $EvalText, $PlanID, $CourseID, $UserID, $SemesterID, $canEdit ) 
	{
		//get rubrics associated to the activity
		$RubricTable = "";
		$sql = "SELECT rubrics_general.* FROM rubrics_general JOIN rubrics_assoc ON rubrics_general.ID=rubrics_assoc.RubricID
				WHERE rubrics_assoc.RapSkillID=".$ActivityID." AND rubrics_assoc.RapSkillType=4";	
		$result_list = $this->conn->query($sql);
		if ($result_list->num_rows > 0)  { 
			$bBR = strlen($EvalText)>0;
			while($row_list = $result_list->fetch_assoc()) {
				if ($bBR) $RubricTable = $RubricTable."<br>";
				if ($canEdit) {
					$aref = "<a href=\"planning_course_rubrics.php?ID=".$CourseID."&SemesterID=".$SemesterID."#rub".$row_list["ID"]."\">";
				} else {
					$aref =  "<a href=\"#rub".$row_list["ID"]."\">";
				}
				$RubricTable = $RubricTable."&equiv; ".$aref.$row_list["Name"]."</a>";
				$bBR = true;
			}
		} 
		if ($canEdit) {
			$btnedit = "<button class=\"button btn_edit\" type=\"button\" onclick=\"editEval(".$ActivityID.",".$PlanID.",".$CourseID.",".$UserID.",'".$SemesterID."')\"></button>"; 	
		} else {
			$btnedit = "";
		}
		return "<td id=\"ev".$ActivityID."\">".$EvalText.$btnedit.$RubricTable."</td>";
	}
		
	function showPlanningCourseActivityTable( $CourseID, $SemesterID, $UserID, $showTooltip, $ViewCols, $EditCols="" ) 
	{
		$ViewPos   = strstr($ViewCols,"P")!==false;
		$ViewTopic = strstr($ViewCols,"T")!==false;
		$ViewHours = strstr($ViewCols,"H")!==false;
		$ViewEval  = strstr($ViewCols,"E")!==false;
		$ViewSum   = strstr($ViewCols,"S")!==false;
		$ViewWeeks = strstr($ViewCols,"W")!==false;
		$EditPos   = strstr($EditCols,"P")!==false;
		$EditHours = strstr($EditCols,"H")!==false;
		$EditEval  = strstr($EditCols,"E")!==false;
		
		if ($ViewSum) {
			//Compute max hours
			$sql = "SELECT NumeroCreditos,HorasTeoricas,HorasPracticas,HorasTeoricoPracticas,HorasIndependientes 
					FROM courses_general WHERE ID=".$CourseID;
			$result = $this->conn->query($sql);
			$row = $result->fetch_assoc();
			$maxHDW = $row["HorasTeoricas"]+$row["HorasPracticas"]+$row["HorasTeoricoPracticas"];
			$maxHIW = $row["HorasIndependientes"];
			$maxSem = ($row["NumeroCreditos"]*48.0)/($maxHDW+$maxHIW);
			$maxHD = round($maxHDW*$maxSem);
			$maxHI = round($maxHIW*$maxSem);
		}
		
		//Display the activities for the given course and semester
		$sql = "SELECT * FROM teacher_activities WHERE CourseID=".$CourseID." AND UserID=".$UserID.
					" AND Semester='".$SemesterID."' ORDER BY Position";
		$result = $this->conn->query($sql);
		$viewStyleRap = $showTooltip ? 1 : 0;
		if ($result->num_rows > 0)  {
			//Show activities
			echo "<small><table id=\"activitiesCourse\" class=\"planning\">";
			echo "<tr>";
			if ($ViewPos)   { echo "<th>#</th>"; }
			echo "<th align=\"center\">Actividad</th><th align=\"center\">Descripción</th>";
			echo "<th>RAPs</th><th>Habilidad(es)</th>";
			if ($ViewTopic) { echo "<th>Tema</th>"; }
			if ($ViewHours) { echo "<th>Hrs. Clase</th><th>Hrs. Ind.</th>"; }
			if ($ViewWeeks) { echo "<th>Semanas <input id=\"maxHDW\" style=\"display:none\" value=\"".$maxHDW."\">
									<input id=\"maxHIW\" style=\"display:none\" value=\"".$maxHIW."\"> </th>"; }
			if ($ViewEval)  { echo "<th>Evaluación</th>"; }
			if ($EditPos)   { echo "<th></th>"; }
			echo "</tr>";
			
			while($row = $result->fetch_assoc()) 
			{	
				echo "<tr id=\"row".$row["ID"]."\">";
				//Show activity position
				if ($ViewPos) {
					if  ($EditPos)  { 
						echo "<td><input id=\"pos".$row["ID"]."\" style=\"width: 1.5em;\" name=\"pos".$row["ID"]."\" value=\"".$row["Position"]."\" readonly></td>"; 
					} else {
						echo "<td>".$row["Position"]."</td>"; 
					}
				}
				
				//Show activity description
				echo "<td>".$row["Name"]."</td><td>".$row["Description"]."</td><td>";
				
				//Show the RAPs associated to the activity
				echo $this->showPlanningCourseRapOrSkill( 0, $row["ID"], $viewStyleRap, ", ");
				echo "</td><td>";
				
				//Show the Skills associated to the activity
				$retP = $this->showPlanningCourseRapOrSkill( 1, $row["ID"], $viewStyleRap, ", ");
				$retI = $this->showPlanningCourseRapOrSkill( 2, $row["ID"], $viewStyleRap, ", ");
				$retC = $this->showPlanningCourseRapOrSkill( 3, $row["ID"], $viewStyleRap, ", ");
				$br1 = ((strlen($retP)>0)&&(strlen($retI)>0)) ? "<br>" : "";
				$br2 = ((strlen($retI)>0)&&(strlen($retC)>0)) ? "<br>" : "";
				$br1 = ((strlen($retI)==0)&&(strlen($retP)>0)&&(strlen($retC)>0)) ? "<br>" : $br1;
				echo $retP.$br1.$retI.$br2.$retC;
				echo "</td>";
				
				//Show the topic associated to the activity
				if ($ViewTopic) {
					echo "<td>";
					$sql = "SELECT TopicNumber,TopicName FROM courses_contents WHERE ID=".$row["TopicID"];
					$result_rapskill = $this->conn->query($sql);
					if ($result_rapskill->num_rows>0) {
						$row_rapskill = $result_rapskill->fetch_assoc();
						echo $row_rapskill["TopicNumber"].". ".$row_rapskill["TopicName"];
					}
					echo "</td>";
				}
				//Display hours 
				if ($ViewHours) {
					if ($EditHours) {
						echo "<td><input type=\"number\" id=\"hd".$row["ID"]."\" name=\"hd".$row["ID"]."\" 
									style=\"width: 2.5em;\" min=0 max=200 value=\"".$row["HD"]."\" onchange=\"updateHours()\"></td>";
						echo "<td><input type=\"number\" id=\"hi".$row["ID"]."\" name=\"hi".$row["ID"]."\" 
									style=\"width: 2.5em;\" min=0 max=200 value=\"".$row["HI"]."\" onchange=\"updateHours()\"></td>";
					} else {
						echo "<td>".$row["HD"]."</td><td>".$row["HI"]."</td>";
					}
				}
				if ($ViewWeeks) { 
					$week = (floatval($row["HD"])/$maxHDW) + (floatval($row["HI"])/$maxHIW); 
					echo "<td>".round($week,1)."</td>"; 
				}
				//Display evaluation
				if ($ViewEval) {
					echo $this->showPlanningCourseEvalInfo( $row["ID"], $row["Evaluation"], $row["PlanID"], $CourseID, $UserID, $SemesterID, $EditEval );
				}
				//Display buttons to edit position
				if ($EditPos) { 
					echo "<td><button class=\"button btn_up\" type=\"button\" onclick=\"moveItem(".$row["ID"].",-1)\"></button>";
					echo "<button class=\"button btn_down\" type=\"button\" onclick=\"moveItem(".$row["ID"].",1)\"></button></td>";  
				}
				echo "</tr>";
			}
			
			//Display the sums of hours and check if they reach the maximum allowed hours
			if ($ViewSum && $ViewHours) {
				$sql = "SELECT SUM(HD),SUM(HI) FROM teacher_activities WHERE CourseID=".$CourseID." AND UserID=".$UserID." AND Semester='".$SemesterID."'";
				$result = $this->conn->query($sql);
				$row = $result->fetch_assoc();
				$span=4;
				if ($ViewPos) { $span++; }
				if ($ViewTopic) { $span++; }
				echo "<tr><th colspan=".$span." align=\"right\">Totales</th>";
				if ($row["SUM(HD)"] > $maxHD) {
					$sfont1 = "<font color=\"red\">"; $snfont1 = "</font>";
				} else {
					$sfont1 = ""; $snfont1 = "";
				}
				if ($row["SUM(HI)"] > $maxHI) {
					$sfont2 = "<font color=\"red\">"; $snfont2 = "</font>";
				} else {
					$sfont2 = ""; $snfont2 = "";
				}
				echo "<th>".$sfont1.$row["SUM(HD)"].$snfont1."</th><th>".$sfont2.$row["SUM(HI)"].$snfont2."</th>";
				if ($ViewWeeks) { echo "<th></th>"; }
				if ($ViewEval) { echo "<th></th>"; }
				if ($EditPos) { echo "<th></th>"; }
				echo "</tr>";
				//Show max hours
				echo "<tr><th colspan=".$span." align=\"right\">Máximos</th>";
				echo "<th>".$maxHD."</th><th>".$maxHI."</th>";
				if ($ViewWeeks) { echo "<th></th>"; }
				if ($ViewEval) { echo "<th></th>"; }
				if ($EditPos) { echo "<th></th>"; }
				echo "</tr>";
			}
			
			echo "</table></small>";
		}
	}
	
	function showPlanningCourseHowTosRow( $HowToID, $CourseID, $RapID, $SemesterID, $UserID, $HowToText, $Position, $RapText ) 
	{
		$btnedit = "<button class=\"button btn_edit\" type=\"button\" onclick=\"editHowTo(".$HowToID.",".$RapID.",".$CourseID.",".$UserID.",'".$SemesterID."')\"></button>"; 	
		echo "<tr id=\"howto".$RapID."\"><td>".$Position."</td><td>".$RapText."</td><td>".$HowToText.$btnedit."</td></tr>";
	}
	
	function showPlanningCourseHowTos( $CourseID, $SemesterID, $UserID ) 
	{
		//Display the how tos for the given course and semester
		$sql = "SELECT ID,Position,Text FROM courses_ilos WHERE CourseID=".$CourseID." ORDER BY Position";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {
			echo "<table id=\"howtos\" class=\"planning\">";
			echo "<tr><th></th><th align=\"center\">RAP</th><th align=\"center\">¿Cómos?</th></tr>";
			while($row = $result->fetch_assoc())
			{
				$RapID = $row["ID"];
				$sql = "SELECT ID,HowTo FROM teacher_howtos WHERE RapID=".$RapID." AND CourseID=".$CourseID.
						" AND UserID=".$UserID." AND Semester='".$SemesterID."'";				
				$result_howto = $this->conn->query($sql);
				if ($result_howto->num_rows > 0)  {
					$row_howto = $result_howto->fetch_assoc();
					$howto = $row_howto["HowTo"];
					$idHowTo = $row_howto["ID"];
				} else {
					$howto = "";
					$idHowTo = -1;
				}
				$this->showPlanningCourseHowTosRow( $idHowTo, $CourseID, $RapID, $SemesterID, $UserID, $howto, $row["Position"], $row["Text"] );
			}
			echo "</table>";
		}
	}
	
	function showPlanningCoursesByUser( $userID, $SemesterID ) 
	{	
		//Display the list of available courses with planning for the given semester and PlanID.
		$sql = "SELECT teacher_activities.CourseID, courses_general.CourseKeyID
				FROM teacher_activities 
				LEFT JOIN courses_general ON teacher_activities.CourseID=courses_general.ID
				WHERE teacher_activities.UserID=".$userID." AND teacher_activities.Semester='".$SemesterID."' 
				GROUP BY teacher_activities.CourseID";
		$result = $this->conn->query($sql);
		if ($result->num_rows > 0)  {
			while($row = $result->fetch_assoc()) {	
				$sql = "SELECT courses_plan.Nombre,study_plan.Program
						FROM courses_plan JOIN study_plan ON courses_plan.PlanID = study_plan.ID 
						WHERE courses_plan.ID =". $row["CourseKeyID"];
				$result_course = $this->conn->query($sql);
				$row_course = $result_course->fetch_assoc();
				echo "<li><a href=\"planning_course_howtos.php?ID=".$row["CourseID"]."&SemesterID=".$SemesterID."\">".
					$row_course["Nombre"]. " (".$row_course["Program"].")</a></li>";
			}
			echo "</table>";
		} else {
			echo "<li>No tiene cursos planeados para el semestre seleccionado.</li>";
		}
	}
}
