<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();

//Get courses where rubric is being used
$sql = "SELECT Nombre FROM courses_general WHERE ID IN 
		(SELECT CourseID FROM rubrics_assoc WHERE rubrics_assoc.RubricID=".$_GET["RubricID"]." AND rubrics_assoc.CourseID!=0 GROUP BY CourseID ) 
		ORDER BY Nombre";
$result = $planea->conn->query($sql);
if ($result->num_rows > 0)  {
	echo "<ol>";
	while(($row = $result->fetch_assoc())) {	
		echo "<li>".$row["Nombre"]."</li>";
	}
	echo "</ol>";
}
			
$planea->closeConnection();
?>