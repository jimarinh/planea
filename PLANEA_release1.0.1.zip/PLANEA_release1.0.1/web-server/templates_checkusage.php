<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	//Check if template is being used by any course
	$sql = "SELECT ID FROM courses_general WHERE Template='".$_GET["template"]."'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		echo "1";
	} else {
		echo "0";
	}
	$planea->closeConnection();
?>