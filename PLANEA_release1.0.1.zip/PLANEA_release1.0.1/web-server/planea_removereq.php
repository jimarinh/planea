<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$CourseID = $_GET["courseID"];
$sql = "DELETE FROM courses_reqs WHERE ID=" . $_GET["removeID"];
$planea->conn->query($sql);
$planea->showRequirementsList( $CourseID, true );
$planea->closeConnection();
?>