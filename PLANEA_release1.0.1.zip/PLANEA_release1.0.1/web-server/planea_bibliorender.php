<?php
require('bibtex2html.php');
$str_html = bibfile2html($_POST["text"],null,false,false); 
echo $str_html;
?>