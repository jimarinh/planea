<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "SELECT * FROM courses_electivecats WHERE ID=" . $_GET["catID"];
$result = $planea->conn->query($sql);
$row = $result->fetch_assoc();
header('Content-type: application/json');
$row["CategoryName"] = $row["CategoryName"];
echo json_encode($row);
$planea->closeConnection();
?>