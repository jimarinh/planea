<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">	
	<script type="text/javascript" src="planea_formattextarea.js"></script> 
	<script type="text/javascript" src="nicEdit.js"></script> 
	<script>
	function updateArrowBtns() {
		var btnup, btndn, pos;
		var items = document.getElementById("rapList").getElementsByTagName("tr");
		for(pos=0;pos<items.length;pos++) {
			btnup = items[pos].getElementsByClassName("button btn_up");
			if (btnup.length>0) { btnup[0].style.display = (pos==1) ? "none" : "inline"; }
			btndn = items[pos].getElementsByClassName("button btn_down");
			if (btndn.length>0) { btndn[0].style.display = (pos==items.length-1) ? "none" : "inline"; }
			posinput = items[pos].getElementsByTagName("input");
			if (posinput.length>0) { posinput[0].value = pos; }
		}
	}
	function moveItem(Id, dir) {
		var tr1   = document.getElementById("ilo"+Id);
		if (dir == -1) { tr1.parentNode.insertBefore(tr1, tr1.previousSibling); } else { tr1.parentNode.insertBefore(tr1.nextSibling, tr1); }
		setModifiedFlag();
		updateArrowBtns();
	}
	
	function savePositions() {
		var serialize = function (form) {
			// Setup our serialized data
			var serialized = [];
			// Loop through each field in the form
			for (var i = 0; i < form.elements.length; i++) {
				var field = form.elements[i];
				// Don't serialize fields without a name, submits, buttons, file and reset inputs, and disabled fields
				if (!field.name || field.disabled || field.type === 'file' || field.type === 'reset' || field.type === 'submit' || field.type === 'button') continue;
				// If a multi-select, get all selections
				if (field.type === 'select-multiple') {
					for (var n = 0; n < field.options.length; n++) {
						if (!field.options[n].selected) continue;
						serialized.push(encodeURIComponent(field.name) + "=" + encodeURIComponent(field.options[n].value));
					}
				}
				// Convert field data to a query string
				else if ((field.type !== 'checkbox' && field.type !== 'radio') || field.checked) {
					serialized.push(encodeURIComponent(field.name) + "=" + encodeURIComponent(field.value));
				}
			}
			return serialized.join('&');
		};
		var serializedForm = serialize(mainForm);
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
			}
		}
		xhttp.open("GET", "ilo_updatepositions.php?"+serializedForm, true);
		xhttp.send();
	}
	function removeItem(Id) {	
		var r = confirm("¿Está seguro que desea eliminar el RAP?\nEsta operación no se puede deshacer.");
		if (r == true) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var tr = document.getElementById("ilo"+Id);
					tr.parentNode.removeChild(tr);
					setModifiedFlag();
					updateArrowBtns();
				}
			}
			xhttp.open("GET", "ilo_removecourseILO.php?iloID="+Id, true);
			xhttp.send();
		}
	}
	
	var nicEditorEditRap = null;
	var actionAfterCheckVerb = "";
	
	function editItem(Id) {	
		savePositions();
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				obj = JSON.parse(this.responseText);
				RapID.value = obj.ID;
				rapEditor.style.display = "block";
				if (nicEditorEditRap==null) { 
					nicEditorEditRap = new nicEditor({buttonList : ['bold','italic','underline','subscript','superscript']}).panelInstance('EditRAP');
					planeaFormatTextarea.textAreaById("EditRAP");
				}
				nicEditors.findEditor("EditRAP").setContent(obj.Text);
				var categories = document.getElementById("editCatRAP").options;
				for(pos=0;pos<categories.length;pos++) {
					if (categories[pos].value == obj.CategoryID) {
						document.getElementById("editCatRAP").selectedIndex = pos;
						break;
					}
				}
				var progRAPs = document.getElementById("editProgRAP").options;
				for(pos=0;pos<progRAPs.length;pos++) {
					if (progRAPs[pos].value == obj.ProgramILOID) {
						document.getElementById("editProgRAP").selectedIndex = pos;
						break;
					}
				}	
			}
		}
		xhttp.open("GET", "ilo_editcourseILO.php?iloID="+Id, true);
		xhttp.send();
	}
	function normalizeRapText(textvalue) {
		//Remove spaces and not allowed HTML tags
		textvalue = textvalue.replace(/&nbsp;/gi," "); //Remove HTML spaces
		textvalue = textvalue.replace(/<br>/gi,"");	//Remove line break
		textvalue = textvalue.replace(/^\s+/g, "");	//Remove spaces at beginning of string
		textvalue = textvalue.replace(/<li>/gi,"");  //Remove bullets and auto-numbering
		textvalue = textvalue.replace(/<\/li>/gi,"");
		textvalue = textvalue.replace(/<ol>/gi,"");
		textvalue = textvalue.replace(/<\/ol>/gi,"");
		textvalue = textvalue.replace(/<ul>/gi,"");
		textvalue = textvalue.replace(/<\/ul>/gi,"");
		return textvalue;
	}
	function changeRapToCourse(courseID,VerbID) {
		var textvalue = nicEditors.findEditor("EditRAP").getContent();
		textvalue = normalizeRapText(textvalue);
		var xhttp = new XMLHttpRequest();
		rapEditor.style.display = "none";
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				rapList.innerHTML = this.responseText;
				updateArrowBtns();
			}
		}
		xhttp.open("GET", "ilo_changecourseILO.php?iloID="+RapID.value+"&CourseID="+courseID+
			"&VerbID="+VerbID+"&Text="+textvalue+"&CatID="+editCatRAP.value+"&ProgILOID="+editProgRAP.value, true);
		xhttp.send();
	}
	function changeRap(CourseID) {
		cancelRap();
		actionAfterCheckVerb="CHANGE";
		var textvalue = nicEditors.findEditor("EditRAP").getContent();
		textvalue = normalizeRapText(textvalue);
		checkVerbRap(CourseID,textvalue);
	}
	
	function removeSkill(courseID,skillType,skillID) {
		var xhttp = new XMLHttpRequest();
		var x = document.getElementById("row"+skillType+skillID);
		var tableObj = document.getElementById("skillTable"+skillType);
		tableObj.deleteRow(x.rowIndex);
		if (tableObj.rows.length>1) {
			tableObj.style.display = "block";
		} else {
			tableObj.style.display = "none";
		}
		xhttp.open("GET", "planea_removeskill.php?courseID="+courseID+"&removeID="+skillID+"&skillType="+skillType, true);
		xhttp.send();
	}
	function addSkill(courseID,skillType) {	
		var xhttp = new XMLHttpRequest();
		var e = document.getElementById(skillType+"Skill");
		var value = e.options[e.selectedIndex].value;	
		if (value==0) {
			alert("Seleccione primero una habilidad del listado y luego de clic el botón 'Añadir Habilidad'");
		} else {
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var tableObj = document.getElementById("skillTable"+skillType);
					var rowObj = tableObj.insertRow(-1);
					var ss = this.responseText.indexOf("\"")+1;
					var es = this.responseText.indexOf("\"",ss);
					var idname = this.responseText.substring(ss, es);
					rowObj.innerHTML = this.responseText;
					rowObj.id = idname;
					tableObj.style.display = "block";
				}
			};
			xhttp.open("GET", "planea_addskill.php?courseID="+courseID+"&skillID="+value+"&skillType="+skillType, true);
			xhttp.send();
		}
	}
	//RAP Assistant
	function configureRapAssistant() {
			rapAssistant.style.display = "none";
			rapAssistantVerbNotListed.style.display = "none";
			rapEditor.style.display = "none";			
			var span0 = document.getElementsByClassName("close")[0];
			span0.onclick = function() { rapAssistant.style.display = "none"; }
			var span1 = document.getElementsByClassName("close")[1];
			span1.onclick = function() { rapAssistantVerbNotListed.style.display = "none"; }
			var span2 = document.getElementsByClassName("close")[2];
			span2.onclick = function() { rapEditor.style.display = "none"; }
		}
		function displayVerbList() {
			var taxonomy = rapTaxonomy.value;
			var category = document.querySelector('input[name="rapCategory"]:checked').value;
			var levElems = document.getElementsByName('rapLevel');
			var level = 0;
			for (var i=0; i<levElems.length; i++) {
				if (levElems[i].checked) level |= levElems[i].value;
			}
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("rapVerbs").innerHTML = this.responseText;
				}
			};
			xhttp.open("GET", "rap_assistant_getverbs.php?taxonomy="+taxonomy+"&level="+level+"&category="+category);
			xhttp.send();		
		}		
		function changeTaxonomy() {
			if (rapTaxonomy.value == "SOLO") {
				taxonomySOLO.style.display = "inline";
				taxonomyBloom.style.display = "none";
			} else {
				taxonomySOLO.style.display = "none";
				taxonomyBloom.style.display = "inline";
			}
			var levElems = document.getElementsByName('rapLevel');
			for (var i=0; i<levElems.length; i++) {
				levElems[i].checked = false;
			}
			displayVerbList();
		}
		function changeVerbLevel() {
			displayVerbList();
		}
		function rapAssistantGo() {
			rapAssistant.style.display = "block";				
		}
		function cancelRap() {
			rapAssistant.style.display = "none";
			rapAssistantVerbNotListed.style.display = "none";
			rapEditor.style.display = "none";
		}
		function generateRap(style) {
			var verbWidget = document.querySelector('input[name="rapVerb"]:checked');
			if (verbWidget!=null) {
				var verbName = verbWidget.value;
				if (style==1) {
					rapComplete.value = verbName+" "+rapCriteria.value+" "+rapContent.value+" "+rapContext.value;
				}
				if (style==2) {
					rapComplete.value = rapContext.value + ", "+verbName.toLowerCase()+" "+rapCriteria.value+" "+rapContent.value;
				}
			}
		}
		
		function addRapToCourse(CourseID, VerbID) {
			var textvalue = nicEditors.findEditor("NewRAP").getContent();
			textvalue = normalizeRapText(textvalue);
			var CatID = 0;
			var ProgILOID = 0;
			var e = document.getElementById("catRAP");
			if (e.selectedIndex != -1) { CatID = e.value; }
			var e = document.getElementById("progRAP");
			if (e.selectedIndex != -1) { ProgILOID = e.value; }
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
						rapList.innerHTML = this.responseText;
						nicEditors.findEditor("NewRAP").setContent("");
						updateArrowBtns();
					}
				}
			xhttp.open("GET", "rap_assistant_addrap.php?CourseID="+CourseID+"&VerbID="+VerbID+"&CatID="+CatID+"&ProgILOID="+ProgILOID+"&Text="+textvalue);
			xhttp.send();
		}
		
		function addRapVerbNotListed(CourseID) {
			rapAssistantVerbNotListed.style.display = "none";
			if (actionAfterCheckVerb=="ADD") {
				addRapToCourse(CourseID,rapMatchedVerb.value);
			}
			if (actionAfterCheckVerb=="CHANGE") {
				changeRapToCourse(CourseID,rapMatchedVerb.value);
			}
		}
		
		function checkVerbRap(CourseID,textvalue) {
			//Check if RAP text is valid
			if (textvalue.length > 1) {			
				//Check if the verb in the RAP exists in the verb list
				var xhttp = new XMLHttpRequest();			
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						obj = JSON.parse(this.responseText);
						if (obj.VerbID != -1) {
							if (actionAfterCheckVerb=="ADD") {
								addRapToCourse(CourseID,obj.VerbID);
							}
							if (actionAfterCheckVerb=="CHANGE") {
								changeRapToCourse(CourseID,obj.VerbID);
							}
						} else {
							rapAssistantVerbNotListed.style.display = "block";
						}						
					}
				}
				xhttp.open("GET", "rap_assistant_analyze.php?Text="+textvalue);
				xhttp.send();
			} else { 
				cancelRap();
			}
		}
		
		function addRap(CourseID) {
			savePositions();
			actionAfterCheckVerb="ADD";
			var textvalue = nicEditors.findEditor("NewRAP").getContent();
			textvalue = normalizeRapText(textvalue);
			checkVerbRap(CourseID,textvalue);
		}
		
		function addRapFromAssitant(CourseID) {
			nicEditors.findEditor("NewRAP").setContent(rapComplete.value);
			rapAssistant.style.display = "none";
		}
	//-------- End RAP Assistant	
	function verifySkillCheckGroup(groupName) {
		//Verify that all skills have any mark as Introduce, Teach, or Use.
		var warningstr = "";
		var items = document.getElementById(groupName).getElementsByTagName("input");
		for(pos=0;pos<items.length;pos+=3) {
			var ename = items[pos].name;
			var e = document.querySelector('input[name="'+ename+'"]:checked');
			if (e==null) {
				ename = "nam"+ename.substring(3);
				warningstr = warningstr + document.getElementById(ename).innerHTML +"\n";
			}
		}
		return warningstr;
	}
	function verifySkillChecks() {
		var str = verifySkillCheckGroup("PSkillFrame");
		str = str+verifySkillCheckGroup("ISkillFrame");
		str = str+verifySkillCheckGroup("CSkillFrame");
		if (str.length>0) { 
			alert("Las siguientes habilidades no tienen definida la responsabilidad (Introduce, Enseña o Utiliza) del curso en su formación:\n"+str);
			return false;
		}
		return clearModifiedFlag();
	}
	
	window.onload = function(){
		configureRapAssistant();
		updateArrowBtns();
		//new nicEditor({buttonList : ['bold','italic','underline','subscript','superscript']}).panelInstance('RAPS');
		new nicEditor({buttonList : ['bold','italic','underline','subscript','superscript']}).panelInstance('NewRAP');
		planeaFormatTextarea.allTextAreas();
	}
	</script>
</head>

<body>
<?php  
	require('planea_basics.php');
	require('planea_logosbar.php');
	$helptopic = "teacher-RAPs";
	require('planea_syllabusbar.php');
		
	$planea = new planea();
	$conn = $planea->openConnection();
	if (isset($_GET["ID"])) {
		$CourseID = $_GET["ID"];
	}
	if (isset($_POST["CourseID"])) {
		$CourseID = $_POST["CourseID"];
		//If "save" button is clicked, save into the database
		//$sql = "UPDATE courses_general SET RAPS='". $_POST["RAPS"] ."' WHERE ID=" . $CourseID;
		//$conn->query($sql);
		$planea->saveSkills("P", $CourseID);
		$planea->saveSkills("I", $CourseID);
		$planea->saveSkills("C", $CourseID);
		foreach ($_POST as $key=>$value) {
			if (substr($key,0,3) == "pos") {	
				$id = substr($key,3);
				$sql = "UPDATE courses_ilos SET Position=". $_POST["pos".$id] ." WHERE ID=".$id;
				$conn->query($sql);
			}
		}
	}
	$sql = "SELECT * FROM courses_general WHERE ID=" . $CourseID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$CourseName = $planea->showCourseTitle($row);
	$canModify = $planea->checkPermission( $_SESSION["RoleID"], $_SESSION["UserID"], $CourseID, 4 );
	$coursebar_opt = 3;
	require('planea_coursebar.php');
?>


<div id="wrapper"></div>

<form class="planeaForm" id="mainForm" action="view_syllabus_raps.php" onsubmit="return verifySkillChecks()" method="POST">
<b>Resultados de Aprendizaje Previstos (RAPs)</b> 
<p style="font-size:small">Para adicionar los resultados de aprendizaje puede: </p>
<ol style="font-size:small">
	<li>Usar el asistente escogiendo el botón <b>Asistente para RAPS</b> que le orientará con la selección de verbos de 
		acuerdo a la taxonomía Bloom o SOLO, o </li>
	<li>Escribir el resultado de aprendizaje (<b>solo 1</b>) en el cuadro de texto. En esta opción se analizará la estructura 
		del RAP buscando si el verbo empleado es acorde a alguna taxonomía. Esta acción no modifica su RAP solamente le consultará
		por un verbo que se aproxima a su selección.</li>
</ol>
<p style="font-size:small">En cualquiera de las dos formas se recomienda escoger la categoría del RAPs de acuerdo a la normativa institucional, y para agregarlo finalmente escoga la opción <b>Añadir RAP</b>.</p> 
<p style="font-size:small">Debe repetir este proceso por cada uno de los RAPs que vaya a adicionar.</p> 
<!--
<textarea id="RAPS" name="RAPS" rows=8 cols=120 onchange="setModifiedFlag()" <?php if (!$canModify) echo " readonly"; ?>><?php echo $row["RAPS"]; ?></textarea>
-->
<div id="rapList">
<?php echo $planea->showRAPList($CourseID,false,$canModify); ?>
</div> <br>
<div <?php if (!$canModify) echo "style=\"display:none\""; ?>>
<u>*Nuevo RAP:</u> <br> <textarea id="NewRAP" rows=3 cols=120></textarea> <br>
<button type="button" onclick="rapAssistantGo()">Asistente para RAPs</button> &nbsp; &nbsp;
<?php 
	$rapCats = $planea->showRAPCategoryForCourse($CourseID); 
	$rapProg = $planea->showRAPProgramForCourse($CourseID);
?>
<select id="catRAP" <?php if (!$rapCats["exist"]) echo "style=\"display:none\""; ?>> <?php echo $rapCats["str"]; ?> </select> &nbsp;
<select id="progRAP" <?php if (!$rapProg["exist"]) echo "style=\"display:none\""; ?>> <?php echo $rapProg["str"]; ?> </select> &nbsp;
<button class="button btn_fancy" onclick="addRap(<?php echo $CourseID; ?>)" type="button">Añadir RAP<img src="images/btn_add1.png"> </button>
</div>		
<br>

<div id="rapAssistant" class="modal">
  <!-- Modal content -->
  <div class="modal-content">
  <div  class="modal-header">
    <span  class="close">&times;</span >
    <h2 >Asistente para RAPs</h2 >
  </div>
  <div  class="modal-body">
    <p><b>Taxonomía:</b> <select id="rapTaxonomy" name="rapTaxonomy" onchange="changeTaxonomy()">
		<option value="SOLO" <?php if ($planea->defaultTaxonomy == planea::taxonomySOLO) echo "selected";?>>SOLO</option>
		<option value="Bloom" <?php if ($planea->defaultTaxonomy == planea::taxonomyBloom) echo "selected";?>>Bloom</option></select>
	</p>
    <p id="taxonomySOLO" <?php if ($planea->defaultTaxonomy != planea::taxonomySOLO) echo "style=\"display:none\"";?>><b>Nivel</b>: 
		<input type="checkbox" name="rapLevel" value=1 onchange="changeVerbLevel()">Uniestructural
		<input type="checkbox" name="rapLevel" value=2 onchange="changeVerbLevel()">Multiestructural
		<input type="checkbox" name="rapLevel" value=4 onchange="changeVerbLevel()">Relacional
		<input type="checkbox" name="rapLevel" value=8 onchange="changeVerbLevel()">Abstracto Extendido <br> <br>
		<b>Categoría</b>: <input type="radio" name="rapCategory" value="D" onchange="changeVerbLevel()" checked>Declarativo<input type="radio" name="rapCategory" value="F" onchange="changeVerbLevel()">Funcional
	</p>	
	<p id="taxonomyBloom" <?php if ($planea->defaultTaxonomy != planea::taxonomyBloom) echo "style=\"display:none\"";?>><b>Nivel</b>:
		<input type="checkbox" name="rapLevel" value=1 onchange="changeVerbLevel()">Recordar
		<input type="checkbox" name="rapLevel" value=2 onchange="changeVerbLevel()">Comprender
		<input type="checkbox" name="rapLevel" value=4 onchange="changeVerbLevel()">Aplicar
		<input type="checkbox" name="rapLevel" value=8 onchange="changeVerbLevel()">Analizar
		<input type="checkbox" name="rapLevel" value=16 onchange="changeVerbLevel()">Evaluar
		<input type="checkbox" name="rapLevel" value=32 onchange="changeVerbLevel()">Crear
	</p>	
	<p><b>Verbos</b>:</p>
	<p id="rapVerbs"></p>
	<p><b>Contenido y Contexto</b><br>
	<i style="font-size:small">Escriba el contenido (o temática) y el contexto (donde se desarrolla el contenido)</i>
	<p style="margin-left:20px">Contenido: <input id="rapContent" style="width: 100%;"> <br> <br> Contexto: <input id="rapContext" style="width: 100%;"></p>
	<p><b>Criterio (opcional)</b>: <input id="rapCriteria"><br><i style="font-size:small">Ejemplo: Eficientemente, consistentemente, efectivamente, etc.</i></p>
	<p><b>RAP</b>: <ul><li>[Verbo][Opcional:Criterio][Contenido][Contexto] &nbsp; <button type="button" onclick="generateRap(1)">Generar</button></li>
	<li>[Contexto], [Verbo][Opcional:Criterio][Contenido] &nbsp; <button type="button" onclick="generateRap(2)">Generar</button></li></ul></p>
	<p><input id="rapComplete" style="width: 100%;"></p>
	<button type="button" onclick="addRapFromAssitant(<?php echo $CourseID; ?>)">Aceptar</button><button type="button" onclick="cancelRap()">Cancelar</button>
  </div>
</div>
</div>

<div id="rapAssistantVerbNotListed" class="modal">
  <!-- Modal content -->
  <div class="modal-content">
  <div  class="modal-header">
  <span  class="close">&times;</span >
    <h2 >Asistente para RAPs</h2 >
  </div>
  <div  class="modal-body">
    <p style="font-size:small">El texto del RAP no incluye ninguno de los verbos contenidos en la plataforma. 
	Por favor seleccione del siguiente listado el verbo más afin. El texto de su RAP no será modificado. 
	el verbo seleccionado solamente se usará para efectos de sugerencia de actividades y/o evaluación en los módulos 
	de planeación de actividades y elaboración de rúbricas.
	</p>
	<p><select id="rapMatchedVerb" onchange="changeTaxonomy()"> <?php $planea->showVerbList(); ?> </select></p>
	<button type="button" onclick="addRapVerbNotListed(<?php echo $CourseID; ?>)">Siguiente</button>
	<button type="button" onclick="cancelRap()">Cancelar</button>
  </div>
</div>
</div>

<div id="rapEditor" class="modal">
  <!-- Modal content -->
  <div class="modal-content">
  <div  class="modal-header">
  <span  class="close">&times;</span >
    <h2 >Modificar RAP</h2 >
  </div>
  <div  class="modal-body">
    <textarea id="EditRAP" rows=4 cols=120></textarea> <br>
	<b>Categoría:</b> <select id="editCatRAP" <?php if (!$rapCats["exist"]) echo "style=\"display:none\""; ?>> <?php echo $rapCats["str"]; ?> </select> <br><br>
	<b>RAP de programa asociado:</b> <select id="editProgRAP" <?php if (!$rapProg["exist"]) echo "style=\"display:none\""; ?>> <?php echo $rapProg["str"]; ?> </select> <br><br>
	<input style="display:none" type="number" id="RapID">
	<button type="button" onclick="changeRap(<?php echo $CourseID; ?>)">Aceptar</button>
	<button type="button" onclick="cancelRap()">Cancelar</button> <br>
  </div>
</div>
</div>

<br>
<b>Habilidades Personales:</b> <br>
<div id="PSkillFrame">
<?php 
	$planea->showSkills( "P", $CourseID, $canModify );
?>
</div>	
<br>

<b>Habilidades Interpersonales:</b> <br>
<div id="ISkillFrame">
<?php    
	$planea->showSkills( "I", $CourseID, $canModify);
?>
</div>
<br>
		
<b>Habilidades CDIO:</b> <br> 
<div id="CSkillFrame">
<?php    
	$planea->showSkills( "C", $CourseID, $canModify);
?>
</div>
<br>

<input style="display:none" type="number" name="CourseID" value="<?php echo $row["ID"]; ?>">

<?php 
	if ($canModify) { 
		echo "<input type=\"submit\" value=\"Guardar\">"; 
	} 
	$planea->closeConnection();
?>
<input type="submit" formaction="syllabus.php" value="Cancelar"> 
</form>  

</body>
</html>
