<?php
require('planea_basics.php');  
$planea = new planea();
$conn = $planea->openConnection();	
$CourseID =  $_GET["ID"];
$sql = "SELECT EstadoVersion,Version,Nombre FROM courses_general WHERE ID=" . $CourseID; 
$result = $conn->query($sql); 
$row = $result->fetch_assoc();
if ($row["EstadoVersion"]==planea::syllStateOpened) { 
	$sql = "UPDATE courses_general SET EstadoVersion=".planea::syllStateDisabled." WHERE CourseKeyID=".$_GET["CourseKeyID"];
	$result = $conn->query($sql); 
	$sql = "UPDATE courses_general SET EstadoVersion=".planea::syllStateApproved.",FechaVersion='".$_GET["versionDate"].
			"',VersionAnotacion='".$_GET["versionAnotacion"]."',VersionResponsable='".$_GET["versionResponsable"]."' WHERE ID=".$CourseID;
	$result = $conn->query($sql); 
	$sql = "DELETE FROM users_assignments WHERE courseID=".$CourseID;
	$result = $conn->query($sql); 
	echo "La versión ".$row["Version"]." del curso ".$row["Nombre"]." ha sido aprobada exitosamente";
}
$planea->closeConnection();
?>