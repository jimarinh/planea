<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection(); 
	$planea->showEvalReportByArea( $_GET["PlanID"], $_GET["SemName"], $_GET["Area"], $_GET["Attr"] );
	$planea->closeConnection();
?>