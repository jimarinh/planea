<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "SELECT * FROM eval_areas WHERE PlanID=" . $_GET["PlanID"]." AND Semester='".$_GET["SemName"]."' AND AreaName='". $_GET["Area"]."'";
$result = $planea->conn->query($sql);
$row = $result->fetch_assoc();
header('Content-type: application/json');
$obj = (object)[];
if (isset($row["ID"])) { 
	$obj->ID = $row["ID"]; 
} else {
	$obj->ID = 0; 
}
$obj->UnknownPrevSkills = $row["UnknownPrevSkills"];
$obj->UncoveredTopics = $row["UncoveredTopics"];
$obj->IrrelevantTopics = $row["IrrelevantTopics"];
$obj->StudentProblems = $row["StudentProblems"];
$obj->SuccessfulExp = $row["SuccessfulExp"];
$obj->UnsuccessfulExp = $row["UnsuccessfulExp"];
$obj->ImprovMeasures = $row["ImprovMeasures"];
$str = json_encode($obj);
echo $str;
$planea->closeConnection();
?>