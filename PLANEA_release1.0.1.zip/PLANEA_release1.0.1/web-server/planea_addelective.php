<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
//Verifica si se debe forzar el semestre
$sql = "SELECT * FROM courses_electivecats WHERE ID=" . $_GET["CatID"];
$result = $planea->conn->query($sql);
$row_cat = $result->fetch_assoc();
$sql = "SELECT Nombre,Semestre,NumeroCreditos FROM courses_general WHERE CourseKeyID=".$_GET["CourseID"]." AND VisVersion=1";
$result = $planea->conn->query($sql);
$row_course = $result->fetch_assoc();
$error = false;
if ($row_cat["Credits"] != $row_course["NumeroCreditos"]) {
	$error_msg = "El número de créditos de la categoría '".$row_cat["CategoryName"]."' (".$row_cat["Credits"].") no coincide con el número de créditos del curso '".$row_course["Nombre"]."' (".$row_course["NumeroCreditos"].")";
	$error = true;
} else {
	if ($row_cat["ForceSemester"] && ($row_cat["Semester"]!=$row_course["Semestre"])) {
		$error_msg = "El semestre del curso '".$row_course["Nombre"]."' (".$row_course["Semestre"].") no coincide con el semestre de la categoría '".$row_cat["CategoryName"]."' (".$row_cat["Semester"].")";
		$error = true;
	} else { //No error
		$sql = "INSERT INTO courses_elective (CategoryID,CourseID) VALUES ('" . $_GET["CatID"] . "', '". $_GET["CourseID"]. "')";
		$planea->conn->query($sql);
		$planea->showElectives($_GET["plan"]);
	}
}
if ($error) {
	echo "ERROR: ".$error_msg.". Debe modificar las propiedades del curso antes de asignarlo como espacio electivo";
}
$planea->closeConnection();
?>