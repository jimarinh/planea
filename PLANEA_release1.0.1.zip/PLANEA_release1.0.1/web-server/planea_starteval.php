<?php
	require('planea_basics.php');  
	$planea = new planea();
	$conn = $planea->openConnection();
	$retval = $planea->startEvalOfSemester( $_GET["PlanID"], $_GET["SemName"] );
	if ($retval > 0 ) {
		echo "Se asignaron para evaluación ".$retval." curso(s)";
	} else {
		switch ($retval) {
			case  0: echo "No existen usuarios asignados para evaluar los cursos.\nDebe asignar resposabilidades"; break;
			case -1: echo "No ha definido el semestre de evaluación"; break;
			case -2: echo "Error habilitando la evaluación para el semestre ".$_GET["SemName"]; break;
			case -3: echo "Todos los cursos ya fueron asignados previamente para evaluación"; break;
		}	
	}
	$planea->closeConnection();
?>