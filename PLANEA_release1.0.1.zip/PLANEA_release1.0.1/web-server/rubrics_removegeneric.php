<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();

if (isset($_GET["UserID"]) && isset($_GET["SemesterID"])) {
	//Remove all associations of the rubric to the activities of the given course, user and semester
	$sql = "DELETE FROM rubrics_assoc WHERE RubricID=".$_GET["RubricID"].
			" AND RapSkillType=4 AND RapSkillID IN (SELECT ID FROM teacher_activities WHERE CourseID=".
			$_GET["CourseID"]." AND UserID=".$_GET["UserID"]." AND Semester='".$_GET["SemesterID"]."')";
} else {
	//Remove all associations of the rubric in the course except those related to the activities
	$sql = "DELETE FROM rubrics_assoc WHERE RubricID=".$_GET["RubricID"]." AND CourseID=".$_GET["CourseID"]." AND RapSkillType!=4";
}
$result = $planea->conn->query($sql);

$planea->closeConnection();
?>