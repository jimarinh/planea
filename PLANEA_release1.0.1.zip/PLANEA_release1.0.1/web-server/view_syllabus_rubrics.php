<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">	
	<script>
	function removeAssoc(RubricAssocID, RubricID, CourseID) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				var item = document.getElementById("as"+RubricAssocID);
				item.parentNode.removeChild(item);	
			}
		}
		xhttp.open("GET", "rubrics_remove_assoc.php?AssocID="+RubricAssocID+"&RubricID="+RubricID+"&CourseID="+CourseID, true);
		xhttp.send();
	}
	function editRubric(RubricID, Scope, PlanID, CourseID) {
		if (Scope == 0) {
			var r = confirm("Advertencia: La rúbrica seleccionada es una rúbrica general para el programa académico y solo puede ser editada por el coordinador.\n"+
					"Si usted insiste en continuar, se creará un duplicado de la rúbrica que puede ser modificado solamente para este curso, "+
					"por lo que futuros cambios que haga el coordinador a la rúbrica general no podrán ser reflejados en este curso.\n"+
					"¿Desea continuar?"); 
			if (r == true) 
			{				
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						window.open("rubrics_edit.php?RubricID="+this.responseText+"&backurl=view_syllabus_rubrics.php?ID="+CourseID,"_self");
					}
				}
				xhttp.open("GET", "rubrics_duplicate.php?RubricID="+RubricID+"&PlanID="+PlanID+"&CourseID="+CourseID+"&DuplicateGeneric=true", true);
				xhttp.send();		
			}
		} else {
			window.open("rubrics_edit.php?RubricID="+RubricID+"&CourseID="+CourseID+"&backurl=view_syllabus_rubrics.php?ID="+CourseID,"_self");
		}
		
	}
	function removeRubric(RubricID, Scope, PlanID, CourseID) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				var item = document.getElementById("rub"+RubricID);
				item.parentNode.removeChild(item);	
			}
		}		
		if (Scope == 0) {
			var r = confirm("¿Está seguro que desea eliminar esta rúbrica genérica del curso?.\n"+
				"La rúbrica puede ser vinculada de nuevo usando el botón 'Asociar Rúbrica Genérica'");
			if (r == true) {
				xhttp.open("GET", "rubrics_removegeneric.php?RubricID="+RubricID+"&CourseID="+CourseID, true);
				xhttp.send();
			}		
		} else {
			var r = confirm("Esta acción eliminará la rúbrica definitivamente. No se puede deshacer.\n"+
						"¿Desea continuar?"); 
			if (r == true) {
				xhttp.open("GET", "rubrics_remove.php?RubricID="+RubricID, true);
				xhttp.send();
			}
		}
	}
	function duplicateRubric(RubricID, PlanID, CourseID) {
		var r = confirm("¿Está seguro que desea crear un duplicado de esta rúbrica?"); 
		if (r == true) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var div = document.createElement("DIV");
					div.innerHTML = this.responseText;
					var item = document.getElementById("rub"+RubricID);
					item.parentNode.insertBefore(div.childNodes[0], item.nextSibling);
				}
			}
			xhttp.open("GET", "rubrics_duplicate.php?RubricID="+RubricID+"&PlanID="+PlanID+"&CourseID="+CourseID, true);
			xhttp.send();
		}
	}
	function associateRubric(RubricID, PlanID, CourseID) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				RAPSkillsList.innerHTML = this.responseText;
				RubricIDToAssoc.value = RubricID; 
				associationPanel.style.display = "block";
			}
		}	
		xhttp.open("GET", "rubrics_show_assoc.php?RubricID="+RubricID+"&CourseID="+CourseID, true);
		xhttp.send();
	}
	function doAssoc(includeAll) {
		//Serialize the rubric selection to modify the rubric association
		var chks = RAPSkillsList.getElementsByTagName("input");
		var qStr = "";
		for(i=0; i<chks.length; i++) 
		{	
			if (!includeAll && !chks[i].checked) continue;
			qStr += "&"+chks[i].id+"="+chks[i].checked;
		}
		if (qStr.length == 0) {
			return;
		}
		//Perform rubric association
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				var div = document.createElement("DIV");
				div.innerHTML = this.responseText;
				document.getElementById("rub"+RubricIDToAssoc.value).innerHTML = div.childNodes[0].innerHTML;
				associationPanel.style.display = "none";
			}
		};
		xhttp.open("GET", "rubrics_assoc.php?RubricID="+RubricIDToAssoc.value+
					"&PlanID="+PlanID.value+"&CourseID="+CourseID.value+qStr, true);
		xhttp.send();
	}
	function cancelAssoc() {
		associationPanel.style.display = "none";
		RubricIDToAssoc.value = 0;
		genericRubricPanel.style.display = "none";
	}
	function assocGenericRubric(RubricID, PlanID, CourseID) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				genericRubricPanel.style.display = "none";
				var div = document.createElement("DIV");
				div.innerHTML = this.responseText;
				courseRubrics.appendChild(div.childNodes[0]);
			}
		}	
		xhttp.open("GET", "rubrics_assoc_generic.php?RubricID="+RubricID+"&PlanID="+PlanID+"&CourseID="+CourseID, true);
		xhttp.send();
	}
	function assocGenericRubricOpen(PlanID, CourseID) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				genericRubricList.innerHTML = this.responseText;
				genericRubricPanel.style.display = "block";
			}
		}	
		xhttp.open("GET", "rubrics_show_genericlist.php?PlanID="+PlanID+"&CourseID="+CourseID, true);
		xhttp.send();
	}
	function viewRubric(RubricID) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				RubricViewer.innerHTML = this.responseText;
				RubricViewerPanel.style.display = "block";
			}
		};
		xhttp.open("GET", "rubrics_show.php?RubricID="+RubricID, true);
		xhttp.send();
	}
	function configurePanels() {
		associationPanel.style.display = "none";
		genericRubricPanel.style.display = "none";
		RubricViewerPanel.style.display = "none";
		var span = document.getElementsByClassName("close");
		span[0].onclick = function() { associationPanel.style.display = "none"; }
		span[1].onclick = function() { genericRubricPanel.style.display = "none"; }
		span = document.getElementsByClassName("close-gray");
		span[0].onclick = function() { RubricViewerPanel.style.display = "none"; }
		window.onclick = function(event) {
			if (event.target == RubricViewerPanel) {
				RubricViewerPanel.style.display = "none";
			}
		}
	}
	function exportTable(tableName) {
		tableToExcel(tableName,'Rubrics');
	}
	var tableToExcel = (function() {
		var uri = 'data:application/vnd.ms-excel;base64,'
			, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
			, base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
			, format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
		return function(table, name) {
			if (!table.nodeType) table = document.getElementById(table)
			var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
			window.location.href = uri + base64(format(template, ctx))
		}
	})()
	</script>
</head>

<body onload="configurePanels()">

<?php  
	require('planea_basics.php');
	require('planea_logosbar.php');
	$helptopic = "teacher-rubrics";
	require('planea_syllabusbar.php');
		
	$planea = new planea();
	$conn = $planea->openConnection();
	if (isset($_GET["ID"])) {
		$CourseID = $_GET["ID"];
	}
	if (isset($_POST["CourseID"])) {
		$CourseID = $_POST["CourseID"];
	}
	//Fetch course description
	$sql = "SELECT * FROM courses_general WHERE ID=" . $CourseID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$CourseName = $planea->showCourseTitle($row);
	$canModify = $planea->checkPermission( $_SESSION["RoleID"], $_SESSION["UserID"], $CourseID, 64 );
	$coursebar_opt = 7;
	require('planea_coursebar.php');
?>

 
<form class="planeaForm" id="mainForm" action="view_syllabus_rubrics.php" method="POST">
<b>Rúbricas</b> 
<p style="font-size:small">En esta sección se definen las rúbricas que se emplearán para la evaluación del curso. 
Se recomienda asociar las rúbricas a RAPs o habilidades declaradas para el curso. 
Sin embargo, es posible incluir rúbricas sin esta asocación, por ejemplo, para incluir rúbricas de evaluación de actividades específicas como proyectos.
</p>

<button  onclick="exportTable('courseRubrics')" type="button">Exportar</button>

<input style="display:none" type="number" id="CourseID" name="CourseID" value="<?php echo $row["ID"]; ?>">
<input style="display:none" type="number" id="PlanID" name="PlanID" value="<?php echo $row["PlanID"]; ?>">
<input style="display:none" type="number" id="RubricIDToAssoc" name="RubricID" value=0>

<div id="associationPanel" class="modal">
  <!-- Modal content -->
  <div class="modal-content">
  <div  class="modal-header">
	<span  class="close">&times;</span >
	<h2>RAPs y/o habilidades para asociar a la rúbrica</h2> 
	<p>Seleccione todos los resultados de aprendizaje y habilidades que serán 
		evaluados con la rúbrica. Aquellos que aparecen resaltados ya han 
		sido asociados.
	</p>
  </div>
  <div  class="modal-body">
	<p id="RAPSkillsList"></p>
	<button type="button" onclick="doAssoc(true)">Asociar</button> &nbsp;
	<button type="button" onclick="cancelAssoc()">Cerrar</button>
  </div>
  </div>
</div>

</form> 

<div class="planeaForm" <?php if (!$canModify) { echo "style=\"display:none\""; } ?>>
	<button type="button" onclick="assocGenericRubricOpen(<?php echo $row["PlanID"].",".$CourseID; ?>)">
		Asociar Rúbrica Genérica</button> 
	&nbsp;
	<button type="button" onclick="window.open('rubrics_edit.php?PlanID=<?php echo $row["PlanID"];?>&CourseID=<?php echo $CourseID;?>&backurl=view_syllabus_rubrics.php?ID=<?php echo $CourseID; ?>','_self')">
		*Crear Nueva Rúbrica para el Curso*</button>

	<div id="genericRubricPanel" class="modal">
	  <!-- Modal content -->
	  <div class="modal-content">
	  <div  class="modal-header">
		<span  class="close">&times;</span >
		<h2 >Rúbricas genéricas que se pueden asociar al curso:</h2 >
	  </div>
	  <div  class="modal-body">
		<p id="genericRubricList"></p>
		<button type="button" onclick="cancelAssoc()">Cerrar</button>
	  </div>
	  </div>
	</div>
</div>

<div id="courseRubrics">
	<?php $planea->showRubricsByCourse( $CourseID, $canModify ); ?>
</div>

<div class="planeaForm">
	<b>RAPs y habilidades que no han sido asociadas a ninguna rúbrica</b> 
	<?php $planea->showNotAssociatedSkillToAnyRubric( $CourseID ); ?>
</div>

<div id="RubricViewerPanel" class="modal" style="display:none">
  <!-- Modal content -->
  <div class="modal-content">
  <div  class="modal-body">
	<span  class="close-gray">&times;</span >
	<small><div id="RubricViewer"></div><small>
   </div>
  </div>
</div>	

<?php
	$planea->closeConnection();	
?>

</body>
</html>
