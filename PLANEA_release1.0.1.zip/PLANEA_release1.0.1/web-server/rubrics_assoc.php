<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
//Associate ILOs or Skills to the rubric 
$RubricID = $_GET["RubricID"];
$PlanID = $_GET["PlanID"];
$CourseID = $_GET["CourseID"];
foreach ($_GET as $key=>$value) {
	if (substr($key,0,3) == "chk") {	
		$type = substr($key,3,1);
		$id = substr($key,4);			
		if ($value=="true") { //associate rubric. First check if it is already associated
			$sql = "SELECT ID FROM rubrics_assoc WHERE RubricID=".$RubricID." AND RapSkillID=".$id." AND RapSkillType=".$type;
			$result = $planea->conn->query($sql);
			if ($result->num_rows==0) {
				$sql = "INSERT INTO rubrics_assoc(RubricID, PlanID, CourseID, RapSkillID, RapSkillType) 
						VALUES (".$RubricID.",".$PlanID.",".$CourseID.",".$id.",".$type.")";
				$result = $planea->conn->query($sql);
			}
		} else { //remove association if checkbox is false
			$sql = "DELETE FROM rubrics_assoc WHERE RubricID=".$RubricID." AND RapSkillID=".$id." AND RapSkillType=".$type;
			$result = $planea->conn->query($sql);
		}
	}
}
if (isset($_GET["UserID"]) && isset($_GET["SemesterID"])) {
	$planea->showRubricsByUserCourseItem( $RubricID, $PlanID, $CourseID, $_GET["SemesterID"], $_GET["UserID"] );
} else {
	$planea->showRubricsByCourseItem( $RubricID, $PlanID, $CourseID );
}

$planea->closeConnection();
?>