<script>
	function setModifiedFlag() { <?php if ($canModify) { echo "window.onbeforeunload = function() { return true; };"; } ?> 	}
	function clearModifiedFlag() { window.onbeforeunload = null; return true; }
</script>
<ul class="navbar"> 
<li><a <?php if ($coursebar_opt==1) echo "class=\"active\""; ?> href="view_syllabus.php?ID=<?php echo $CourseID ?>">Generalidades</a></li>
<li><a <?php if ($coursebar_opt==2) echo "class=\"active\""; ?> href="view_syllabus_desc.php?ID=<?php echo $CourseID ?>">Descripción</a></li>
<li><a <?php if ($coursebar_opt==3) echo "class=\"active\""; ?> href="view_syllabus_raps.php?ID=<?php echo $CourseID ?>">RAPs</a></li>
<li><a <?php if ($coursebar_opt==4) echo "class=\"active\""; ?> href="view_syllabus_act.php?ID=<?php echo $CourseID ?>">Metodología</a></li>
<li><a <?php if ($coursebar_opt==5) echo "class=\"active\""; ?> href="view_syllabus_eval.php?ID=<?php echo $CourseID ?>">Evaluación</a></li>
<li><a <?php if ($coursebar_opt==6) echo "class=\"active\""; ?> href="view_syllabus_cont.php?ID=<?php echo $CourseID ?>">Contenidos</a></li>
<li><a <?php if ($coursebar_opt==7) echo "class=\"active\""; ?> href="view_syllabus_rubrics.php?ID=<?php echo $CourseID ?>">Rúbricas</a></li>
<li><a <?php if ($coursebar_opt==8) echo "class=\"active\""; ?> href="view_syllabus_biblio.php?ID=<?php echo $CourseID ?>">Bibliografía</a></li>
<li><a href="#"> <?php echo $CourseName ?> </a></li>
</ul>
<?php 
	if (!$canModify) {
		echo "<p class=\"warningbox\">Esta sección es de solo lectura. No tiene privilegios para modificar la información aquí contenida.</p>";
	}
?>
