<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
</head>

<body>

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();  
	if ($_SESSION["RoleID"]!=planea::roleUser) {
		exit("Seleccione el rol Docente");
	}
	
	$CourseID 	= $_GET["ID"];
	$SemesterID = isset($_GET["SemesterID"]) ? $_GET["SemesterID"] : $planea->getDefaultSemester();
	$UserID = $_SESSION["UserID"];
	
	$sql = "SELECT Nombre,PlanID FROM courses_general WHERE ID=" . $CourseID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$CourseName = $row["Nombre"]."(".$SemesterID.")";
	$Action = 5;
?>
	<script type="text/javascript" language="javascript" src="planning_course.js"></script>	
	


<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="planning_course_user.php">Planeación de Cursos</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#teacher-planning5" target="PLANEA-help">?</a></li>
</ul>

<ul class="navbar"> 
<li>
	<a <?php if ($Action==1) echo "class=\"active\""; ?> href="planning_course_howtos.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 1: Preguntas</a>
</li>
<li>
	<a <?php if ($Action==2) echo "class=\"active\""; ?> href="planning_course_activities.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 2: Actividades</a>
</li>
<li>
	<a <?php if ($Action==3) echo "class=\"active\""; ?> href="planning_course_schedule.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 3: Cronograma</a>
</li>
<li>
	<a <?php if ($Action==4) echo "class=\"active\""; ?> href="planning_course_eval.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 4: Evaluación</a>
</li>
<li>
	<a <?php if ($Action==5) echo "class=\"active\""; ?> href="planning_course_rubrics.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 5: Rúbricas
	</a>
</li>
<li>
	<a <?php if ($Action==6) echo "class=\"active\""; ?> href="planning_course_summary.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Resumen
	</a>
</li>
<li><a href="view_syllabus.php<?php echo "?ID=".$CourseID;?>"> <?php echo $CourseName; ?> </a></li>
</ul>


<!-- FORM FOR CONFIGURING RUBRICS -->

<div id="step5" style="display:<?php echo ($Action==5) ? "block" : "none"; ?>">
	<div class="planeaForm">
		<small><p>En esta sección se visualizan las rúbricas asociadas a las actividades. 
		Se muestran con diferentes colores el tipo de rúbrica: genéricas del plan de estudios (azul), 
		establecidas en el sílabo del curso (verde) y específicas para una actividad (gris). Estas rúbricas se pueden editar o borrar.
		</p></small>
		<button  onclick="exportRubrics('courseRubrics')" type="button">Exportar</button>
	</div>
	<div id="courseRubrics">
		<?php $planea->showRubricsByUserCourse( $CourseID, $SemesterID, $UserID );?>
	</div>
	<div id="associationPanel" class="modal">
	  <!-- Modal content -->
	  <div class="modal-content">
	  <div  class="modal-header">
		<span  class="close">&times;</span >
		<h2>Actividades asociadas a la rúbrica</h2> 
		<p>Seleccione todas las actividades del curso que serán evaluadas con la rúbrica. Aquellas que aparecen resaltadas ya han 
			sido asociadas.
		</p>
	  </div>
	  <div  class="modal-body">
		<p id="assocActList"></p>
		<input type="button" onclick="assocRubGo(true)" value="Asociar"> &nbsp;
		<button type="button" onclick="assocRubCancel()">Cerrar</button>
	  </div>
	  </div>
	</div>
	<input style="display:none" type="number" id="RubricIDToAssoc" name="RubricID" value=0>
</div>

<?php $planea->closeConnection(); ?>

</body>
</html>
