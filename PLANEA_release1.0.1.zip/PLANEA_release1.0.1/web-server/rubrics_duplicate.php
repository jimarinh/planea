<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();

//Duplicate rubric 
$NewRubricID = $planea->cloneRubric($_GET["RubricID"], true);

if ($NewRubricID > 0) {	
	//Insert new association
	if (isset($_GET["DuplicateGeneric"])) { //if duplicate a generic rubric
		if (isset($_GET["UserID"]) && isset($_GET["SemesterID"])) {
			$sql = "UPDATE rubrics_assoc SET RubricID=".$NewRubricID." WHERE RubricID=".
					$_GET["RubricID"]." AND RapSkillType=4 AND RapSkillID IN 
					(SELECT ID FROM teacher_activities WHERE CourseID=".
					$_GET["CourseID"]." AND UserID=".$_GET["UserID"]." AND Semester='".$_GET["SemesterID"]."')";
		} else {
			$sql = "UPDATE rubrics_assoc SET RubricID=".$NewRubricID." WHERE RubricID=".$_GET["RubricID"]." AND CourseID=".$_GET["CourseID"]." AND RapSkillType!=4";
		}
		$res = $planea->conn->query($sql);	
		echo $NewRubricID;
	} else {
		$PlanID = $_GET["PlanID"];
		if (isset($_GET["CourseID"])) {
			$courseID = $_GET["CourseID"];
		} else {
			$courseID = 0;
		}
		if (isset($_GET["ActID"])) {
			$actID = $_GET["ActID"];
			$type = 4;
		} else {
			$actID = 0;
			$type = 0;
		} 
		$sql = "INSERT INTO rubrics_assoc (RubricID,PlanID,CourseID,RapSkillID,RapSkillType) VALUES (".
			$NewRubricID.",".$PlanID.",".$courseID.",".$actID.",".$type.")";
		$res = $planea->conn->query($sql);	
	
		if ($courseID == 0) {
			$planea->showRubricsByPlanItem( $NewRubricID, $PlanID );
		} else {
			if ($actID == 0) {
				$planea->showRubricsByCourseItem( $NewRubricID, $PlanID, $courseID );
			} else {
				$planea->showRubricsByUserCourseItem( $NewRubricID, $PlanID, $courseID, $_GET["SemesterID"], $_GET["UserID"] );
			}
		}
	}
}

		
$planea->closeConnection();
?>