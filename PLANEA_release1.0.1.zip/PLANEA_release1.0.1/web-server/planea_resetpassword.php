<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$userID = $_GET["userID"];
$sql = "SELECT * FROM users WHERE ID=" . $userID ;
$result = $planea->conn->query($sql);
$row = $result->fetch_assoc();
$sql = "UPDATE users SET password='". password_hash($row["countryID"], PASSWORD_DEFAULT) . "' WHERE ID=" . $userID;
$planea->conn->query($sql);
$msg = planea::msg_passwordreset1 . $row["countryID"].".". planea::msg_passwordreset2;
$msg = wordwrap($msg,70);
mail( $row["email"], "PLANEA - password reset", $msg );
$planea->closeConnection();
?>