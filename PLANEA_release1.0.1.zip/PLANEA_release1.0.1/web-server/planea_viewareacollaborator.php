<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	$planID = $_GET["PlanID"];
	$semName = $_GET["SemName"];
	$planea->showAreaCollaboratorsForEval($planID,$semName);
	$planea->closeConnection();
?>