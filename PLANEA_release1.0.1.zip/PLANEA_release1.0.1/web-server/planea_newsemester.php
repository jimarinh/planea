<?php
	require('planea_basics.php');  
	$planea = new planea();
	$conn = $planea->openConnection();
	//Verify if semester does not exist into semester list
	$sql = "SELECT ID FROM semesters WHERE SemesterName='".$_GET["SemName"]."'";
	$res = $planea->conn->query($sql);
	if ($res->num_rows==0) { 		
		$sql = "INSERT INTO semesters (SemesterName) VALUES ('" . $_GET["SemName"]."')";
		$res = $planea->conn->query($sql);
	}
	$planea->showSemesterList();
	$planea->closeConnection();
?>