<?php 
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
if ($_GET["showElect"]=="true") 
	$sql = "SELECT ID, Nombre, Semestre, Codigo FROM courses_general WHERE PlanID=".$_GET["PlanID"]." AND VisVersion=1 ORDER BY Semestre";
else
	$sql = "SELECT ID, Nombre, Semestre, Codigo FROM courses_general WHERE CourseKeyID NOT IN (SELECT CourseID FROM courses_elective) AND PlanID = ".$_GET["PlanID"]." AND VisVersion=1 ORDER BY Semestre";
$result = $planea->conn->query($sql);
$nrows = $result->num_rows; 
$courses = array();
$ncourses = 0;
if ($nrows > 0) {
	while($row = $result->fetch_assoc()) {
		$course = ["ID" => intval($row["ID"]), "Sem" => intval($row["Semestre"]), "Name" => $row["Nombre"], "Code"=>$row["Codigo"]];
		$courses[$ncourses] = $course; 
		$ncourses++;
	}
}
echo "<table  id=\"RqTb\"><tr><th>Semestre</th><th>Espacio Académico</th><th>Código</th><th>Requisitos</th></tr>\n";	
for ($n=0; $n<$ncourses; $n++ ) {
	echo "<tr><td>".$courses[$n]["Sem"]."</td><td>".$courses[$n]["Name"]."</td><td>".$courses[$n]["Code"]."</td><td>";
	$sql = "SELECT courses_reqs.RequirementID, courses_general.Nombre, courses_general.Codigo FROM courses_reqs 
			JOIN courses_general ON courses_reqs.RequirementID=courses_general.CourseKeyID WHERE courses_reqs.CourseID=".$courses[$n]["ID"]." AND courses_general.VisVersion=1";
	$result = $planea->conn->query($sql);
	$nrows = $result->num_rows;
	if ($nrows > 0) {
		while($row = $result->fetch_assoc()) {
			if (!empty($row["Codigo"])) {
				echo $row["Nombre"]."(".$row["Codigo"].")";	
			} else {
				echo $row["Nombre"];
			}
			if ($nrows>1) echo "<br>";
		}
	}
	echo "</td></tr>\n";
}
echo "</table>";			  
$planea->closeConnection();
?>