<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
</head>

<body>
<?php 
	require('planea_basics.php');
	require('stats_viewcredits_table.php');
	
	$planea = new planea();
	$conn = $planea->openConnection(); 

	$planID = $_GET["PlanID"];
	renderCreditTable( $planID, $planea, false );	
	$planea->closeConnection();
?> 	
</body>
</html>