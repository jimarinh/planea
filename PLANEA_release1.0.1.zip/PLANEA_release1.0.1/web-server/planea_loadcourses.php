<?php
	require('planea_basics.php');  
	$planea = new planea();
	$conn = $planea->openConnection();	
	if ( $_GET["state"] == "plan" )
		$planea->showCourseListByPlan($_GET["plan"]);
	else
		$planea->showCourseListByVersionState($_GET["plan"],$_GET["state"]);
	$planea->closeConnection();
?>