<?php
	require('planea_basics.php');  
	$planea = new planea();
	$conn = $planea->openConnection();
	$sql = "DELETE FROM courses_elective WHERE ID=" . $_GET["ElectiveID"]; 
	$planea->conn->query($sql);
	$planea->showElectives($_GET["plan"]);
	$planea->closeConnection();
?>