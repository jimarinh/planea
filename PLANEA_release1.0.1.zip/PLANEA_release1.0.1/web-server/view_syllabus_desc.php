<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">	
</head>

<body>

<?php  
	require('planea_basics.php');
	require('planea_logosbar.php');
	$helptopic = "teacher-syllabusdesc";
	require('planea_syllabusbar.php');
		
	$planea = new planea();
	$conn = $planea->openConnection();
	if (isset($_GET["ID"])) {
		$CourseID = $_GET["ID"];
	}
	if (isset($_POST["CourseID"])) {
		$CourseID = $_POST["CourseID"];
		//Si se da clic en el botón Guardar, almacena la información en la base de datos
		foreach ($_POST as $key=>$value) {
			$sql = "UPDATE courses_general SET ". $key . "='". $value ."' WHERE ID=" . $CourseID;
			$conn->query($sql);
		}
	}
	$sql = "SELECT * FROM courses_general WHERE ID=" . $CourseID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$CourseName = $planea->showCourseTitle($row);
	$canModify = $planea->checkPermission( $_SESSION["RoleID"], $_SESSION["UserID"], $CourseID, 2 );
	$coursebar_opt = 2;
	require('planea_coursebar.php');
?>


<form class="planeaForm" id="mainForm" action="view_syllabus_desc.php" onsubmit="return clearModifiedFlag()" method="POST">

<script type="text/javascript" src="planea_formattextarea.js"></script> 
<script type="text/javascript" src="nicEdit.js"></script> 
<script type="text/javascript">
  bkLib.onDomLoaded(function() {
		nicEditors.allTextAreas({buttonList : ['bold','italic','underline','subscript','superscript','ol','ul','indent','outdent']});
		planeaFormatTextarea.allTextAreas();
	});
</script>  
<b>Descripción</b> 
<p style="font-size:x-small">Un párrafo que resume la naturaleza del espacio académico, núcleo o catedra, 
en términos de la disciplina</p>
<textarea name="Descripcion" rows=8 style="width: 100%;"><?php echo ($row["Descripcion"]); ?></textarea><br><br>


<b>Justificación</b> <br>
<p style="font-size:x-small">Se hace énfasis en: La formación básica, la función del espacio en el área, 
la secuencia a la cual responde, los vínculos con las líneas de investigación vigentes y con los proyectos 
terminados y en curso</p>
<textarea name="Justificacion" rows=8 style="width: 100%;"><?php echo ($row["Justificacion"]); ?></textarea><br><br>

<b>Procesos Integrativos</b> <br>
<p style="font-size:x-small">Se mencionan proyectos de investigación, semilleros, grupos de estudio, 
actividades de los estudiantes, actividades de extensión  que soporta todo lo relacionado con el espacio
 y se describen las relaciones o construcciones que con los ítem anteriores se flexibiliza el proceso de formación</p>
<textarea name="ProcesosIntegracion" rows=8 style="width: 100%;"><?php echo ($row["ProcesosIntegracion"]); ?></textarea><br> 

<input style="display:none" type="number" name="CourseID" value="<?php echo $row["ID"]; ?>">

<?php 
	if ($canModify) { 
		echo "<input type=\"submit\" value=\"Guardar\">"; 
	}
	$planea->closeConnection();	
?>
<input type="submit" formaction="syllabus.php" value="Cancelar"> 
</form>  

</body>
</html>
