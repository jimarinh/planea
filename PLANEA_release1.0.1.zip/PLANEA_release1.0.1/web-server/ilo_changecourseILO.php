<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "UPDATE courses_ilos SET Text='".$_GET["Text"]."',VerbID=".$_GET["VerbID"].
		",CategoryID=".$_GET["CatID"].",ProgramILOID=".$_GET["ProgILOID"].
		" WHERE ID=".$_GET["iloID"];
$result = $planea->conn->query($sql);
echo $planea->showRAPList($_GET["CourseID"],false,true);
$planea->closeConnection();
?>