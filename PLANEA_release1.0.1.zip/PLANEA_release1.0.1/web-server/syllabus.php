<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="ISO-8859-1">
	<title>PLANEA</title>
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<style>
		.custom-combobox {
			position: relative;
			display: inline-block;
		}
		.custom-combobox-toggle {
			position: absolute;
			top: 0;
			bottom: 0;
			margin-left: -32px;
			padding: 0;
		}
		.custom-combobox-input {
			margin: 0;
			padding: 3px 6px;
		}
		.custom-overflow {
			height: 200px;
		}
		.ui-autocomplete {
			max-height: 300px;
			overflow-y: auto;
			overflow-x: hidden;
			padding-right: 20px;
		}
	</style>
	<script src="combobox_search.js"></script>
	<script>
	  $( function() { 
		$("#ListOfCourses").combobox({ 
			select: function (event, ui) { 
				changeCourse(this.value);
			} 
		});
		} );
	</script>
	<script>
		function getPlan() {
			var e = document.getElementById("ListOfStudyPlans");
			if (e.selectedIndex == -1) {
				return 0;
			}
			return parseInt(e.options[e.selectedIndex].value);
		}
		function resetListOfCourses() {
			$("#ListOfCourses option").each(function(){ $(this).removeAttr("selected") });
			$("#ListOfCourses option:first").attr("selected", "selected");
			$("input.ui-autocomplete-input").val("");
			document.getElementById("ListOfVersions").innerHTML = "";
		}
		function updateListOfCourses(textHTML) {
			document.getElementById("ListOfCourses").innerHTML = "<option value=\"\">Seleccione uno...</option>"+textHTML;
			resetListOfCourses();
		}
		function changePlan() {
			var e = document.getElementById("ListOfStudyPlans");
			if (e.selectedIndex == -1) {
				return null;
			}
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					updateListOfCourses(this.responseText);
				}
				messageStr.style = "display:none";
			};
			xhttp.open("GET", "planea_loadcourses.php?plan="+e.value+"&state=plan", true);
			xhttp.send();
		}
		function changeCourseNoCombobox() {
			var e = document.getElementById("ListOfCourses");
			changeCourse(e.value);
		}
		function changeCourse(value) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var e = document.getElementById("ListOfVersions");
					e.innerHTML = this.responseText;
					document.getElementById("versionTitle").innerHTML = e.options[e.selectedIndex].text;
					syllabusActions.style = "display:inline-block";
					syllabusPleaseWait.style = "display:none";
				}
				messageStr.style = "display:none";
			};
			syllabusActions.style = "display:none";
			syllabusPleaseWait.style = "display:inline-block";
			xhttp.open("GET", "planea_loadversionslist.php?courseID="+value, true);
			xhttp.send();	
		}
		function viewNewSyllabusInfo() {
			if (getPlan()!=0) {
				document.getElementById("newSyllabusInfo").style.display = "inline";
				document.getElementById("newSyllabusButton").style.display = "none";
			}
		}
		function cancelNewSyllabusInfo() {
			document.getElementById("newSyllabusInfo").style.display = "none";
			document.getElementById("newSyllabusButton").style.display = "inline";
		}
		function newSyllabusInfo() {
			var xhttp = new XMLHttpRequest();
			var e = document.getElementById("newSyllabusName");
			document.getElementById("newSyllabusInfo").style.display = "none";
			document.getElementById("newSyllabusButton").style.display = "inline";
			coursename=e.value;
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					updateListOfCourses(this.responseText);
					messageStr.innerHTML="El curso "+coursename+" fue creado exitosamente";
					messageStr.style = "display:inline";
				}
			};
			xhttp.open("GET", "planea_newsyllabus.php?courseName="+coursename+"&plan="+getPlan(), true);
			xhttp.send();
		}

		function removeSyllabus() {
			var xhttp = new XMLHttpRequest();
			var e = document.getElementById("ListOfCourses");
			if (e.selectedIndex == -1)
				return null;
			var value = e.options[e.selectedIndex].value;
			if (value=="")
				return null;
			var coursename = e.options[e.selectedIndex].text;
			var r = confirm("Todas las versiones del espacio académico se eliminarán.\n"+
							"Esta acción no se puede deshacer.\n\n"+
							"¿Desea eliminar el espacio académico '" + coursename + "'?");
			if (r == true) {	
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						updateListOfCourses(this.responseText);
						messageStr.innerHTML="El curso "+coursename+" fue eliminado exitosamente";
						messageStr.style = "display:inline";
					}
				};
				xhttp.open("GET", "planea_removesyllabus.php?courseID="+value+"&plan="+getPlan(), true);
				xhttp.send();
			}
		}
		function validateCourseID() {
			var e = document.getElementById("ListOfCourses");
			if (e.selectedIndex == -1)
				return false;
			var value = e.options[e.selectedIndex].value;
			if (value == "") 
				return false;
			return true;
		}
		function configureVerControlPanel() {
			versionPanel.style.display = "none";
			var span = document.getElementsByClassName("close")[0];
			span.onclick = function() { versionPanel.style.display = "none"; }
			window.onclick = function(event) {
				if (event.target == versionPanel) {
					versionPanel.style.display = "none";
				}
			}
			changePlan();
		}
		function versionControl() {
			if (validateCourseID()) {
				versionPanel.style.display = "block";
				var k = document.getElementById("ListOfCourses");
				document.getElementById('versionCourseName').innerHTML  = k.options[k.selectedIndex].text;
				var c = document.getElementById("ListOfVersions");
				document.getElementById('versionName').innerHTML  = c.options[c.selectedIndex].text;
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						var value = parseInt(this.responseText);
						var style;
						if ((value&1) == 1) style = "block"; else style = "none"; document.getElementById("verPanelAprov").style.display = style;
						if ((value&2) == 2) style = "block"; else style = "none"; document.getElementById("verPanelRem").style.display = style;
						if ((value&4) == 4) style = "block"; else style = "none"; document.getElementById("verPanelNew").style.display = style;
						if ((value&8) == 8) style = "block"; else style = "none"; document.getElementById("verPanelOpen").style.display = style;
					}
				};
				xhttp.open("GET", "planea_loadversionpanel.php?CourseID="+c.value+"&CourseKeyID="+k.value, true);
				xhttp.send();				
			}
		}
		function versionControlGo(action) {
			var xhttp = new XMLHttpRequest();
			versionPanel.style.display = "none";
			var urlEncodedData = $( "#formSyllabus" ).serialize();		
			var url;
			switch (action) {
				case 1: url = "verscontrol_approve.php"; 
					var re = /^\d{4}\-\d{1,2}\-\d{1,2}$/;
					if( (versionDate.value == '') || (versionDate.value != '' && !versionDate.value.match(re)) ) {
						messageStr.innerHTML="Especifique una fecha válida";
						messageStr.style = "display:inline";
						return;
					} else
					break;
				case 2: url = "verscontrol_remove.php";
					if (confirm("¿Desea eliminar la versión?") == false) { return; }
					break;
				case 4: url = "verscontrol_newcopy.php"; break;
				case 8: url = "verscontrol_open.php"; break;
			}
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					if (this.responseText.length>0) { 
						messageStr.innerHTML=this.responseText; 
						messageStr.style = "display:inline";
					}
					resetListOfCourses();
				}
			};
			xhttp.open("GET", url+"?"+decodeURI(urlEncodedData));
			xhttp.send();
		}
	</script>
</head>

<body onload="configureVerControlPanel()">

<?php  
	require('planea_logosbar.php');
?>


<?php
require('planea_basics.php');
$planea = new planea();
$conn = $planea->openConnection();

switch($_SESSION["RoleID"]) {
	case planea::roleAdmin: $helptopic = "admin-syllabus"; break;
	case planea::roleCoord: $helptopic = "coord-studyplan"; break;
	case planea::roleUser:  $helptopic = "teacher-syllabusmain"; break;	
}	
require('planea_syllabusbar.php');
  
if ($_SESSION["RoleID"]==planea::roleUser) {
	echo "<div class=\"planeaForm\"><p>Mis espacios académicos: </p>";
	$planea->showUserAssignmentList( $_SESSION["UserID"], "view_syllabus", 0 );
	echo "</div>";
}
?>

<p class="warningbox" style="display:none" id="messageStr"></p> 

<form class="planeaForm" action="syllabus_electives.php" method="GET">
Plan:
<select id="ListOfStudyPlans" name="PlanID" onchange="changePlan()">
<?php 
	$defaultPlan = $_SESSION["DefaultPlan"];
	if ($_SESSION["RoleID"]==planea::roleCoord) $defaultPlan = $planea->showStudyPlan($defaultPlan,false,$_SESSION["UserID"]); 
	else $planea->showStudyPlan($defaultPlan); 
?>
</select>

<?php 
	if ($_SESSION["RoleID"]==planea::roleCoord) {
		echo "&nbsp; &nbsp; <input type=\"submit\" formaction=\"syllabus_electives.php\" value=\"Configurar Espacios Electivos\">\n";
		echo "&nbsp; &nbsp; <input type=\"submit\" formaction=\"stats_viewcredits.php\" formmethod=\"POST\" value=\"Definir Créditos del Currículo\">\n";
		echo "&nbsp; &nbsp; <input type=\"submit\" formaction=\"syllabus_approvemultiple.php\" formmethod=\"POST\" value=\"Aprobar Múltiples Sílabos\">\n";
		echo "&nbsp; &nbsp; <input type=\"submit\" formaction=\"syllabus_openmultiple.php\" formmethod=\"POST\" value=\"Establecer Múltiples Sílabos en Borrador\">\n";
	}
?>
</form>  


<form class="planeaForm" id="formSyllabus" action="view_syllabus.php" onsubmit="return validateCourseID()" method="GET">

Espacio Académico:
<select id="ListOfCourses" name="CourseKeyID" onchange="changeCourseNoCombobox()">
<option value="">Seleccione uno...</option>
</select>

&nbsp;

<div id="syllabusPleaseWait" style="display:none">
<img src="images\load.gif" alt="Por favor espere..." height="20" width="20">
</div>

<div id="syllabusActions" style="display:none">
 
Versión:
<select id="ListOfVersions" name="ID" <?php if($_SESSION["RoleID"]!=planea::roleCoord) echo "style=\"display:none\""; ?> >
</select>
<i id="versionTitle" <?php if($_SESSION["RoleID"]==planea::roleCoord) echo "style=\"display:none\""; ?>>N.A.</i>

&nbsp;

<input type="submit" value="Abrir">  
<input type="submit" formaction="viewpdf_syllabus.php" formtarget="_blank" value="Ver PDF">

<?php 
	if ($_SESSION["RoleID"]==planea::roleCoord) {
		echo "<button type=\"button\" onclick=\"removeSyllabus()\">Eliminar</button>\n  &nbsp;"; 
		echo "<button type=\"button\" onclick=\"versionControl()\">Control de Versiones</button>\n </div> <br> <br>"; 
		
		echo "<div id=\"newSyllabusInfo\" style=\"display:none\">\n";
		echo "Nombre del nuevo espacio académico: <input type=\"text\" id=\"newSyllabusName\" size=50>\n";
		echo "<button type=\"button\" onclick=\"newSyllabusInfo()\">Crear</button>  &nbsp;\n";
		echo "<button type=\"button\" onclick=\"cancelNewSyllabusInfo()\">Cancelar</button>\n";
		echo "</div>";
					
		echo "<button type=\"button\" id=\"newSyllabusButton\" onclick=\"viewNewSyllabusInfo()\">*Nuevo Espacio Académico</button>\n";
	} else {
		echo "</div>";
	}
?>

<div id="versionPanel" class="modal">
  <!-- Modal content -->
  <div class="modal-content">
  <div  class="modal-header">
    <span  class="close">&times;</span >
    <h2 >Control de Versiones</h2 >
  </div>
  <div  class="modal-body">
    <p>Acciones posibles sobre la versión <b id="versionName"></b> del curso <b id="versionCourseName"></b></p>
    <p id="verPanelAprov">Aprobar según... Fecha <input name="versionDate" id="versionDate" type="date"> 
		Anotación <input name="versionAnotacion" type="text"> Responsable <input name="versionResponsable" type="text"> 
		<button type="button" onclick="versionControlGo(1)">Aprobar</button></p>
	<p id="verPanelRem"> <button type="button" onclick="versionControlGo(2)">Remover</button></p>
	<p id="verPanelNew"> <button type="button" onclick="versionControlGo(4)">Crear nueva versión basada en ésta</button></p>
	<p id="verPanelOpen"> <button type="button" onclick="versionControlGo(8)">Abrir como borrador para modificarla</button></p>
  </div>
</div>
</div>
</form>



<?php $planea->closeConnection(); ?>

</body>
</html>
