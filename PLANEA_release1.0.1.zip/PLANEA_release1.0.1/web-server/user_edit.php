<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "SELECT ID, name, email, role, countryID, defaultPlan FROM users WHERE ID=" . $_GET["userID"];
$result = $planea->conn->query($sql);
$row = $result->fetch_assoc();
header('Content-type: application/json');
$row["name"] = $row["name"];
echo json_encode($row);
$planea->closeConnection();
?>