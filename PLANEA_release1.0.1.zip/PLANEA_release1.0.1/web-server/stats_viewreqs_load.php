<?php 
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
if ($_GET["showElect"]=="true") 
	$sql = "SELECT CourseKeyID, Nombre, Semestre FROM courses_general WHERE PlanID=".$_GET["PlanID"]." AND VisVersion=1 ORDER BY Semestre";
else
	$sql = "SELECT CourseKeyID, Nombre, Semestre FROM courses_general WHERE CourseKeyID NOT IN (SELECT CourseID FROM courses_elective) AND PlanID = ".$_GET["PlanID"]." AND VisVersion=1 ORDER BY Semestre";
$result = $planea->conn->query($sql);
$nrows = $result->num_rows; 
$courses = array();
$ncourses = 0;
if ($nrows > 0) {
	while($row = $result->fetch_assoc()) {
		$course = ["ID" => intval($row["CourseKeyID"]), "Sem" => intval($row["Semestre"]), "Name" => $row["Nombre"],
					"Row" => 0, "C" => 0, "NO" => 0, "AO" => 0, "NI" => 0, "AI" => 0];
		$courses[$ncourses] = $course; 
		$ncourses++;
	}
}
$electives = array();
$nelectives = 0;	
if ($_GET["showElect"]=="false") {
	//Inserta las categorías de cursos electivos
	$sql = "SELECT CategoryName, Semester FROM courses_electivecats WHERE PlanID = ".$_GET["PlanID"]." ORDER BY Semester";
	$result = $planea->conn->query($sql);
	$nrows = $result->num_rows;
	if ($nrows > 0) {
		while($row = $result->fetch_assoc()) {
			$id = $ncourses+100000;
			$course = ["ID" => $id, "Sem" => intval($row["Semester"]), "Name" => $row["CategoryName"],
						"Row" => 0, "C" => 0, "NO" => 0, "AO" => 0, "NI" => 0, "AI" => 0];
			$courses[$ncourses] = $course; 
			$ncourses++;
			$electives[$nelectives] = ["ID" => $id];
			$nelectives++;
		}
	}
	//Captura los requisitos
	$sql = "SELECT courses_general.CourseKeyID, RequirementID FROM courses_reqs 
			JOIN courses_general ON courses_reqs.CourseID=courses_general.ID WHERE courses_general.CourseKeyID NOT IN (SELECT CourseID FROM courses_elective) AND courses_general.PlanID=".$_GET["PlanID"]." AND courses_general.VisVersion=1";
			
} else { 
	//Captura los IDs de los cursos electivos
	$sql = "SELECT CourseID FROM courses_elective JOIN courses_electivecats ON courses_elective.CategoryID = courses_electivecats.ID WHERE courses_electivecats.PlanID =".$_GET["PlanID"];
	$result = $planea->conn->query($sql);
	$nrows = $result->num_rows;
	if ($nrows > 0) {
		while($row = $result->fetch_assoc()) {
			$electives[$nelectives] = ["ID" => intval($row["CourseID"])];
			$nelectives++;
		}
	}
	//Captura los requisitos
	$sql = "SELECT courses_general.CourseKeyID, RequirementID FROM courses_reqs 
			JOIN courses_general ON courses_reqs.CourseID=courses_general.ID WHERE courses_general.PlanID=".$_GET["PlanID"]." AND courses_general.VisVersion=1";
}
$result = $planea->conn->query($sql);
$nrows = $result->num_rows; 
$reqs = array();
$nreqs = 0;
if ($nrows > 0) {
	while($row = $result->fetch_assoc()) {
		$req = ["E" => intval($row["CourseKeyID"]), "R" => intval($row["RequirementID"]) ];
		$reqs[$nreqs] = $req;
		$nreqs++;
	}		
}   
header('Content-type: application/json');
$json_data = array();
$json_data["Courses"] = $courses;
$json_data["Reqs"] = $reqs;
$json_data["Electives"] = $electives;
echo json_encode($json_data);
$planea->closeConnection();
?>