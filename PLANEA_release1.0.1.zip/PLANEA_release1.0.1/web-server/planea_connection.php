<?php 
//PLANEA  v1.0
//
// This class defines the server configuration 
//
//  (c) 2020 	Jorge Iván Marín Hurtado
//				email: jorgemarin@uniquindio.edu.co
//				Programa de Ingeniería Electrónica, Universidad del Quindío
//				Cra 15 Calle 12N Armenia, Quindío, Colombia
class planeaConnection 
{
	public $conn;     //Server connection

	//Establishes the server connection
	function openConnection()
	{
	  $servername = "localhost";
	  $username   = "root";
	  $password   = "";
	  $dbname     = "planea-db";	
	    // Create a server connection
		$this->conn = new mysqli($servername, $username, $password, $dbname);
		$this->conn->set_charset("utf8");
		// Check if server connection works
		if ($this->conn->connect_error) {
		   die("Fallo en la conexión con el servidor: " . $this->conn->connect_error);
		}
		return $this->conn;
	}
	
	function closeConnection()
	{
		$this->conn->close();
	}  
}
?>
