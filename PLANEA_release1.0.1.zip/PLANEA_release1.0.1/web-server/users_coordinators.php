<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<style>
		.custom-combobox {
			position: relative;
			display: inline-block;
		}
		.custom-combobox-toggle {
			position: absolute;
			top: 0;
			bottom: 0;
			margin-left: -32px;
			padding: 0;
		}
		.custom-combobox-input {
			margin: 0;
			padding: 3px 6px;
		}
		.custom-overflow {
			height: 200px;
		}
		.ui-autocomplete {
			max-height: 300px;
			overflow-y: auto;
			overflow-x: hidden;
			padding-right: 20px;
		}
	</style>
</head>

<body>

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	//Check for credentials
	if ($_SESSION["RoleID"]!=planea::roleAdmin) {
		exit("<p><font color=\"red\">No tiene permiso para acceder a esta sección</font><p>");
	}
?>

	<script src="combobox_search.js"></script>
	<script>
	  $( function() { $( "#userID" ).combobox(); } );
	</script>
	<script>
	function removeCoordinator(coordinatorID,userID) {
		var xhttp = new XMLHttpRequest();
		var x = document.getElementById("row"+coordinatorID);
		var tableObj = document.getElementById("assignmentTable");
		tableObj.deleteRow(x.rowIndex);
		xhttp.open("GET", "planea_removecoordinator.php?removeID="+coordinatorID+"&userID="+userID, true);
		xhttp.send();
	}
	</script>

<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a href="users.php">Administrar Usuarios</a></li>
<li><a class="active" href="#">Definir Coordinadores</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#admin-coords" target="PLANEA-help">?</a></li>
</ul>


<?php  
	$planea = new planea();
	$conn = $planea->openConnection();
	//Create new coordinator
	if ( isset($_POST["IDStudyPlan"]) && isset($_POST["userID"]) && !empty($_POST["userID"]) ) {
		$sql = "INSERT INTO users_coordinators (userID,planID) VALUES ('" . $_POST["userID"] . "', '" . $_POST["IDStudyPlan"] . "')";
		$conn->query($sql);
		//Set role as coordinator in the users table
		$sql = "SELECT role FROM users WHERE ID=" . $_POST["userID"];
		$result = $conn->query($sql);
		$row_user = $result->fetch_assoc();
		if ( strstr($row_user["role"],"C")===false ) {
			$sql = "UPDATE users SET role='C".$row_user["role"]."' WHERE ID=" . $_POST["userID"];	
			$conn->query($sql);
		}
	}
?>

<form class="planeaForm" action="users_coordinators.php" method="POST">
	Plan:
	<select name="IDStudyPlan">
	<?php $planea->showStudyPlan($_SESSION["DefaultPlan"]); ?>	
	</select>
	Coordinador <select name="userID" id="userID">
	<option value="">Seleccione uno...</option>
	<?php $planea->showUserList(); ?>
	</select> 
	<input type="submit" value="Crear Nuevo Coordinador">
</form>

<form class="planeaForm" action="#" method="POST">
	<table id="assignmentTable">
	<tr><th>Plan</th><th>Encargado</th><th></th></tr>
	<?php $planea->showUserCoordinators(); ?>
	</table>
</form>

<?php $planea->closeConnection(); ?>

</body>
</html>
