<?php
	require('planea_basics.php');  
	$planea = new planea();
	$conn = $planea->openConnection();	
	$sql = "INSERT INTO courses_plan (Nombre,PlanID) VALUES ('" . $_GET["courseName"]."',".$_GET["plan"].")";
	$res = $planea->conn->query($sql);
	if ($res) {
		$sql = "INSERT INTO courses_general (Nombre,PlanID,CourseKeyID,Version,EstadoVersion,VisVersion) VALUES ('" . 
			$_GET["courseName"]."',".$_GET["plan"].",".$planea->conn->insert_id.",1,".planea::syllStateOpened.",1)";
		$planea->conn->query($sql);	
	}
	$planea->showCourseListByPlan($_GET["plan"]);
	$planea->closeConnection();
?>