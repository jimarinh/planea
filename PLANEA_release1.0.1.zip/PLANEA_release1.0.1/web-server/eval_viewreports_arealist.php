<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$PlanID = $_GET["PlanID"];
$SemName = $_GET["SemName"];
$filterArea = $_GET["filter"];
echo "<option value=\"\">Seleccione un área...</option>";
$planea->showAreasListByFilter( $filterArea, $PlanID, $SemName );
$planea->closeConnection();
?>
