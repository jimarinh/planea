<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script>
	function removeReq(courseID,reqID) {
		var r = confirm("¿Desea eliminar el requisito?");
		if (r == true) {		
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("courseRequirements").innerHTML = this.responseText;
				}
			};
			xhttp.open("GET", "planea_removereq.php?removeID="+reqID+"&courseID="+courseID, true);
			xhttp.send();
		}
	}
	function addReq(courseID) {				
			var xhttp = new XMLHttpRequest();
			var e = document.getElementById("NuevoRequisito");
			var value = e.options[e.selectedIndex].value;
			if (value==0) {
				alert("Seleccione primero un espacio académico del listado y luego de clic el botón 'Añadir Requisito'");
			} else {
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						document.getElementById("courseRequirements").innerHTML = this.responseText;
					}
				};
				xhttp.open("GET", "planea_addreq.php?courseID="+courseID+"&reqID="+value, true);
				xhttp.send();
			}
	}
	function analyzeCredits() {
		var numWeeks = 16;
		var HT = parseFloat(document.getElementById("HT").value); if (isNaN(HT)) HT = 0;
		var HP = parseFloat(document.getElementById("HP").value); if (isNaN(HP)) HP = 0;
		var HTP= parseFloat(document.getElementById("HTP").value); if (isNaN(HTP)) HTP = 0;
		var HI = parseFloat(document.getElementById("HI").value); if (isNaN(HI)) HI = 0;
		var HA = parseFloat(document.getElementById("HA").value); if (isNaN(HA)) HA = 0;
		var CC = parseFloat(document.getElementById("CC").value);
		var CE = ((HT+HP+HTP+HI+HA)*numWeeks)/48;
		var cwarning = document.getElementById("creditWarning");
		if (CE>CC) {
			cwarning.style.display = "inline"
			cwarning.innerHTML = "¡El número de horas excede los créditos académicos! El número máximo de horas semanales permitidas es "+CC*48/16;
		} else {
			cwarning.style.display = "none"
		}
	}
	function updateCredits() {
		analyzeCredits();
		setModifiedFlag();
	}
	</script>
	
</head>

<body onload="analyzeCredits()">

<?php  
	require('planea_basics.php');
	require('planea_logosbar.php');
	$helptopic = "teacher-syllabus";
	require('planea_syllabusbar.php');
		
	$planea = new planea();
	$conn = $planea->openConnection();
	
	if (isset($_GET["ID"])) {
		//Si el espacio se selecciona por primera vez, captura el ID del curso	
		$CourseID = $_GET["ID"];
	}
	if (isset($_GET["PlanID"])) {
		$_SESSION["DefaultPlan"] = $_GET["PlanID"];
	}
	if (isset($_POST["CourseID"])) {
		//Si se da clic en el botón Guardar, almacena la información en la base de datos
		$CourseID = $_POST["CourseID"];
		foreach ($_POST as $key=>$value) {
			$sql = "UPDATE courses_general SET ". $key . "='". $value ."' WHERE ID=" . $CourseID;
			$conn->query($sql);
		}
		$sql = "UPDATE courses_plan SET Nombre='". $_POST["Nombre"] ."' WHERE ID=" . $_POST["CourseKeyID"];
		$conn->query($sql);
	}
	$sql = "SELECT * FROM courses_general WHERE ID=" . $CourseID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$CourseName = $planea->showCourseTitle($row);
	$canModify = $planea->checkPermission( $_SESSION["RoleID"], $_SESSION["UserID"], $CourseID, 1 );
	$coursebar_opt = 1;
	require('planea_coursebar.php');
?>


<form class="planeaForm" id="mainForm" action="view_syllabus.php" onsubmit="return clearModifiedFlag()" method="POST">

Nombre: <input type="text" name="Nombre" size=50 value="<?php echo $row["Nombre"]; ?>" onchange="setModifiedFlag()"> <br><br>
Código: <input type="text" name="Codigo" value="<?php echo $row["Codigo"]; ?>" onchange="setModifiedFlag()"> 
Semestre: <input type="number" name="Semestre" min=1 max=12 style="width: 2.5em;" value="<?php echo $row["Semestre"]; ?>" onchange="setModifiedFlag()"> <br><br>
Naturaleza:  <?php $Naturaleza = $row["Naturaleza"]; ?>
<select name="Naturaleza" onchange="setModifiedFlag()">
	<option value="Teórico" <?php if ($Naturaleza == "Teórico") { echo "selected"; } ?> >Teórico</option>
	<option value="Práctico" <?php if ($Naturaleza == "Práctico") { echo "selected"; } ?> >Práctico</option>
	<option value="Teórico-Práctico" <?php if ($Naturaleza == "Teórico-Práctico") { echo "selected"; } ?> >Teórico-Práctico</option>
</select><br><br>
Créditos <input type="number" id="CC" name="NumeroCreditos" min=0 max=10 style="width: 2.5em;" value="<?php echo $row["NumeroCreditos"]; ?>" onchange="updateCredits()"> <br><br>

Horas Teóricas <input type="number" id="HT" name="HorasTeoricas"  min=0 max=10 style="width: 2.5em;" value="<?php echo $row["HorasTeoricas"]; ?>" onchange="updateCredits()">
Horas Prácticas <input type="number" id="HP" name="HorasPracticas"  min=0 max=10 style="width: 2.5em;" value="<?php echo $row["HorasPracticas"]; ?>" onchange="updateCredits()">
Horas Teórico-Prácticas <input type="number" id="HTP" name="HorasTeoricoPracticas"  min=0 max=10 style="width: 2.5em;" value="<?php echo $row["HorasTeoricoPracticas"]; ?>" onchange="updateCredits()">
Horas Asesoría <input type="number" id="HA" name="HorasAsesoria"  min=0 max=10 style="width: 2.5em;" value="<?php echo $row["HorasAsesoria"]; ?>" onchange="updateCredits()">
Horas Independientes <input type="number" id="HI" name="HorasIndependientes"  min=0 max=10 style="width: 2.5em;" value="<?php echo $row["HorasIndependientes"]; ?>" onchange="updateCredits()">

<br><p class="warning" id="creditWarning"></p><br>
<input type="checkbox" name="Habilitable" value=1 <?php if ($row["Habilitable"]==1) { echo "checked"; } ?> onchange="setModifiedFlag()">Habilitable
<input type="checkbox" name="Validable" value=1 <?php if ($row["Validable"]==1) { echo "checked"; } ?> onchange="setModifiedFlag()">Validable
<input type="checkbox" name="Homologable" value=1 <?php if ($row["Homologable"]==1) { echo "checked"; } ?> onchange="setModifiedFlag()">Homologable
<br><br>

Tipo de Actividad Académica:
<select name="TipoActividad" onchange="setModifiedFlag()">
	<?php $planea->showCourseCatList( $row["PlanID"], $row["TipoActividad"] ); ?>	
</select><br><br>

Núcleo Temático: <input type="text" name="NucleoTematico" size=50 value="<?php echo $row["NucleoTematico"]; ?>" onchange="setModifiedFlag()"> <br><br>

Tipo de Metodología: 
<select name="TipoMetodologia" onchange="setModifiedFlag()">
	<option value="Presencial" <?php if ($row["TipoMetodologia"] == "Presencial") { echo "selected"; } ?> >Presencial</option>
	<option value="Virtual" <?php if ($row["TipoMetodologia"] == "Virtual") { echo "selected"; } ?> >Virtual</option>
	<option value="Clase Invertida" <?php if ($row["TipoMetodologia"] == "Clase Invertida") { echo "selected"; } ?> >Clase Invertida</option>
</select><br><br>

Tipo de Evaluación: 
<select name="TipoEvaluacion" onchange="setModifiedFlag()">
	<option value="Cuantitativa" <?php if ($row["TipoEvaluacion"] == "Cuantitativa") { echo "selected"; } ?> >Cuantitativa</option>
	<option value="Cualitativa" <?php if ($row["TipoEvaluacion"] == "Cualitativa") { echo "selected"; } ?> >Cualitativa</option>
</select><br><br>

<input style="display:none" type="number" name="CourseID" value="<?php echo $row["ID"]; ?>">
<input style="display:none" type="number" name="CourseKeyID" value="<?php echo $row["CourseKeyID"]; ?>">

<?php 
	if ($canModify) { 
		echo "<input type=\"submit\" value=\"Guardar\">"; 
	} 
?>
<input type="submit" formaction="syllabus.php" value="Cancelar"> 
</form>  

<div class="planeaForm">
<b>Requisitos:</b>
<div id="courseRequirements">
<?php
	$planea->showRequirementsList( $CourseID, $canModify );
?>
</div>
<div>
<?php
	if ($canModify) {
		$planea->showRequirementsAddList( $CourseID );
	}
	$planea->closeConnection();
?>
</div>
</div>

</body>
</html>
