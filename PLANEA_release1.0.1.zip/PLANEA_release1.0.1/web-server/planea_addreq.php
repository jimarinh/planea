<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$CourseID = $_GET["courseID"];	
$sql = "INSERT INTO courses_reqs (CourseID,RequirementID) VALUES ('" . $CourseID . "', '". $_GET["reqID"]. "')";
$planea->conn->query($sql);
$planea->showRequirementsList( $CourseID, true );
$planea->closeConnection();
?>