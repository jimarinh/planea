<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
</head>

<body>

<?php  
	$_SESSION["overrideAuth"] = true;
	require('planea_logosbar.php');
?>


<?php
	require('planea_basics.php');
	
	$access_error = true;
	$access_error_msg = "Bienvenido a la herramienta de gestión curricular. Por favor ingrese su nombre de usuario y contraseña para comenzar.";
  
	$planea = new planea();
	$conn = $planea->openConnection();
		
	//Login and display main form
	if (isset($_POST["User"])) {	
		$sql = "SELECT * FROM users WHERE email='".($_POST["User"])."'";
		$result = $conn->query($sql);
	  		
		if ($result->num_rows > 0) {
			$row = $result->fetch_assoc();			
			if ( password_verify( $_POST["Password"], $row["password"] ) )	
			{
				$roleList = $row["role"];
				$roleID = $planea->chooseDefaultRole($roleList);
				$_SESSION["Name"] = $row["name"];
				$_SESSION["UserID"] = $row["ID"];
				$_SESSION["CountryID"] = $row["countryID"];
				$_SESSION["RoleList"] = $roleList;
				$_SESSION["RoleID"] = $roleID;
				$_SESSION["DefaultPlan"] =  $row["defaultPlan"];
				$planea->registerLog( $_SESSION["UserID"], "login");
				$access_error = false;
			} else {
				$access_error = true;
				$access_error_msg = "Contraseña inválida";		
			}
		} else {
			$access_error = true;
			$access_error_msg = "No cuenta con autorización para ingresar al aplicativo";	
		}			
	}

	//If a session is already open, display the application for the current role
	if (isset($_SESSION["Name"])) {
		
		if (isset($_GET["role"])) {
			//verify if the role is allowed for the current user	
			$sql = "SELECT * FROM users WHERE countryID='".($_SESSION["CountryID"])."'";
			$result = $conn->query($sql);
			if ($result->num_rows > 0) {
				$row = $result->fetch_assoc();			
				if ( $row["ID"] == $_SESSION["UserID"] )  {
					if ( $planea->checkRole($_GET["role"], $row["role"]) ) {
						$_SESSION["RoleID"] = $_GET["role"];
						$planea->formHome($_SESSION["Name"],$_SESSION["RoleID"],$_SESSION["RoleList"]);
						$access_error = false;
					}
				}
			}			
			if ( $access_error ) {
				$access_error_msg = "Operación fraudulenta en el sistema";
			}
		} else {
			//If page is refreshed...
			$planea->formHome($_SESSION["Name"],$_SESSION["RoleID"],$_SESSION["RoleList"]);
			$access_error = false;
		}
	}	
	$planea->closeConnection();
	
	if ( $access_error ) {
		echo "<p>". $access_error_msg ."</p>";		
		echo "<form action=\"login.php\" method=\"POST\">
				Usuario: <input type=\"text\" name=\"User\" size=50> <br> <br>
				Contraseña: <input  type=\"password\" name=\"Password\" size=12> <br>
				<p style=\"font-size:x-small\"><a href=\"recoverpassword.php\">Olvidé la contraseña</a></p>
				<input type=\"submit\" value=\"Entrar\">
			</form>";
		session_unset(); 
		session_destroy(); 	
	}
?>

</body>
</html>
