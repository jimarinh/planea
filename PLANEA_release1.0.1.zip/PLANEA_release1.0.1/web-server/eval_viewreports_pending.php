<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
</head>

<body>

<?php  
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection(); 

	require('planea_logosbar.php');
	$subMenuName = "Listado de Reportes Incompletos";
	
	//Check for credentials
	if ($_SESSION["RoleID"]!=planea::roleCoord) {
		exit("<font color=\"red\">No tiene permiso para acceder a esta sección</font>");
	}
	
	$helptopic = "coord-eval-course-pending";
	require('planea_evalcoordbar.php'); 
	if ( !isset($PlanID) || !isset($SemesterID) ) exit(0);	
?>

	<script>
	function removeAllPendingReports(PlanID,Semester) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("reportList").innerHTML = this.responseText;
			}
		}
		xhttp.open("GET", "planea_remove_all_pending_evalreports.php?PlanID="+PlanID+"&Semester="+Semester, true);
		xhttp.send();	
	}
	function removePendingReport(reportID) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("reportList").innerHTML = this.responseText;
			}
		}
		xhttp.open("GET", "planea_remove_pending_evalreport.php?ReportID="+reportID, true);
		xhttp.send();	
	}
	</script>

<h3>Programa: <i><?php echo $planName; ?></i> &nbsp; Semestre: <i><?php echo $semesterName;?></i> </h3>
<table id="reportList">
<?php 
	$planea->showEvalReportListByCourse($_GET["PlanID"], $semesterName, 0);
?>
</table>
<br>
<button type="button" onclick="removeAllPendingReports(<?php echo $_GET["PlanID"].",'".$semesterName."'"; ?>)">Eliminar todas las asignaciones incompletas</button>
<?php $planea->closeConnection(); ?>

</body>
</html>
