<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
//Get position and rubricID of the entry to be removed
	$sql = "SELECT RubricID,Position FROM rubrics_entries WHERE ID=".$_GET["entryID"];
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$rubricID = $row["RubricID"];
	$position = $row["Position"];
//Assign new positions to remaining entries
	$sql = "SELECT ID FROM rubrics_entries WHERE RubricID=".$rubricID." AND Position>".$position." ORDER BY Position";
	$result = $planea->conn->query($sql);
	while($row = $result->fetch_assoc()) {	
		$sql = "UPDATE rubrics_entries SET Position=".$position." WHERE ID=".$row["ID"];
		$planea->conn->query($sql);
		$position++;
	}
//Remove entry
	$sql = "DELETE FROM rubrics_entries WHERE ID=".$_GET["entryID"];
	$result = $planea->conn->query($sql);
$planea->closeConnection();
?>