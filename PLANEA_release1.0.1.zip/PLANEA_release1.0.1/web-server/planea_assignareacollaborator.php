<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection(); 
	$planID = $_GET["PlanID"];
	$SemName = $_GET["SemName"];
	$areaName = $_GET["AreaName"];
	$userID = $_GET["UserID"];
	//Verify that evaluation has not started
	$sql = "SELECT ID FROM eval_areas WHERE PlanID=".$planID." AND Semester='".$SemName."' AND AreaName='".$areaName."'";
	$result = $conn->query($sql);
	if ($result->num_rows==0) {
		$sql = "INSERT INTO eval_areas (PlanID,AreaName,Semester,UserID,State)
				VALUES (".$planID.",'".$areaName."','".$SemName."',".$userID.",0)";
		$result = $conn->query($sql);
	} else {
		$row = $result->fetch_assoc();
		$sql = "UPDATE eval_areas SET UserID=".$userID.",State=0 WHERE ID=".$row["ID"];
		$result = $conn->query($sql);
	}
	$planea->showAreaCollaboratorsForEval($planID,$SemName);
	$planea->closeConnection();
?>