<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script>
		function changePlan() {
			var e = document.getElementById("ListOfStudyPlans");
			if (e.selectedIndex == -1) {
				return null;
			}
			var value = parseInt(e.options[e.selectedIndex].value);
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("ListOfCourses").innerHTML = this.responseText;
				}
			};
			xhttp.open("GET", "planea_loadcourses.php?plan="+e.value+"&state=Approved", true);
			xhttp.send();
		}
	</script>
</head>

<body>

<?php  
	$_SESSION["overrideAuth"] = true;
	require('planea_logosbar.php');
?>


<?php
require('planea_basics.php');
$planea = new planea();
$conn = $planea->openConnection();  
?>

<form class="planeaForm" action="viewpdf_syllabus.php" method="GET">
Plan:
<select id="ListOfStudyPlans" name="PlanID" onchange="changePlan()">
<?php 
	if (isset($_GET["PlanID"])) {
		$defaultPlan = $_GET["PlanID"]; 
	} else {
		$defaultPlan = 1;
	}
	$planea->showStudyPlan($defaultPlan); 
?>
</select>

Espacio Académico:
<select id="ListOfCourses" name="ID">
<?php $planea->showCourseListByVersionState($defaultPlan,planea::syllStateApproved); ?>
</select>

<input type="submit" value="Ver PDF">  

</form>  

<?php $planea->closeConnection(); ?>

</body>
</html>
