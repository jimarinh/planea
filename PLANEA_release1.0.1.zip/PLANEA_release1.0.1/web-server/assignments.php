<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<style>
		.custom-combobox {
			position: relative;
			display: inline-block;
		}
		.custom-combobox-toggle {
			position: absolute;
			top: 0;
			bottom: 0;
			margin-left: -32px;
			padding: 0;
		}
		.custom-combobox-input {
			margin: 0;
			padding: 3px 6px;
		}
		.custom-overflow {
			height: 200px;
		}
		.ui-autocomplete {
			max-height: 300px;
			overflow-y: auto;
			overflow-x: hidden;
			padding-right: 20px;
		}
	</style>
</head>

<body>
<?php  
	require('planea_logosbar.php'); 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	//Check credentials
	if ($_SESSION["RoleID"]!=planea::roleCoord) {
		exit("<p><font color=\"red\">No tiene permiso para acceder a esta sección</font><p>");
	}
?>
	<script src="combobox_search.js"></script>
	<script>
	  $( function() { $( "#ListOfCourses" ).combobox(); } );
	  $( function() { $( "#ListOfUsers" ).combobox(); } );
	</script>
	<script>
	function changePlan() {
			var e = document.getElementById("ListOfStudyPlans");
			if (e.selectedIndex == -1) {
				return null;
			}
			var value = parseInt(e.options[e.selectedIndex].value);
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("ListOfCourses").innerHTML = "<option value=\"\">Seleccione uno...</option>"+this.responseText;
					$("#ListOfCourses option").each(function(){ $(this).removeAttr("selected") });
					$("#ListOfCourses option:first").attr("selected", "selected");
					$("#ListOfUsers option").each(function(){ $(this).removeAttr("selected") });
					$("#ListOfUsers option:first").attr("selected", "selected");
					$("input.ui-autocomplete-input").val("");
				}
			};
			var state;
			if (role.value==1) state="Approved"; else state="Opened"; 
			xhttp.open("GET", "planea_loadcourses.php?plan="+e.value+"&state="+state, true);
			xhttp.send();
		}
	function removeAssignment(assignmentID) {
		var xhttp = new XMLHttpRequest();
		var x = document.getElementById("row"+assignmentID);
		var tableObj = document.getElementById("assignmentTable");
		tableObj.deleteRow(x.rowIndex);
		xhttp.open("GET", "planea_removeassignment.php?removeID="+assignmentID, true);
		xhttp.send();
	}
	function changeRole() {
			var e = document.getElementById("ListOfRoles");
			if (e.selectedIndex == -1)
				return null;
			var value = e.options[e.selectedIndex].value;
			if (value==1) {
				document.getElementById("chkPermissions").style.display = "none";	
			} else {
				document.getElementById("chkPermissions").style.display = "inline";
			}	
		}
	var bChecked = true;
	function checkAllSecs() {
		var id;
		for (id=1; id<=128; id=id*2) {
			document.getElementById("chk"+id).checked = bChecked;
		}
		bChecked = !bChecked;
	}
	</script>
	
<?php
	//If first time...
	if (!isset($_POST["role"])) {
		$user_role = 2;
		$helptopic = "";
	}
	//If menu bar is selected
	if (isset($_GET["role"])) {
		$user_role = $_GET["role"];
		if ($user_role==2) $helptopic = "-collaborators"; else  $helptopic = "-teachers";
	}
	if (isset($_POST["role"])) {
		$user_role = $_POST["role"];
		if ($user_role==2) $helptopic = "-collaborators"; else  $helptopic = "-teachers";
	}
	if ($_SESSION["RoleID"]==planea::roleCoord) {
		//Create New Assignment
		if ( isset($_POST["courseID"]) && isset($_POST["userID"]) && !empty($_POST["courseID"]) && !empty($_POST["userID"]) ) {
			$permissions = 0;
			if ($_POST["role"]==2) {
				if (isset($_POST["chk1"])) $permissions += 1;
				if (isset($_POST["chk2"])) $permissions += 2;
				if (isset($_POST["chk4"])) $permissions += 4;
				if (isset($_POST["chk8"])) $permissions += 8;
				if (isset($_POST["chk16"])) $permissions += 16;
				if (isset($_POST["chk32"])) $permissions += 32;
				if (isset($_POST["chk64"])) $permissions += 64;
				if (isset($_POST["chk128"])) $permissions += 128;
			}
			$sql = "SELECT ID FROM users_assignments WHERE userID='".$_POST["userID"] . "' AND courseID='". $_POST["courseID"] . "'";
			$result = $conn->query($sql);
			$row = $result->fetch_assoc();
			if ( empty($row) ) {
				$sql = "INSERT INTO users_assignments (userID,courseID,roleType,permissions) VALUES ('" . $_POST["userID"] . "', '" . $_POST["courseID"] . "','" . $_POST["role"] . "','" . $permissions . "')";
			} else {
				$sql = "UPDATE users_assignments SET roleType='".$_POST["role"] . "',permissions='" . $permissions . "' WHERE ID=".$row["ID"];
			}
			$result = $conn->query($sql);	
		}
	}
?>

<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a <?php if ($user_role==2) echo "class=\"active\""; ?> href="assignments.php?role=2">Asignar Colaboradores</a></li>
<li><a <?php if ($user_role==1) echo "class=\"active\""; ?> href="assignments.php?role=1">Asignar Docentes</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#coord-users<?php echo $helptopic;?>" target="PLANEA-help">?</a></li>
</ul>

<div class="planeaForm" style="font-size:small<?php if ($user_role==1) echo ";display:none"; ?>">
<p>Utilice este formulario para asignar las personas que colaborarán en la construcción de los sílabos. 
Puede restringuir la modificación del sílabo a las secciones marcadas con X.</p>
<p>En el listado de espacios académicos solamente se visualizan aquellos que se encuentran en modo borrador. 
Para asignar colaboradores a un sílabo vigente (no borrador), debe abrirlo en modo borrador, en la sección 
"Control de Versiones" del menú "Sílabos".</p>
</div>

<div class="planeaForm" style="font-size:small<?php if ($user_role==2) echo ";display:none"; ?>">
<p>Utilice este formulario para asignar los docentes resposables de la planeación y  evaluación curricular del curso. 
Los docentes no pueden modificar los sílabos. Para que un docente colabore en la construcción del sílabo, 
debe asignarlo en la pestaña "Asignar Colaboradores".</p>
<p>En el listado de espacios académicos solamente se visualizan aquellos que se encuentran aprobados y vigentes. 
Para aprobar un sílabo, debe dirigirse a la sección "Control de Versiones" del menú "Sílabos".</p>
</div>

<form class="planeaForm" action="assignments.php" method="POST">
	Plan:
	<select id="ListOfStudyPlans" name="IDStudyPlan" onchange="changePlan()">
	<?php $defaultPlan = $planea->showStudyPlan($_SESSION["DefaultPlan"], false, $_SESSION["UserID"]); ?>	
	</select>
	Espacio Académico: <select id="ListOfCourses" name="courseID">
	<option value="">Seleccione uno...</option>
	<?php 
		if ($user_role==1) { $state = "Approved"; }
		if ($user_role==2) { $state = "Opened"; }
		$planea->showCourseListByVersionState($defaultPlan,$state); 
	?>
	</select> 
	Usuario a encargar: <select id="ListOfUsers" name="userID">
	<option value="">Seleccione uno...</option>
	<?php $planea->showUserList(); ?>
	</select> 
	<br> <br>
	<input type="number" style="display:none" id="role" name="role" value=<?php echo $user_role; ?>>
	<div id="chkPermissions" <?php if ($user_role==1) echo "style=\"display:none\"" ?>>
	<a href="#" onclick="checkAllSecs()">Marcar/desmarcar todas</a>
	<input type="checkbox" id="chk1" name="chk1" value=1>Generalidades
	<input type="checkbox" id="chk2" name="chk2" value=1>Descripción
	<input type="checkbox" id="chk4" name="chk4" value=1>RAPs
	<input type="checkbox" id="chk8" name="chk8" value=1>Actividades
	<input type="checkbox" id="chk16" name="chk16" value=1>Evaluación
	<input type="checkbox" id="chk32" name="chk32" value=1>Contenidos
	<input type="checkbox" id="chk64" name="chk64" value=1>Rúbricas
	<input type="checkbox" id="chk128" name="chk128" value=1>Bibliografía
	<br> <br>
	</div>
	<input type="submit" value="Crear Nueva Asignación">
</form>


<form class="planeaForm" action="#" method="POST">
	<table id="assignmentTable">
	<tr><th>Plan</th><th>Curso</th><th>Encargado</th>
	<?php if ($user_role==2) echo "<th>Gen.</th><th>Desc.</th><th>RAPs</th><th>Acts.</th><th>Eval.</th><th>Conts.</th><th>Rúbs.</th><th>Biblio</th><th></th>"; ?>
	</tr>
	<?php $planea->showUserAssignments($_SESSION["UserID"], $user_role); ?>
	</table>
</form>

<?php $planea->closeConnection(); ?>

</body>
</html>
