<?php
	require('planea_basics.php');  
	$planea = new planea();
	$conn = $planea->openConnection();
	$planea->showElectiveCategoryList($_GET["plan"]);
	$planea->closeConnection();
?>