<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
</head>

<body>

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();  
	if ($_SESSION["RoleID"]!=planea::roleCoord) {
		exit("Seleccione el rol Coordinador");
	}
?>

<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="planning_course_coord.php">Planeación de Cursos</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#coord-planning" target="PLANEA-help">?</a></li>
</ul>

<script type="text/javascript" language="javascript" src="planning_course.js"></script>	
<script>
	function changePlanOrSemester() {
		var e = document.getElementById("ListOfStudyPlans");
		if (e.selectedIndex == -1) {
			return null;
		}
		var Plan = e.value;
		var s = document.getElementById("SemesterID");
		if (s.selectedIndex==-1) return;
		var semName = s.options[s.selectedIndex].text;
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("planningCourses").innerHTML = this.responseText;
			}
		};
		xhttp.open("GET", "planning_course_go.php?action=loadCoordList&PlanID="+Plan+"&SemesterID="+semName, true);
		xhttp.send();
	}
	
	function viewNewSemesterInfo() {
		document.getElementById("newSemesterInfo").style.display = "inline";
		document.getElementById("newSemesterButton").style.display = "none";
	}
	function cancelNewSemesterInfo() {
		document.getElementById("newSemesterInfo").style.display = "none";
		document.getElementById("newSemesterButton").style.display = "inline";
	}
	function newSemesterInfo() {
		var xhttp = new XMLHttpRequest();
		var e = document.getElementById("newSemesterName");
		document.getElementById("newSemesterInfo").style.display = "none";
		document.getElementById("newSemesterButton").style.display = "inline";
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("SemesterID").innerHTML = this.responseText;
				document.getElementById("planningCourses").innerHTML = "";
			}
		};
		xhttp.open("GET", "planea_newsemester.php?semName="+e.value, true);		
		xhttp.send();
	}
	
	var exportCourseID = 0;
	var exportUserID = 0;
	var exportSemesterID = 0;
	function viewPlanning(CourseID, UserID, SemesterID) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				planningCourses.style.display = "none";
				planningSelectPlan.style.display = "none";
				planningViewer.style.display = "block";
				document.getElementById("planningViewerInfo").innerHTML = this.responseText;
				exportCourseID = CourseID;
				exportUserID = UserID;
				exportSemesterID = SemesterID;
			}
		};
		xhttp.open("GET", "planning_course_go.php?action=loadCourse&CourseID="+CourseID+"&SemesterID="+SemesterID+"&UserID="+UserID+"&showTooltip=true", true);
		xhttp.send();
	}
</script>

	
<form class="planeaForm" id="planningSelectPlan" action="planning_course_coord.php" method="GET">
Plan:
<select id="ListOfStudyPlans" name="PlanID" onchange="changePlanOrSemester()">
<?php 
	$defaultPlan = $_SESSION["DefaultPlan"];
	if ($_SESSION["RoleID"]==planea::roleCoord) $defaultPlan = $planea->showStudyPlan($defaultPlan,false,$_SESSION["UserID"]); 
	else $planea->showStudyPlan($defaultPlan); 
?>
</select>
&nbsp;

Semestre: 
<select id="SemesterID" name="SemesterID" onchange="changePlanOrSemester()">
<?php 
	$defaultSem = $planea->showSemesterList(); 
?>
</select>

<div id="newSemesterInfo" style="display:none">
	Nombre del semestre: <input type="text" id="newSemesterName" size=20>
	<button type="button" onclick="newSemesterInfo()">Crear Semestre</button>  &nbsp;
	<button type="button" onclick="cancelNewSemesterInfo()">Cancelar</button>
</div>
<button type="button" id="newSemesterButton" onclick="viewNewSemesterInfo()">*Nuevo Semestre</button>
</form>  

<div class="planeaForm" id="planningCourses">
	<?php 
		$planea->showPlanningCoursesList($defaultPlan,$defaultSem);
	?>
</div>


<div class="planeaForm" id="planningViewer" style="display:none">
<button  onclick="exportPlanningSummary(exportCourseID,exportUserID,exportSemesterID)" type="button">Exportar</button> <br><br>
<div id="planningViewerInfo">
</div>
</div>

<div id="planningExportInfo" style="display:none"></div>

<?php $planea->closeConnection(); ?>

</body>
</html>
