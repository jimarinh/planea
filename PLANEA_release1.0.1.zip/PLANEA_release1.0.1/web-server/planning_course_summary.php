<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
</head>

<body>

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();  
	if ($_SESSION["RoleID"]!=planea::roleUser) {
		exit("Seleccione el rol Docente");
	}
	
	$CourseID 	= $_GET["ID"];
	$SemesterID = isset($_GET["SemesterID"]) ? $_GET["SemesterID"] : $planea->getDefaultSemester();
	$UserID = $_SESSION["UserID"];
	
	$sql = "SELECT Nombre,PlanID FROM courses_general WHERE ID=" . $CourseID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$CourseName = $row["Nombre"]."(".$SemesterID.")";
	$Action = 6;
?>
	<script type="text/javascript" language="javascript" src="planning_course.js"></script>	
	


<ul class="navbar"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="planning_course_user.php">Planeación de Cursos</a></li>
<li><a href="logout.php">Salir</a></li>
</ul>

<ul class="navbar"> 
<li>
	<a <?php if ($Action==1) echo "class=\"active\""; ?> href="planning_course_howtos.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 1: Preguntas</a>
</li>
<li>
	<a <?php if ($Action==2) echo "class=\"active\""; ?> href="planning_course_activities.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 2: Actividades</a>
</li>
<li>
	<a <?php if ($Action==3) echo "class=\"active\""; ?> href="planning_course_schedule.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 3: Cronograma</a>
</li>
<li>
	<a <?php if ($Action==4) echo "class=\"active\""; ?> href="planning_course_eval.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 4: Evaluación</a>
</li>
<li>
	<a <?php if ($Action==5) echo "class=\"active\""; ?> href="planning_course_rubrics.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 5: Rúbricas
	</a>
</li>
<li>
	<a <?php if ($Action==6) echo "class=\"active\""; ?> href="planning_course_summary.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Resumen
	</a>
</li>
<li><a href="view_syllabus.php<?php echo "?ID=".$CourseID;?>"> <?php echo $CourseName; ?> </a></li>
</ul>


<div class="planeaForm" id="planningViewer">
<button  onclick="exportPlanningSummary(<?php echo $CourseID;?>,<?php echo $UserID;?>,'<?php echo $SemesterID;?>')" type="button">Exportar</button> <br><br>
<div id="planningViewerInfo">
<?php 
	$planea->showPlanningCourseName( $CourseID, $UserID );
	$planea->showPlanningCourseRapsAndSkills( $CourseID, $SemesterID, $UserID );
	$planea->showPlanningCourseActivityTable( $CourseID, $SemesterID, $UserID, true, "THES" );
	echo "<p><b>Rúbricas</p><small>";
	$planea->showRubricsByUserCourse( $CourseID, $SemesterID, $UserID, false );
	echo "</small>";
?>
</div>
</div>

<div id="planningExportInfo" style="display:none"></div>



<?php $planea->closeConnection(); ?>

</body>
</html>
