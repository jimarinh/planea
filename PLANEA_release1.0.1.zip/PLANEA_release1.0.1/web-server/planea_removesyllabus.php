<?php
require('planea_basics.php');  
$planea = new planea();
$conn = $planea->openConnection();	
$CourseKeyID =  $_GET["courseID"];
$sql = "DELETE FROM courses_plan WHERE ID=" . $CourseKeyID; $conn->query($sql); 
$sql = "DELETE FROM courses_reqs WHERE RequirementID=" . $CourseKeyID; $conn->query($sql); 
$sql = "DELETE FROM courses_elective WHERE CourseID=" . $CourseKeyID; $conn->query($sql);
$sql = "DELETE FROM courses_contents WHERE CourseID IN (SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID.")"; $conn->query($sql); 
$sql = "DELETE FROM courses_reqs WHERE CourseID IN (SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID.")"; 	$conn->query($sql); 
$sql = "DELETE FROM courses_personal_skills WHERE CourseID IN (SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID.")"; $conn->query($sql);
$sql = "DELETE FROM courses_interpersonal_skills WHERE CourseID IN (SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID.")"; $conn->query($sql); 
$sql = "DELETE FROM courses_cdio_skills WHERE CourseID IN (SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID.")"; $conn->query($sql);
$sql = "DELETE FROM courses_ilos WHERE CourseID IN (SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID.")"; $conn->query($sql);
$sql = "DELETE FROM users_assignments WHERE courseID IN (SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID.")"; $conn->query($sql);
$sql = "DELETE FROM rubrics_assoc WHERE CourseID IN (SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID.")"; $conn->query($sql);
$planea->purgeNotUsedRubrics();
$sql = "DELETE FROM teacher_actassoc WHERE ActID IN (SELECT ID FROM teacher_activities WHERE CourseID IN (SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID."))"; $conn->query($sql);
$sql = "DELETE FROM teacher_activities WHERE CourseID IN (SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID.")"; $conn->query($sql);
$sql = "DELETE FROM courses_general WHERE CourseKeyID=" . $CourseKeyID; $conn->query($sql);
$sql = "DELETE FROM eval_courses WHERE CourseKeyID=" . $CourseKeyID; $conn->query($sql);  
$planea->showCourseListByPlan($_GET["plan"]);
$planea->closeConnection();
?>