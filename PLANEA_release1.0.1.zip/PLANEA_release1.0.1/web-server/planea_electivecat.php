<?php
	require('planea_basics.php');  
	$planea = new planea();
	$conn = $planea->openConnection();
	if (isset($_GET["CatID"])) {	
		$sql = "UPDATE courses_electivecats SET CategoryName='". $_GET["name"]."', Credits=".$_GET["c"].", Semester=".$_GET["s"].", ForceSemester=".$_GET["f"]." WHERE ID=".$_GET["CatID"];
	} else {
		$sql = "INSERT INTO courses_electivecats (CategoryName,PlanID,Credits,Semester,ForceSemester) VALUES ('" . $_GET["name"]."',".$_GET["plan"].",".$_GET["c"].",".$_GET["s"].",".$_GET["f"].")";
	}
	$planea->conn->query($sql);
	$planea->showElectiveCategories($_GET["plan"]);
	$planea->closeConnection();
?>