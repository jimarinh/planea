<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">	
</head>

<body>

<?php  
	require('planea_basics.php');
	require('planea_logosbar.php');
	$helptopic = "teacher-syllabuseval";
	require('planea_syllabusbar.php');
		
	$planea = new planea();
	$conn = $planea->openConnection();
	if (isset($_GET["ID"])) {
		$CourseID = $_GET["ID"];
	}
	if (isset($_POST["Evaluacion"])) {
		$CourseID = $_POST["CourseID"];
		//Si se da clic en el botón Guardar, almacena la información en la base de datos
		foreach ($_POST as $key=>$value) {
			$sql = "UPDATE courses_general SET ". $key . "='". $value ."' WHERE ID=" . $CourseID;
			$conn->query($sql);
		}
	}
	$sql = "SELECT * FROM courses_general WHERE ID=" . $CourseID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$CourseName = $planea->showCourseTitle($row);
	$canModify = $planea->checkPermission( $_SESSION["RoleID"], $_SESSION["UserID"], $CourseID, 16 );
	$coursebar_opt = 5;
	require('planea_coursebar.php');
?>

 
<form class="planeaForm" id="mainForm" action="view_syllabus_eval.php" onsubmit="return clearModifiedFlag()" method="POST">

<script type="text/javascript" src="planea_formattextarea.js"></script> 
<script type="text/javascript" src="nicEdit.js"></script> 
<script type="text/javascript">
  bkLib.onDomLoaded(function() {
		nicEditors.allTextAreas({buttonList : ['bold','italic','underline','subscript','superscript','ol','ul','indent','outdent']});
		planeaFormatTextarea.allTextAreas();
	});
</script> 

<b>Evaluación</b> 
<p style="font-size:x-small">Las formas de evaluación deben ser de naturaleza múltiple. Se recuerdan algunas:
Pruebas escritas, trabajos de aplicación (talleres), informes de lectura y de consulta (en oralidad y 
escritura), exposiciones individuales o grupales, elaboración o recolección de material para documentación, 
participación en actividades académicas relacionadas con el área (congresos, encuentros), 
elaboración de informes, resúmenes, artículos y ensayos, diseño de recursos, pruebas con el formato 
Saber-Pro, control del trabajo cooperativo, informes parciales y finales de proyectos, seguimiento 
de actividades permanentes, participación en discusiones y en el intercambio de opiniones en clase, 
organización y participación en eventos.
Los porcentajes y el peso de cada producto de evaluación no van aquí, sino en el acta de concertación
</p>
<textarea name="Evaluacion" rows=16 style="width: 100%;"><?php echo $row["Evaluacion"]; ?></textarea><br>

<input style="display:none" type="number" name="CourseID" value="<?php echo $row["ID"]; ?>">

<?php 
	if ($canModify) { 
		echo "<input type=\"submit\" value=\"Guardar\">"; 
	}
	$planea->closeConnection();	
?>
<input type="submit" formaction="syllabus.php" value="Cancelar"> 
</form>  

</body>
</html>
