<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "DELETE FROM courses_ilos WHERE ID=".$_GET["iloID"];
$planea->conn->query($sql);
$sql = "DELETE FROM rubrics_assoc WHERE RapSkillID=".$_GET["iloID"]." AND RapSkillType=0";
$planea->conn->query($sql);
$sql = "DELETE FROM teacher_howtos WHERE RapID=".$_GET["iloID"];
$planea->conn->query($sql);
$sql = "DELETE FROM teacher_actassoc WHERE RapSkillID=".$_GET["iloID"]." AND RapSkillType=0";
$planea->conn->query($sql);
$planea->closeConnection();
?>