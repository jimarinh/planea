<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	//Check if Course-Category Set could be removed...
	$sql = "SELECT Code FROM study_plan WHERE CatSetID=".$_GET["setID"];
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		echo "0";
	} else {
		$sql = "DELETE FROM coursecat_values WHERE SetID=".$_GET["setID"];
		$result = $conn->query($sql);		
		$sql = "DELETE FROM coursecat_sets WHERE ID=".$_GET["setID"];
		$result = $conn->query($sql);
		echo "1";
	}
	$planea->closeConnection();
?>