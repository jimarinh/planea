<?php
	//Actions to support the planning duplicate
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection(); 
	switch($_GET["action"]) 
	{
		//Return the list of courses for a given user in the active semester
		case "getTarget":
			$sql = "SELECT users_assignments.courseID,courses_general.Nombre 
					FROM users_assignments JOIN courses_general ON courses_general.ID=users_assignments.courseID 
					WHERE userID=".$_GET["UserID"]." AND roleType=1";
			$result = $conn->query($sql);
			if ($result->num_rows > 0)  {  
				while($row = $result->fetch_assoc()) {	
					echo "<option value=".$row["courseID"].">".$row["Nombre"]."</option>\n";
				}
			}		
			break;
			
		//Return the list of courses for a given user in previous semesters
		case "getSource":
			//Get active semester
			$sql = "SELECT SemesterName FROM semesters ORDER BY SemesterName DESC";
			$result = $conn->query($sql);
			if ($result->num_rows > 0)  {
				$row = $result->fetch_assoc();
				$activeSemester = $row["SemesterName"];
				
				//Get planning courses by the given user in previous semesters
				if ($_GET["type"]=="equal") {
					$sql = "SELECT teacher_activities.CourseID, courses_general.CourseKeyID, teacher_activities.Semester
						FROM teacher_activities 
						LEFT JOIN courses_general ON teacher_activities.CourseID=courses_general.ID
						WHERE teacher_activities.UserID=".$_GET["UserID"]." AND teacher_activities.Semester!='".$activeSemester.
						"' AND teacher_activities.CourseID=".$_GET["CourseID"].
						" GROUP BY teacher_activities.CourseID,teacher_activities.Semester";
				} else {
					$sql = "SELECT teacher_activities.CourseID, courses_general.CourseKeyID, teacher_activities.Semester
						FROM teacher_activities 
						LEFT JOIN courses_general ON teacher_activities.CourseID=courses_general.ID
						WHERE teacher_activities.UserID=".$_GET["UserID"]." GROUP BY teacher_activities.CourseID,teacher_activities.Semester";
				}
				$result = $conn->query($sql);
				if ($result->num_rows > 0)  {
					while($row = $result->fetch_assoc()) {	
						if ( ($row["CourseID"]==$_GET["CourseID"]) && ($row["Semester"]==$activeSemester) )
							continue;
						$sql = "SELECT courses_plan.Nombre,study_plan.Program
								FROM courses_plan JOIN study_plan ON courses_plan.PlanID = study_plan.ID 
								WHERE courses_plan.ID =". $row["CourseKeyID"];
						$result_course = $conn->query($sql);
						$row_course = $result_course->fetch_assoc();
						echo "<option value='".$row["CourseID"].",".$row["Semester"]."'>".$row_course["Nombre"].
							   " (".$row_course["Program"].") [".$row["Semester"]."]</option>";
					}
				}
			}
			break;	
			
			
		//Return the list of courses that a user has planned in the given semester 
		case "getSections":
			//Get active semester
			$sql = "SELECT SemesterName FROM semesters ORDER BY SemesterName DESC";
			$result = $conn->query($sql);
			if ($result->num_rows == 0) return;
			$row = $result->fetch_assoc();
			$activeSemester = $row["SemesterName"];
		
			//Activity List
			//-------------
		
			//Check if importing the same course from previous semester. 
			//In case of importing another course, create the ILO list to associate each activity to import.
			if ( $_GET["SourceID"] != $_GET["TargetID"] ) {
				//Get ILOs list from Target Course
				$sql = "SELECT ID,Text FROM courses_ilos WHERE CourseID=".$_GET["TargetID"]." ORDER BY Position";
				$ilo_list = "";
				$result = $conn->query($sql);
				if ($result->num_rows > 0)  {
					while($row = $result->fetch_assoc()) {	
						$ilo_list = $ilo_list."<option value=\"".$row["ID"]."\">".$row["Text"]."</option>/n";
					}
				}
				$bEqual = false;
			} else {
				$bEqual = true;
			}
			
			//Get activities list
			$sql = "SELECT ID,Name FROM teacher_activities WHERE UserID=".$_GET["UserID"]." AND CourseID=".$_GET["SourceID"].
					" AND Semester='".$_GET["SemesterID"]."' ORDER BY Position";
			$result = $conn->query($sql);
			$Acts  = "";
			if ($result->num_rows > 0)  {
				if (!$bEqual) { $Acts = "<tr><td></td><td></td><td>Asociar al RAP:</td></tr>\n"; }
				while($row = $result->fetch_assoc()) {	
					$Acts = $Acts."<tr><td></td><td><input type=\"checkbox\" id=\"act".$row["ID"]."\">".$row["Name"]."</td>";
					if (!$bEqual) {
						$Acts = $Acts."<td><select id=\"rap".$row["ID"]."\">".$ilo_list."</select></td>";
					}
					$Acts = $Acts."</tr>\n";
				}
			}
			
			//Rubric List
			//-----------
			
			if ( !$bEqual ) {
				//Get activity list from Target Course
				$sql = "SELECT ID,Name FROM teacher_activities WHERE UserID=".$_GET["UserID"]." AND CourseID=".$_GET["TargetID"].
						" AND Semester='".$activeSemester."' ORDER BY Position"; 
				$act_list = "<option value=\"0\" selected>** Actividad por defecto **</option>/n";
				$result = $conn->query($sql);
				if ($result->num_rows > 0)  {
					while($row = $result->fetch_assoc()) {	
						$act_list = $act_list."<option value=\"".$row["ID"]."\">".$row["Name"]."</option>/n";
					}
				}
			}
			
			//Get rubric list
			$sql = "SELECT RubricID FROM rubrics_assoc WHERE RapSkillType=4 AND RapSkillID IN 
					 (SELECT ID FROM teacher_activities WHERE UserID=".$_GET["UserID"]." AND CourseID=".$_GET["SourceID"]." AND Semester='".$_GET["SemesterID"]."')";
			$result = $conn->query($sql);
			$Rubs  = "";
			$tableheader = false;
			if ($result->num_rows > 0)  {
				while($row = $result->fetch_assoc()) {	
					$sql = "SELECT ID,Name,Scope FROM rubrics_general WHERE ID=".$row["RubricID"];
					$result_rub = $conn->query($sql);
					$row_rub = $result_rub->fetch_assoc();
					if ($row_rub["Scope"]!=2) 
						continue;
					if (!$bEqual && !$tableheader) { 
						$Rubs = "<tr><td></td><td></td><td>Asociar a la actividad:</td></tr>\n"; 
						$tableheader = true;
					}
					$Rubs = $Rubs."<tr><td></td><td><input type=\"checkbox\" id=\"rub".$row_rub["ID"]."\">".$row_rub["Name"]."</td>";
					if (!$bEqual) {
						$Rubs = $Rubs."<td><select id=\"actr".$row_rub["ID"]."\">".$act_list."</select></td>";
					}
					$Rubs = $Rubs."</tr>\n";
				}
			}
					
			//Send data using JSON encoding
			header('Content-type: application/json');
			$json_data = array();
			$json_data["Acts"] = $Acts;
			$json_data["Rubs"] = $Rubs;
			echo json_encode($json_data);
			break;

			
		//Perform Importing
		case "import":
			$UserID = $_GET["UserID"];
			$TargetID = $_GET["TargetID"];
			$SourceID = $_GET["SourceID"];
			$SemesterID = $_GET["SemesterID"];
			
			//Get PlanID
			$sql = "SELECT PlanID FROM courses_general WHERE ID=".$TargetID;
			$result = $conn->query($sql);
			if ($result->num_rows == 0) return;
			$row = $result->fetch_assoc();
			$PlanID = $row["PlanID"];
			
			//Get active semester
			$sql = "SELECT SemesterName FROM semesters ORDER BY SemesterName DESC";
			$result = $conn->query($sql);
			if ($result->num_rows == 0) return;
			$row = $result->fetch_assoc();
			$activeSemester = $row["SemesterName"];
			
			$bEqual = ($_GET["SourceID"] == $_GET["TargetID"] );

			//Import HowTos
			if ( $bEqual & isset($_GET["howtos"]) ) {
				$sql = "SELECT RapID,HowTo FROM teacher_howtos WHERE UserID=".$UserID." AND CourseID=".$SourceID." AND Semester='".$SemesterID."'";
				$r_src = $conn->query($sql);
				if ($r_src->num_rows > 0)  {
					while($row_src = $r_src->fetch_assoc()) {
						//If HowTos are already set for the target course, update its values.
						$sql = "SELECT ID FROM teacher_howtos WHERE UserID=".$UserID." AND CourseID=".$TargetID." AND Semester='".$activeSemester."' AND RapID=".$row_src["RapID"];
						$r_tar = $conn->query($sql);
						if ($r_tar->num_rows>0) {
							$row_tar = $r_tar->fetch_assoc();
							$sql = "UPDATE teacher_howtos SET CourseID=".$TargetID.",RapID=".$row_src["RapID"].",UserID=".$UserID.
									",Semester='".$activeSemester."',HowTo='".$row_src["HowTo"]."' WHERE ID=".$row_tar["ID"];
							$r_tar = $conn->query($sql);
						} else {
							$sql = "INSERT INTO teacher_howtos (CourseID, RapID, UserID, Semester, HowTo) VALUES (".
								$TargetID.",".$row_src["RapID"].",".$UserID.",'".$activeSemester."','".$row_src["HowTo"]."')";
							$r_tar = $conn->query($sql);
						}
					}
				}
			} 			
			
			//Get the next position for activities
			$sql = "SELECT Position FROM teacher_activities WHERE UserID=".$UserID." AND CourseID=".$TargetID." AND Semester='".$activeSemester."' ORDER BY Position DESC";
			$r_src = $conn->query($sql);
			if ($r_src->num_rows > 0)  {
				$row_src = $r_src->fetch_assoc();
				$pos = $row_src["Position"]+1;
			} else {
				$pos = 1;
			}		
			
			$mapAct = array();
			
			//Import activities	
			foreach ($_GET as $key=>$value) {
				if (substr($key,0,3) == "act") {	
					$id = substr($key,3);
					if (!is_numeric($id)) continue;
					
					//Clone the activity
					$sql = "SELECT * FROM teacher_activities WHERE ID=".$id;
					$r_src = $conn->query($sql);
					if ($r_src->num_rows == 0) continue;
					$row_src = $r_src->fetch_assoc();
					
					$sql = "INSERT INTO teacher_activities(PlanID, CourseID, UserID, Semester, Position, Name, Description, HD, HI, TopicID, Evaluation) VALUES (".
							$PlanID.",".$TargetID.",".$UserID.",'".$activeSemester."',".$pos.",'".
							$row_src["Name"]."','".$row_src["Description"]."',".$row_src["HD"].",".$row_src["HI"].",".
							($bEqual ? $row_src["TopicID"] : 0).",'".$row_src["Evaluation"]."')";
					$r_tar = $conn->query($sql);
					$newActID = $conn->insert_id;
					$mapAct[$key] = $newActID;
					$pos++;
						
					//Clone activity associations
					if ($bEqual) {
						//For the same syllabus, import all ILOs and skills
						$sql = "SELECT RapSkillID,RapSkillType FROM teacher_actassoc WHERE ActID=".$id;
						$r_src = $conn->query($sql);
						if ($r_src->num_rows>0) {
							while( $row_src = $r_src->fetch_assoc()) {
								$sql = "INSERT INTO teacher_actassoc(ActID, RapSkillID, RapSkillType) VALUES (".
										$newActID.",".$row_src["RapSkillID"].",".$row_src["RapSkillType"].")";
								$r_tar = $conn->query($sql);									
							}	
						}
					} else {
						//For different syllabus import only ILOs		
						$sql = "INSERT INTO teacher_actassoc(ActID, RapSkillID, RapSkillType) VALUES (".$newActID.",".$value.",0)";
						$r_tar = $conn->query($sql);				
					}
					
					//Clone generic rubrics associated to the activity
					if (isset($_GET["grubs"])) {
						$sql = "SELECT rubrics_assoc.RubricID FROM rubrics_assoc INNER JOIN
									rubrics_general ON rubrics_general.ID = rubrics_assoc.RubricID
									WHERE rubrics_assoc.RapSkillID=".$id." AND rubrics_assoc.RapSkillType=4 AND rubrics_general.Scope!=2";
						$r_src = $conn->query($sql);
						if ($r_src->num_rows>0) {
							while( $row_src = $r_src->fetch_assoc()) {
								$sql = "INSERT INTO rubrics_assoc (RubricID,PlanID,CourseID,RapSkillID,RapSkillType) VALUES (".
										$row_src["RubricID"].",".$PlanID.",".$TargetID.",".$newActID.",4)";
								$r_tar = $conn->query($sql);		
							}	
						}	
					}
				}
			}
			
			//Import rubrics
			foreach ($_GET as $key=>$value) {
				if (substr($key,0,3) == "rub") {	
					$RubricID = substr($key,3);
					
					//In case of a default activity, check if the activity has been imported
					if ($value == 0) {
						$sql = "SELECT RapSkillID FROM rubrics_assoc WHERE RubricID=".$RubricID." AND CourseID=".$SourceID." AND RapSkillType=4";
						$result = $conn->query($sql);
						$bAnyAct = false;
						if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()) {
								if (isset($mapAct["act".$row["RapSkillID"]])) {		
									$bAnyAct = true;
								}
							}
						}
						if (!$bAnyAct) { //If activity is not imported, rubric will not be also imported
							continue;
						}
					}
						
					//Clone activity rubrics
					$NewRubricID = $planea->cloneRubric($RubricID, false);
					
					//Clone rubric associations
					if ($NewRubricID > 0) {	
						if ($bEqual || ($value==0) ) {
							//For the same syllabus or different syllabus but default activity...
							$sql = "SELECT * FROM rubrics_assoc WHERE RubricID=".$RubricID;
							$r_src = $conn->query($sql);
							if ($r_src->num_rows>0) {
								while( $row_src = $r_src->fetch_assoc()) {
									if (isset($mapAct["act".$row_src["RapSkillID"]])) {										
										$sql = "INSERT INTO rubrics_assoc (RubricID,PlanID,CourseID,RapSkillID,RapSkillType) VALUES (".
												$NewRubricID.",".$PlanID.",".$TargetID.",".$mapAct["act".$row_src["RapSkillID"]].",4)";
										$r_tar = $conn->query($sql);
									}
								}	
							}	
						} else {
							//For different syllabus...		
							$sql = "INSERT INTO rubrics_assoc (RubricID,PlanID,CourseID,RapSkillID,RapSkillType) VALUES (".
								$NewRubricID.",".$PlanID.",".$TargetID.",".$value.",4)";
							$r_tar = $conn->query($sql);				
						}
					}
				}
			}
			break;
	}
	
	$planea->closeConnection();
?>