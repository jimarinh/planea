<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
foreach ($_GET as $key=>$value) {
		if (substr($key,0,3) == "pos") {	
			$id = substr($key,3);
			$sql = "UPDATE courses_ilos SET Position=". $_GET["pos".$id] ." WHERE ID=".$id;
			$planea->conn->query($sql);
		}
	}
$planea->closeConnection();
?>