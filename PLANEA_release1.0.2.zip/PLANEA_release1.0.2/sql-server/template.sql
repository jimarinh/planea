-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 12-06-2020 a las 15:14:38
-- Versión del servidor: 5.6.41-84.1
-- Versión de PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ingelect_planea_ie`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cdiosyllabus_cdio_skills`
--

CREATE TABLE `cdiosyllabus_cdio_skills` (
  `ID` int(11) NOT NULL,
  `ref_syllabus` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `description` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `level` int(11) NOT NULL,
  `parentID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Habilidades CDIO según Syllabus';

--
-- Volcado de datos para la tabla `cdiosyllabus_cdio_skills`
--

INSERT INTO `cdiosyllabus_cdio_skills` (`ID`, `ref_syllabus`, `description`, `level`, `parentID`) VALUES
(1, '4.1', '--- Contexto Externo, Social y Ambiental', 2, 0),
(2, '4.1.1', 'El rol y responsabilidad del ingeniero', 3, 1),
(3, '4.1.2', 'El impacto de la ingeniería en la sociedad y el ambiente', 3, 1),
(4, '4.1.3', 'Regulaciones sociales (normatividad) sobre la ingeniería', 3, 1),
(5, '4.1.4', 'Contexto histórico y cultural', 3, 1),
(6, '4.1.5', 'Comprensión de la actualidad y valores contemporáneos', 3, 1),
(7, '4.1.6', 'Desarrollar una perspectiva global', 3, 1),
(8, '4.1.7', 'Reconocer la sostenibilidad y necesidad de desarrollo sostenible en su rol como ingeniero', 3, 1),
(9, '4.2', '--- Contexto organizacional y de negocios', 2, 0),
(10, '4.2.1', 'Apreciar diferentes culturas organizacionales', 3, 9),
(11, '4.2.2', 'Reconocer la estrategia empresarial, metas y sistema de planificación', 3, 9),
(12, '4.2.3', 'Emprendimiento', 3, 9),
(13, '4.2.4', 'Trabajo efectivo en organizaciones', 3, 9),
(14, '4.2.5', 'Trabajo efectivo en organizaciones internacionales', 3, 9),
(15, '4.2.6', 'Desarrollar y evaluar nuevas tecnologías', 3, 9),
(16, '4.2.7', 'Reconocer aspectos financieros y económicos de proyectos de ingeniería', 3, 9),
(17, '4.3', '--- Concepción y aplicación de la ingeniería a los sistemas y la administración', 2, 0),
(18, '4.3.1', 'Definir requerimientos y metas del sistema', 3, 17),
(19, '4.3.2', 'Definir funciones, conceptos y arquitectura del sistema', 3, 17),
(20, '4.3.3', 'Desarrollar modelos del sistema e interfaces', 3, 17),
(21, '4.3.4', 'Planear proyectos', 3, 17),
(22, '4.4', '--- Diseño', 2, 0),
(23, '4.4.1', 'El proceso de diseño', 3, 22),
(24, '4.4.2', 'Las fases y enfoques alternativos de diseño', 3, 22),
(25, '4.4.3', 'Utilización del conocimiento técnico en el diseño', 3, 22),
(26, '4.4.4', 'Diseño disciplinario', 3, 22),
(27, '4.4.5', 'Diseño multidisciplinario', 3, 22),
(28, '4.4.6', 'Diseño para la sostenibilidad, seguridad, estética, operabilidad y otros objetivos', 3, 22),
(29, '4.5', '--- Implementación', 2, 0),
(30, '4.5.1', 'Proponer procesos de implementación sostenibles', 3, 29),
(31, '4.5.2', 'Concebir el proceso de fabricación de equipos (hardware)', 3, 29),
(32, '4.5.3', 'Concebir el proceso de Implementación de Software', 3, 29),
(33, '4.5.4', 'Proponer procesos de integración hardware-software', 3, 29),
(34, '4.5.5', 'Concebir pruebas, verificaciones, validaciones y certificaciones', 3, 29),
(35, '4.5.6', 'Administración de la implementación', 3, 29),
(36, '4.6', '--- Operación', 2, 0),
(37, '4.6.1', 'Diseñar y optimizar operaciones en forma sostenible y segura', 3, 36),
(38, '4.6.2', 'Proponer planes de entrenamiento y capacitación de las operaciones', 3, 36),
(39, '4.6.3', ' Soporte durante el ciclo de vida del sistema', 3, 36),
(40, '4.6.4', 'Reconocer la evolución y mejoramiento del sistema', 3, 36),
(41, '4.6.5', 'Manejo de fin de vida útil y desechos', 3, 36),
(42, '4.6.6', 'Administración de Operaciones', 3, 36),
(43, '4.7', '--- Liderazgo en Ingeniería', 2, 0),
(44, '4.7.1', 'Identificación del Aspecto, Problema o Paradoja', 3, 43),
(45, '4.7.2', 'Pensamiento Creativo y Posibilidades de Comunicación', 3, 43),
(46, '4.7.3', 'Definición de la Solución', 3, 43),
(47, '4.7.4', 'Creación de Nuevos Conceptos de Solución', 3, 43),
(48, '4.7.5', 'Construcción y Conducción de una Organización', 3, 43),
(49, '4.7.6', 'Planificación y Administración de un Proyecto hasta Completarlo', 3, 43),
(50, '4.7.7', 'Jucio de Proyectos/Soluciones y Razonamiento Crítico', 3, 43),
(51, '4.7.8', 'Innovación - La Concepción, Diseño e Introducción de Nuevos Bienes y Servicios', 3, 43),
(52, '4.7.9', 'Invención - El Desarrollo de Nuevos Dispositivos, Materiales y Procesos que Conducen a Nuevos Bienes', 3, 43),
(53, '4.7.10', 'Implementación y Operación - La Creación y Operación de Bienes y Servicios que Conducen a Valor Agre', 3, 43),
(54, '4.8', '--- Emprenderismo', 2, 0),
(55, '4.8.1', 'Formación, Formulación, Liderazgo y Organización de Empresas', 3, 54),
(56, '4.8.2', 'Desarrollo de Plan de Negocios', 3, 54),
(57, '4.8.3', 'Capitalización y Financiamiento de una Compañía', 3, 54),
(58, '4.8.4', 'Mercadeo Innovador de Productos', 3, 54),
(59, '4.8.5', 'Concepción de Productos y Servicios Enmarcados en Nuevas Tecnologías', 3, 54),
(60, '4.8.6', 'El Sistema de Innovación, Redes, Infraestructura y Servicios', 3, 54),
(61, '4.8.7', 'Construcción de Equipos e Iniciación de Procesos en Ingeniería', 3, 54),
(62, '4.8.8', 'Manejo de la Propiedad Intelectual', 3, 54);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cdiosyllabus_interpersonal_skills`
--

CREATE TABLE `cdiosyllabus_interpersonal_skills` (
  `ID` int(11) NOT NULL,
  `ref_syllabus` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `description` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `level` int(11) NOT NULL,
  `parentID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Habilidades interpersonales (comunicación y trabajo en equip';

--
-- Volcado de datos para la tabla `cdiosyllabus_interpersonal_skills`
--

INSERT INTO `cdiosyllabus_interpersonal_skills` (`ID`, `ref_syllabus`, `description`, `level`, `parentID`) VALUES
(1, '3.1', '--- Trabajo en Equipo', 2, 0),
(2, '3.1.1', 'Capacidad de formación de equipos efectivos', 3, 1),
(3, '3.1.2', 'Capacidad de gestión de equipos', 3, 1),
(4, '3.1.3', 'Identificar y desarrollar habilidades para el crecimiento y evolución del equipo', 3, 1),
(5, '3.1.4', 'Capacidad de liderazgo de equipos', 3, 1),
(6, '3.1.5', 'Capacidad de trabajar en distintos tipos de equipos y colaborar técnicamente', 3, 1),
(7, '3.2', '--- Comunicación Efectiva', 2, 0),
(8, '3.2.1', 'Analizar situaciones y elegir estrategias comunicacionales', 3, 7),
(9, '3.2.2', 'Construir estructuras comunicacionales adecuadas', 3, 7),
(10, '3.2.3', 'Capacidad de comunicación escrita efectiva', 3, 7),
(11, '3.2.4', 'Capacidad de comunicación por medios Electrónicos/Multimedia', 3, 7),
(12, '3.2.5', 'Capacidad de comunicación por medios gráficos', 3, 7),
(13, '3.2.6', 'Capacidad de comunicación por presentaciones orales', 3, 7),
(14, '3.2.7', 'Capacidad para solicitar amablemente, escuchar y dialogar', 3, 7),
(15, '3.2.8', 'Capacidad de negociación, compromiso y resolución de conflictos', 3, 7),
(16, '3.2.9', 'Capacidad de defensa con argumentos', 3, 7),
(17, '3.2.10', 'Capacidad de interactuar con diferentes individuos y comunidades (networking)', 3, 7),
(18, '3.3', '--- Comunicación en Lengua Extranjera', 2, 0),
(19, '3.3.1', 'Capacidad de comprender e interpretar textos escritos en inglés', 3, 18),
(20, '3.3.2', 'Capacidad de comunicarse de forma escrita en inglés', 3, 18);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cdiosyllabus_personal_skills`
--

CREATE TABLE `cdiosyllabus_personal_skills` (
  `ID` int(11) NOT NULL,
  `ref_syllabus` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `description` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `level` int(11) NOT NULL,
  `parentID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Habilidades personales segun CDIO Syllabus';

--
-- Volcado de datos para la tabla `cdiosyllabus_personal_skills`
--

INSERT INTO `cdiosyllabus_personal_skills` (`ID`, `ref_syllabus`, `description`, `level`, `parentID`) VALUES
(1, '2.1', '--Solución de problemas y razonamiento ingenieril', 2, 0),
(2, '2.1.1', 'Identificar y formular problemas', 3, 1),
(3, '2.1.2', 'Crear y usar modelos', 3, 1),
(4, '2.1.3', 'Estimar y analizar problemas de forma cualitativa', 3, 1),
(5, '2.1.4', 'Analizar problemas bajo condiciones de incertidumbre', 3, 1),
(6, '2.1.5', 'Solucionar problemas y establecer recomendaciones', 3, 1),
(7, '2.2', '--- Experimentación y conducción de investigaciones', 2, 0),
(8, '2.2.1', 'Formular hipótesis', 3, 7),
(9, '2.2.2', 'Realizar búsqueda de literatura impresa y electrónica', 3, 7),
(10, '2.2.3', 'Conducir investigaciones experimentales', 3, 7),
(11, '2.2.4', 'Probar y defender hipótesis', 3, 7),
(12, '2.3', '--- Pensamiento Sistémico', 2, 0),
(13, '2.3.1', 'Pensar holísticamente', 3, 12),
(14, '2.3.2', 'Analizar la interacción de componentes y nuevos elementos', 3, 12),
(15, '2.3.3', 'Priorizar y sintetizar', 3, 12),
(16, '2.3.4', 'Resolver realizando juicio crítico y alcanzando balance entre los trade-off', 3, 12),
(17, '2.4', '--- Habilidades y actitudes personales', 2, 0),
(18, '2.4.1', 'Iniciativa y disposición de aceptar riesgos', 3, 17),
(19, '2.4.2', 'Responsabilidad, urgencia para entrega, adaptación al cambio', 3, 17),
(20, '2.4.3', 'Pensamiento Creativo', 3, 17),
(21, '2.4.4', 'Pensamiento Crítico', 3, 17),
(22, '2.4.5', 'Conciencia de competencias personales (Autonomía, Metacognición e Integración de Conocimiento)', 3, 17),
(23, '2.4.6', 'Curiosidad y disposición a aprender de por vida', 3, 17),
(24, '2.4.7', 'Gestión del tiempo y recursos', 3, 17),
(25, '2.5', '--- Habilidades y actitudes profesionales', 2, 0),
(26, '2.5.1', 'Ética profesional, integridad y responsabilidad social', 3, 25),
(27, '2.5.2', 'Comportamiento profesional', 3, 25),
(28, '2.5.3', 'Planificación proactiva de su carrera profesional', 3, 25),
(29, '2.5.4', 'Disposición a mantenerse actualizado en el mundo de la ingeniería', 3, 25),
(30, '2.5.5', 'Equidad y Diversidad', 3, 25);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `coursecat_sets`
--

CREATE TABLE `coursecat_sets` (
  `ID` int(11) NOT NULL,
  `SetName` text COLLATE utf8_unicode_ci NOT NULL,
  `Description` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `coursecat_values`
--

CREATE TABLE `coursecat_values` (
  `ID` int(11) NOT NULL,
  `SetID` int(11) NOT NULL,
  `Value` text COLLATE utf8_unicode_ci NOT NULL,
  `Position` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `courses_cdio_skills`
--

CREATE TABLE `courses_cdio_skills` (
  `ID` int(11) NOT NULL,
  `CourseID` int(11) NOT NULL,
  `SkillID` int(11) NOT NULL,
  `Introduce` tinyint(1) NOT NULL,
  `Teach` tinyint(1) NOT NULL,
  `Utilize` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `courses_contents`
--

CREATE TABLE `courses_contents` (
  `ID` int(11) NOT NULL,
  `TopicNumber` int(11) NOT NULL,
  `TopicName` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Weeks` int(11) NOT NULL,
  `Contents` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `CourseID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `courses_elective`
--

CREATE TABLE `courses_elective` (
  `ID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `CourseID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `courses_electivecats`
--

CREATE TABLE `courses_electivecats` (
  `ID` int(11) NOT NULL,
  `PlanID` int(11) NOT NULL,
  `CategoryName` text COLLATE utf8_unicode_ci NOT NULL,
  `Credits` int(11) NOT NULL,
  `Semester` int(11) NOT NULL,
  `ForceSemester` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `courses_general`
--

CREATE TABLE `courses_general` (
  `ID` int(11) NOT NULL,
  `PlanID` int(11) NOT NULL,
  `CourseKeyID` int(11) NOT NULL,
  `Codigo` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Nombre` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Semestre` int(11) NOT NULL,
  `Habilitable` tinyint(1) NOT NULL,
  `Validable` tinyint(1) NOT NULL,
  `Homologable` tinyint(1) NOT NULL,
  `NumeroCreditos` int(11) DEFAULT NULL,
  `HorasTeoricas` int(11) DEFAULT NULL,
  `HorasPracticas` int(11) DEFAULT NULL,
  `HorasTeoricoPracticas` int(11) DEFAULT NULL,
  `HorasAsesoria` int(11) DEFAULT NULL,
  `HorasIndependientes` int(11) DEFAULT NULL,
  `Naturaleza` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `TipoActividad` varchar(60) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `TipoMetodologia` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `TipoEvaluacion` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `NucleoTematico` text COLLATE utf8_unicode_ci,
  `Descripcion` text CHARACTER SET utf8 COLLATE utf8_spanish_ci,
  `Justificacion` text CHARACTER SET utf8 COLLATE utf8_spanish_ci,
  `ProcesosIntegracion` text CHARACTER SET utf8 COLLATE utf8_spanish_ci,
  `Metodologia` text CHARACTER SET utf8 COLLATE utf8_spanish_ci,
  `Evaluacion` text CHARACTER SET utf8 COLLATE utf8_spanish_ci,
  `Bibliografia` text CHARACTER SET utf8 COLLATE utf8_spanish_ci,
  `ContenidosProcedimentales` text CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `ContenidosActitudinales` text CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `Version` int(11) NOT NULL,
  `FechaVersion` date NOT NULL,
  `VisVersion` tinyint(1) NOT NULL,
  `EstadoVersion` int(11) NOT NULL,
  `VersionAnotacion` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `VersionResponsable` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Template` text CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `courses_ilos`
--

CREATE TABLE `courses_ilos` (
  `ID` int(11) NOT NULL,
  `CourseID` int(11) NOT NULL,
  `VerbID` int(11) NOT NULL,
  `Text` text COLLATE utf8_unicode_ci NOT NULL,
  `Position` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `ProgramILOID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `courses_interpersonal_skills`
--

CREATE TABLE `courses_interpersonal_skills` (
  `ID` int(11) NOT NULL,
  `CourseID` int(11) NOT NULL,
  `SkillID` int(11) NOT NULL,
  `Introduce` tinyint(1) NOT NULL,
  `Teach` tinyint(1) NOT NULL,
  `Utilize` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `courses_personal_skills`
--

CREATE TABLE `courses_personal_skills` (
  `ID` int(11) NOT NULL,
  `CourseID` int(11) NOT NULL,
  `SkillID` int(11) NOT NULL,
  `Introduce` tinyint(1) NOT NULL,
  `Teach` tinyint(1) NOT NULL,
  `Utilize` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `courses_plan`
--

CREATE TABLE `courses_plan` (
  `ID` int(11) NOT NULL,
  `PlanID` int(11) NOT NULL,
  `Nombre` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `courses_reqs`
--

CREATE TABLE `courses_reqs` (
  `ID` int(11) NOT NULL,
  `CourseID` int(11) NOT NULL,
  `RequirementID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eval_areas`
--

CREATE TABLE `eval_areas` (
  `ID` int(11) NOT NULL,
  `PlanID` int(11) NOT NULL,
  `AreaName` text COLLATE utf8_unicode_ci NOT NULL,
  `Semester` text COLLATE utf8_unicode_ci NOT NULL,
  `Date` date NOT NULL,
  `UserID` int(11) NOT NULL,
  `State` int(11) NOT NULL,
  `UnknownPrevSkills` text COLLATE utf8_unicode_ci NOT NULL,
  `UncoveredTopics` text COLLATE utf8_unicode_ci NOT NULL,
  `IrrelevantTopics` text COLLATE utf8_unicode_ci NOT NULL,
  `StudentProblems` text COLLATE utf8_unicode_ci NOT NULL,
  `SuccessfulExp` text COLLATE utf8_unicode_ci NOT NULL,
  `UnsuccessfulExp` text COLLATE utf8_unicode_ci NOT NULL,
  `ImprovMeasures` text COLLATE utf8_unicode_ci NOT NULL,
  `PercentApproved` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `eval_courses`
--

CREATE TABLE `eval_courses` (
  `ID` int(11) NOT NULL,
  `PlanID` int(11) NOT NULL,
  `CourseID` int(11) NOT NULL,
  `CourseKeyID` int(11) NOT NULL,
  `Semester` text CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `UserID` int(11) NOT NULL,
  `State` int(11) NOT NULL,
  `Date` date NOT NULL,
  `NStudents` int(11) NOT NULL,
  `NFailedStudents` int(11) NOT NULL,
  `UnknownPrevSkills` text CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `UncoveredTopics` text CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `IrrelevantTopics` text CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `StudentProblems` text CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `SuccessfulExp` text CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `UnsuccessfulExp` text CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `ImprovMeasures` text CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ilo_categories`
--

CREATE TABLE `ilo_categories` (
  `ID` int(11) NOT NULL,
  `SetID` int(11) NOT NULL,
  `Value` text COLLATE utf8_unicode_ci NOT NULL,
  `Position` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ilo_program`
--

CREATE TABLE `ilo_program` (
  `ID` int(11) NOT NULL,
  `PlanID` int(11) NOT NULL,
  `Value` text COLLATE utf8_unicode_ci NOT NULL,
  `Position` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ilo_sets`
--

CREATE TABLE `ilo_sets` (
  `ID` int(11) NOT NULL,
  `SetName` text COLLATE utf8_unicode_ci NOT NULL,
  `Description` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rubrics_assoc`
--

CREATE TABLE `rubrics_assoc` (
  `ID` int(11) NOT NULL,
  `RubricID` int(11) NOT NULL,
  `PlanID` int(11) NOT NULL,
  `CourseID` int(11) NOT NULL,
  `RapSkillID` int(11) NOT NULL,
  `RapSkillType` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rubrics_entries`
--

CREATE TABLE `rubrics_entries` (
  `ID` int(11) NOT NULL,
  `RubricID` int(11) NOT NULL,
  `Criteria` text COLLATE utf8_unicode_ci NOT NULL,
  `DescLevel1` text COLLATE utf8_unicode_ci NOT NULL,
  `DescLevel2` text COLLATE utf8_unicode_ci NOT NULL,
  `DescLevel3` text COLLATE utf8_unicode_ci NOT NULL,
  `DescLevel4` text COLLATE utf8_unicode_ci NOT NULL,
  `Position` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rubrics_general`
--

CREATE TABLE `rubrics_general` (
  `ID` int(11) NOT NULL,
  `Name` text COLLATE utf8_unicode_ci NOT NULL,
  `Description` text COLLATE utf8_unicode_ci NOT NULL,
  `Type` int(11) NOT NULL,
  `NumLevels` int(11) NOT NULL,
  `Scope` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `semesters`
--

CREATE TABLE `semesters` (
  `ID` int(11) NOT NULL,
  `SemesterName` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `study_plan`
--

CREATE TABLE `study_plan` (
  `ID` int(11) NOT NULL,
  `Code` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Faculty` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Program` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `Description` text CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `ILOSetID` int(11) NOT NULL,
  `CatSetID` int(11) NOT NULL,
  `Template` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `teacher_actassoc`
--

CREATE TABLE `teacher_actassoc` (
  `ID` int(11) NOT NULL,
  `ActID` int(11) NOT NULL,
  `RapSkillID` int(11) NOT NULL,
  `RapSkillType` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `teacher_activities`
--

CREATE TABLE `teacher_activities` (
  `ID` int(11) NOT NULL,
  `PlanID` int(11) NOT NULL,
  `CourseID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Semester` text COLLATE utf8_unicode_ci NOT NULL,
  `Position` int(11) NOT NULL,
  `Name` text COLLATE utf8_unicode_ci NOT NULL,
  `Description` text COLLATE utf8_unicode_ci NOT NULL,
  `HD` int(11) NOT NULL,
  `HI` int(11) NOT NULL,
  `TopicID` int(11) NOT NULL,
  `Evaluation` text COLLATE utf8_unicode_ci NOT NULL,
  `StartWeek` int(11) NOT NULL,
  `EndWeek` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `teacher_howtos`
--

CREATE TABLE `teacher_howtos` (
  `ID` int(11) NOT NULL,
  `CourseID` int(11) NOT NULL,
  `RapID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Semester` text COLLATE utf8_unicode_ci NOT NULL,
  `HowTo` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `countryID` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `defaultPlan` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

INSERT INTO `users` (`ID`, `name`, `email`, `role`, `password`, `countryID`, `defaultPlan`) VALUES
(1, 'root', 'root@planea', 'CDA', '$2y$10$VpfGknGc83FjvemrA1ihc.EhJ0sJCwPH8I8koPOd.TihUu2c.NqhG', '0', 1);


--
-- Estructura de tabla para la tabla `users_assignments`
--

CREATE TABLE `users_assignments` (
  `ID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `courseID` int(11) NOT NULL,
  `roleType` int(11) NOT NULL,
  `permissions` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_coordinators`
--

CREATE TABLE `users_coordinators` (
  `ID` int(11) NOT NULL,
  `userID` int(11) NOT NULL,
  `planID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `verb_list`
--

CREATE TABLE `verb_list` (
  `ID` int(11) NOT NULL,
  `VerbName` text COLLATE utf8_unicode_ci NOT NULL,
  `SOLOLevel` int(11) NOT NULL,
  `SOLOCat` text COLLATE utf8_unicode_ci NOT NULL,
  `BloomLevel` int(11) NOT NULL,
  `StigginsCat` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `verb_list`
--

INSERT INTO `verb_list` (`ID`, `VerbName`, `SOLOLevel`, `SOLOCat`, `BloomLevel`, `StigginsCat`) VALUES
(1, 'Definir', 1, 'D', 1, 1),
(2, 'Identificar', 1, 'D', 2, 1),
(3, 'Memorizar', 1, 'D', 1, 1),
(4, 'Recitar', 1, 'D', 1, 1),
(5, 'Recordar', 1, 'D', 1, 1),
(6, 'Dibujar', 1, 'F', 2, 4),
(7, 'Emparejar', 1, 'F', 4, 4),
(8, 'Encontrar', 1, 'F', 1, 4),
(9, 'Etiquetar', 1, 'F', 1, 4),
(10, 'Igualar', 1, 'F', 1, 4),
(11, 'Localizar', 1, 'F', 2, 4),
(12, 'Nombrar', 1, 'F', 1, 4),
(13, 'Ordenar', 1, 'F', 4, 4),
(14, 'Reconocer', 1, 'F', 2, 1),
(15, 'Seleccionar', 1, 'F', 2, 2),
(16, 'Describir', 2, 'D', 2, 2),
(17, 'Listar', 2, 'D', 1, 2),
(18, 'Bosquejar', 2, 'F', 3, 4),
(19, 'Calcular', 2, 'F', 3, 4),
(20, 'Combinar', 2, 'F', 3, 4),
(21, 'Seguir un procedimiento', 2, 'F', 1, 4),
(22, 'Analizar', 3, 'D', 4, 2),
(23, 'Clasificar', 3, 'D', 2, 2),
(24, 'Comparar', 3, 'D', 4, 2),
(25, 'Constrastar', 3, 'D', 4, 2),
(26, 'Distinguir', 3, 'D', 4, 2),
(27, 'Explicar causas', 3, 'D', 2, 2),
(28, 'Explicar efectos', 3, 'D', 2, 2),
(29, 'Valorar', 3, 'D', 5, 1),
(30, 'Aplicar', 3, 'F', 3, 4),
(31, 'Demostrar', 3, 'F', 3, 4),
(32, 'Discutir', 3, 'F', 2, 2),
(33, 'Entrevistar', 3, 'F', 4, 4),
(34, 'Formular', 3, 'F', 6, 4),
(35, 'Hacer una analogía', 3, 'F', 6, 4),
(36, 'Implementar', 3, 'F', 3, 3),
(37, 'Integrar', 3, 'F', 6, 4),
(38, 'Intrepretar', 3, 'F', 3, 2),
(39, 'Preguntar', 3, 'F', 4, 4),
(40, 'Relacionar', 3, 'F', 4, 4),
(41, 'Solucionar', 3, 'F', 3, 4),
(42, 'Traducir', 3, 'F', 2, 4),
(43, 'Usar', 3, 'F', 3, 4),
(44, 'Generalizar', 4, 'D', 5, 3),
(45, 'Plantear hipótesis', 4, 'D', 6, 3),
(46, 'Teorizar', 4, 'D', 6, 3),
(47, 'Argumentar', 4, 'F', 5, 2),
(48, 'Componer', 4, 'F', 6, 2),
(49, 'Construir', 4, 'F', 6, 4),
(50, 'Crear', 4, 'F', 6, 3),
(51, 'Desarrollar', 4, 'F', 6, 4),
(52, 'Diseñar', 4, 'F', 6, 4),
(53, 'Evaluar', 4, 'F', 5, 4),
(54, 'Inventar', 4, 'F', 6, 3),
(55, 'Justificar', 4, 'F', 5, 2),
(56, 'Planear', 4, 'F', 3, 4),
(57, 'Predecir', 4, 'F', 5, 4),
(58, 'Priorizar', 4, 'F', 5, 4),
(59, 'Probar', 4, 'F', 4, 4),
(60, 'Reflejar', 4, 'F', 5, 4);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cdiosyllabus_cdio_skills`
--
ALTER TABLE `cdiosyllabus_cdio_skills`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `cdiosyllabus_interpersonal_skills`
--
ALTER TABLE `cdiosyllabus_interpersonal_skills`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `cdiosyllabus_personal_skills`
--
ALTER TABLE `cdiosyllabus_personal_skills`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `coursecat_sets`
--
ALTER TABLE `coursecat_sets`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `coursecat_values`
--
ALTER TABLE `coursecat_values`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `courses_cdio_skills`
--
ALTER TABLE `courses_cdio_skills`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `courses_contents`
--
ALTER TABLE `courses_contents`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `courses_elective`
--
ALTER TABLE `courses_elective`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `courses_electivecats`
--
ALTER TABLE `courses_electivecats`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `courses_general`
--
ALTER TABLE `courses_general`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `courses_ilos`
--
ALTER TABLE `courses_ilos`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `courses_interpersonal_skills`
--
ALTER TABLE `courses_interpersonal_skills`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `courses_personal_skills`
--
ALTER TABLE `courses_personal_skills`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `courses_plan`
--
ALTER TABLE `courses_plan`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `courses_reqs`
--
ALTER TABLE `courses_reqs`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `eval_areas`
--
ALTER TABLE `eval_areas`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `eval_courses`
--
ALTER TABLE `eval_courses`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `ilo_categories`
--
ALTER TABLE `ilo_categories`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `ilo_program`
--
ALTER TABLE `ilo_program`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `ilo_sets`
--
ALTER TABLE `ilo_sets`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `rubrics_assoc`
--
ALTER TABLE `rubrics_assoc`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `rubrics_entries`
--
ALTER TABLE `rubrics_entries`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `rubrics_general`
--
ALTER TABLE `rubrics_general`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `semesters`
--
ALTER TABLE `semesters`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `study_plan`
--
ALTER TABLE `study_plan`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `teacher_actassoc`
--
ALTER TABLE `teacher_actassoc`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `teacher_activities`
--
ALTER TABLE `teacher_activities`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `teacher_howtos`
--
ALTER TABLE `teacher_howtos`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `users_assignments`
--
ALTER TABLE `users_assignments`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `users_coordinators`
--
ALTER TABLE `users_coordinators`
  ADD PRIMARY KEY (`ID`);

--
-- Indices de la tabla `verb_list`
--
ALTER TABLE `verb_list`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cdiosyllabus_cdio_skills`
--
ALTER TABLE `cdiosyllabus_cdio_skills`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT de la tabla `cdiosyllabus_interpersonal_skills`
--
ALTER TABLE `cdiosyllabus_interpersonal_skills`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `cdiosyllabus_personal_skills`
--
ALTER TABLE `cdiosyllabus_personal_skills`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de la tabla `coursecat_sets`
--
ALTER TABLE `coursecat_sets`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `coursecat_values`
--
ALTER TABLE `coursecat_values`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `courses_cdio_skills`
--
ALTER TABLE `courses_cdio_skills`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `courses_contents`
--
ALTER TABLE `courses_contents`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `courses_elective`
--
ALTER TABLE `courses_elective`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `courses_electivecats`
--
ALTER TABLE `courses_electivecats`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `courses_general`
--
ALTER TABLE `courses_general`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `courses_ilos`
--
ALTER TABLE `courses_ilos`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `courses_interpersonal_skills`
--
ALTER TABLE `courses_interpersonal_skills`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `courses_personal_skills`
--
ALTER TABLE `courses_personal_skills`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `courses_plan`
--
ALTER TABLE `courses_plan`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `courses_reqs`
--
ALTER TABLE `courses_reqs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `eval_areas`
--
ALTER TABLE `eval_areas`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `eval_courses`
--
ALTER TABLE `eval_courses`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ilo_categories`
--
ALTER TABLE `ilo_categories`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ilo_program`
--
ALTER TABLE `ilo_program`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ilo_sets`
--
ALTER TABLE `ilo_sets`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `rubrics_assoc`
--
ALTER TABLE `rubrics_assoc`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `rubrics_entries`
--
ALTER TABLE `rubrics_entries`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `rubrics_general`
--
ALTER TABLE `rubrics_general`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `semesters`
--
ALTER TABLE `semesters`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `study_plan`
--
ALTER TABLE `study_plan`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `teacher_actassoc`
--
ALTER TABLE `teacher_actassoc`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `teacher_activities`
--
ALTER TABLE `teacher_activities`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `teacher_howtos`
--
ALTER TABLE `teacher_howtos`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `users_assignments`
--
ALTER TABLE `users_assignments`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `users_coordinators`
--
ALTER TABLE `users_coordinators`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `verb_list`
--
ALTER TABLE `verb_list`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
