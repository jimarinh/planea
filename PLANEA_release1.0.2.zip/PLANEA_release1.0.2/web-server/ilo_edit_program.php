<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
echo $planea->showRAPProgram( $_GET["PlanID"] );
$planea->closeConnection();
?>