<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "SELECT * FROM ilo_sets WHERE ID=" . $_GET["setID"];
$result = $planea->conn->query($sql);
$row = $result->fetch_assoc();
$strTable = $planea->showRAPCustomizableSetEntries( $_GET["setID"] );
header('Content-type: application/json');
$row["Name"] = $row["SetName"];
$row["Description"] = $row["Description"];
$row["Table"] = $strTable;
echo json_encode($row);
$planea->closeConnection();
?>