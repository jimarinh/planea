<?php  
	require('planea_basics.php');

	function displayAnalysisLevel2( $conn, $skills_title, $skills_table, $planID, $showElectives, $showTooltip )
	{	
		//Pone el título de la página
		$strheading = "<h2>" . $skills_title . "</h2>";
	  
		//Captura el listado de cursos
		if ($showElectives) 
			$sql = "SELECT ID, Nombre, Semestre FROM courses_general WHERE PlanID=".$planID." AND VisVersion=1 ORDER BY Semestre, Nombre";
		else
			$sql = "SELECT ID, Nombre, Semestre FROM courses_general WHERE CourseKeyID NOT IN (SELECT CourseID FROM courses_elective) AND PlanID = ".$planID." AND VisVersion=1 ORDER BY Semestre, Nombre";
						
		$result_courses = $conn->query($sql);
		$ncourses = $result_courses->num_rows;
	  
		//Captura el listado de habilidades de nivel 2
		$sql = "SELECT * FROM cdiosyllabus_" . $skills_table . " WHERE level=2";
		$result_skill  = $conn->query($sql);
		$nskills = $result_skill->num_rows;

		//Pone el listado de habilidades de nivel 2
		$strheading = $strheading. "<p><small>";
		for ($i = 0; $i<$nskills; $i++) {	
			$skill = $result_skill->fetch_assoc();
			$strheading = $strheading. $skill["ref_syllabus"].". ".$skill["description"]."<br>\n";
		}
		$strheading = $strheading. "</small></p>\n";
		
		//Pone el encabezado con el listado de habilidades de nivel 2
		$sql = "SELECT * FROM cdiosyllabus_" . $skills_table;
		$result_skill  = $conn->query($sql);
		$nskills = $result_skill->num_rows;
		
		$strtable = "<table id=\"skTb\" style=\"width:100%\"> <tr>\n<th>Sem</th><th>Curso</th>\n";
		$nskills_n2 = 0;
		$skills_list = array();
		$skills_parent = array();
		$skills_names = array();
		while( $skill = $result_skill->fetch_assoc() ) {
			$skills_parent[$skill["ID"]] = $skill["parentID"];
			if ($skill["level"]==2) {
				$strtable = $strtable. "<th>".$skill["ref_syllabus"]."</th>\n";
				$skills_list[$nskills_n2] = $skill["ID"];
				$skills_names[$nskills_n2] = $skill["ref_syllabus"].". ".$skill["description"];
				$nskills_n2++;
			}
		}
		$strtable = $strtable. "</tr>\n";
			
		$warnings_skills_info = "";
		
		//Por cada curso busca las habilidades relacionadas y las ubica indicando la información sobre introduce, enseña y utiliza
		for($i = 0; $i < $ncourses; $i++) {
		
			$warnings_skillsIDs = array();
			
			//Limpia las banderas de las habilidades
			$courseSkills = array();
			for ($j = 0; $j<$nskills_n2; $j++) {
				$courseSkills[$j] = 0;
			}
				
			//Captura la información del curso
			$course = $result_courses->fetch_assoc();
		
			//Captura las habilidades para dicho curso    
			$sql = "SELECT * FROM courses_".$skills_table." WHERE CourseID=" . $course["ID"] ." ORDER BY SkillID";
			$result_skillcourse  = $conn->query($sql);
			
			while( $skillinfo = $result_skillcourse->fetch_assoc() ) {
				$skillID_check  = $skillinfo["SkillID"]; 
				$skillID_parent =  $skills_parent[$skillID_check];
				if ( $skillID_parent != 0 ) {
					$skillID_check = $skillID_parent;
					$warnings_skills_flag = false;
				} else {
					$warnings_skills_flag = true;
				}
				for ($j = 0; $j<$nskills_n2; $j++) {	
					$skillID = $skills_list[$j];
					if ( $skillID_check == $skillID )
					{
						if ( $skillinfo["Introduce"]==1 ) { $courseSkills[$j]|=1; }
						if ( $skillinfo["Teach"]==1 ) { $courseSkills[$j]|=2; }
						if ( $skillinfo["Utilize"]==1 ) { $courseSkills[$j]|=4; }
						if ($warnings_skills_flag) {
							array_push($warnings_skillsIDs, $j);
						}
					}
				}
			}
		
			$strtable = $strtable. "<tr> <td><small>" . $course["Semestre"] . "</small></td> <td><small>" . $course["Nombre"] . "</small></td> \n";
			for ($j = 0; $j<$nskills_n2; $j++)
			{	
				$info = "";
				if ( $courseSkills[$j] & 1 ) { $info = $info . "I "; }
				if ( $courseSkills[$j] & 2 ) { $info = $info . "E "; }
				if ( $courseSkills[$j] & 4 ) { $info = $info . "U"; }
				if (empty($info)) $info = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; 
				if ($showTooltip) 
					$strtable = $strtable. "<td><small><div class=\"tooltip\">". $info. "</small><span class=\"tooltiptext\">".$skills_names[$j]."</span></div></td>\n";
				else 
					$strtable = $strtable. "<td><small>". $info. "</small></td>\n";
				
			}
			$strtable = $strtable. "</tr>\n";
			
			if (count($warnings_skillsIDs)>0) {
				$warnings_skills_info .= "<i>".$course["Nombre"]."</i>: ";
				for ($j = 0; $j<count($warnings_skillsIDs); $j++) {
					$warnings_skills_info .= $skills_names[ $warnings_skillsIDs[$j] ] .", ";
				}
				$warnings_skills_info .= "<br>";
			}
		}
		$strtable = $strtable. "</table>";  
		if (strlen($warnings_skills_info)>0) {
			$strwarning = "<p class=\"warningbox\"><b>¡Advertencia! Los siguientes cursos tienen definidas habilidades de nivel 2 
					y se sugiere tener definidas sólo habilidades de nivel 3:</b><br>".$warnings_skills_info."</p>";
		} else { 
			$strwarning = "";
		}
		echo $strheading . $strwarning. $strtable;
	}

	
	$planea = new planea();
	$conn = $planea->openConnection();
	if ( $_GET["skill"] == "personal") {
		//Visualiza las habilidades Personales (Nivel 2)
		displayAnalysisLevel2( $conn, "Habilidades Personales", "personal_skills", $_GET["PlanID"], $_GET["showElect"]=="true", $_GET["showTooltip"]=="true" );
	}
	if ( $_GET["skill"] == "interpersonal") {
		//Visualiza las habilidades Interpersonales (Nivel 2)
		displayAnalysisLevel2( $conn, "Habilidades Interpersonales", "interpersonal_skills", $_GET["PlanID"], $_GET["showElect"]=="true", $_GET["showTooltip"]=="true" );
	}
	if ( $_GET["skill"] == "cdio") {
		//Visualiza las habilidades CDIO (Nivel 2)
		displayAnalysisLevel2( $conn, "Habilidades CDIO", "cdio_skills", $_GET["PlanID"], $_GET["showElect"]=="true", $_GET["showTooltip"]=="true" );
	}
	$planea->closeConnection();
?>