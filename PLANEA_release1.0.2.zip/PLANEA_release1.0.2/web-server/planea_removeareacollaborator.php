<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	$sql = "SELECT PlanID,Semester FROM eval_areas WHERE ID=".$_GET["ID"];
	$result = $conn->query($sql);
	$row = $result->fetch_assoc();
	$planID = $row["PlanID"];
	$semName = $row["Semester"];
	$sql = "UPDATE eval_areas SET UserID=0 WHERE ID=".$_GET["ID"];
	$result = $conn->query($sql);
	$planea->showAreaCollaboratorsForEval($planID,$semName);
	$planea->closeConnection();
?>