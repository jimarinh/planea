<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$CourseID = $_GET["CourseID"];
//Determine the position in the RAP list
$sql = "SELECT Position FROM courses_ilos WHERE CourseID=".$CourseID." ORDER BY Position DESC";
$result = $planea->conn->query($sql);		
if ($result->num_rows > 0)  {
	$row_rap = $result->fetch_assoc();
	$position = $row_rap["Position"]+1;
} else {	
	$position = 1;
}
//Append to RAP list
$sql = "INSERT INTO courses_ilos (CourseID,VerbID,Text,Position,CategoryID,ProgramILOID) 
			VALUES (".$CourseID.",".$_GET["VerbID"].",'" . $_GET["Text"]."',".$position.",".$_GET["CatID"].",".$_GET["ProgILOID"].")";
$res = $planea->conn->query($sql);
$planea->showRAPList( $CourseID, false, true );
$planea->closeConnection();
?>
