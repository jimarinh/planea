<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<style>
		textarea  
		{  
			font-family:"Helvetica", Helvetica, sansserif;  
			font-size: 14px;
			width:100%;
		}
	</style>
</head>

<body onload="configure()">

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();  
	if ($_SESSION["RoleID"]!=planea::roleUser) {
		exit("Seleccione el rol Docente");
	}
	
	$CourseID 	= $_GET["ID"];	
	$SemesterID = isset($_GET["SemesterID"]) ? $_GET["SemesterID"] : $planea->getDefaultSemester();
	$UserID = $_SESSION["UserID"];
	
	//Check if current CourseID is the last available version of the syllabus.
	$sql = "SELECT Nombre,VisVersion,CourseKeyID FROM courses_general WHERE ID=".$CourseID;
	$result = $conn->query($sql);
	$row = $result->fetch_assoc();
	if ( $row["VisVersion"]==0 ) {
		//If CourseID is obsolete and planning has not started, update CourseID, otherwise continue with old CourseID.
		$sql = "SELECT ID FROM teacher_activities WHERE CourseID=".$CourseID." AND UserID=".$UserID." AND Semester='".$SemesterID."'";
		$result_act = $conn->query($sql);
		if ($result_act->num_rows == 0) {
			//Remove HowTos
			$sql = "DELETE FROM teacher_howtos WHERE CourseID=".$CourseID." AND UserID=".$UserID." AND Semester='".$SemesterID."'";
			$result = $conn->query($sql);
			//Fetch last available CourseID
			$sql = "SELECT ID,Nombre FROM courses_general WHERE CourseKeyID=".$row["CourseKeyID"]." AND VisVersion=1";
			$result = $conn->query($sql);
			$row = $result->fetch_assoc();
			//Update user assignments
			$sql = "UPDATE users_assignments SET courseID=".$row["ID"]." WHERE userID=".$UserID." AND roleType=1 AND courseID=".$CourseID;
			$result = $conn->query($sql);
			$CourseID = $row["ID"];
		}
	}
	$CourseName = $row["Nombre"]."(".$SemesterID.")";
	$Action = 1;
?>
	<script type="text/javascript" language="javascript" src="planning_course.js"></script>	
	<script>
		//Functions to configure the working environment
		//-------------------------------------------------
		function configurePanels() {
			HowTosPanel.style.display = "none";
			var span = document.getElementsByClassName("close");
			span[0].onclick = function() { HowTosPanel.style.display = "none"; }
		}
		function configure() {
			configurePanels();
		}
	</script>
	


<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="planning_course_user.php">Planeación de Cursos</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#teacher-planning1" target="PLANEA-help">?</a></li>
</ul>

<ul class="navbar"> 
<li>
	<a <?php if ($Action==1) echo "class=\"active\""; ?> href="planning_course_howtos.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 1: Preguntas</a>
</li>
<li>
	<a <?php if ($Action==2) echo "class=\"active\""; ?> href="planning_course_activities.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 2: Actividades</a>
</li>
<li>
	<a <?php if ($Action==3) echo "class=\"active\""; ?> href="planning_course_schedule.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 3: Cronograma</a>
</li>
<li>
	<a <?php if ($Action==4) echo "class=\"active\""; ?> href="planning_course_eval.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 4: Evaluación</a>
</li>
<li>
	<a <?php if ($Action==5) echo "class=\"active\""; ?> href="planning_course_rubrics.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 5: Rúbricas
	</a>
</li>
<li>
	<a <?php if ($Action==6) echo "class=\"active\""; ?> href="planning_course_summary.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Resumen
	</a>
</li>
<li><a href="view_syllabus.php<?php echo "?ID=".$CourseID;?>"> <?php echo $CourseName; ?> </a></li>
</ul>

<!-- FORM FOR SETTING COURSE HOW TOS -->

<div id="step1" style="display:<?php echo ($Action==1) ? "block" : "none"; ?>">
	<div class="planeaForm">
		<small><p>Antes de definir las actividades y la evaluación, responda por cada uno de los resultados de aprendizaje (RAP) 
			<b>¿cómo el estudiante demuestra que cumple el RAP?.</b> Se recomienda que una vez termine estas respuestas vaya al Paso 2 para la definición de actividades.
		</p></small>
	</div>
	<div class="planeaForm">
		<small><?php $planea->showPlanningCourseHowTos( $CourseID, $SemesterID, $UserID ); ?></small>
	</div>
	<div id="HowTosPanel" class="modal" style="display:none">
	  <!-- Modal content -->
	  <div class="modal-content">
	  <div  class="modal-header">
		<span  class="close">&times;</span >
		<h2 >Preguntas de planeación</h2 >
	  </div>
	  <div  class="modal-body">
		<p>¿Cómo el estudiante demuestra que "<i><font color="green"><span id="HowTosRap"></span></font></i>"?</p>
		<textarea id="HowToText" cols=50 rows=3></textarea> <br><br>
		<button type="button" onclick="editHowToGo(1)">Guardar</button>
		<button type="button" onclick="editHowToGo(2)">Cancelar</button>
	  </div>
	  </div>
	</div>
</div>

<?php $planea->closeConnection(); ?>

</body>
</html>
