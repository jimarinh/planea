<?php
	require('planea_basics.php');  
	$planea = new planea();
	$conn = $planea->openConnection();
	$planea->showVersionList($_GET["courseID"], $_GET["roleID"]);
	$planea->closeConnection();
?>