<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
</head>

<body>

<?php  
	$_SESSION["overrideAuth"] = true;
	require('planea_logosbar.php');
?>

<br>

<?php
	require('planea_basics.php');
  
	$planea = new planea();
	$conn = $planea->openConnection();
	
	if ( isset($_POST["User"]) && !empty($_POST["User"]) ) {
		$sql = "SELECT * FROM users WHERE email=\"" . $_POST["User"]."\"";
		$result = $planea->conn->query($sql);
		$row = $result->fetch_assoc();
		$sql = "UPDATE users SET password='". password_hash($row["countryID"], PASSWORD_DEFAULT) . "' WHERE ID=" . $row["ID"];
		$planea->conn->query($sql);
		$msg = planea::msg_passwordreset1 . $row["countryID"].".". planea::msg_passwordreset2;
		$msg = wordwrap($msg,70);
		mail( $row["email"], "PLANEA - password reset", $msg );
		echo "<p>La contraseña ha sido reiniciada a tu número de documento.</p>";
		echo "<p><a href=\"login.php\">Ingresar de nuevo</a></p>";
	} else {
		echo "<form action=\"recoverpassword.php\" method=\"POST\">
				Usuario: <input type=\"text\" name=\"User\" size=50> <br> <br>
				<input type=\"submit\" value=\"Reiniciar contraseña\">
			</form>";
	}	
	$planea->closeConnection();
?>

</body>
</html>
