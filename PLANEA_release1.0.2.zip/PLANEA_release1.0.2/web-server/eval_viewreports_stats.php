<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$planID = $_GET["PlanID"];
$SemName = $_GET["SemName"];
$sql = "SELECT ID FROM eval_courses WHERE PlanID=".$planID." AND Semester='".$SemName."' AND State=1";
$result = $planea->conn->query($sql);
$numCourseReportsDone = $result->num_rows;

$sql = "SELECT ID FROM eval_courses WHERE PlanID=".$planID." AND Semester='".$SemName."' AND State=0";
$result = $planea->conn->query($sql);
$numCourseReportsPend = $result->num_rows;

$sql = "SELECT ID FROM eval_areas WHERE PlanID=".$planID." AND Semester='".$SemName."' AND State=1";
$result = $planea->conn->query($sql);
$numAreaReportsDone = $result->num_rows;

$sql = "SELECT ID FROM eval_areas WHERE PlanID=".$planID." AND Semester='".$SemName."' AND State=0";
$result = $planea->conn->query($sql);
$numAreaReportsPend = $result->num_rows;

header('Content-type: application/json');
$row["nCRDone"] = $numCourseReportsDone;
$row["nCRPend"] = $numCourseReportsPend;
$row["nARDone"] = $numAreaReportsDone;
$row["nARPend"] = $numAreaReportsPend;
echo json_encode($row);

$planea->closeConnection();
?>
