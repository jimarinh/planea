<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	
	echo "<table>";
	
	echo "<tr><td>Uso de la Plantilla: <u>".$_GET["template"]."</u></td></tr>";
	
	//Retrieve the list of study plans where the template is used
	$sql = "SELECT Program, Code FROM study_plan WHERE study_plan.Template='".$_GET["template"]."' ORDER BY Program, Code";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {	
		echo "<tr><th colspan=\"2\">Planes de estudio que usan la plantilla</th></tr>\n";
		echo "<tr><th>Programa</th><th>Plan</th></tr>\n";
		while ( $row = $result->fetch_assoc() ) {
			echo "<tr><td>".$row["Program"]."</td><td>".$row["Code"]."</td></tr>\n";
		}
	}
	
	echo "<tr><td></td></tr>";
	
	//Retrieve the list of courses where the template is used
	$sql = "SELECT courses_general.Nombre, courses_general.Version, study_plan.Program, study_plan.Code FROM courses_general 
			INNER JOIN study_plan ON study_plan.ID=courses_general.PlanID
			WHERE courses_general.Template='".$_GET["template"]."' ORDER BY Program, Code, Nombre";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		echo "<tr><th colspan=\"4\">Espacios académicos que usan la plantilla</th></tr>\n";
		echo "<tr><th>Programa</th><th>Plan</th><th>Espacio Académico</th><th>Versión</th></tr>\n";
		while ( $row = $result->fetch_assoc() ) {
			echo "<tr><td>".$row["Program"]."</td><td>".$row["Code"]."</td><td>".$row["Nombre"]."</td><td>".$row["Version"]."</td></tr>\n";
		}
	}
	
	echo "</table>";
	
	$planea->closeConnection();
?>