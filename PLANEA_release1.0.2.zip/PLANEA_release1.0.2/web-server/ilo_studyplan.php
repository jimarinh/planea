<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<style>
	textarea  
	{  
		font-family:"Helvetica", Helvetica, sansserif;  
		font-size: 14px;
	}
	</style>
</head>

<body>

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	//Check credentials
	if ($_SESSION["RoleID"]!=planea::roleCoord) {
		exit("<p><font color=\"red\">No tiene permiso para acceder a esta sección</font><p>");
	}
?>

	<script>
	function setModifiedFlag() { window.onbeforeunload = function() { return true; }; }
	function clearModifiedFlag() { window.onbeforeunload = null; return true; }
	function changePlan() {
		var e = document.getElementById("ListOfStudyPlans");
		if (e.selectedIndex == -1) {
			return null;
		}
		document.getElementById("configPanel").style.display = "block";
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("rapList").innerHTML = this.responseText;
				updateArrowBtns();
			}
		}
		xhttp.open("GET", "ilo_edit_program.php?PlanID="+e.value, true);
		xhttp.send();
	}
	function updateArrowBtns() {
		var btnup, btndn, pos;
		var items = document.getElementById("rapList").getElementsByTagName("tr");
		for(pos=0;pos<items.length;pos++) {
			btnup = items[pos].getElementsByClassName("button btn_up");
			btnup[0].style.display = (pos==0) ? "none" : "inline";
			btndn = items[pos].getElementsByClassName("button btn_down");
			btndn[0].style.display = (pos==items.length-1) ? "none" : "inline";
			posinput = items[pos].getElementsByTagName("input");
			posinput[0].value = pos+1;
		}	
	}
	function moveItem(Id, dir) {
		var tr1   = document.getElementById("ilo"+Id);
		if (dir == -1) { tr1.parentNode.insertBefore(tr1, tr1.previousSibling); } else { tr1.parentNode.insertBefore(tr1.nextSibling, tr1); }
		setModifiedFlag();
		updateArrowBtns();
	}
	function removeItem(Id) {		
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				//If program ILO was removed successfully...
				if (this.responseText=="1") {					
					var tr = document.getElementById("ilo"+Id);
					tr.parentNode.removeChild(tr);
					setModifiedFlag();
					updateArrowBtns();
				} else {
					alert("El resultado de aprendizaje no puede ser removido porque está siendo usado por algún sílabo");
				}
			}
		}
		xhttp.open("GET", "ilo_removeprogramILO.php?iloID="+Id, true);
		xhttp.send();
	}
	function addRAP() {	
		var rapName = NewRAP.value;
		var planID 	= ListOfStudyPlans.value;
		var items 	= document.getElementById("rapList").getElementsByTagName("tr");
		var position= items.length+1;
		if (rapName.length>0)
		{ 
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					if (this.responseText.length>0) {
						var iloID = this.responseText;
						var table = document.getElementById("rapList").getElementsByTagName("table");
						var tr_new = table[0].insertRow(-1); 
						var btn1 = "<button class=\"button btn_up\" type=\"button\" onclick=\"moveItem("+iloID+",-1)\"></button>";
						var btn2 = "<button class=\"button btn_down\" type=\"button\" onclick=\"moveItem("+iloID+",1)\"></button>"; 
						var btn3 = "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeItem("+iloID+")\"></button>"; 	
						var btn4 = "<input id=\"pos"+iloID+"\" name=\"pos"+iloID+"\" size=1>";
						tr_new.innerHTML = "<td>"+btn4+"</td><td><textarea name=\"txt"+iloID+"\" rows=1 style=\"width: 100%;\" onchange=\"setModifiedFlag()\">"+rapName+"</textarea></td><td>"+btn3+btn1+btn2+"</td>";
						tr_new.id = "ilo"+iloID;
						updateArrowBtns();
						NewRAP.value = "";
					}
				}
			}	
			xhttp.open("GET", "ilo_addprogramILO.php?PlanID="+planID+"&name="+rapName+"&pos="+position, true);
			xhttp.send();
		}
	}
	window.onload = function(){
		changePlan();
	}
	</script>
	
<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="#">Resultados de Aprendizaje de Programa</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#coord-RAPs" target="PLANEA-help">?</a></li>
</ul>


<?php  
	$planea = new planea();
	$conn = $planea->openConnection();
	//Save Program ILOs...
	if ( isset($_POST["PlanID"]) ) { 
		foreach ($_POST as $key=>$value) {
			if (substr($key,0,3) == "txt") {	
				$id = substr($key,3);
				$sql = "UPDATE ilo_program SET Value='". $value . "', Position=". $_POST["pos".$id] ." WHERE ID=".$id;
				$conn->query($sql);
			}
		}
	}
?>

<form class="planeaForm" id="setConfiguration" action="ilo_studyplan.php" method="POST" onsubmit="return clearModifiedFlag()">
	<p style="font-size:small"> 
	Utilice esta sección para definir los resultados de aprendizaje del plan de estudios. 
	Estos resultados de aprendizaje se pueden asociar a los resultados de aprendizaje de cada curso en el módulo <b>Sílabos</b><br>
	</p>
	Plan:
	<select id="ListOfStudyPlans" name="PlanID" onchange="changePlan()">
	<?php 
		$defaultPlan = $_SESSION["DefaultPlan"];
		if ($_SESSION["RoleID"]==planea::roleCoord) $defaultPlan = $planea->showStudyPlan($defaultPlan,false,$_SESSION["UserID"]); 
		else $planea->showStudyPlan($defaultPlan); 
	?>
	</select>
	<br><br>
	<div id="configPanel" style="display:none">
		<div id="rapList">
		</div>
		<br>
		*Nuevo RAP: <input type="text" id="NewRAP" size=100>
		<button class="button btn_fancy" onclick="addRAP()" type="button">Añadir RAP<img src="images/btn_add1.png"> </button>
		<br> <br>
		<input type="submit" value="Guardar">
	</div>
</form>

<?php $planea->closeConnection(); ?>

</body>
</html>
