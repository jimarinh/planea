<?php
	require('planea_basics.php');  
	$planea = new planea();
	$conn = $planea->openConnection();
	$planea->showElectives($_GET["plan"]);
	$planea->closeConnection();
?>