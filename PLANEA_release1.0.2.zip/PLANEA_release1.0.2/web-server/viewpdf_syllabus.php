<?php 
require('fpdf.php');
require('planea_basics.php');
require('bibtex2html.php');



class tokenHTML {
	var $str;
	var $param;
	var $isTag;
	var $nextStr;
};

class borderInfo 
{
	var $fx1;		//Posiciones iniciales X,Y del TextFrame. Empleada para dibujar los bordes
	var $fy1;
	var $fx2;		//Posiciones finales del TextFrame
	var $fy2;
	var $border;	//Descripción del borde
	var $fixedWidth;//Indica si el valor de fx2 es fijo o variable
}
			
class templateParser {
	
	var $xml;							//Objeto XML con la plantilla
	var $fields = array();				//Arreglo donde se almacenan los campos visualizables y accesibles con $$
	var $currentFontFamily = "Arial";	//Tipo de letra actual
	var $currentFontStyle = '';			//Estilo del tipo de letra
	var $wIntroduceCol;					//Ancho de la columna "Introduce" empleada en la visualización de las habilidades
	var $wTeachCol;						//Ancho de la columna "Enseña" empleada en la visualización de las habilidades
	var $wUseCol;						//Ancho de la columna "Utiliza" empleada en la visualización de las habilidades
	var $startNumering=0;				//Inicio de la numeración empleada por la función drawFormattedText
	var $borderFrames=array();
	var $planea;						//Acceso al objeto planea que permite la conexión a la base de datos SQL
	var $CourseID;						//ID del curso
	var $CourseKeyID;					//ID de la clave principal del curso
	
	
	function SetConnection( $planea, $CourseID, $CourseKeyID )
	{
		$this->planea 	= $planea;
		$this->CourseID = $CourseID;
		$this->CourseKeyID = $CourseKeyID;
	}
	
	//Convierte cadena a mayúsculas
	function strtoupperSpanish( $str )
	{
	  $str = strtoupper(utf8_encode($str));
	  $find    = array("á", "é", "í", "ó", "ú", "ñ");
	  $replace = array("Á", "É", "Í", "Ó", "Ú", "Ñ");
	  $str = str_replace( $find, $replace, $str);
	  return utf8_decode($str);
	} 
	
	//Convierte cadena a minúsculas
	function strtolowerSpanish( $str )
	{
	  $str = strtolower($str);
	  $find = array("Á", "É", "Í", "Ó", "Ú", "Ñ");
	  $replace = array("á", "é", "í", "ó", "ú", "ñ");
	  $str = str_replace( $find, $replace, $str);
	  return $str;
	} 
	
	//Extracta el valor del parámetro de la función matemática aplicada sobre campos
	function parseParam($str) {
		if ($str[0] == '$') {
			$field = substr($str,1,strlen($str)-2);
			return $this->fields[$field];
		} else {
			return $str;
		}
	}
	
	//Ejecuta la función matemática con los campos
	function parseOp($str, $pos, $op) {
		$slen = strlen($str);
		$start = $pos;
		//Valor inicial del valor antes de la operación
		switch($op) {
			case 1: $val = 0.0; break;
			case 2: $val = 1.0; break;
			default: $val = "";
		}
		while($pos<$slen) {
			if ( ($str[$pos] == ',') || ($str[$pos] == ')') ) {
				$param = $this->parseParam( substr($str,$start,$pos-$start) );
				$start = $pos+1;
				switch($op) {
					case 1: $val += floatval($param); break;
					case 2: $val *= floatval($param); break;
					case 3: $val = $this->strtoupperSpanish($param); break;
					case 4: $val = $this->strtolowerSpanish($param); break;
				}
			}
			if ( $str[$pos] == '(' )  {
				$sop = substr($str,$start+1,$pos-$start-1);
				switch( $sop ) {
					case "_sum": $doAction = 1; break;
					case "_mpy": $doAction = 2; break;
					default: 
						echo "Error in nested math operation";
						exit(1);
				}
				$ret = $this->parseOp($str, $pos+1, $doAction);				
				switch($op) {
					case 1: $val += floatval($ret["value"]); break;
					case 2: $val *= floatval($ret["value"]); break;
				}
				$pos = $ret["pos"]+1;
				if ($str[$pos] == "$") $pos++;
				if ($str[$pos] == ",") $pos++;
				$start = $pos;
			}
			if ($str[$pos] == ')') {
				break;
			}
			$pos++;
		}
		$ret["value"] = $val;
		$ret["pos"] = $pos;
		return $ret;
	}

	//Chequea si la cadena en formato HTML está vacía
	function isEmptyHTML( $str	) {
		$txt = str_replace("&nbsp;",' ',$str);
		$len = strlen($txt);
		if ($len==0) 
			return true;
		$i = 0;
		do {
			if (!ctype_space($txt[$i])) {
				if ($txt[$i]=='<') {
					$i = strpos($txt, ">", $i+1)+1;
				} else
					return false;
			} else 
				$i++;
		}while($i<$len);
		return true;
	}

	
	function parseText( $str ) {
		$retStr = "";
		$slen = strlen($str);
		$posi = 0;
		while($posi<$slen) {
			//Busca inicio del campo con el caracter $
			$posj = strpos($str, "$", $posi);
			if ($posj === false) {
				$retStr = $retStr.substr($str,$posi);
				break;
			} else {
				$retStr = $retStr.substr($str,$posi,$posj-$posi);
				//Busca la finalización del campo con el caracter $
				$post = $posj+1;
				//Identifica si es una función sobre campos o un campo
				if ($str[$post]=='_') {
					$search_ch = '(';
				} else {
					$search_ch = '$';
				}
				$pos = strpos($str, $search_ch, $post);			
				if ($pos === false) {
					break;
				} else {
					$len = $pos-$post; 
					//Si es $$ se trata del signo $
					if ($len == 0) {
						$retStr = $retStr."$";
					} else {
						//Analiza el tag
						$tag = substr($str,$post,$len);
						switch($tag) {
							case "_sum": $doAction = 1; break;
							case "_mpy": $doAction = 2; break;
							case "_toupper": $doAction = 3; break;
							case "_tolower": $doAction = 4; break;
							default: 
								if (isset($this->fields[$tag])) {
									$retStr = $retStr.$this->fields[$tag];
									$doAction = 0;
								} else {
									echo "Error: Field (".$tag.") does not exist";
									exit(0);
								}
						}
						//Si es una operación matemática, la ejecuta
						if ($doAction!=0) {
							$ret = $this->parseOp($str, $pos+1, $doAction);
							$retStr = $retStr.$ret["value"];
							$pos = strpos($str, '$', $ret["pos"]);
							if ($pos === false) {
								break;
							} 
						}
					}
					$posi = $pos+1;
				}
			}
		}
		return $retStr;
	}
	
	function drawBorder( $pdf, $border, $X1, $Y1, $X2, $Y2 )
	{
		if ($border != "0") {
			if ($border == "1") {
				$pdf->Rect($X1, $Y1, $X2-$X1, $Y2-$Y1);	
			} else {
				if(strpos($border,'L')!==false)
					$pdf->Line($X1, $Y1, $X1, $Y2);
				if(strpos($border,'T')!==false)
					$pdf->Line($X1, $Y1, $X2, $Y1);
				if(strpos($border,'R')!==false)
					$pdf->Line($X2, $Y1, $X2, $Y2);
				if(strpos($border,'B')!==false)
					$pdf->Line($X1, $Y2, $X2, $Y2);
			}
		}
	}
	
	function getHTMLtoken( $str	) {
		$token = new tokenHTML;
		$pos = strpos($str, "<");
		if ($pos === false) {
			$token->str = $str;
			$token->isTag = false; 
			$token->nextStr = null;
		} else {
			if ($pos == 0) {
				$pos = strpos($str, '>');
				$token->str = substr($str,1,$pos-1);
				$posp = strpos($token->str, ' ');
				if ($posp!==false) {
					$token->param = substr($token->str,$posp+1);
					$token->str = substr($token->str,0,$posp);
				}
				$token->isTag = true;
				$token->nextStr = substr($str,$pos+1);
			} else {
				$token->str = substr($str,0,$pos);
				$token->isTag = false;
				$token->nextStr = substr($str,$pos);
			}
		}
		//Remueve los espacios multiples en la cadena
		$token->str = preg_replace('/\s+/', ' ', $token->str);
		return $token;
	}	

	function parseHTMLSetFont($pdf, $bold, $italic, $underline)
	{
		$fontStyle = '';
		if ($bold) { $fontStyle = $fontStyle.'B'; }
		if ($italic) { $fontStyle = $fontStyle.'I'; }
		if ($underline) { $fontStyle = $fontStyle.'U'; }
		$pdf->SetFont($this->currentFontFamily, $fontStyle);
		return $fontStyle;
	}
	
	
	function __drawFormattedTextNewLine( $pdf, $indent, $fontSpace ) {
		if ( $pdf->CheckIfAutoPageBreak(0) ) {
			//Actualiza la información de los frames activos para que se dibujen correctamente 
			//al usar flushFrames
			$this->expandFrames( $pdf, $pdf->GetX(), $pdf->GetY()+$fontSpace);
			
			//Adiciona una nueva página y aplica sangría
			$this->flushFramesAndAddPage($pdf); 
			if ($indent>0) { 
				$pdf->Cell($indent,$fontSpace);
			}
		} 
		$pdf->Ln();
		if ($pdf->CheckIfAutoPageBreak($fontSpace)) {
			$this->expandFrames( $pdf, $pdf->GetX(), $pdf->GetY());
			$this->flushFramesAndAddPage($pdf);
		}
		if ($indent>0) { 
			$pdf->Cell($indent,$fontSpace);
		}
	}

	function drawFormattedText($pdf, $str, $pw=0, $ph=0, $startNumering=0, $border=0) {
		$indentList = array(20);
		$indentLevel = 0;
		$numering = array(10);
		$bullets = array("F","G","E","3","1");
		$listType = array(20);
		$numeringlevel = 0;
		$bulletlevel = 0;
		$listlevel = 0;
		$showBullet = false;
		$readyLine = true;
		$pendingBR = 0;
		$bold = false;
		$italic = false;
		$underline = false;
		$hyperlink = false;
		$fontStyle = '';
		$fontSpace = round($pdf->GetFontSpace());
		$subOffset = 0;
		$listType[0] = 0;
		$fx1 = $pdf->GetX();
		$indent = $fx1 - $pdf->GetLeftMargin();
		$maxX  = $pw==0 ? $pdf->GetPageWidth()-$pdf->GetRightMargin()-2 : $pw+$fx1-2;
		$indentList[0] = $indent;
		
		$this->startFrame($pdf, $border, $maxX+2);
		
		//$pdf->MultiCell(0,4,$str);
		
		if ($startNumering>0) {
			$listlevel++;
			$listType[$listlevel] = 1;
			$numering[$numeringlevel]=$startNumering;
			$numeringlevel++;
		}	
			
		$str = str_replace("\r"," ",str_replace("\n","<br>",str_replace("&nbsp;",' ',$str)));
		$str = str_replace("&aacute;","á",$str);
		$str = str_replace("&eacute;","é",$str);
		$str = str_replace("&iacute;","í",$str);
		$str = str_replace("&oacute;","ó",$str);
		$str = str_replace("&uacute;","ú",$str);
		
		do {
			//Revisa si es necesario añadir una nueva página
			if ($pdf->CheckIfAutoPageBreak($fontSpace)) {
				$this->expandFrames($pdf, $pdf->GetX(), $pdf->GetY());
				$this->flushFramesAndAddPage($pdf);
			}
			//Extrae el siguiente Token HTML
			$token = $this->getHTMLtoken( $str	);
			if ($token->isTag) {
				$tag = strtoupper($token->str);
				
				if ($tag=="B") {
					$bold = true;
					$fontStyle = $this->parseHTMLSetFont($pdf,$bold, $italic, $underline);
				}
				if ($tag=="/B") {
					$bold = false;
					$fontStyle = $this->parseHTMLSetFont($pdf,$bold, $italic, $underline);
				}
				if ($tag=="U") {
					$underline = true;
					$fontStyle = $this->parseHTMLSetFont($pdf,$bold, $italic, $underline);
				}
				if ($tag=="/U") {
					$underline = false;
					$fontStyle = $this->parseHTMLSetFont($pdf,$bold, $italic, $underline);
				}
				if ($tag=="I") {
					$italic = true;
					$fontStyle = $this->parseHTMLSetFont($pdf,$bold, $italic, $underline);
				}
				if ($tag=="/I") {
					$italic = false;
					$fontStyle = $this->parseHTMLSetFont($pdf,$bold, $italic, $underline);
				}
				if ($tag=="SUP") {
					$subOffset = $pdf->setSmallFont(round($fontSpace*0.75));
				}
				if ($tag=="/SUP") {
					$pdf->unsetSmallFont($subOffset);
				}
				if ($tag=="SUB") {
					$subOffset = $pdf->setSmallFont(-round($fontSpace*0.75));
				}
				if ($tag=="/SUB") {
					$pdf->unsetSmallFont($subOffset);
				}
				if ($tag=="SPAN") {
					if ($token->param=="class=\"title\"") {
						$italic = true;
						$fontStyle = $this->parseHTMLSetFont($pdf,$bold, $italic, $underline);
					}
					if ($token->param=="class=\"links\"") {
						$underline = true;
						$hyperlink = true;
						$fontStyle = $this->parseHTMLSetFont($pdf,$bold, $italic, $underline);
					}
				}
				if ($tag=="/SPAN") {
					$bold = false;
					$italic = false;
					$underline = false;
					$hyperlink = false;
					$fontStyle = $this->parseHTMLSetFont($pdf,$bold, $italic, $underline);
				}
				if (($tag=="P") || ($tag=="/P")) {
					if (!$readyLine) {
						if ($pendingBR < 2) { $pendingBR = 2; }
					}
				}
				if (($tag=="DIV")||($tag=="/DIV")) {
					if (!$readyLine) {
						if ($pendingBR == 0) { $pendingBR = 1; }
					}
				}
				if ($tag=="BR") {
					if ($readyLine) {
						$pendingBR = 1;
						$readyLine = false;
					} else {
						$pendingBR++;
					}
				}
				if ($tag=="BLOCKQUOTE") {
					$indent+=$fontSpace;
					if (!$readyLine) {
						if ($pendingBR == 0) { $pendingBR = 1; }
					}
				}
				if ($tag=="/BLOCKQUOTE") {
					$indent-=$fontSpace;
					if (!$readyLine) {
						if ($pendingBR == 0) { $pendingBR = 1; }
					}
				}
				if ($tag=="OL") {
					$listlevel++;
					$listType[$listlevel] = 1;
					$numering[$numeringlevel]=0;
					$numeringlevel++;
					$indent+=$fontSpace;
					$pdf->Cell($fontSpace,$fontSpace);
					if (!$readyLine) { 
						if ($listlevel == 1) {
							if ($pendingBR < 2) { $pendingBR = 2; }
						} else {
							if ($pendingBR == 0) { $pendingBR = 1; }
						}
					}
				}			
				if ($tag=="/OL") {
					$listlevel--;
					$numeringlevel--;
					$indent -= $fontSpace;
					if (!$readyLine) { 
						if ($listlevel == 0) {
							if ($pendingBR < 2) { $pendingBR = 2; }
						} else {
							if ($pendingBR == 0) { $pendingBR = 1; }
						}
					}
				}
				if ($tag=="UL") {
					$listlevel++;
					$listType[$listlevel] = 2;
					$bulletlevel++;
					$indent+=$fontSpace;
					$pdf->Cell($fontSpace,$fontSpace);
					if (!$readyLine) { 
						if ($listlevel == 1) {
							if ($pendingBR < 2) { $pendingBR = 2; }
						} else {
							if ($pendingBR == 0) { $pendingBR = 1; }
						}
					}
				} 
				if ($tag=="/UL") {
					$listlevel--;
					$bulletlevel--;
					$indent -= $fontSpace;
					if (!$readyLine) { 
						if ($listlevel == 0) {
							if ($pendingBR < 2) { $pendingBR = 2; }
						} else {
							if ($pendingBR == 0) { $pendingBR = 1; }
						}
					}
				}
				if ($tag=="LI") {
					$indentList[$indentLevel] = $indent;
					$indentLevel++;
					if ($listType[$listlevel]==1) { $numering[$numeringlevel-1]++; }
					$showBullet = true;
				} 
				if ($tag=="/LI") {
					$indentLevel--;
					$indent = $indentList[$indentLevel];
					if (!$readyLine) { 
						if ($pendingBR == 0) { $pendingBR = 1; }
					}
				}
			} 
			else 
			{
				if ( substr_count($token->str,' ') != strlen($token->str) ) 
				{	
					if (!$readyLine) {
						for($i=0; $i<$pendingBR; $i++) {
							$this->__drawFormattedTextNewLine( $pdf, $indent, $fontSpace );
						}
						$pendingBR = 0;
						$readyLine = true;
					}
					if ($showBullet) {
						if (($listType[$listlevel]==1) && ($numeringlevel>0)) {
							$strnumering = $numering[0];
							for($i = 1; $i<$numeringlevel; $i++) {
								$strnumering = $strnumering.".".$numering[$i];
							}
							$strnumering = $strnumering.". ";
							$pdf->Cell($fontSpace*($numeringlevel+0.5),$fontSpace,$strnumering);	
						}
						if ($bulletlevel>0) {
							$fontSize = $pdf->GetFontSize();
							$pdf->SetFont('ZapfDingbats','',$fontSize*0.7);
							$pdf->Cell($fontSpace,$fontSpace,$bullets[$bulletlevel-1]);     
							$pdf->SetFont($this->currentFontFamily,$fontStyle,$fontSize);	
						}
						$indent = $pdf->GetX() - $pdf->GetLeftMargin();
						$showBullet = false;
					}
						
					$readyLine = false;
					$txt = $token->str;
					
					if ($hyperlink) {
						$hl = $txt;
					} else {
						$hl = '';
					}
					
					$fontFactor = $pdf->GetFontFactor();
					$cw = $pdf->GetFontCharWidths();
					$pStart  = 0;	//Start position of the string
					$pLastSp = 0;	//Position of the last space
					$wTxt    = 0;	//Width of the string from start to i
					$wLastSp = 0;	//Width of the string from start to last space
					$wmax    = ($maxX - $pdf->GetX()) * $fontFactor;	//Max width
					$nSp     = 0;	//Number of spaces from start to i
					$i = 0;
					$l = strlen($txt);
					while( $i < $l )
					{
						$c = $txt[$i];
						$charw = $cw[$c];
						if ($c==' ') {
							$nSp++;
							$pLastSp = $i;
							$wLastSp = $wTxt + $charw;
						}
						if ($wTxt + $charw > $wmax) {
							if ($pLastSp == $pStart) {	//No spaces within the string (no justify)
								$disptxt = substr($txt,$pStart,$i-$pStart);
								$pdf->setWordSpacing(0);
								$pdf->Cell($wTxt/$fontFactor,$fontSpace,$disptxt,0,0,'L',false,$hl);	
								$pStart  = $i;
								$pLastSp = $i;
								$wTxt = 0;				
							} else {	//Spaces within the string (justify)
								$disptxt = substr($txt,$pStart,$pLastSp-$pStart);
								$pdf->setWordSpacing( $nSp > 1 ? ($wmax - $wLastSp)/(($nSp-1)*$fontFactor) : 0 );
								$pdf->Cell($wmax/$fontFactor,$fontSpace,$disptxt,0,0,'L',false,$hl);
								$nSp = 0;
								$pStart  = $pLastSp+1;
								$pLastSp = $pStart;
								$wTxt -= $wLastSp;	
							}
							//Inserta el salto de línea para continuar volcando más texto
							$pdf->Ln();
							//Revisa si es necesario añadir una nueva página
							if ($pdf->CheckIfAutoPageBreak($fontSpace)) {
								$this->expandFrames($pdf, $maxX+2, $pdf->GetY());
								$this->flushFramesAndAddPage($pdf);
							}							
							if ($indent>0) { $pdf->Cell($indent,$fontSpace); }
							//Update max width 
							$wmax = ($maxX - $pdf->GetX()) * $fontFactor;
						} else {
							$wTxt += $charw;
							$i++;
						}

					}
					if ($i != $pStart) {
						$disptxt = substr($txt,$pStart,$i-$pStart);
						$pdf->setWordSpacing(0);
						$pdf->Cell($wTxt/$fontFactor,$fontSpace,$disptxt,0,0,'L',false,$hl);
					}
				}
			}		
			$str = $token->nextStr;
		} while( $token->nextStr != null );
		
		//Dibuja el borde
		$this->expandFrames($pdf, $maxX+2, $pdf->GetY()+$fontSpace);
		$borderInfo = $this->finishFrame($pdf);
		
		//Fija la posición de X,Y al final del TextFrame y el alto de la celda para el adecuado funcionamiento del line break
		$pdf->SetXY( $borderInfo->fx2, $borderInfo->fy1 );
		$pdf->SetLastH($borderInfo->fy2 - $borderInfo->fy1);
	}

	function startFrame($pdf, $border, $maxX=0)
	{
		$borderFrame = new borderInfo;
		$borderFrame->fx1 = $pdf->GetX();
		$borderFrame->fy1 = $pdf->GetY();
		$borderFrame->fx2 = $maxX==0 ? $pdf->GetX() : $maxX;
		$borderFrame->fy2 = $pdf->GetY();
		$borderFrame->border = $border;
		$borderFrame->fixedWidth = ($maxX>0);
		array_push($this->borderFrames, $borderFrame);
	}
	
	function expandFrames($pdf, $x, $y)
	{
		//Si está dibujando un header o footer no se pueden actualizar los frames, 
		//pues se está creando una nueva página
		if ($pdf->CheckIfHeaderOrFooter())
			return;
		foreach($this->borderFrames as $borderFrame) {
			//Actualiza posiciones máximas de todos los frames 
			if ( !$borderFrame->fixedWidth && ($x > $borderFrame->fx2)) { $borderFrame->fx2 = $x; }
			if ($y > $borderFrame->fy2) $borderFrame->fy2 = $y;
		}
	}
	
	function expandFramesSpanRow( $minH ) {
		foreach($this->borderFrames as $borderFrame) {
			//Si SpanRow está activo, garantiza un alto mínimo de cada fila
			//para evitar filas con alto cero. 
			if ($borderFrame->fy2-$borderFrame->fy1 < $minH ) $borderFrame->fy2 = $borderFrame->fy1+$minH;
		}
	}
	
	function finishFrame($pdf) 
	{
		$borderFrame = array_pop($this->borderFrames);
		if ($borderFrame!==null) {
			$this->drawBorder( $pdf, $borderFrame->border, 
				$borderFrame->fx1, $borderFrame->fy1, 
				$borderFrame->fx2, $borderFrame->fy2 );
			return $borderFrame;
		}
	}
	
	function flushFramesAndAddPage($pdf)
	{
		foreach($this->borderFrames as $borderFrame) {
			$this->drawBorder( $pdf, $borderFrame->border, 
				$borderFrame->fx1, $borderFrame->fy1, 
				$borderFrame->fx2, $borderFrame->fy2 );
		}
		$pdf->AddPage();
		foreach($this->borderFrames as $borderFrame) {
			$borderFrame->fy1 = $pdf->GetY();
			$borderFrame->fy2 = $borderFrame->fy1;
		}
	}
	
	
	//Devuelve la consulta SQL necesaria según la configuración de captura de los ILos
	function getILOsSQL( $entry )
	{
		$group = 0;
		if (isset($entry->filter)) {	
			//Filtro para una categoría específica
			if ( isset($entry->filter->row) && isset($entry->filter->value) ) 
			{
				if ($entry->filter->row->__toString()=="category") $filterCat = "ilo_categories";
				if ($entry->filter->row->__toString()=="progcat") $filterCat = "ilo_program";
				$sql = "SELECT courses_ilos.*, ilo_categories.Value AS catValue, ilo_categories.Position AS catPos, ilo_program.Value AS progValue, ilo_program.Position AS progPos 
						FROM courses_ilos 
						LEFT JOIN ilo_categories ON courses_ilos.CategoryID=ilo_categories.ID 
						LEFT JOIN ilo_program ON courses_ilos.ProgramILOID=ilo_program.ID 
						WHERE CourseID=".$this->CourseID." AND ".$filterCat.".Value='".$entry->filter->value->__toString()."' 
						ORDER BY courses_ilos.Position";
			} else {
				$sql = "";
			}
		} 
		else 
		{	
			//Si no hay filtro o agrupación, los RAPs son ordenados por posición
			$order = "";
			//Agrupación por categorías
			if (isset($entry->groupBy)) {				
				if ($entry->groupBy->__toString()=="category") { $order = "catPos,"; $group = 1; }
				if ($entry->groupBy->__toString()=="progCat") { $order = "progPos,"; $group = 2; }
			}
			$sql = "SELECT courses_ilos.*, ilo_categories.Value AS catValue, ilo_categories.Position AS catPos, ilo_program.Value AS progValue, ilo_program.Position AS progPos 
					FROM courses_ilos 
					LEFT JOIN ilo_categories ON courses_ilos.CategoryID=ilo_categories.ID 
					LEFT JOIN ilo_program ON courses_ilos.ProgramILOID=ilo_program.ID 
					WHERE CourseID=".$this->CourseID." ORDER BY ".$order."courses_ilos.Position";
		}  
		$ret["sql"] = $sql;
		$ret["group"] = $group;
		return $ret;
	}
	
	
	//Devuelve la consulta SQL necesaria según la habilidad
	function getSkillsSQL( $entry ) 
	{
		if (!isset($entry['type']))
			return "";		
		if ($entry['type']=="personal") {
			//Muestra las habilidades personales segun syllabus CDIO
			$sql = "SELECT cdiosyllabus_personal_skills.description, cdiosyllabus_personal_skills.ref_syllabus,
						   courses_personal_skills.Introduce, courses_personal_skills.Teach,
						   courses_personal_skills.Utilize, cdiosyllabus_personal_skills.ID
					FROM cdiosyllabus_personal_skills
					INNER JOIN courses_personal_skills
					ON courses_personal_skills.SkillID = cdiosyllabus_personal_skills.ID
					WHERE courses_personal_skills.CourseID=". $this->CourseID . " ORDER BY cdiosyllabus_personal_skills.ID";
		}
		if ($entry['type']=="interpersonal") {		
			//Muestra las habilidades interpersonales segun syllabus CDIO
			$sql = "SELECT cdiosyllabus_interpersonal_skills.description, cdiosyllabus_interpersonal_skills.ref_syllabus,
						   courses_interpersonal_skills.Introduce, courses_interpersonal_skills.Teach,
						   courses_interpersonal_skills.Utilize, cdiosyllabus_interpersonal_skills.ID
					FROM cdiosyllabus_interpersonal_skills
					INNER JOIN courses_interpersonal_skills
					ON courses_interpersonal_skills.SkillID = cdiosyllabus_interpersonal_skills.ID
					WHERE courses_interpersonal_skills.CourseID=". $this->CourseID . " ORDER BY cdiosyllabus_interpersonal_skills.ID";    
		}
		if ($entry['type']=="CDIO") {
			//Muestra las habilidades CDIO segun syllabus CDIO
			$sql = "SELECT cdiosyllabus_cdio_skills.description, cdiosyllabus_cdio_skills.ref_syllabus,
						   courses_cdio_skills.Introduce, courses_cdio_skills.Teach,
						   courses_cdio_skills.Utilize, cdiosyllabus_cdio_skills.ID
					FROM cdiosyllabus_cdio_skills
					INNER JOIN courses_cdio_skills
					ON courses_cdio_skills.SkillID = cdiosyllabus_cdio_skills.ID
					WHERE courses_cdio_skills.CourseID=". $this->CourseID . " ORDER BY cdiosyllabus_cdio_skills.ID";    
		}
		return $sql;
	}	
		
		
	function parseRubric( $pdf, $rubricID, $entry )
	{
		if ($rubricID==0) return;
		//Calcula el ancho de la rúbrica
		$w = isset($entry['width']) ? $entry['width'] : ($pdf->GetPageWidth()-$pdf->GetRightMargin()-$pdf->GetX());
		$fontSpace = round($pdf->GetFontSpace());
		//Configura si se pinta el título en gris
		if (isset($entry['grayedTitle'])&&($entry['grayedTitle']==1)) {
			$pdf->SetFillColor(200,200,200);
			$fillRubricTitle = true;
		} else {
			$fillRubricTitle = false;
		}
		//Calcula el ancho de las columnas de la rúbrica y define fija el valor del border
		$rubricType = $this->fields["_rubricType"];
		$NumLevels = $this->fields["_rubricNLevels"];
		$LevelText = "Nivel";
		$CriteriaText = "Criterio";
		$DescText = "Descripción";
		switch($rubricType) {
			case 1: 	
				$colw[0] = $w/($NumLevels+1);
				$border = "1";
				$spanTitle = 2;
				break;
			case 2:	
				$colw[0] = $fontSpace + $pdf->GetStringWidth($LevelText);
				$colw[1] = $w-$colw[0];
				$border = "1";
				$spanTitle = 1;
				break;
			case 3: 
				$colw[0] = $w/$NumLevels;
				$border = "TB";
				$spanTitle = 2;
				break;
		}
		if (isset($entry['border'])) $border = $entry['border']->__toString();
		//Captura cada fila de la rúbrica comenzando con el título
		$sql = "SELECT * FROM rubrics_entries WHERE RubricID=".$rubricID." ORDER BY Position";
		$result = $this->planea->conn->query($sql); 
		$pos = $result->num_rows-1;
		if ($result->num_rows > 0)  {
			//Pone el título
			if ($pdf->CheckIfAutoPageBreak($fontSpace*3)) {
				$this->expandFrames( $pdf, $pdf->GetX(), $pdf->GetY());
				$this->flushFramesAndAddPage($pdf);
			}
			if ($fillRubricTitle) {
				$pdf->Rect($pdf->GetX(), $pdf->GetY(), $w, $spanTitle*$fontSpace, 'F');
			}
			$pdf->SetFont($this->currentFontFamily,'B');
			$row = $result->fetch_assoc();
			switch($rubricType) {
				case 1:
					$pdf->Cell($colw[0], 2*$fontSpace, $CriteriaText, $border, 0, "C");
					$x1 = $pdf->GetX();
					$y1 = $pdf->GetY();
					for($i=$NumLevels; $i>=1; $i--) {
						$pdf->Cell($colw[0], $fontSpace, $i, 0, 0, "C");
						$pdf->SetXY($x1,$y1+$fontSpace);
						$pdf->Cell($colw[0], $fontSpace, $row["DescLevel".$i], 0, 0, "C");
						$this->drawBorder( $pdf, $border, $x1, $y1, $x1+$colw[0], $y1+$fontSpace*2 );
						$x1+=$colw[0];
						$pdf->SetXY($x1,$y1);
					}
					$this->expandFrames($pdf, $x1, $y1+2*$fontSpace);
					break;
				case 2:
					$pdf->Cell($colw[0], $fontSpace, $LevelText, $border, 0, "C");
					$pdf->Cell($colw[1], $fontSpace, $DescText, $border, 0, "C");
					$this->expandFrames($pdf, $pdf->GetX(), $pdf->GetY()+$fontSpace);
					break;
				case 3:
					$x1 = $pdf->GetX();
					$y1 = $pdf->GetY();
					for($i=1;$i<=$NumLevels;$i++) {
						$txt = $row["DescLevel".$i];
						$pdf->Cell($colw[0], $fontSpace, $i, 0, 0, "C");
						$pdf->SetXY($x1,$y1+$fontSpace);
						$pdf->Cell($colw[0], $fontSpace, $row["DescLevel".$i], 0, 0, "C");
						$this->drawBorder( $pdf, $border, $x1, $y1, $x1+$colw[0], $y1+$fontSpace*2 );
						$x1+=$colw[0];
						$pdf->SetXY($x1,$y1);
					}
					$this->expandFrames($pdf, $pdf->GetX(), $pdf->GetY()+2*$fontSpace);
					break;
			}
			//Dibuja las filas restantes
			for($i=0; $i<$spanTitle; $i++) $pdf->Ln();
			$pdf->SetFont($this->currentFontFamily,'');
			while( $row = $result->fetch_assoc() )
			{
				if ($pdf->CheckIfAutoPageBreak($fontSpace*3)) {
					$this->expandFrames( $pdf, $pdf->GetX(), $pdf->GetY());
					$this->flushFramesAndAddPage($pdf);
				}
				$x1 = $pdf->GetX();
				switch($rubricType) {
					case 1:								
						$xt = $x1;
						for($i=0; $i<=$NumLevels; $i++) {
							$this->startFrame($pdf, $border, $xt+$colw[0]);
							$xt += $colw[0];
							$pdf->SetX($xt);
						}
						$pdf->SetX($x1);
						$pdf->SetFont($this->currentFontFamily,'B');
						$this->drawFormattedText($pdf, $this->planea->parseRubricCell($row["Criteria"]), $colw[0], 0, $this->startNumering, 0);
						$pdf->SetFont($this->currentFontFamily,'');
						for($i=$NumLevels; $i>=1; $i--) {
							$this->drawFormattedText($pdf, $this->planea->parseRubricCell($row["DescLevel".$i]), $colw[0], 0, $this->startNumering, 0);
						}
						for($i=0; $i<=$NumLevels; $i++) {
							$borderFrame = $this->finishFrame($pdf);
						}
						$pdf->SetLastH( $borderFrame->fy2 - $borderFrame->fy1 );
						break;
					case 2:
						$this->startFrame($pdf, $border, $x1+$colw[0]);
						$pdf->SetX($x1+$colw[0]);
						$this->startFrame($pdf, $border, $x1+$colw[0]+$colw[1]);
						$this->drawFormattedText($pdf, $this->planea->parseRubricCell($row["DescLevel1"]), $colw[1], 0, $this->startNumering, 0);
						$borderFrame = $this->finishFrame($pdf);
						$pdf->SetXY($x1,$borderFrame->fy1);
						$pdf->SetFont($this->currentFontFamily,'B');
						$pdf->Cell($colw[0], $borderFrame->fy2-$borderFrame->fy1, $pos, $border, 0, "C");
						$pdf->SetFont($this->currentFontFamily,'');
						$this->finishFrame($pdf);
						break;
					case 3:
						$xt = $x1;
						for($i=0; $i<$NumLevels; $i++) {
							$this->startFrame($pdf, $border, $xt+$colw[0]);
							$xt += $colw[0];
							$pdf->SetX($xt);
						}
						$pdf->SetX($x1);
						for($i=1;$i<=$NumLevels;$i++) {
							if ($i >= ($NumLevels-$pos+1)) {	
								$this->drawFormattedText($pdf, $this->planea->parseRubricCell($row["DescLevel1"]), $colw[0], 0, $this->startNumering, 0);
							}
							else {
								$pdf->Cell($colw[0], $fontSpace);
							}
						}
						for($i=0; $i<=$NumLevels; $i++) {
							$borderFrame = $this->finishFrame($pdf);
						}
						break;
				}
				$pdf->Ln();
				$pos--;								
			}
		}	
	}

	
	function parse( $pdf, $xml_section, $sectionNumber = "" ) 
	{	
		$secN = 0;
		$this->fields["sectionNumber"] = $sectionNumber;
		
		foreach($xml_section->children() as $entry) 
		{
			$tag = $entry->getName();
			
			if ($tag == "tf") {
				$fontSpace = round($pdf->GetFontSpace());
				$w = isset($entry['width']) ? $entry['width'] : 0;
				$h = isset($entry['height']) ? $entry['height'] : $fontSpace;
				switch($entry['align']) {
					case "left": $align = "L"; break;
					case "right": $align = "R"; break;
					case "center": $align = "C"; break;
					default: $align = "J";
				}
				$border = isset($entry['border']) ? $entry['border']->__toString() : "0";		
				if ($pdf->CheckIfAutoPageBreak($fontSpace)) {
					$this->flushFramesAndAddPage($pdf);
				}
				$str = $this->parseText(utf8_decode($entry->__toString()));
				if ($align != 'J') {
					$pdf->Cell($w, $h, $str, $border, 0, $align);
					$this->expandFrames($pdf, $pdf->GetX(), $pdf->GetY()+$fontSpace);
				} else {
					$this->drawFormattedText($pdf, $str, $w, $h, $this->startNumering, $border);
				}	
			}
			if ($tag == "img") {
				$x = isset($entry->x) ? $entry->x : null;
				$y = isset($entry->y) ? $entry->y : null;
				$width = isset($entry->width) ? $entry->width : 0;
				$height = isset($entry->height) ? $entry->height : 0;
				$src1 = $entry->src->__toString();
				$src = "templates/".$src1;
				if (!file_exists($src)) {
					echo "El archivo de imagen '".$src1."' no existe.";
					exit(0);
				}
				$pdf->Image($src,$x,$y,$width,$height);
			}
			if ($tag == "font") {
				$style = '';
				if (isset($entry->b)) { $style = $style.'B'; }
				if (isset($entry->i)) { $style = $style.'I'; }
			    if (isset($entry->u)) { $style = $style.'U'; }
				if (isset($entry->family)) { $this->currentFontFamily = $entry->family; }
				$this->currentFontStyle = $style;
				$pdf->SetFont($this->currentFontFamily,$style,$entry->size);
			}
			if ($tag == "color") {
				switch ($entry->__toString()) {
					case "black": 	$r = 0; 	$g = 0; 	$b = 0; break;
					case "white": 	$r = 255; 	$g = 255; 	$b = 255; break;
					case "gray": 	$r = 128; 	$g = 128; 	$b = 128; break;
					case "red": 	$r = 255; 	$g = 0; 	$b = 0; break;
					case "blue": 	$r = 0; 	$g = 0; 	$b = 255; break;
					case "green": 	$r = 0; 	$g = 255; 	$b = 0; break;
					default:
						$r = $entry->r;
						$g = $entry->g;
						$b = $entry->b;
				}	
				$pdf->SetTextColor($r,$g,$b);
			}
			if ($tag == "setPos") {
				if (!isset($entry->x)) { 
					$pdf->SetY($entry->y); 
				} else {
					if (!isset($entry->y)) { 
						$pdf->SetX($entry->x);
					} else {
						$pdf->SetXY($entry->x, $entry->y);
					}
				}
			}
			if ($tag == "br") {
				$h = $entry['height'];
				if (isset($h)) $pdf->Ln($h); else $pdf->Ln();
				$fontSpace = round($pdf->GetFontSpace());
				$pdf->SetLastH($fontSpace);
			}
			if ($tag=="pageBreak") {
				$pdf->AddPage();
			}
			if ($tag == "bullet") {
				$fontSpace = round($pdf->GetFontSpace());
				if ($pdf->CheckIfAutoPageBreak($fontSpace)) {
					$this->flushFramesAndAddPage($pdf);
				}
				$fontSize  = $pdf->GetFontSize();
				$pdf->SetFont('ZapfDingbats','', $fontSize*0.5);
				$pdf->Cell($fontSpace,$fontSpace,'l');     
				$pdf->SetFont($this->currentFontFamily,$this->currentFontStyle, $fontSize);
			}
			if ($tag == "checkbox") {
				if ( isset($entry->tag) && isset($entry->value) ) {
					$fontSpace = round($pdf->GetFontSpace());
					if ($pdf->CheckIfAutoPageBreak($fontSpace)) {
						$this->flushFramesAndAddPage($pdf);
					}
					$str = $this->parseText($entry->tag->__toString());
					if ( $str == utf8_decode($entry->value->__toString()) ) {	
						$pdf->SetFont('ZapfDingbats','');
						$pdf->Cell($fontSpace,$fontSpace,'4', 1, 0, 'C');     
						$pdf->SetFont($this->currentFontFamily,$this->currentFontStyle);
					} else {
						$pdf->Cell($fontSpace,$fontSpace,'', 1);
					}
				}
			}
			if ($tag == "section") {
				if ( $pdf->CheckIfAutoPageBreak(20) ) { $pdf->AddPage(); } 
				$doSection = true;
				$skip = $entry['skipIfEmpty'];
				if (isset($skip)) {
					$field = substr($skip,1,strlen($skip)-2);
					if ($this->isEmptyHTML( $this->fields[$field] )) {
						$doSection = false;
					}
				}
				if ($doSection) {
					$secN++;
					$this->parse( $pdf, $entry, $sectionNumber=="" ? $secN : $sectionNumber.".".$secN );
				}
			}
			if ($tag == "spanRow") {
				$fontSpace = round($pdf->GetFontSpace());
				//Fija el margen izquierdo y posición en la que se expanden las filas hijas
				$lm = $pdf->GetLeftMargin();
				$w = (isset($entry->tf) && isset($entry->tf['width'])) ? $entry->tf['width'] : 0;
				$nlm = $pdf->GetX() + $w;
				$this->startFrame($pdf, (isset($entry->tf) && isset($entry->tf['border'])) ? $entry->tf['border'] : 0, $nlm);				
				$pdf->SetX($nlm);
				$pdf->SetLeftMargin($nlm);
				//Genera las filas
				
				if (isset($entry->rows)) {
					$this->parse( $pdf, $entry->rows, $sectionNumber );
				}
				//Genera la fila principal usando el alto de celda calculado automáticamente.
				$this->expandFramesSpanRow( $fontSpace );
				$borderFrame = $this->finishFrame($pdf);
				$h = $borderFrame->fy2 - $borderFrame->fy1;
				
				$entry->tf['height'] = $h>0 ? $h : $fontSpace;
				$entry->tf['border'] = "0";
				$pdf->SetLeftMargin($lm);
				$pdf->SetXY($borderFrame->fx1, $borderFrame->fy1);
				$this->parse( $pdf, $entry, $sectionNumber );				
				$pdf->SetXY($borderFrame->fx1, $borderFrame->fy1);
				$pdf->SetLastH($h);
			}
			if ($tag == "ilos") {
				//Crea la cadena de consulta SQL con base en los filtros y agrupaciones seleccionadas
				$fontSpace = round($pdf->GetFontSpace());
				$bSpanRow = false;
				$bShowILO = false;
				$lastILOCat = "";
				$lastILOCatPos = 0;
				$lastILOProgCat = "";
				$lastILOProgCatPos = 0;
				$ret = $this->getILOsSQL($entry);
				$sql = $ret["sql"];
				$group = $ret["group"];
				$result = $this->planea->conn->query($sql); 
				if ($result->num_rows > 0) { 
					if ( isset($entry->foreachGroup) && isset($entry->foreachGroup->spanRow) && 
						 isset($entry->foreachGroup->spanRow->tf) && isset($entry->foreachGroup->spanRow->tf['border']) ) {
						$borderGroup = clone $entry->foreachGroup->spanRow->tf['border'];
						$entry->foreachGroup->spanRow->tf['border'] = 0;
					} else {
						$borderGroup = 0;
					}					
					$borderILO = (isset($entry->foreachILO) && isset($entry->foreachILO['border'])) ? $entry->foreachILO['border'] : 0;
					$rapCat = -1;
					//Visualiza cada elemento
					while($rowILO = $result->fetch_assoc()) {
						//Inserta los valores de las etiquetas
						$this->fields["iloText"] 		= ltrim($rowILO["Text"]);
						$this->fields["iloPos"] 		= ltrim($rowILO["Position"]);
						$this->fields["iloCategory"] 	= isset($rowILO["catValue"]) ? $rowILO["catValue"] : "";
						$this->fields["iloCategoryPos"] = isset($rowILO["catPos"]) ? $rowILO["catPos"] : 0;
						$this->fields["iloProgCat"] 	= isset($rowILO["progValue"]) ? $rowILO["progValue"] : "";
						$this->fields["iloProgCatPos"] 	= isset($rowILO["progPos"]) ? $rowILO["progPos"] : 0;
						//Analiza si cambia la categoría del RAP
						if ( ($group>0) && isset($entry->foreachGroup) ) {
							$doGroup = false;
							if ( ($group==1) && ($rapCat != $rowILO["CategoryID"]) ) {
								$rapCat = $rowILO["CategoryID"];
								$doGroup = true;
							}
							if ( ($group==2) && ($rapCat != $rowILO["ProgramILOID"]) ) {
								$rapCat = $rowILO["ProgramILOID"];
								$doGroup = true;
							}
							if ($doGroup) {
								//Si los RAPs tienen borde, lo dibuja
								if ($bShowILO) {
									$this->finishFrame($pdf);
									$bShowILO = false;
								}
								//Dibuja la celda principal
								if (!isset($entry->foreachGroup->spanRow)) {
									$this->parse( $pdf, $entry->foreachGroup, $sectionNumber );
								} else {
									//Fija las etiquetas de la categoría a la categoría que estaba pendiente
									$nextILOCat = $this->fields["iloCategory"];
									$this->fields["iloCategory"] = $lastILOCat;
								
									$nextILOCatPos = $this->fields["iloCategoryPos"];
									$this->fields["iloCategoryPos"] = $lastILOCatPos;
								
									$nextILOProgCat = $this->fields["iloProgCat"];
									$this->fields["iloProgCat"] = $lastILOProgCat;
								
									$nextILOProgCatPos = $this->fields["iloProgCatPos"];
									$this->fields["iloProgCatPos"] = $lastILOProgCatPos;
									
									//Si hay una fila principal pendiente, la dibuja		
									if ($bSpanRow) { 
										//Dibuja la celda principal 
										$borderFrame = $this->finishFrame($pdf);
										$h = $borderFrame->fy2 - $borderFrame->fy1;
										$entry->foreachGroup->spanRow->tf['height'] = $h>0 ? $h : $fontSpace;
										$pdf->SetLeftMargin($lm);
										$pdf->SetXY($borderFrame->fx1, $borderFrame->fy1);
										$this->parse( $pdf, $entry->foreachGroup->spanRow, $sectionNumber );
										$pdf->SetXY($borderFrame->fx1, $borderFrame->fy2);	
									}
									
									//Configura las etiquetas de la categoría para que en la próxima iteración se dibujen correctamente
									$lastILOCat 		= $nextILOCat;
									$lastILOCatPos 		= $nextILOCatPos;
									$lastILOProgCat 	= $nextILOProgCat;
									$lastILOProgCatPos 	= $nextILOProgCatPos;
								
									$bSpanRow = true;
							
									//Si los RAPs se visualizan con filas expandidas, realiza el procedimiento inicial del spanRow									
									$lm = $pdf->GetLeftMargin();
									$w = (isset($entry->foreachGroup->spanRow->tf) && isset($entry->foreachGroup->spanRow->tf['width'])) ? $entry->foreachGroup->spanRow->tf['width'] : 0;
									$nlm = $pdf->GetX() + $w;
									$this->startFrame($pdf, $borderGroup, $nlm);				
									$pdf->SetX($nlm);
									$pdf->SetLeftMargin($nlm);	
								}
							}
						}	
						if (!$bShowILO) {
							$this->startFrame($pdf, $borderILO);
							$bShowILO = true;
						}
						//Muestra el RAP
						if ( isset($entry->foreachILO) ) {
							$this->parse( $pdf, $entry->foreachILO, $sectionNumber );
						}
					}
					
					//Si hay borde lo dibuja
					$this->finishFrame($pdf);
					
					//Si se ha activado SpanRow, debe dibujar la última celda con la categoría
					if ($bSpanRow) {
						//Si hay una fila principal pendiente, la dibuja
						if (isset($entry->foreachGroup) && isset($entry->foreachGroup->spanRow)) {
							$this->fields["iloCategory"] 	= $lastILOCat;
							$this->fields["iloCategoryPos"] = $lastILOCatPos;
							$this->fields["iloProgCat"] 	= $lastILOProgCat;
							$this->fields["iloProgCatPos"] 	= $lastILOProgCatPos;
						}						
						//Dibuja la fila
						$borderFrame = $this->finishFrame($pdf);
						$h = $borderFrame->fy2 - $borderFrame->fy1;
						$entry->foreachGroup->spanRow->tf['height'] = $h>0 ? $h : $fontSpace;
						$pdf->SetLeftMargin($lm);
						$pdf->SetXY($borderFrame->fx1, $borderFrame->fy1);
						$this->parse( $pdf, $entry->foreachGroup->spanRow, $sectionNumber );
						$pdf->SetXY($borderFrame->fx1, $borderFrame->fy2);
					}					
				} else {
					if ( isset($entry->filter) && isset($entry->foreachILO) && isset($entry->foreachILO['border']) ) {
						//Inserta valores vacíos de las etiquetas
						$this->fields["iloText"] = "";
						$this->fields["iloPos"] = "";
						$this->fields["iloCategory"] = "";
						$this->fields["iloCategoryPos"] = "";
						$this->fields["iloProgCat"] = "";
						$this->fields["iloProgCatPos"] = "";
						//Muestra el borde del RAP
						$this->startFrame($pdf, $entry->foreachILO['border']);
						$this->parse( $pdf, $entry->foreachILO, $sectionNumber );
						$this->finishFrame($pdf);
					}
				}
			}
			if ($tag == "skills") {
				$fontSpace = round($pdf->GetFontSpace());
				$sql = $this->getSkillsSQL($entry);
				$result = $this->planea->conn->query($sql); 
				if ($result->num_rows > 0) { 

					//Visualiza el título
					$w = isset($entry->caption['width']) ? $entry->caption['width'] : 151;
					$h = isset($entry->caption['height']) ? $entry->caption['height'] : $fontSpace;
					if ( $pdf->CheckIfAutoPageBreak($fontSpace+$h) ) { $this->flushFramesAndAddPage($pdf); }
					$pdf->SetFont($this->currentFontFamily, 'B', $pdf->GetFontSize());
					$pdf->Cell($w,$h,utf8_decode($entry->caption->__toString()));
					$pdf->SetFont($this->currentFontFamily, $this->currentFontStyle, $pdf->GetFontSize());
					
					//Visualiza las columnas de Introduce/Enseña/Utiliza
					$this->wIntroduceCol = isset($entry->introduce['width']) ? $entry->introduce['width'] : 15;
					$this->wTeachCol = isset($entry->teach['width']) ? $entry->teach['width'] : 15;
					$this->wUseCol = isset($entry->use['width']) ? $entry->use['width'] : 15;
					$pdf->Cell($this->wIntroduceCol,$h, utf8_decode($entry->introduce->__toString()),0,0,'C');
					$pdf->Cell($this->wTeachCol, 	$h, utf8_decode($entry->teach->__toString()),0,0,'C');
					$pdf->Cell($this->wUseCol, 		$h, utf8_decode($entry->use->__toString()),0,0,'C');
					$pdf->Ln();
					
					//Configura si se pintan intercaladas las filas
					if (isset($entry->grayed) && isset($entry->grayed['height']) ) {
						$pdf->SetFillColor(235,235,235);
						$fillSkillGrayH = $entry->grayed['height'];
						$fillSkillGrayW = $w + $this->wIntroduceCol + $this->wTeachCol + $this->wUseCol;
						$fillSkillRow = true;            
					} else {
						$fillSkillGrayH = 0;
						$fillSkillRow = false; 
					}
					
					//Chequea si requiere salto de página 
					if ( $pdf->CheckIfAutoPageBreak($fontSpace) ) { $this->flushFramesAndAddPage($pdf); }
						
					//Visualiza cada habilidad
					while($row = $result->fetch_assoc()) {      
						$this->fields["skillText"] = $row["description"];
						$this->fields["skillRef"] 	= $row["ref_syllabus"];
						$this->fields["_skillI"] 	= ($row["Introduce"]==1) ? '4' : '';
						$this->fields["_skillT"] 	= ($row["Teach"]==1) ? '4' : '';
						$this->fields["_skillU"] 	= ($row["Utilize"]==1) ? '4' : '';
						if ( ($fillSkillGrayH>0) && $fillSkillRow) {
							$pdf->Rect($pdf->GetX(), $pdf->GetY(), $fillSkillGrayW, $fillSkillGrayH, 'F');
						}
						if ( isset($entry->foreachSkill) ) {
							$this->parse( $pdf, $entry->foreachSkill, $sectionNumber );
						}
						$fillSkillRow = !$fillSkillRow;
						//Chequea si requiere salto de página 
						if ( $pdf->CheckIfAutoPageBreak($fontSpace) ) { $this->flushFramesAndAddPage($pdf); }  
					}   
				}	  	
			}
			
			if ($tag == "skillAttrib") {
				$fontSpace = round($pdf->GetFontSpace());
				$pdf->SetFont('ZapfDingbats','',$pdf->GetFontSize());
				$pdf->Cell($this->wIntroduceCol,$fontSpace,$this->fields["_skillI"],0,0,'C');	
				$pdf->Cell($this->wTeachCol,$fontSpace,$this->fields["_skillT"],0,0,'C');	
				$pdf->Cell($this->wUseCol,$fontSpace,$this->fields["_skillU"], 0,0,'C');
				$pdf->SetFont($this->currentFontFamily, $this->currentFontStyle, $pdf->GetFontSize());
			}
			
			if ($tag == "reqs") {
				$sql = "SELECT Nombre
						FROM courses_plan
						INNER JOIN courses_reqs
						ON courses_reqs.requirementID=courses_plan.ID
						WHERE courses_reqs.CourseID=". $this->CourseID;;
				$result = $this->planea->conn->query($sql); 
				$this->startFrame($pdf, (isset($entry->foreachReq) && isset($entry->foreachReq['border'])) ? $entry->foreachReq['border'] : 0);
				if ($result->num_rows > 0) { 
					//Visualiza cada requisito
					$nrow = 1;
					while($row_reqs = $result->fetch_assoc()) {      
						$this->fields["req"] = $row_reqs["Nombre"];
						$this->fields[","] = $nrow != $result->num_rows ? "," : "";
						if ( isset($entry->foreachReq) ) {
							$this->parse( $pdf, $entry->foreachReq, $sectionNumber );
						}
						$nrow++;						
					}					
				} else {
					$this->fields["req"] = "";
					$this->fields[","] = "";
					if ( isset($entry->foreachReq) ) {
						$this->parse( $pdf, $entry->foreachReq, $sectionNumber );
					}
				}				
				//Si hay borde lo dibuja
				$this->finishFrame($pdf);
			}
			
			if ($tag=="topics") {
				$sql = "SELECT * FROM courses_contents WHERE CourseID=" . $this->CourseID . " ORDER BY TopicNumber";
				$result = $this->planea->conn->query($sql); 
				if ($result->num_rows > 0) { 
					//Visualiza cada tema
					while($row_content = $result->fetch_assoc()) {
						$this->fields["topicNumber"] 	= $row_content["TopicNumber"];
						$this->fields["topicName"] 		= $row_content["TopicName"];
						$this->fields["topicWeeks"] 	= $row_content["Weeks"];
						$this->fields["topicText"] 		= $row_content["Contents"];
						$this->startNumering 			= $row_content["TopicNumber"];
						$this->startFrame($pdf, (isset($entry->foreachTopic) && isset($entry->foreachTopic['border'])) ? $entry->foreachTopic['border'] : 0);
						if ( isset($entry->foreachTopic) ) {
							$this->parse( $pdf, $entry->foreachTopic, $sectionNumber );
						}
						//Si hay borde lo dibuja
						$this->finishFrame($pdf);						
					}					
				}
				$this->startNumering = 0;
			}
			
			if ($tag=="versionHistory") {
				$sql = "SELECT Version,FechaVersion,VersionAnotacion,VersionResponsable 
						FROM courses_general WHERE CourseKeyID=" . $this->CourseKeyID . " AND Version <= ".$this->fields["version"]." ORDER BY Version";
				$result_ver = $this->planea->conn->query($sql); 
				if ($result_ver->num_rows > 0) { 
					//Visualiza cada versión del historial
					while($row_version = $result_ver->fetch_assoc()) {      
						$this->fields["versionNumber"] 		= $row_version["Version"];
						$this->fields["versionDate"] 		= $row_version["FechaVersion"];
						$this->fields["versionAnotation"] 	= $row_version["VersionAnotacion"];
						$this->fields["versionResponsible"] = $row_version["VersionResponsable"];
						$this->startFrame($pdf, (isset($entry->foreachVersion) && isset($entry->foreachVersion['border'])) ? $entry->foreachVersion['border'] : 0);
						if ( isset($entry->foreachVersion) ) {
							$this->parse( $pdf, $entry->foreachVersion, $sectionNumber );
						}
						//Si hay borde lo dibuja
						$this->finishFrame($pdf);						
					}					
				}
				$this->startNumering = 0;
			}
			
			
			if ($tag == "rubrics") {
				$sql = "SELECT RubricID FROM rubrics_assoc WHERE CourseID=".$this->CourseID." AND RapSkillType!=4 GROUP BY RubricID";
				$result = $this->planea->conn->query($sql); 	
				if ($result->num_rows > 0) { 
					//Fija la margen a la posición actual de X
					$lm = $pdf->GetLeftMargin();
					$pdf->SetLeftMargin($pdf->GetX());
				
					//Chequea si requiere salto de página 
					if ( $pdf->CheckIfAutoPageBreak(0) ) { $this->flushFramesAndAddPage($pdf); }
					
					//Visualiza cada rúbrica
					while($row = $result->fetch_assoc()) {  
						$sql = "SELECT * FROM rubrics_general WHERE ID=".$row["RubricID"];
						$result_desc = $this->planea->conn->query($sql);
						$row_desc = $result_desc->fetch_assoc();
						$this->fields["rubricName"] = $row_desc["Name"];
						$this->fields["rubricDesc"] = $row_desc["Description"];
						$this->fields["_rubricType"] = $row_desc["Type"];
						$this->fields["_rubricNLevels"] = $row_desc["NumLevels"];
						$this->fields["_rubricID"] = $row_desc["ID"];			
						if ( isset($entry->foreachRubric) ) {
							$this->parse( $pdf, $entry->foreachRubric, $sectionNumber );
						}
						//Chequea si requiere salto de página 
						if ( $pdf->CheckIfAutoPageBreak(0) ) { $this->flushFramesAndAddPage($pdf); }  
					}
					//Restaura la margen izquierda
					$pdf->SetLeftMargin($lm);
				}	  	
			}
			
			if ($tag == "rubric") {
				if (isset($this->fields["_rubricID"])) {
					$this->parseRubric($pdf, $this->fields["_rubricID"], $entry);
				}
			}
		}	
	}

	function loadTemplate( $strFile ) {
		$this->xml = simplexml_load_file( $strFile) or die("Error: No puedo abrir la plantilla");
	}
	
	function Header( $pdf ) {
		$lm = $pdf->GetLeftMargin();
		$tm = $pdf->GetTopMargin();
		$family = $this->currentFontFamily;
		$style = $this->currentFontStyle;
		$size = $pdf->GetFontSize();
		$this->parse( $pdf, $this->xml->head );
		$pdf->SetFont($family,$style,$size);
		$this->currentFontFamily = $family;
		$this->currentFontStyle = $style;
		$pdf->SetXY( $lm, $tm );
	}
	
	function SetBodyMargins( $pdf ) {
		if ( isset($this->xml->body['left']) ) $pdf->SetTopMargin($this->xml->body['left']);
		if ( isset($this->xml->body['right']) ) $pdf->SetTopMargin($this->xml->body['right']);
		if ( isset($this->xml->body['top']) ) $pdf->SetTopMargin($this->xml->body['top']);
		if ( isset($this->xml->body['bottom']) ) $pdf->SetAutoPageBreak(true, $this->xml->body['bottom']);
	}	
	
	function Body( $pdf ) {
		$this->parse( $pdf, $this->xml->body );
	}

	function Footer( $pdf, $pageNo ) {
		$family = $this->currentFontFamily;
		$style = $this->currentFontStyle;
		$size = $pdf->GetFontSize();
		$this->fields["pageNo"] = $pageNo;
		$this->parse( $pdf, $this->xml->foot );
		$pdf->SetFont($family,$style,$size);
		$this->currentFontFamily = $family;
		$this->currentFontStyle = $style;
	}
}

	
//Definición de la clase para exportar el PDF
class PDF extends FPDF
{
	var $template;
	var $prevFontSize;

	function SetTemplate( $template ) {
		$this->template = $template;
	}
	// Cabecera de página
	function Header() {
		$this->template->Header($this);
	}
	// Pie de página
	function Footer() {
		$this->template->Footer( $this, $this->PageNo() );
	}
	function GetLeftMargin() {
		return $this->lMargin;
	}
	function GetRightMargin() {
		return $this->rMargin;
	}
	function GetTopMargin() {
		return $this->tMargin;
	}	
	function SetLastH($h) {
		$this->lasth = $h;
	}
	function GetLastH() {
		return $this->lasth;
	}
	function GetPageNumber() {
		return $this->page;
	}
	function CheckIfAutoPageBreak($fontSpace) {
		if(($this->y+$fontSpace>$this->PageBreakTrigger) && !$this->InHeader && !$this->InFooter && $this->AcceptPageBreak())
			return true;
		else 
			return false;
	}
	function CheckIfHeaderOrFooter() {
		return $this->InHeader || $this->InFooter;
	}
	function GetFontSize() {
		return $this->FontSizePt;
	}
	function GetFontSpace() {
		return $this->FontSizePt/$this->k;
	}
	function GetFontFactor() {
		return 1000/$this->FontSize;
	}
	function GetFontCharWidths() {
		return $this->CurrentFont['cw'];
	}
	function setSmallFont($subOffset) {
		$fontSizeDelta = $subOffset;
		$this->prevFontSize = $this->GetFontSize();
		$fontSize = $this->prevFontSize - $fontSizeDelta;
		$this->SetFontSize($fontSize);
		$subOffset = ((-$fontSizeDelta/$this->k)*0.3)+($subOffset/$this->k);
		$subX = $this->x;
		$subY = $this->y;
		$this->SetXY($subX,$subY-$subOffset);
		return $subOffset;
	}
	function unsetSmallFont($subOffset) {
		$subX = $this->x;
		$subY = $this->y;
		$this->SetXY($subX,$subY+$subOffset);
		$this->SetFontSize($this->prevFontSize);
	}
	function setWordSpacing( $ws ) {
		if ($this->ws != $ws) {
			$this->ws = $ws;
			$this->_out(sprintf('%.3F Tw',$this->ws*$this->k));
		}
	}
}


//=================================================
//Startup 
//

$planea = new planea();
$planea->openConnection();
$planea->conn->set_charset("latin1");

$CourseID = $_GET["ID"]; 
  
$sql = "SELECT * FROM courses_general WHERE ID=" . $CourseID;
$result = $planea->conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

	$sql = "SELECT Faculty, Program, Template FROM study_plan WHERE ID=" . $row["PlanID"];
	$result = $planea->conn->query($sql);
	$row_pname = $result->fetch_assoc();
    
	//Carga la plantilla
	if (isset($_GET["template"])) { 
		$templateFile = $_GET["template"];
	} else { 
		//Si se ha invocado para previsualizar una plantilla, la emplea, en caso contrario,
		//usa la plantilla establecida en el curso o una por defecto establecida para 
		//el plan de estudios 
		if (!empty($row["Template"])) {
			$templateFile = $row["Template"];
		} else {
			if (!empty($row_pname["Template"])) {
				$templateFile = $row_pname["Template"];
			} else {
				echo "No se ha establecido una plantilla para generar el PDF";
				exit(0);
			}
		}
	}
	$templateFile = "templates/".$templateFile;
	if (!file_exists($templateFile)) {
		echo "No se encuentra la plantilla para generar el PDF";
		exit(0);
	}
	$template = new templateParser;
	$template->loadTemplate($templateFile);
	
	//Fija todas las entradas NULL en cadenas vacías para evitar 
	//que el parser XML genere error en las etiquetas que son NULL.
	foreach ($row as $key => $value) {
		if (is_null($value)) {
			 $row[$key] = "";
		}
	}
	
	//Configura los campos
	$template->fields["pageNo"] 			= 0;
	$template->fields["pageTotal"] 			= "{nb}";	
	$template->fields["sectionNumber"]  	= 0;	
	$template->fields["facultyName"] 		= $row_pname["Faculty"];
	$template->fields["programName"] 		= $row_pname["Program"];
	$template->fields["courseName"] 		= $row["Nombre"];
	$template->fields["description"] 		= $row["Descripcion"];
	$template->fields["rationale"] 			= $row["Justificacion"];
	$template->fields["thHours"] 			= $row["HorasTeoricas"]; 
	$template->fields["prHours"] 			= $row["HorasPracticas"]; 
	$template->fields["thprHours"] 			= $row["HorasTeoricoPracticas"];
	$template->fields["numberCredits"] 		= $row["NumeroCreditos"];
	$template->fields["methodologyFormat"] 	= $row["TipoMetodologia"];
	$template->fields["courseCode"] 		= $row["Codigo"];
	$template->fields["courseCategory"] 	= $row["TipoActividad"];
	$template->fields["semester"] 			= $row["Semestre"];
	$template->fields["methodologyClass"] 	= $row["Naturaleza"];
	$template->fields["courseArea"] 		= $row["NucleoTematico"];
	$template->fields["evaluationClass"] 	= $row["TipoEvaluacion"];
	$template->fields["indHours"] 			= $row["HorasIndependientes"];
	$template->fields["officeHours"] 		= $row["HorasAsesoria"];
	$template->fields["allowCertifyingExam"]= $row["Habilitable"]==1 ? "Si" : "No"; 
	$template->fields["allowValidationExam"]= $row["Validable"]==1 ? "Si" : "No"; 
	$template->fields["allowHomologation"] 	= $row["Homologable"]==1 ? "Si" : "No";
	$template->fields["integration"] 		= $row["ProcesosIntegracion"];
	$template->fields["procedureContents"] 	= $row["ContenidosProcedimentales"];
	$template->fields["behaviorContents"] 	= $row["ContenidosActitudinales"];
	$template->fields["methodology"] 		= $row["Metodologia"];
	$template->fields["evaluation"] 		= $row["Evaluacion"];
	$template->fields["bibliography"] 		= bibfile2html($row["Bibliografia"],null,false,false);
	$template->fields["version"] 			= $row["Version"];
	$template->fields["versionNumber"] 		= $row["Version"];
	$template->fields["versionDate"] 		= $row["FechaVersion"];
	$template->fields["versionAnotation"] 	= $row["VersionAnotacion"];
	$template->fields["versionResponsible"] = $row["VersionResponsable"];
	switch($row["EstadoVersion"]) {
		case planea::syllStateDisabled: $syll_status="Obsoleto"; break;
		case planea::syllStateOpened: 	$syll_status="Borrador"; break;
		case planea::syllStateApproved: $syll_status="Activo"; break;
	}
	$template->fields["versionStatus"] = $syll_status;
	
	//Creación del PDF
    $pdf = new PDF("Portrait", "mm", "Letter");
	$pdf->SetTemplate($template);
	$template->SetConnection($planea, $CourseID, $row["CourseKeyID"]);
    $template->SetBodyMargins( $pdf );
	$pdf->SetFont('Arial','',12); 
	$pdf->SetTitle($row["Nombre"]);
    $pdf->AliasNbPages();
    $pdf->AddPage();
	$template->Body($pdf);
    $pdf->Output('I',$row["Nombre"].".pdf");
	
} else {
    echo "No se encuentra el curso seleccionado";
}

$planea->closeConnection();
?>

