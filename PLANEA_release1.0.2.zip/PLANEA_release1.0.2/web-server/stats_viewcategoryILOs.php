<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script>
		var reportID = 1;
		var catID = 0;
		function loadTable(showTooltip) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var tableObj = document.getElementById("rapTable");
					tableObj.innerHTML = this.responseText;
				}
			};
			xhttp.open("GET", "planea_viewcategoryraps.php?reportID="+reportID+"&PlanID="+
				<?php if (isset($_POST["PlanID"])) echo $_POST["PlanID"]; else echo "0"; ?>+
				"&showElect="+document.getElementById("showElectiveChk").checked+
				"&showTooltip="+showTooltip+"&catID="+catID, true);
			xhttp.send();
		}
		function changeReportType() {
			var e = document.getElementById("reportType");
			if (e.selectedIndex == -1) {
				return null;
			}
			reportID = parseInt(e.options[e.selectedIndex].value);
			loadTable(true);
		}
		function changeRAP() {
			var e = document.getElementById("rapSelection");
			if (e.selectedIndex == -1) {
				return null;
			}
			catID = parseInt(e.options[e.selectedIndex].value);
			loadTable(true);
		}
		function exportTable() {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var tableObj = document.getElementById("rapTable");
					tableObj.innerHTML = this.responseText;
					tableToExcel('RapTb','RAPs Report');
					loadTable(true);
				}
			};
			xhttp.open("GET", "planea_viewcategoryraps.php?reportID="+reportID+"&PlanID="+
				<?php if (isset($_POST["PlanID"])) echo $_POST["PlanID"]; else echo "0"; ?>+
				"&showElect="+document.getElementById("showElectiveChk").checked+
				"&showTooltip=false&catID="+catID, true);
			xhttp.send();
		}
		var tableToExcel = (function() {
			var uri = 'data:application/vnd.ms-excel;base64,'
				, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
				, base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
				, format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
			return function(table, name) {
				if (!table.nodeType) table = document.getElementById(table)
				var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
				window.location.href = uri + base64(format(template, ctx))
			}
		})()

		window.onload = function(){
			loadTable(true);
		}
	</script>
</head>

<body>
<?php  
	require('planea_logosbar.php');
	$helptopic = "coord-stats-intcatraps";
	require('planea_statisticsbar.php');
?>

<div class="planeaForm">
Reporte: <select id="reportType" onchange="changeReportType()">
	<option value="1" selected>Cursos vs. categorías institucionales</option>
	<option value="2">Categorías vs. RAPs de cursos</option>
	<option value="3">RAPs de curso sin asociar categoría</option>
</select> 
<input id="showElectiveChk" type="checkbox" value=0 onchange="loadTable(true)">Mostrar electivas &nbsp; 
<button  onclick="exportTable()" type="button">Exportar</button>
</div> 	

<div id="rapTable" class="planeaForm">
</div>  
</body>
</html>
