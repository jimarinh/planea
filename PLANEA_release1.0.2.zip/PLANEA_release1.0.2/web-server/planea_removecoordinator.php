<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
//Remove from coordinator table
$sql = "DELETE FROM users_coordinators WHERE ID=" . $_GET["removeID"];
$planea->conn->query($sql);
//Remove coordinator role if necessary
$sql = "SELECT * FROM users_coordinators WHERE userID=" . $_GET["userID"];
$result = $planea->conn->query($sql);
if ($result->num_rows == 0)  {  
	$sql = "SELECT role FROM users WHERE ID=" . $_GET["userID"];
	$result = $planea->conn->query($sql);
	$row_user = $result->fetch_assoc();
	$sql = "UPDATE users SET role='".str_replace("C","",$row_user["role"])."' WHERE ID=" . $_GET["userID"];	
	$planea->conn->query($sql);
}
$planea->closeConnection();
?>