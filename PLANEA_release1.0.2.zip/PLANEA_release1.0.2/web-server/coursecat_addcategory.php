<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "INSERT INTO coursecat_values(SetID, Value, Position) VALUES ('".$_GET["setID"]."','".$_GET["catName"]."','".$_GET["pos"]."')";
$result = $planea->conn->query($sql);
if ($result == true) {
	echo $planea->conn->insert_id;
}
$planea->closeConnection();
?>