<?php
	//Actions to support the planning course interface
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection(); 
	switch($_GET["action"]) 
	{
		//Return the list of courses with a planning for the given semester
		case "loadCoordList":
			$planea->showPlanningCoursesList($_GET["PlanID"], $_GET["SemesterID"]);
			break;
			
		//Return the list of courses that a user has planned in the given semester 
		case "loadUserList":
			$planea->showPlanningCoursesByUser( $_GET["UserID"], $_GET["SemesterID"] );
			break;
			
		//Return a summary of the course planning
		case "loadCourse":
			$planea->showPlanningCourseName( $_GET["CourseID"], $_GET["UserID"] );
			$planea->showPlanningCourseRapsAndSkills( $_GET["CourseID"], $_GET["SemesterID"], $_GET["UserID"] );
			$planea->showPlanningCourseActivityTable( $_GET["CourseID"], $_GET["SemesterID"], $_GET["UserID"], 
				$_GET["showTooltip"]=="true", "THESG" );
			echo "<p><b>Rúbricas</p><small>";
			$planea->showRubricsByUserCourse( $_GET["CourseID"], $_GET["SemesterID"], $_GET["UserID"], false );
			echo "</small>";
			break;
			
		//Action when the user modifies a How To in the Step 1 for course planning
		case "editHowTo":
			$HowToID = $_GET["HowToID"];
			if ($HowToID==-1) {
				//Insert new how to...
				$sql = "INSERT INTO teacher_howtos (CourseID, RapID, UserID, Semester, HowTo) 
					VALUES (".$_GET["CourseID"].",".$_GET["RapID"].",".$_GET["UserID"].
					",'".$_GET["SemesterID"]."','".$_GET["Text"]."')";
				$conn->query($sql);
				$HowToID = $planea->conn->insert_id;
			} else {
				//Update how to...
				$sql = "UPDATE teacher_howtos SET HowTo='".$_GET["Text"]."' WHERE ID=".$HowToID;
				$conn->query($sql);
			}

			//Display the updated row
			$sql = "SELECT ID,Position,Text FROM courses_ilos WHERE ID=".$_GET["RapID"];
			$result = $conn->query($sql);
			$row = $result->fetch_assoc();
			
			$planea->showPlanningCourseHowTosRow( $HowToID, $_GET["CourseID"], $_GET["RapID"], $_GET["SemesterID"],
				$_GET["UserID"], $_GET["Text"], $row["Position"], $row["Text"] );
			break;
			
		//Action when the user change the order of the activities in the Step 3 of course planning.
		case "updatePos":
			foreach ($_GET as $key=>$value) {
				if (substr($key,0,3) == "pos") {	
					$id = substr($key,3);
					$sql = "UPDATE teacher_activities SET Position=". $_GET["pos".$id] ." WHERE ID=".$id;
					$planea->conn->query($sql);
				}
			}
			break;

		//Action when the user updates the number of hours for a given activity in the Step 3 of course planning.
		case "updateHours":
			foreach ($_GET as $key=>$value) {
				if (substr($key,0,2) == "hd") {	
					$id = substr($key,2);
					$sql = "UPDATE teacher_activities SET HD=".$_GET["hd".$id].", HI=".$_GET["hi".$id]." WHERE ID=".$id;
					$planea->conn->query($sql);
				}
			}
			break;
			
		//Action when the user updates the Gantt chart for a given activity in the Step 3 of course planning.
		case "ganttUpdate":
			$sql = "UPDATE teacher_activities SET StartWeek=".$_GET["StartWeek"].", EndWeek=".$_GET["EndWeek"]." WHERE ID=".$_GET["ActID"];
			$planea->conn->query($sql);
			break;
	}
	
	$planea->closeConnection();
?>