//================================================
//Methods to support the course planning interface
//================================================

function setModifiedFlag() { window.onbeforeunload = function() { return true; }; }
function clearModifiedFlag() { window.onbeforeunload = null; return true; }
var editPlanID = -1;
var editCourseID = -1;
var editUserID = -1;
var editSemesterID = "";

//Functions for editing the ILO HowTos 
//-------------------------------------
var editHowToID = -1;
var editRapID = -1;
function editHowTo(idHowTo,RapID,CourseID,UserID,SemesterID) {
	editHowToID = idHowTo;
	editRapID = RapID;
	editCourseID = CourseID;
	editUserID = UserID;
	editSemesterID = SemesterID;
	var e = document.getElementById("howto"+RapID).getElementsByTagName("td");
	HowToText.value = e[2].innerText;
	HowTosRap.innerHTML = e[1].innerHTML;
	HowTosPanel.style.display = "block";
}
function editHowToGo(action) {
	if (action==1) {  //Aceptar				
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("howto"+editRapID).innerHTML = this.responseText;
				HowTosPanel.style.display = "none";
			}
		};
		var str = HowToText.value.replace(/\n/g,"<br>");
		xhttp.open("GET", "planning_course_go.php?action=editHowTo&HowToID="+editHowToID+
			"&RapID="+editRapID+"&CourseID="+editCourseID+"&UserID="+editUserID+
			"&SemesterID="+editSemesterID+"&Text="+str, true);
		xhttp.send(); 
	}
	if (action==2) { //Cancelar
		HowTosPanel.style.display = "none";
	}
}

//Functions for configuring the activity schedule (time order, slots, and Gantt chart)
//------------------------------------------------------------------------------------
function updateArrowBtns() {
	var btnup, btndn, pos;
	var items = document.getElementById("activitiesCourse").getElementsByTagName("tr");
	var max = items.length-3;
	for(pos=1;pos<=max;pos++) {
		btnup = items[pos].getElementsByClassName("button btn_up");
		btnup[0].style.display = (pos==1) ? "none" : "inline";
		btndn = items[pos].getElementsByClassName("button btn_down");
		btndn[0].style.display = (pos==max) ? "none" : "inline";
		posinput = items[pos].getElementsByTagName("input");
		posinput[0].value = pos;
	}	
}
function moveItem(Id, dir) {
	var tr1   = document.getElementById("row"+Id);
	if (dir == -1) { tr1.parentNode.insertBefore(tr1, tr1.previousSibling); } else { tr1.parentNode.insertBefore(tr1.nextSibling, tr1); }
	updateArrowBtns();
	savePositions();
}
var serialize = function (form) {
	// Setup our serialized data
	var serialized = [];
	// Loop through each field in the form
	for (var i = 0; i < form.elements.length; i++) {
		var field = form.elements[i];
		// Don't serialize fields without a name, submits, buttons, file and reset inputs, and disabled fields
		if (!field.name || field.disabled || field.type === 'file' || field.type === 'reset' || field.type === 'submit' || field.type === 'button') continue;
		// If a multi-select, get all selections
		if (field.type === 'select-multiple') {
			for (var n = 0; n < field.options.length; n++) {
				if (!field.options[n].selected) continue;
				serialized.push(encodeURIComponent(field.name) + "=" + encodeURIComponent(field.options[n].value));
			}
		}
		// Convert field data to a query string
		else if ((field.type !== 'checkbox' && field.type !== 'radio') || field.checked) {
			serialized.push(encodeURIComponent(field.name) + "=" + encodeURIComponent(field.value));
		}
	}
	return serialized.join('&');
};
function savePositions() {
	var serializedForm = serialize(activityTime);
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
		}
	}
	xhttp.open("GET", "planning_course_go.php?action=updatePos&"+serializedForm, true);
	xhttp.send();
}
function updateHours() 
{
	var items = document.getElementById("activitiesCourse").getElementsByTagName("tr");
	var max = items.length-3;
	//Compute the number total of hours
	var totalHD = 0;
	var totalHI = 0;
	var maxHDWf = parseFloat(maxHDW.value);
	var maxHIWf = parseFloat(maxHIW.value);
	var weeks = 0;
	for(pos=1;pos<=max;pos++) {
		inputs = items[pos].getElementsByTagName("input");
		var HD = parseFloat(inputs[1].value);
		var HI = parseFloat(inputs[2].value);
		totalHD += HD;
		totalHI += HI;
		if ((HD!=0)&&(HI!=0)) {
			weeks = Math.round(10*(HD+HI)/(maxHDWf+maxHIWf))/10;
		} else {
			weeks = Math.round(10*((HD/maxHDWf)+(HI/maxHIWf)))/10;
		}
		items[pos].getElementsByTagName("td")[8].innerHTML = weeks;	
	}
	//Check if the total hours reaches the maximum available time
	var tds = items[max+2].getElementsByTagName("th");
	var maxHD = parseFloat(tds[1].innerHTML);
	var maxHI = parseFloat(tds[2].innerHTML);
	var tds = items[max+1].getElementsByTagName("th");
	tds[1].innerHTML = totalHD > maxHD ? "<font color=\"red\">"+totalHD+"</font>" : totalHD;
	tds[2].innerHTML = totalHI > maxHI ? "<font color=\"red\">"+totalHI+"</font>" : totalHI;
	setModifiedFlag();
}
function saveHours() {
	var serializedForm = serialize(activityTime);
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			clearModifiedFlag();
		}
	}
	xhttp.open("GET", "planning_course_go.php?action=updateHours&"+serializedForm, true);
	xhttp.send();
}
//Functions for the Gantt chart
var startWeek = -1;
var endWeek = -1;
var bGanttActive = false;
function ganttMouseDown(e,week,id) {
	if (!bGanttActive) {
		startWeek = week;
		endWeek = week;
		bGanttActive = true;
		for (var i=0; i<e.parentElement.children.length; i++) {
			e.parentElement.children[i].bgColor = "";
		}
	}
	e.bgColor="darkgoldenrod";
}
function ganttMouseUp(e,week,id) {
	if (bGanttActive) {
		e.bgColor="darkgoldenrod";
		endWeek = week;
		if (endWeek < startWeek) {
			tt = endWeek;
			endWeek = startWeek;
			startWeek = tt;
		}
		//Save Gantt-chart entry
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
			}
		};
		xhttp.open("GET", "planning_course_go.php?action=ganttUpdate&ActID="+id+"&StartWeek="+startWeek+"&EndWeek="+endWeek, true);
		xhttp.send();
	}
	bGanttActive = false;
}
function ganttMouseOver(e,week,id) {
	if (bGanttActive) {
		e.bgColor="darkgoldenrod";	
		if ( (week>startWeek)  && (endWeek>week) )  event.relatedTarget.bgColor="";
		if ( (week<startWeek)  && (endWeek<week) )  event.relatedTarget.bgColor="";
		if ( (week==startWeek) && (endWeek!=week) ) event.relatedTarget.bgColor="";
		endWeek = week;
	}	
}

//Functions for editing the evaluation strategies
//--------------------------------------------------------------
var bNewEval = true;
var bRubricsChanged = false;
function evalCancel() { //cancel
	if (bNewEval || (evalPanelStep3.style.display == "block")) {
		//close Panel and update evaluation table if any rubrics were changed.
		if (bRubricsChanged) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					EvaluationPanel.style.display = "none";
					document.getElementById("ev"+evalActID.value).innerHTML = this.responseText;
				}
			};
			xhttp.open("GET", "planning_course_evalgo.php?action=cancelEval&ActID="+evalActID.value+
				"&PlanID="+editPlanID+"&CourseID="+editCourseID+"&UserID="+editUserID+"&SemesterID="+editSemesterID, true);
			xhttp.send();
		} else {
			EvaluationPanel.style.display = "none";
		}
	} else {
		//cancel internal actions and return to the main activity editor
		evalPanelStep1.style.display = "none";
		evalPanelStep2.style.display = "none";
		evalPanelStep3.style.display = "block";
		evalPanelStep4.style.display = "none";
	}
}
function evalChangeVerb() { //change verb category
	var e = document.getElementById("evalCat");
	var VerbCat = e.options[e.selectedIndex].value;
	for(i=1; i<=5; i++) {
		document.getElementById("suggestEval"+i).style = (VerbCat == i) ? "display:block" : "display:none";
	}			
}
function evalSetStrategy() {
	//Insert evaluation strategy in the Textarea element
	var strategyName = document.querySelector('input[name="strategyVal"]:checked').value;
	if (strategyName=="other") strategyName = "";
	if (evalText.value.length==0) { 
		evalText.value = strategyName; 
	} else {
		evalText.value = evalText.value + "\n" + strategyName;
	}
	//Configure panel to display 
	if (bNewEval) {
		evalSuggRubsAssistant();
	} else { 
		evalMainAssistant();
	}
}
function evalLoadRubricTable(type)
{
	var filter = "";
	if (type=="SuggRubs") {
		filter = "&filter="+document.querySelector('input[name="filterRubs"]:checked').value;
	}
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("eval"+type).innerHTML  = this.responseText;
		}
	};	
	xhttp.open("GET", "planning_course_evalgo.php?action=get"+type+"&ActID="+evalActID.value+filter+
		"&CourseID="+editCourseID+"&UserID="+editUserID+"&SemesterID="+editSemesterID, true);
	xhttp.send();
}
function evalMainAssistant()
{
	evalLoadRubricTable("ActRubs");
	evalPanelStep1.style.display = "none";
	evalPanelStep2.style.display = "none";
	evalPanelStep3.style.display = "block";
	evalPanelStep4.style.display = "none";
	bNewEval = false;
}
function evalStrategyAssistant()
{
	evalPanelStep1.style.display = "block";
	evalPanelStep2.style.display = "none";
	evalPanelStep3.style.display = "none";
	evalPanelStep4.style.display = "none";
}
function evalSuggRubsAssistant() 
{
	evalLoadRubricTable("SuggRubs");
	evalPanelStep1.style.display = "none";
	evalPanelStep2.style.display = "block";
	evalPanelStep3.style.display = "none";
}
function evalGenRubsAssistant() 
{
	evalLoadRubricTable("GenRubs");
	evalPanelStep3.style.display = "none";
	evalPanelStep4.style.display = "block";
}
function evalAppendRubrics(type,includeAll) {
	//Serialize the rubric selection to modify the rubric association
	var chks = document.getElementById(type).getElementsByTagName("input");
	var qStr = "";
	for(i=0; i<chks.length; i++) 
	{	
		if (!includeAll && !chks[i].checked) continue;
		qStr += "&"+chks[i].id+"="+chks[i].checked;
	}
	//If no rubrics are available go to next panel
	if (qStr.length == 0) {
		evalMainAssistant();
		return;
	}
	//Perform rubric association
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			bRubricsChanged = true;
			evalMainAssistant();
		}
	};
	xhttp.open("GET", "planning_course_evalgo.php?action=appendRubrics&ActID="+evalActID.value+qStr+
		"&CourseID="+editCourseID+"&UserID="+editUserID+"&SemesterID="+editSemesterID, true);
	xhttp.send();
}
function evalViewRubric(RubricID) {
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			RubricViewer.innerHTML = this.responseText;
			RubricViewerPanel.style.display = "block";
		}
	};
	xhttp.open("GET", "rubrics_show.php?RubricID="+RubricID, true);
	xhttp.send();
}
function evalRemoveRubric(RubricID, Scope) {
	if (Scope==2) {
		var r = confirm("Advertencia: La rúbrica que intenta eliminar ha sido personalizada para la actividad.\n"+ 
				"Si la elimina y no ha sido asociada a otra actividad en el Paso 5, se perderá, y no se podrá recuperar.\n"+
				"¿Desea continuar?"); 
		if (r == false) 
			return;
	}
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			var rub = document.getElementById("rub"+RubricID);
			rub.parentNode.removeChild(rub);
			bRubricsChanged = true;
		}
	};
	xhttp.open("GET", "planning_course_evalgo.php?action=removeRubric&RubricID="+RubricID+"&ActID="+evalActID.value+
		"&CourseID="+editCourseID+"&UserID="+editUserID+"&SemesterID="+editSemesterID, true);
	xhttp.send();
}
function evalNewRubric() {
	evalSave();
	bRubricsChanged = true;
	window.open("rubrics_edit.php?PlanID="+editPlanID+"&CourseID="+editCourseID+"&ActID="+
		evalActID.value+"&backurl="+encodeURIComponent("planning_course_eval.php?ID="+editCourseID+"&SemesterID="+editSemesterID),"_self");
}
function evalSave() {
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			EvaluationPanel.style.display = "none";
			document.getElementById("ev"+evalActID.value).innerHTML = this.responseText;
		}
	};
	xhttp.open("GET", "planning_course_evalgo.php?action=saveEval&ActID="+evalActID.value+"&Text="+evalText.value.replace(/\n/g,"<br>")+
		"&PlanID="+editPlanID+"&CourseID="+editCourseID+"&UserID="+editUserID+"&SemesterID="+editSemesterID, true);
	xhttp.send();
}
function editEval(ActID, PlanID, CourseID, UserID, SemesterID) 
{
	editPlanID = PlanID;
	editCourseID = CourseID;
	editUserID = UserID;
	editSemesterID = SemesterID;
	//Get the topics and skill information
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			var obj = JSON.parse(this.responseText);
			//Set values in the Evaluation Panel
			evalActID.value 	   = ActID;
			evalText.value     	   = obj.Desc.replace(/<br>/g,'\n');
			evalRapText.innerText  = obj.RapText;
			//Display the suggested evaluation strategies according to ILO verb
			var op = document.getElementById("evalCat").options;
			for(pos=0;pos<op.length;pos++) {
				if (op[pos].value == obj.RapCat) {
					document.getElementById("evalCat").selectedIndex = pos;
					break;
				}
			}
			for(i=1; i<=5; i++) {
				document.getElementById("suggestEval"+i).style = (obj.RapCat == i) ? "display:block" : "display:none";
			}
			//Configure view in the Evaluation Panel
			bNewEval = ((obj.Desc.length==0)&&(obj.TbAct.length==0));
			if (bNewEval) {
				evalStrategyAssistant();
			} else {
				evalMainAssistant();
			}
			EvaluationPanel.style.display = "block";
		}
	};
	xhttp.open("GET", "planning_course_evalgo.php?action=getEvalInfo&ActID="+ActID+
		"&CourseID="+CourseID+"&UserID="+UserID+"&SemesterID="+SemesterID, true);
	xhttp.send();
}

//Functions for configuring rubrics
//--------------------------------------------------------------

function editRubric(RubricID, Scope, PlanID, CourseID, UserID, SemesterID, ActID) {
	var scopeStr = "";
	if (Scope == 0) scopeStr = "general";
	if (Scope == 1) scopeStr = "del sílabo";
	if (Scope != 2) {
		var r = confirm("Advertencia: La rúbrica seleccionada es una rúbrica "+scopeStr+" del programa académico y solo puede ser editada por el coordinador.\n"+
			"Si usted insiste en continuar, se creará un duplicado de la rúbrica que puede ser modificado solamente para este curso, "+
			"por lo que futuros cambios que haga el coordinador a la rúbrica "+scopeStr+" no podrán ser reflejados en este curso.\n"+
			"¿Desea continuar?"); 
		if (r == true) 
		{				
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					window.open("rubrics_edit.php?RubricID="+this.responseText+"&CourseID="+CourseID+"&ActID="+ActID+
					"&backurl="+encodeURIComponent("planning_course_rubrics.php?ID="+CourseID+"&SemesterID="+SemesterID),"_self");
				}
			}
			xhttp.open("GET", "rubrics_duplicate.php?RubricID="+RubricID+"&PlanID="+PlanID+
						"&CourseID="+CourseID+"&UserID="+UserID+"&SemesterID="+SemesterID+
						"&ActID="+ActID+"&DuplicateGeneric=true", true);
			xhttp.send();		
		}
	} else {
		window.open("rubrics_edit.php?RubricID="+RubricID+"&CourseID="+CourseID+"&ActID="+ActID+
			"&backurl="+encodeURIComponent("planning_course_rubrics.php?ID="+CourseID+"&SemesterID="+SemesterID),"_self");
	}	
}
function removeRubric(RubricID, Scope, PlanID, CourseID, UserID, SemesterID) {
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			var item = document.getElementById("rub"+RubricID);
			item.parentNode.removeChild(item);	
		}
	}	
	if (Scope != 2) {
		var r = confirm("Esta rúbrica será eliminada de todas las actividades a las que está asociada. "+
			"Al ser una rúbrica genérica puede ser vinculada de nuevo en el Paso 4 (Evaluación).\n"+
			"¿Está seguro que desea eliminar esta rúbrica genérica?");
		if (r == true) {
			xhttp.open("GET", "rubrics_removegeneric.php?RubricID="+RubricID+"&CourseID="+CourseID+
						"&UserID="+UserID+"&SemesterID="+SemesterID, true);
			xhttp.send();
		}		
	} else {
		var r = confirm("Esta acción eliminará la rúbrica definitivamente. No se puede deshacer.\n"+
					"¿Desea continuar?"); 
		if (r == true) {
			xhttp.open("GET", "rubrics_remove.php?RubricID="+RubricID, true);
			xhttp.send();
		}
	}
}
function duplicateRubric(RubricID, PlanID, CourseID, UserID, SemesterID, ActID) {
	var r = confirm("¿Está seguro que desea crear un duplicado de esta rúbrica?"); 
	if (r == true) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				var div = document.createElement("DIV");
				div.innerHTML = this.responseText;
				var item = document.getElementById("rub"+RubricID);
				item.parentNode.insertBefore(div.childNodes[0], item.nextSibling);	
			}
		}
		xhttp.open("GET", "rubrics_duplicate.php?RubricID="+RubricID+"&PlanID="+PlanID+
			"&CourseID="+CourseID+"&UserID="+UserID+"&SemesterID="+SemesterID+"&ActID="+ActID, true);
		xhttp.send();
	}
}
function associateRubric(RubricID, PlanID, CourseID, UserID, SemesterID) {
	editPlanID = PlanID;
	editCourseID = CourseID;
	editUserID = UserID;
	editSemesterID = SemesterID;
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			assocActList.innerHTML = this.responseText;
			RubricIDToAssoc.value = RubricID; 
			associationPanel.style.display = "block";
		}
	}	
	xhttp.open("GET", "rubrics_show_assoc.php?RubricID="+RubricID+"&CourseID="+CourseID+
				"&UserID="+UserID+"&SemesterID="+SemesterID, true);
	xhttp.send();
}
function assocRubCancel() {
	associationPanel.style.display = "none";
	RubricIDToAssoc.value = 0;
}
function assocRubGo(includeAll) {
	//Serialize the rubric selection to modify the rubric association
	var chks = assocActList.getElementsByTagName("input");
	var qStr = "";
	for(i=0; i<chks.length; i++) 
	{	
		if (!includeAll && !chks[i].checked) continue;
		qStr += "&"+chks[i].id+"="+chks[i].checked;
	}
	if (qStr.length == 0) {
		return;
	}
	//Perform rubric association
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			var div = document.createElement("DIV");
			div.innerHTML = this.responseText;
			document.getElementById("rub"+RubricIDToAssoc.value).innerHTML = div.childNodes[0].innerHTML;
			associationPanel.style.display = "none";
		}
	};
	xhttp.open("GET", "rubrics_assoc.php?RubricID="+RubricIDToAssoc.value+
				"&PlanID="+editPlanID+"&CourseID="+editCourseID+"&SemesterID="+editSemesterID+"&UserID="+editUserID+qStr, true);
	xhttp.send();
}
function exportRubrics(tableName) {
	tableToExcel(tableName,'Rubrics');
}
function exportPlanningSummary(exportCourseID,exportUserID,exportSemesterID) {
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			planningExportInfo.innerHTML = this.responseText;
			tableToExcel('planningExportInfo','Actividades');
		}
	};
	xhttp.open("GET", "planning_course_go.php?action=loadCourse&CourseID="+exportCourseID+"&SemesterID="+exportSemesterID+"&UserID="+exportUserID+"&showTooltip=false", true);
	xhttp.send();
}
var tableToExcel = (function() {
	var uri = 'data:application/vnd.ms-excel;base64,'
		, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
		, base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
		, format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
	return function(table, name) {
		if (!table.nodeType) table = document.getElementById(table)
		var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
		window.location.href = uri + base64(format(template, ctx))
	}
})()
