<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$planea->showGenericRubricListForCourse($_GET["PlanID"], $_GET["CourseID"]);
$planea->closeConnection();
?>