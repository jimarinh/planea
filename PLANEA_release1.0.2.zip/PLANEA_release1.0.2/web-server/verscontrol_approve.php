<?php
require('planea_basics.php');  
$planea = new planea();
$conn = $planea->openConnection();	
$CourseID =  $_GET["ID"];
$sql = "SELECT EstadoVersion,Version,Nombre FROM courses_general WHERE ID=" . $CourseID; 
$result = $conn->query($sql); 
$row = $result->fetch_assoc();
if ($row["EstadoVersion"]==planea::syllStateOpened) { 
	$sql = "UPDATE courses_general SET EstadoVersion=".planea::syllStateDisabled.",VisVersion=0 WHERE CourseKeyID=".$_GET["CourseKeyID"];
	$result = $conn->query($sql); 
	$sql = "UPDATE courses_general SET EstadoVersion=".planea::syllStateApproved.",VisVersion=1,FechaVersion='".$_GET["versionDate"].
			"',VersionAnotacion='".$_GET["versionAnotacion"]."',VersionResponsable='".$_GET["versionResponsable"]."' WHERE ID=".$CourseID;
	$result = $conn->query($sql); 
	//Remove assignment as collaborator
	$sql = "DELETE FROM users_assignments WHERE courseID=".$CourseID." AND roleType=2";
	$result = $conn->query($sql); 
	//Update assignment as teacher
	$sql = "UPDATE users_assignments SET courseID=".$CourseID." WHERE courseID IN 
			(SELECT ID FROM courses_general WHERE CourseKeyID=".$_GET["CourseKeyID"]." AND VisVersion=0)";
	$result = $conn->query($sql); 
	echo "La versión ".$row["Version"]." del curso ".$row["Nombre"]." ha sido aprobada exitosamente";
}
$planea->closeConnection();
?>