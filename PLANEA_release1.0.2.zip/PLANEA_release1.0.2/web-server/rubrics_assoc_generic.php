<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
//Insert new association of a generic rubric for the given course.
$sql = "INSERT INTO rubrics_assoc(RubricID, PlanID, CourseID, RapSkillID, RapSkillType) 
	VALUES (".$_GET["RubricID"].",".$_GET["PlanID"].",".$_GET["CourseID"].",0,0)";
$result = $planea->conn->query($sql);
$planea->showRubricsByCourseItem( $_GET["RubricID"], $_GET["PlanID"], $_GET["CourseID"] );
$planea->closeConnection();
?>