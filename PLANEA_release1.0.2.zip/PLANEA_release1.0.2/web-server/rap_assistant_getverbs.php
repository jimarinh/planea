<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
if (isset($_GET["level"])) {
	$level_filt = "";
	for ($i = 1; $i<=6; $i++) {
		if ($_GET["level"] & (1<<($i-1))) {
			if (strlen($level_filt)>0) $level_filt .= ",".$i; 
			else $level_filt .= $i;
		}
	}
	if (strlen($level_filt)==0) {
		return;
	}
	if ($_GET["taxonomy"]=="SOLO") {		
		$sql = "SELECT * FROM verb_list WHERE SOLOLevel IN (".$level_filt.") AND SOLOCat='". $_GET["category"]."' ORDER BY SOLOLevel";
	} else {
		$sql = "SELECT * FROM verb_list WHERE BloomLevel IN (".$level_filt.") ORDER BY BloomLevel";
	}
	$result = $planea->conn->query($sql);
	if ($result->num_rows > 0)  {      	
		$prev_level = 0;
		while($row = $result->fetch_assoc()) {	
			if ($_GET["taxonomy"]=="SOLO") {
				$level = $row["SOLOLevel"];
				switch($level) {
					case 1: $level_name = "Uniestructural"; break;
					case 2: $level_name = "Multiestructural"; break;
					case 3: $level_name = "Relacional"; break;
					case 4: $level_name = "Abstracto Extendido"; break;
				}
				$cat   = " [".$row["SOLOCat"]."]";
			} else {
				$level = $row["BloomLevel"];
				switch($level) {
					case 1: $level_name = "Recordar"; break;
					case 2: $level_name = "Comprender"; break;
					case 3: $level_name = "Aplicar"; break;
					case 4: $level_name = "Analizar"; break;
					case 5: $level_name = "Evaluar"; break;
					case 6: $level_name = "Crear"; break;
				}
				$cat   = "";
			}
			if ($level != $prev_level ) {
				echo "<br><b>".$level_name."</b><br>";
				$prev_level = $level;
			}
			echo "<input type=\"radio\" name=\"rapVerb\" value=\"".$row["VerbName"]."\">".$row["VerbName"].$cat."<br>\n";
		}           
	}
}
$planea->closeConnection();
?>
