<?php
	require('planea_basics.php');  
	$planea = new planea();
	$conn = $planea->openConnection();
	$sql = "DELETE FROM courses_electivecats WHERE ID=" . $_GET["CatID"]; $planea->conn->query($sql);
	$sql = "DELETE FROM courses_elective WHERE CategoryID=" . $_GET["CatID"]; $planea->conn->query($sql);
	$planea->showElectiveCategories($_GET["plan"]);
	$planea->closeConnection();
?>