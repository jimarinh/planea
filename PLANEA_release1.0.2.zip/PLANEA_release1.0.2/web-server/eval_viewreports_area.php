<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="ùtf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<style>
	textarea  
	{  
		font-family:"Helvetica", Helvetica, sansserif;  
		font-size: 16px;
		color: darkblue;
	}
	</style>
	<script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</head>

<?php  
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection(); 

	require('planea_logosbar.php');
	$subMenuName = "Reporte por área/núcleo temático";
	
	if ($_SESSION["RoleID"]==planea::roleCoord) 
		$helptopic = "coord-eval-area";
	else
		$helptopic = "teacher-eval-area"; 
	
	require('planea_evalcoordbar.php');
	if ( !isset($PlanID) || !isset($SemesterID) ) exit(0);

	$AutoSave = false;
	//Fetch user ID
	if (isset($_GET["UserID"])) {
		$UserID = $_GET["UserID"];
	} else if (isset($_POST["UserID"])) {
		$UserID = $_POST["UserID"];
	} else {
		$UserID = $_SESSION["UserID"];
	}
	//Configure Area Selector and Behaviour
	if (isset($_GET["AreaID"])) {	
		$AreaID = $_GET["AreaID"];
		$sql = "SELECT UserID FROM eval_areas WHERE PlanID=" . $PlanID." AND Semester='".$semesterName."' AND AreaName='". $AreaID."' AND UserID=".$UserID." AND State=0";
		$result = $planea->conn->query($sql);
		if ($result->num_rows > 0) {	//If area is set and area report is being editing by collaborator, enable editing mode and autosave
			$bReadOnly = false;
			$AutoSave = true;
		} else {
			$bReadOnly = true;			//If area is set and area report is already submitted by collaborator, disable editing
		}
		$bFixedArea = true; 
	} else {
		if ($_SESSION["RoleID"]==planea::roleCoord) { 	//If no area is set and user role is coordinator, enable editing, area selector, but no autosaving
			$bReadOnly = false;
			$bFixedArea = false;				
		} else {		//If no area is set, I may be set by POST method (for saving form) 
			$bReadOnly = true;
			$bFixedArea = true;			
		}
	}
	if (isset($_POST["AreaID"])) {		//If area is set by 
		$AreaID = $_POST["AreaID"];
		$bReadOnly = false;
		$bFixedArea = true;
	}
	//Saving form...
	if (isset($_POST["BtnAction"])) {
		if ($_POST["BtnAction"]=="Guardar") {	//Save & Continue
			$bState = 0;
		}
		if ($_POST["BtnAction"]=="Devolver al Colaborador") {	//Return to collaborator
			$bState = 0;
		}
		if ($_POST["BtnAction"]=="Guardar & Enviar") {	//Save and Submit
			$bState = 1;
			if ($_SESSION["RoleID"]!=planea::roleCoord) {	//If user is a collaborator, the form can't longer be edited after submission.
				$bReadOnly = true;
				$bFixedArea = true;
			}
		}
		$planea->saveEvalReportByArea($PlanID, $AreaID, $semesterName, $UserID, $bState);
	}
	
	if ( $bReadOnly && $bFixedArea && !isset($AreaID) ) {
		exit("<p><font color=\"red\">No tiene permiso para acceder a esta sección</font><p>");
	}
?>

	<script>
		function loadReportAreaAttr(PlanID, SemName, AreaName, Attr, n) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("T"+n).innerHTML = this.responseText;
					if ((this.responseText.length==0)&&(n!=7)) {
						document.getElementById("cT"+n).style= "display:none";
					} else {
						document.getElementById("cT"+n).style= "display:inline";
					}
				}
			};
			xhttp.open("GET", "eval_viewreports_area_table.php?PlanID="+PlanID+"&SemName="+encodeURIComponent(SemName)+"&Area="+encodeURIComponent(AreaName)+"&Attr="+Attr, true);
			xhttp.send();	
		}
		function loadReportArea(PlanID, SemName, AreaName) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var obj = JSON.parse(this.responseText);
					document.getElementById("TT1").innerHTML = obj.UnknownPrevSkills;
					document.getElementById("TT2").innerHTML = obj.UncoveredTopics;
					document.getElementById("TT3").innerHTML = obj.IrrelevantTopics;
					document.getElementById("TT4").innerHTML = obj.StudentProblems;
					document.getElementById("TT5").innerHTML = obj.SuccessfulExp;
					document.getElementById("TT6").innerHTML = obj.UnsuccessfulExp;
					document.getElementById("TT7").innerHTML = obj.ImprovMeasures;
					document.getElementById("ReportID").value = obj.ID;
				}
			};
			var url = "eval_viewreports_area_load.php?PlanID="+PlanID+"&SemName="+encodeURIComponent(SemName)+"&Area="+encodeURIComponent(AreaName);	
			xhttp.open("GET", url, true);
			xhttp.send();	
		}	
		function changeArea(PlanID, SemName) {
			var e = document.getElementById("AreaSelector");
			if (e.selectedIndex == -1) { return; }
			var AreaName = e.options[e.selectedIndex].text;
			setArea(PlanID, SemName, AreaName);
		}
		function setArea(PlanID, SemName, AreaName) {
			var xhttp = new XMLHttpRequest();
			loadReportAreaAttr(PlanID, SemName, AreaName, "UnknownPrevSkills", 1);
			loadReportAreaAttr(PlanID, SemName, AreaName, "UncoveredTopics", 2);
			loadReportAreaAttr(PlanID, SemName, AreaName, "IrrelevantTopics", 3);
			loadReportAreaAttr(PlanID, SemName, AreaName, "StudentProblems", 4);
			loadReportAreaAttr(PlanID, SemName, AreaName, "SuccessfulExp", 5);
			loadReportAreaAttr(PlanID, SemName, AreaName, "UnsuccessfulExp", 6);
			loadReportAreaAttr(PlanID, SemName, AreaName, "ImprovMeasures", 7);
			loadReportArea(PlanID, SemName, AreaName);
			document.getElementById("AreaID").value = AreaName;
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					if (this.responseText.length==0) {
						document.getElementById("reportForm").style = "display:none";
						document.getElementById("noReportForm").style = "display:block";
						return;
					}
					document.getElementById("reportForm").style = "display:block";
					document.getElementById("noReportForm").style = "display:none";
					var obj = JSON.parse(this.responseText);
					var chart = new CanvasJS.Chart("chartContainer",
					{
					  title:{
						text: "Desempeño de los estudiantes en "+AreaName
					  },
					  data:[
					  {
						type: "stackedBar100",
						dataPoints: obj.ds2
					  },
					   {
						type: "stackedBar100",
						dataPoints: obj.ds1
					  }
					  ]
					});
					chart.render();					
				}
			};
			xhttp.open("GET", "eval_viewreports_area_tablep.php?PlanID="+PlanID+"&SemName="+encodeURIComponent(SemName)+"&Area="+encodeURIComponent(AreaName), true);
			xhttp.send();	
		}
		function changeAreaList(PlanID, SemName, filterArea)
		{
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("AreaSelector").innerHTML = this.responseText;
				}
			};
			xhttp.open("GET", "eval_viewreports_arealist.php?PlanID="+PlanID+"&SemName="+encodeURIComponent(SemName)+"&filter="+filterArea, true);
			xhttp.send();
		}
			
		function autoSave() {
			var xhttp = new XMLHttpRequest();
			var formData = new FormData();
			serializeForPOST(reportForm, formData);
			xhttp.open("POST", "eval_area_save.php", true);
			xhttp.send(formData);
		}
	</script>
	<script>
		function setModifiedFlag() { window.onbeforeunload = function() { return true; }; }
		function clearModifiedFlag() { window.onbeforeunload = null; return true; }
		var serializeForPOST = function (form, formData) {
			// Loop through each field in the form
			for (var i = 0; i < form.elements.length; i++) {
				var field = form.elements[i];
				// Don't serialize fields without a name, submits, buttons, file and reset inputs, and disabled fields
				if (!field.name || field.disabled || field.type === 'file' || field.type === 'reset' || field.type === 'submit' || field.type === 'button') continue;
				// If a multi-select, get all selections
				if (field.type === 'select-multiple') {
					for (var n = 0; n < field.options.length; n++) {
						if (!field.options[n].selected) continue;
						formData.append(field.name, field.options[n].value);
					}
				}
				// Convert field data to a query string
				else if ((field.type !== 'checkbox' && field.type !== 'radio') || field.checked) {
					formData.append(field.name, field.value);
				}
			}
		};
	</script>		
	<script>	
		function exportReports(PlanID,SemName) {
			var xhttp = new XMLHttpRequest();
			<?php 
				if ( $bFixedArea && isset($AreaID) ) {
					echo "var AreaName = '".$AreaID."';\n";
				} else {
					echo "var e = document.getElementById(\"AreaSelector\");\n";
					echo "if (e.selectedIndex == -1) { return; }\n";
					echo "var AreaName = e.options[e.selectedIndex].text;\n";
				}
			?>
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					tableToExcel(this.responseText,'reports');
				}
			}
			xhttp.open("GET", "eval_viewreports_exportall.php?PlanID="+PlanID+"&SemName="+encodeURIComponent(SemName)+"&Area="+encodeURIComponent(AreaName), true);
			xhttp.send();	
		}
		var tableToExcel = (function() {
			var uri = 'data:application/vnd.ms-excel;base64,'
				, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
				, base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
				, format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
			return function(tableHTML, name) {
				var ctx = {worksheet: name || 'Worksheet', table: tableHTML}
				window.location.href = uri + base64(format(template, ctx))
			}
		})()
		
		window.onload=function(){
			<?php 
				if ($bFixedArea) { 
					echo "setArea(".$PlanID.",'".$semesterName."','".$AreaID."');\n"; 
				} 
				if ($AutoSave) {
					echo "setInterval(\"autoSave()\", 60000);";
				}
			?>	
		}
	</script>


<body>
<h3>Programa: <i><?php echo $planName; ?></i> &nbsp; Semestre: <i><?php echo $semesterName;?></i> </h3>

<div class="planeaForm">

Área/Núcleo Temático:
<?php
	if (!$bFixedArea) { 
		echo "&nbsp;&nbsp;&nbsp;Filtrar reportes por: ";
		$filterArea = 0;
		$chkDisp0 = "";
		$chkDisp1 = "";
		$chkDisp2 = "";
		$chkDisp3 = "";
		if (isset($_GET["disp"])) {
			if ($_GET["disp"] == "All")  { $chkDisp0 = "checked"; }
			if ($_GET["disp"] == "Done") { $chkDisp1 = "checked"; $filterArea = 1; }
			if ($_GET["disp"] == "Pend") { $chkDisp2 = "checked"; $filterArea = 2; }
		} else {
			$chkDisp0 = "checked";
		}
		echo "<input type=\"radio\" name=\"dispMode\" value=\"0\" ".$chkDisp0." onchange=\"changeAreaList(".$PlanID.",'".$semesterName."',0)\">Todas las áreas";
		echo "<input type=\"radio\" name=\"dispMode\" value=\"1\" ".$chkDisp1." onchange=\"changeAreaList(".$PlanID.",'".$semesterName."',1)\">Completos";
		echo "<input type=\"radio\" name=\"dispMode\" value=\"2\" ".$chkDisp2." onchange=\"changeAreaList(".$PlanID.",'".$semesterName."',2)\">Incompletos";
		echo "<input type=\"radio\" name=\"dispMode\" value=\"3\" ".$chkDisp3." onchange=\"changeAreaList(".$PlanID.",'".$semesterName."',3)\">Sin colaborador";
		echo "<br><br>";
	}
?> 
<?php
	if ($bFixedArea) { 
		echo "<b>".$AreaID."</b>"; 
	} else {
		echo "<select id=\"AreaSelector\" onchange=\"changeArea(".$PlanID.",'".$semesterName."')\">";
		echo "<option value=\"\">Seleccione un área...</option>";
		$planea->showAreasListByFilter( $filterArea, $PlanID, $semesterName );
		echo "</select>";
	}
?>
&nbsp;
<button type="button" onClick="exportReports(<?php echo $PlanID.",'".$semesterName."'";?>)">Exportar Reporte del Área a Excel</button> 
</div>

<form class="planeaForm" id="reportForm" style="display:none" action="eval_viewreports_area.php" method="POST" onsubmit="return clearModifiedFlag();">
<h3>Reporte por áreas</h3>
<div id="chartContainer" style="height: 300px; width: 100%;"></div> 
<br> <br>
<div id="cT1">
<b>Deficiencias de los estudiantes en conocimientos o habilidades previas</b>  
<table id="T1"></table> <br> 
<i>Resumen:</i> <br>
<textarea id="TT1" name="TT1" rows=4 style="width: 100%;" onchange="setModifiedFlag()" <?php if ($bReadOnly) { echo "readonly"; }?>></textarea> <br> <br>
</div>
<div id="cT2">
<b>Temas o unidades de aprendizaje no cubiertos en el desarrollo del semestre</b> 
<table id="T2"></table> <br>
<i>Resumen:</i> <br>
<textarea id="TT2" name="TT2" rows=4 style="width: 100%;" onchange="setModifiedFlag()" <?php if ($bReadOnly) { echo "readonly"; }?>></textarea> <br> <br>
</div>
<div id="cT3">
<b>Temas o unidades de aprendizaje irrelevantes y se podrían suprimir del sílabo</b> 
<table id="T3"></table> <br>
<i>Resumen:</i> <br>
<textarea id="TT3" name="TT3" rows=4 style="width: 100%;" onchange="setModifiedFlag()" <?php if ($bReadOnly) { echo "readonly"; }?>></textarea> <br> <br> 
</div>
<div id="cT4">
<b>Problemas de los estudiantes para el desarrollo del curso</b>
<table id="T4"></table> <br>
<i>Resumen:</i> <br>
<textarea id="TT4" name="TT4" rows=4 style="width: 100%;" onchange="setModifiedFlag()" <?php if ($bReadOnly) { echo "readonly"; }?>></textarea> <br> <br>
</div>
<div id="cT5">
<b>Experiencias <u>exitosas</u> en el desarrollo del curso</b> 
<table id="T5"></table> <br>
<i>Resumen:</i> <br>
<textarea id="TT5" name="TT5" rows=4 style="width: 100%;" onchange="setModifiedFlag()" <?php if ($bReadOnly) { echo "readonly"; }?>></textarea> <br> <br>
</div>
<div id="cT6">
<b>Experiencias <u>no exitosas</u> en el desarrollo del curso</b>
<table id="T6"></table> <br>
<i>Resumen:</i> <br>
<textarea id="TT6" name="TT6" rows=4 style="width: 100%;" onchange="setModifiedFlag()" <?php if ($bReadOnly) { echo "readonly"; }?>></textarea> <br> <br>
</div>
<div id="cT7">
<b >Acciones de mejora para el próximo semestre o cambio en el sílabo</b>
<table id="T7"></table> <br>
<i>Resumen:</i> <br>
<textarea id="TT7" name="TT7" rows=4 style="width: 100%;" onchange="setModifiedFlag()" <?php if ($bReadOnly) { echo "readonly"; }?>></textarea> <br> <br>
</div>
<?php if ( (!$bReadOnly) && ($_SESSION["RoleID"]!=planea::roleCoord) ) { echo "<input type=\"submit\" name=\"BtnAction\" value=\"Guardar\">"; }?>
&nbsp;&nbsp;&nbsp;
<?php if (!$bReadOnly) { echo "<input type=\"submit\" name=\"BtnAction\" value=\"Guardar & Enviar\">"; }?>
&nbsp;&nbsp;&nbsp;
<?php if ( (!$bReadOnly) && ($_SESSION["RoleID"]==planea::roleCoord) ) { echo "<input type=\"submit\" name=\"BtnAction\" value=\"Devolver al Colaborador\">"; }?>


<input style="display:none" type="number" name="PlanID" value="<?php echo $PlanID; ?>">
<input style="display:none" type="number" name="SemesterID" value="<?php echo $SemesterID; ?>">
<input style="display:none" type="text" id="AreaID" name="AreaID" value="<?php if (isset($AreaID)) echo $AreaID; ?>">
<input style="display:none" type="number" name="UserID" value="<?php echo $UserID; ?>">
<input style="display:none" type="number" id="ReportID" name="ReportID" value="0">

</form>

<div class="planeaForm" id="noReportForm" style="display:none">
<h3>No existe reporte del área para el semestre seleccionado.</h3>
</div>

<?php $planea->closeConnection(); ?>

</body>
</html>
