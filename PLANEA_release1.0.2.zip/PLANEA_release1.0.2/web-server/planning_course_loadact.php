<?php 
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();

$CourseID = $_GET["CourseID"];
$UserID = $_GET["UserID"];
$Semester = $_GET["SemesterID"];

//Gather information for RAP boxes
$sql = "SELECT courses_ilos.ID,Text,Position,verb_list.StigginsCat FROM courses_ilos 
	JOIN verb_list ON verb_list.ID=courses_ilos.VerbID
	WHERE CourseID=".$CourseID." ORDER BY Position";
$result = $planea->conn->query($sql);
$raps = array();
$nraps = 0;
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		//Fetch HowTo associated to the given RAP
		$sql = "SELECT HowTo FROM teacher_howtos WHERE RapID=".$row["ID"]." AND CourseID=".$CourseID." AND UserID=".$UserID." AND Semester='".$Semester."'";
		$result_t = $planea->conn->query($sql);
		if ($result_t->num_rows>0) {
			$row_t = $result_t->fetch_assoc();
			$howto = $row_t["HowTo"];
		} else {
			$howto = "";
		}
		//Build box information
		$rap = ["ID" => intval($row["ID"]), "Pos" => intval($row["Position"]), "Text" => $row["Text"], 
				"VerbCat" => $row["StigginsCat"], "HowTo" => $howto];
		$raps[$nraps] = $rap; 
		$nraps++;
	}
}

//Gather information for activity boxes
$sql = "SELECT * FROM teacher_activities WHERE CourseID=".$CourseID." AND UserID=".$UserID." AND Semester='".$Semester."' ORDER BY Position";
$result = $planea->conn->query($sql);
$acts = array();
$nacts = 0;
if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		//Fetch content information 
		$sql = "SELECT TopicNumber,TopicName FROM courses_contents WHERE ID=".$row["TopicID"];
		$result_t = $planea->conn->query($sql);
		if ($result_t->num_rows>0) {
			$row_t = $result_t->fetch_assoc();
			$topicText = $row_t["TopicNumber"].". ".$row_t["TopicName"];
		} else {
			$topicText = "";
		}
		//Fetch skills information
		$retP = $planea->showPlanningCourseRapOrSkill( 1, $row["ID"], 2, "<br>");
		$retI = $planea->showPlanningCourseRapOrSkill( 2, $row["ID"], 2, "<br>");
		$retC = $planea->showPlanningCourseRapOrSkill( 3, $row["ID"], 2, "<br>");
		$br1 = ((strlen($retP)>0)&&(strlen($retI)>0)) ? "<br>" : "";
		$br2 = ((strlen($retI)>0)&&(strlen($retC)>0)) ? "<br>" : "";
		$br1 = ((strlen($retI)==0)&&(strlen($retP)>0)&&(strlen($retC)>0)) ? "<br>" : $br1;
		
		$skillSet = $retP.$br1.$retI.$br2.$retC;
		//Fetch information about associated ILOs
		$sql = "SELECT * FROM teacher_actassoc WHERE ActID=".$row["ID"]." AND RapSkillType=0";
		$result_t = $planea->conn->query($sql);
		$assocRaps = array();
		if ($result_t->num_rows>0) {
			while($row_t = $result_t->fetch_assoc()) {
				array_push($assocRaps, $row_t["RapSkillID"]);
			}
		}
		//Collect information
		$act = ["ID" => intval($row["ID"]), "Pos" => intval($row["Position"]), "Name" => $row["Name"],
					"Desc" => $row["Description"], "HD" => $row["HD"], "HI" => $row["HI"], 
					"TopicText" => $topicText, "TopicID" => $row["TopicID"], "SkillSet" => $skillSet, "AssocRaps" => $assocRaps ];
		$acts[$nacts] = $act; 
		$nacts++;
	}
}	
	  
header('Content-type: application/json');
$json_data = array();
$json_data["Raps"] = $raps;
$json_data["Acts"] = $acts;
echo json_encode($json_data);
$planea->closeConnection();
?>