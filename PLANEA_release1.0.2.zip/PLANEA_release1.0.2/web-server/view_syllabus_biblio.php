<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script>
		function changebiblioCategory() {
			document.getElementById("book").style.display = "none";
			document.getElementById("incollection").style.display = "none";
			document.getElementById("techreport").style.display = "none";
			document.getElementById("article").style.display = "none";
			document.getElementById("inproceedings").style.display = "none";
			document.getElementById("web").style.display = "none";
			document.getElementById("misc").style.display = "none";
			var e = document.getElementById("biblioCat");
			if (e.selectedIndex == -1) {
				return null;
			}
			var biblioCat = e.options[e.selectedIndex].value;
			document.getElementById(biblioCat).style.display = "inline";
		}
		function createBiblioEntry() {	
			var e = document.getElementById("biblioCat");
			if (e.selectedIndex == -1) {
				return null;
			}
			var author = document.getElementById("author").value;
			var title = document.getElementById("title").value;
			var year = document.getElementById("year").value;
			var url = document.getElementById("url").value;
			var doi = document.getElementById("doi").value;
			var biblioCat = e.options[e.selectedIndex].value;
			var str = "@"+biblioCat+"{\n"+"\tauthor={"+author+"},\n\ttitle={"+title+"},\n\tyear={"+year+"},\n";
			if (url.length!=0) str = str + "\turl={"+url+"},\n";
			if (doi.length!=0) str = str + "\tdoi={"+doi+"},\n";
			var it;
			it = document.getElementById("publisher-"+biblioCat); if (it && (it.value.length>0)) {str += "\tpublisher={"+it.value+"},\n";}
			it = document.getElementById("volume-"+biblioCat); if (it && (it.value.length>0)) {str += "\tvolume={"+it.value+"},\n";}
			it = document.getElementById("edition-"+biblioCat); if (it && (it.value.length>0)) {str += "\tedition={"+it.value+"},\n";}
			it = document.getElementById("booktitle-"+biblioCat); if (it && (it.value.length>0)) {str += "\tbooktitle={"+it.value+"},\n";}
			it = document.getElementById("chapter-"+biblioCat); if (it && (it.value.length>0)) {str += "\tchapter={"+it.value+"},\n";}
			it = document.getElementById("institution-"+biblioCat); if (it && (it.value.length>0)) {str += "\tinstitution={"+it.value+"},\n";}
			it = document.getElementById("journal-"+biblioCat); if (it && (it.value.length>0)) {str += "\tjournal={"+it.value+"},\n";}
			it = document.getElementById("number-"+biblioCat); if (it && (it.value.length>0)) {str += "\tnumber={"+it.value+"},\n";}
			it = document.getElementById("pages-"+biblioCat); 	if (it && (it.value.length>0)) {str += "\tpages={"+it.value+"},\n";}
			it = document.getElementById("urldate-"+biblioCat); 	if (it && (it.value.length>0)) {str += "\turldate={"+it.value+"},\n";}
			it = document.getElementById("howpublished-"+biblioCat); 	if (it && (it.value.length>0)) {str += "\thowpublished={"+it.value+"},\n";}
			it = document.getElementById("note-"+biblioCat); 	if (it && (it.value.length>0)) {str += "\tnote={"+it.value+"},\n";}
			it = document.getElementById("series-"+biblioCat); 	if (it && (it.value.length>0)) {str += "\tseries={"+it.value+"},\n";}
			it = document.getElementById("address-"+biblioCat); 	if (it && (it.value.length>0)) {str += "\taddress={"+it.value+"},\n";}		
			str += "}\n\n";
			return str;
		}
		var autoEntryIdx = 0;
		function appendButtonsAndInfo(obj, strBibText) {
			var btn0 = "<button class=\"button btn_edit\" type=\"button\" id=\"BtnItem"+autoEntryIdx+"\" onclick=\"editBiblioItem("+autoEntryIdx+")\"></button>"; 
			var btn1 = "<button class=\"button btn_up\" type=\"button\" style=\"display:inline\" onclick=\"moveBiblioItem("+autoEntryIdx+",-1)\"></button>";
			var btn2 = "<button class=\"button btn_down\" type=\"button\" style=\"display:inline\" onclick=\"moveBiblioItem("+autoEntryIdx+",1)\"></button>"; 
			var btn3 = "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeBiblioItem("+autoEntryIdx+")\"></button>"; 	
			var span = "<p style=\"display:none\">"+strBibText+"</p>";
			obj.innerHTML = obj.innerHTML + btn0 + btn1 + btn2 + btn3 + span;
			autoEntryIdx++;
		}
		function updateArrowBtns() {
			var btnup, btndn;
			var items = document.getElementById("formattedBiblio").getElementsByTagName("li");
			for(pos=0;pos<items.length;pos++) {
				btnup = items[pos].getElementsByClassName("button btn_up");
				btnup[0].style.display = (pos==0) ? "none" : "inline";
				btndn = items[pos].getElementsByClassName("button btn_down");
				btndn[0].style.display = (pos==items.length-1) ? "none" : "inline";
			}	
		}
		function clearBiblioEntry() {
			var i;
			var inputs = document.getElementById("BibWizard").getElementsByTagName("input");
			for(i=0;i<inputs.length;i++) {
				inputs[i].value = "";
			}
		}
		function insertToBiblio(style) {	
			var str = createBiblioEntry();
			if (str) {
				if (document.getElementById("radioFormatted").checked) { //Preview
					var xhttp = new XMLHttpRequest();
					xhttp.onreadystatechange = function() {
						if (this.readyState == 4 && this.status == 200) {
							var span = document.createElement("ol"); span.innerHTML = this.responseText;
							var li_new = span.getElementsByTagName("li"); appendButtonsAndInfo(li_new[0], str);
							var ol = document.getElementById("formattedBiblio").getElementsByTagName("ol");
							if (style == "addItem") {
								ol[0].appendChild(li_new[0]);
							}
							if (style == "editItem") {
								ol[0].replaceChild(li_new[0], modifyingEntry);
							}
							updateArrowBtns();
							clearBiblioEntry();
						}
					}	
					var data = new FormData();
					data.append('text',str);
					xhttp.open("POST", "planea_bibliorender.php", true);
					xhttp.overrideMimeType('text/xml; charset=utf-8');
					xhttp.send(data);
				} else { //BibTEX view
					document.getElementById("Bibliografia").value = document.getElementById("Bibliografia").value + str;
				}
			}
		}
		function addToBiblio() {
			insertToBiblio("addItem");
			document.getElementById("btnEditItem").style.display = "none";
			setModifiedFlag();
		}
		function changeBiblio() {	
			insertToBiblio("editItem");
			document.getElementById("btnEditItem").style.display = "none";
			setModifiedFlag();
		}
		function moveBiblioItem(Id, dir) {
			var li1   = document.getElementById("BtnItem"+Id).parentNode;
			if (dir == -1) { li1.parentNode.insertBefore(li1, li1.previousSibling); } else { li1.parentNode.insertBefore(li1.nextSibling, li1); }
			updateArrowBtns();
			setModifiedFlag();
		}
		function removeBiblioItem(Id) {
			var li    = document.getElementById("BtnItem"+Id).parentNode;
			li.parentNode.removeChild(li);
			updateArrowBtns();
			setModifiedFlag();
		}
		var modifyingEntry = null;
		function editBiblioItem(Id) {
			modifyingEntry = document.getElementById("BtnItem"+Id).parentNode;
			var span = modifyingEntry.getElementsByTagName("p")[0];
			var str = span.innerText;
			var biblioCat = str.substring(1,str.indexOf("{"));
			biblioCat =  biblioCat.toLowerCase();
			document.getElementById("biblioCat").value = biblioCat;
			changebiblioCategory();
			//Convert BibTEX to JSON to extract attributes
			str = str.substring(str.indexOf("{")+1, str.lastIndexOf("}")-1);
			str = str.replace(/[\f\r\n\t]/g,"");
			str = str.replace(/  +/g," ");
			var ikeyend = str.indexOf(",");
			if (ikeyend<str.indexOf("=")) { str=str.substring(ikeyend+1); }		
			str=str.substring(str.search(/\S/i));			
			str = str.replace(/= {/g,"\":\"");
			str = str.replace(/={/g,"\":\"");
			str = str.replace(/= "/g,"\":\"");
			str = str.replace(/="/g,"\":\"");
			//if (str.lastIndexOf(",")==str.length-1) { str = str.substring(0, str.lastIndexOf("}")); }
			if (str.lastIndexOf(",")==str.length-1) { str = str.substring(0, str.length-1); }
			if (str.lastIndexOf("\"")==str.length-1) { str = str.substring(0, str.length-1); }
			if (str.lastIndexOf("}")==str.length-1) { str = str.substring(0, str.length-1); }
			str = str.replace(/{'a}/g,"á");
			str = str.replace(/{'e}/g,"é");
			str = str.replace(/{'i}/g,"í");
			str = str.replace(/{'o}/g,"ó");
			str = str.replace(/{'u}/g,"ú");
			str = str.replace(/\\/g,"\\\\");
			str = str.replace(/",/g,"\",\"");
			str = str.replace(/},/g,"\",\"");
			str = str.replace(/ "/g,"\"");
			str = str.replace(/" /g,"\"");
			str = "{\""+str+"\"}";
			var obj = JSON.parse(str);
			var it;
			it = document.getElementById("author"); if (it && obj.author) { it.value = obj.author; } else it.value = "";
			it = document.getElementById("title"); if (it && obj.title) { it.value = obj.title; }  else it.value = "";
			it = document.getElementById("year"); if (it && obj.year) { it.value = obj.year; }  else it.value = "";
			it = document.getElementById("url");  if (it && obj.url) { it.value = obj.url; } else it.value = ""; 
			it = document.getElementById("doi");  if (it && obj.doi) { it.value = obj.doi; } else it.value = ""; 
			/*if (it && obj.url) { it.value = obj.url; } else {
				if (it && obj.doi) { it.value = "https://dx.doi.org/"+obj.doi; } else it.value = "";
			}*/
			
			
			
			it = document.getElementById("publisher-"+biblioCat); if (it) { if (obj.publisher) { it.value = obj.publisher; }  else it.value = ""; }
			it = document.getElementById("volume-"+biblioCat); if (it) { if (obj.volume) { it.value = obj.volume; }  else it.value = ""; }
			it = document.getElementById("edition-"+biblioCat); if (it) { if (obj.edition) { it.value = obj.edition; }  else it.value = ""; }
			it = document.getElementById("booktitle-"+biblioCat); if (it) { if (obj.booktitle) { it.value = obj.booktitle; }  else it.value = ""; }
			it = document.getElementById("chapter-"+biblioCat); if (it) { if (obj.chapter) { it.value = obj.chapter; }  else it.value = ""; }
			it = document.getElementById("institution-"+biblioCat); if (it) { if (obj.institution) { it.value = obj.institution; }  else it.value = ""; }
			it = document.getElementById("journal-"+biblioCat); if (it) { if (obj.journal) { it.value = obj.journal; }  else it.value = ""; }
			it = document.getElementById("number-"+biblioCat); if (it) { if (obj.number) { it.value = obj.number; }  else it.value = ""; }
			it = document.getElementById("pages-"+biblioCat); 	if (it) { if (obj.pages) { it.value = obj.pages; }  else it.value = ""; }
			it = document.getElementById("urldate-"+biblioCat); 	if (it) { if (obj.urldate) { it.value = obj.urldate; }  else it.value = ""; }
			it = document.getElementById("howpublished-"+biblioCat); 	if (it) { if (obj.howpublished) { it.value = obj.howpublished; }  else it.value = ""; }
			it = document.getElementById("note-"+biblioCat); 	if (it) { if (obj.note) { it.value = obj.note; }  else it.value = ""; }
			it = document.getElementById("series-"+biblioCat); 	if (it) { if (obj.series) { it.value = obj.series; }  else it.value = ""; }
			it = document.getElementById("address-"+biblioCat); 	if (it) { if (obj.address) { it.value = obj.address; }  else it.value = ""; }			
			document.getElementById("btnEditItem").style.display = "inline";
		}
		var iStartSearch = 0;
		function startGetBiblioItems() {
			iStartSearch = 0;
		}
		function getBiblioItem() {
			var ipos, iStartEntry, iEndEntry;
			var strEntry = "";
			var str = document.getElementById("Bibliografia").value;
			iStartEntry = str.indexOf("@", iStartSearch);
			if ( iStartEntry!=-1 ) {
				iEndEntry = iStartEntry;
				do {
					ipos = iEndEntry+1;
					iEndEntry = str.indexOf("@", ipos);
					if (iEndEntry==-1) {
						iEndEntry = str.length;
						break;
					}
					substr = str.substring(str, ipos, iEndEntry-1);
					nOpen  = (substr.match(/{/g) || []).length;
					nClose = (substr.match(/}/g) || []).length;
				} while (nOpen > nClose);
				strEntry = str.substring(iStartEntry, iEndEntry);
				iStartSearch = iEndEntry;
			}
			return strEntry;
		}
		function renderBiblio() {
			var itemIdx;
			var str;
			//Extract biblio entries from BibTEX info
			var biblioItems = [];
			startGetBiblioItems();
			do { str = getBiblioItem(); if (str.length>0) { biblioItems.push(str); } } while(str.length>0);
			//Assign buttons to formatted bibliography & extra BibTEX information
			if (bDisplayButtons) { 
				var items = document.getElementById("formattedBiblio").getElementsByTagName("li");
				for (itemIdx = 0; itemIdx<items.length; itemIdx++) {
					appendButtonsAndInfo(items[itemIdx],biblioItems[itemIdx]);
				}
				updateArrowBtns(); 
			}
		}
		function normalizeBibTEX() {
			var itemIdx;
			var str;
			//Extract biblio entries from BibTEX info
			var biblioItems = [];
			startGetBiblioItems();
			do { str = getBiblioItem(); if (str.length>0) { biblioItems.push(str); } } while(str.length>0);
			//Convert quotes to braces
			str = "";
			for (itemIdx = 0; itemIdx<biblioItems.length; itemIdx++) {
				var bibentry = biblioItems[itemIdx];
				bibentry = bibentry.replace(/=[ |\t]"/g,"={");
				bibentry = bibentry.replace(/="/g,"={");
				bibentry = bibentry.replace(/"[ |\t],/g,"},");
				bibentry = bibentry.replace(/",/g,"},");
				bibentry = bibentry.replace(/"[ \f\r\n\t]}/g,"}\n}");
				str = str+bibentry;			
				if ( bibentry.substr(-1,1)=="}" )  {
					str = str+'\n'; 
				}
			}
			return str;
		}
		function getBibTEX() {
			var str = "";
			var items = document.getElementById("formattedBiblio").getElementsByTagName("li");
			for (itemIdx = 0; itemIdx<items.length; itemIdx++) {
				var strEntry = items[itemIdx].getElementsByTagName("p")[0].innerText;
				str = str+strEntry;			
				if ( strEntry.substr(-1,1)=="}" )  {
					str = str+'\n'; 
				}
			}
			document.getElementById("Bibliografia").value = str;
		}
		function viewFormatted() {
			var strBibTEX = "";
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("formattedBiblio").innerHTML = this.responseText;
					renderBiblio();
				}
			}
			strBibTEX = normalizeBibTEX();
			document.getElementById("Bibliografia").value = strBibTEX;
			var data = new FormData();
			data.append('text', strBibTEX);
			xhttp.open("POST", "planea_bibliorender.php", true);
			xhttp.overrideMimeType('text/xml; charset=utf-8');
			xhttp.send(data);
			document.getElementById("formattedBiblio").style.display = "block";
			document.getElementById("rawBiblio").style.display = "none";
		}
		function viewBibTEX() {
			if (bDisplayButtons) { getBibTEX(); }
			document.getElementById("btnEditItem").style.display = "none";
			document.getElementById("formattedBiblio").style.display = "none";
			document.getElementById("rawBiblio").style.display = "inline";
		}
		function saveBiblio() {
			if ( document.getElementById("radioFormatted").checked ) { //Preview
				getBibTEX();
			} else { //BibTEX mode
				document.getElementById("Bibliografia").value = normalizeBibTEX();
			}
			return clearModifiedFlag();
		}
	</script>	
</head>

<body onload="renderBiblio()">

<?php  
	require('planea_basics.php');
	require('planea_logosbar.php');
	$helptopic = "teacher-syllabusbiblio";
	require('planea_syllabusbar.php');
	require('bibtex2html.php');
		
	$planea = new planea();
	$conn = $planea->openConnection();
	if (isset($_GET["ID"])) {
		$CourseID = $_GET["ID"];
	}
	if (isset($_POST["Bibliografia"])) {
		$CourseID = $_POST["CourseID"];
		$biblio = str_replace('\"', '', $_POST["Bibliografia"]);
		$sql = "UPDATE courses_general SET Bibliografia=\"". $biblio ."\" WHERE ID=" . $CourseID;
		$conn->query($sql);
	}
	$sql = "SELECT * FROM courses_general WHERE ID=" . $CourseID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$CourseName = $planea->showCourseTitle($row);
	$canModify = $planea->checkPermission( $_SESSION["RoleID"], $_SESSION["UserID"], $CourseID, 128 );
	$coursebar_opt = 8;
	require('planea_coursebar.php');
?>

<script>
	var	bDisplayButtons = <?php if ($canModify) echo "true"; else echo "false"; ?>
</script>

<form class="planeaForm" id="mainForm" action="view_syllabus_biblio.php" onsubmit="saveBiblio()" method="POST">

<b>Bibliografía</b> 
<label><input type="radio" id="radioFormatted" name="viewFormat" value=1 onclick="viewFormatted()" checked> Vista previa</label>
<label><input type="radio" id="radioBibTEX" name="viewFormat" value=2 onclick="viewBibTEX()"> BibTEX</label>

<div id="formattedBiblio" class="planeaForm">
	<?php 		
		$str_html = bibfile2html($row["Bibliografia"],null,false,false);  
		echo $str_html;
    ?>
</div>

<div id="rawBiblio" style="display:none">
<textarea id="Bibliografia" name="Bibliografia" rows=16 style="width: 100%;" onchange="setModifiedFlag()"><?php echo $row["Bibliografia"]; ?></textarea><br><br>
</div>

<div id="BibWizard"<?php if ($canModify==false) echo " style=\"display:none\"" ?> class="planeaForm">
Categoría <select id="biblioCat" onchange="changebiblioCategory()">
	<option value="book" selected>Libro</option>
	<option value="incollection">Capítulo de libro</option>
	<option value="techreport">Reporte técnico</option>
	<option value="article">Artículo</option>
	<option value="inproceedings">Trabajo en evento</option>
	<option value="web">Página web</option>
	<option value="misc">Miscelaneo</option>
	</select> <br>	
Autor: <input type="text" id="author" size=50 style="width: 80%;"> <br>
Título: <input type="text" id="title" size=50 style="width: 80%;"> <br>
<div id="book" style="display:inline">
Editorial: <input type="text" id="publisher-book" size=50 style="width: 80%;"> <br>
Volumen: <input type="text" id="volume-book" size=50 style="width: 80%;">  <br>
Edición: <input type="text" id="edition-book" size=50 style="width: 80%;"> <br>
</div>
<div id="incollection" style="display:none">
Título del libro: <input type="text" id="booktitle-incollection" size=50 style="width: 80%;"> <br>
Editorial: <input type="text" id="publisher-incollection" size=50 style="width: 80%;"> <br>
Volumen: <input type="text" id="volume-incollection" size=50 style="width: 80%;">  <br>
Edición: <input type="text" id="edition-incollection" size=50 style="width: 80%;"> <br>
Capítulo: <input type="text" id="chapter-incollection" size=50 style="width: 80%;">  <br>
</div>
<div id="techreport" style="display:none">
Institución: <input type="text" id="institution-techreport" size=50 style="width: 80%;"> <br>
</div>
<div id="article" style="display:none">
Revista: <input type="text" id="journal-article" size=50 style="width: 80%;"> <br>
Número: <input type="text" id="number-article" size=50 style="width: 80%;"> <br>
Volumen: <input type="text" id="volume-article" size=50 style="width: 80%;"> <br>
Páginas: <input type="text" id="pages-article" size=50 style="width: 80%;"> <br>
</div>
<div id="inproceedings" style="display:none">
Título de las memorias: <input type="text" id="booktitle-inproceedings" size=50 style="width: 70%;"> <br>
Volumen: <input type="text" id="volume-inproceedings" size=50 style="width: 80%;">  <br>
Páginas: <input type="text" id="pages-inproceedings" size=50 style="width: 80%;"> <br>
Series: <input type="text" id="series-inproceedings" size=50 style="width: 80%;"> <br>
Editorial: <input type="text" id="publisher-inproceedings" size=50 style="width: 80%;"> <br>
Lugar: <input type="text" id="address-inproceedings" size=50 style="width: 80%;">  <br>
</div>
<div id="web" style="display:none">
Fecha de acceso: <input type="text" id="urldate-web" size=50 value="Accesado: " style="width: 70%;"> <br>
</div>
<div id="misc" style="display:none">
Cómo fue publicado: <input type="text" id="howpublished-misc" size=50 style="width: 70%;"> <br>
Fecha de acceso: <input type="text" id="note-misc" size=50 value="Accesado: " style="width: 70%;"> <br>
</div>
URL: <input type="text" id="url" size=50 style="width: 80%;"> <br>
DOI: <input type="text" id="doi" size=50 style="width: 80%;"> <br>
Año: <input type="number" min=1900 max=2100 id="year" size=50>
<button class="button btn_fancy" id="btnAddItem" onclick="addToBiblio()" type="button">Añadir a bibliografía <img src="images/btn_add1.png"></button>
<button class="button btn_fancy" id="btnEditItem" onclick="changeBiblio()" type="button" style="display:none">Modificar <img src="images/btn_add1.png"></button>	
</div>
<br>
<input style="display:none" type="number" name="CourseID" value="<?php echo $row["ID"]; ?>">

<?php 
	if ($canModify) { 
		echo "<input type=\"submit\" value=\"Guardar\">"; 
	}
	$planea->closeConnection();	
?>
<input type="submit" formaction="syllabus.php" value="Cancelar"> 
</form>  

</body>
</html>
