<div class="logosbar">
	<a href="http://www.uniquindio.edu.co"><img class="logos" src="images/logouq.jpg" alt="Uniquindio" style="width:62px;height:77px"></a>	 
	<a href="http://www.cdio.org"><img class="logos" src="images/logocdio.jpg" alt="CDIO" style="width:134px;height:64px"></a>
	<img class="logoplanea" src="images/logoplanea.png" alt="PLANEA" style="width:192px;height:62px">
</div>
<?php 
	if ( !isset($_SESSION["overrideAuth"]) && !isset($_SESSION["UserID"])) {
		echo "<br><a href=\"login.php\">Inicie Sesión</a></br>";
		exit(0);
	}
?>