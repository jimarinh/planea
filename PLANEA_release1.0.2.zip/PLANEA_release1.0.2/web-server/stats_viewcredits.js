
function updateCreditsCourse(id)
{
	var HT = parseFloat(document.getElementById("HT"+id).value);
	var HP = parseFloat(document.getElementById("HP"+id).value);
	var HTP = parseFloat(document.getElementById("HTP"+id).value);
	var HI = parseFloat(document.getElementById("HI"+id).value);
	var HA = parseFloat(document.getElementById("HA"+id).value);
	var EstimatedCredits = ((HT+HP+HTP+HI+HA)*16.0)/48.0;
	document.getElementById("EC"+id).value = EstimatedCredits;
}	

function updateCreditsSemester(sem)
{
	var i;
	var HTS=0, HPS=0, HTPS=0, HIS=0, HAS=0, ECS=0, CS=0;
	
	//Calcula el número de horas totales del semestre
	for (i=0; i<courses.length; i++)
	{
		if ((courses[i].Sem == sem) && (courses[i].Ig==0))
		{
			HTS += parseFloat(document.getElementById("HT"+courses[i].ID).value);
			HPS += parseFloat(document.getElementById("HP"+courses[i].ID).value);
			HTPS += parseFloat(document.getElementById("HTP"+courses[i].ID).value);
			HIS += parseFloat(document.getElementById("HI"+courses[i].ID).value);
			HAS += parseFloat(document.getElementById("HA"+courses[i].ID).value);
			ECS += parseFloat(document.getElementById("EC"+courses[i].ID).value);
			CS += parseFloat(document.getElementById("C"+courses[i].ID).value);
		}
	}
	if ( document.getElementById("HTS"+sem) != null ) {
		document.getElementById("HTS"+sem).value = HTS;
		document.getElementById("HPS"+sem).value = HPS;
		document.getElementById("HTPS"+sem).value = HTPS;
		document.getElementById("HIS"+sem).value = HIS;
		document.getElementById("HAS"+sem).value = HAS;
		document.getElementById("ECS"+sem).value = ECS;
		document.getElementById("CS"+sem).value = CS;
	}
}

function updateCreditsElectives()
{
	//Actualiza la vista de horas y créditos con base en el primer curso del listado de la categoría
	for(i=0; i<electives.length; i++) {
		cat = electives[i].cat;
		id  = electives[i].ID;
		document.getElementById("ElHT"+cat).value = document.getElementById("HT"+id).value;
		document.getElementById("ElHP"+cat).value = document.getElementById("HP"+id).value;
		document.getElementById("ElHTP"+cat).value = document.getElementById("HTP"+id).value;
		document.getElementById("ElHI"+cat).value = document.getElementById("HI"+id).value;
		document.getElementById("ElHA"+cat).value = document.getElementById("HA"+id).value;
		document.getElementById("ElEC"+cat).value = document.getElementById("EC"+id).value;
		document.getElementById("ElC"+cat).value = document.getElementById("C"+id).value;
	}
}

function updateCreditsProgram()
{
	var i, TotalCredits=0;
	for(i=0; i<courses.length; i++)
	{
		if (courses[i].Ig==0) { TotalCredits += parseFloat( document.getElementById("C"+courses[i].ID).value ); }
	}
	document.getElementById("TotalCredits").innerHTML = "Total Créditos del Programa: "+TotalCredits;
}


function updateCredits(id)
{
	var i, sem;
	//Actualiza los créditos del curso
	updateCreditsCourse(id);	
	//Busca el semestre en el cual se ubica el curso
	for(i=0; i<courses.length; i++)
	{
		if (courses[i].ID == id) {
			sem = courses[i].Sem;
			break;
		}
	}	
	//Actualiza los créditos del semestre
	updateCreditsSemester(sem);	
	//Actualiza los créditos del programa
	updateCreditsProgram();
	updateCreditsElectives();
}

function updateAll()
{
	var i, maxsem = 0;
	for(i=0; i<courses.length; i++)
	{
		updateCreditsCourse( courses[i].ID );
		if (courses[i].Sem > maxsem) {
			maxsem = courses[i].Sem;
		}
	}	
	for(i=0; i<=maxsem; i++)
	{
		updateCreditsSemester(i);
	}
	updateCreditsProgram();
	updateCreditsElectives();
}
