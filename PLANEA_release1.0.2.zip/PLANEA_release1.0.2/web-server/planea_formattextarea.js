var planeaFormatTextarea = {
	str:""
	,
	planeaFormatModify:function(e){
		setModifiedFlag();
	},
	planeaFormatChild:function(obj) {
		if (obj==null) {
			return;
		}
		if (obj.nodeType==3) { //text
			planeaFormatTextarea.str += obj.nodeValue;
		}
		if (obj.nodeType==1) { //styling
			var bOpenTag = false;
			var bCloseTag = false;
			var tag = obj.nodeName;
			
			if (obj.nodeName.localeCompare("A")==0) { //remove link but preserve text
				tag = "U"; bOpenTag = true; bCloseTag = true; } 
			else if ((obj.nodeName.localeCompare("H1")==0) || (obj.nodeName.localeCompare("H2")==0) || (obj.nodeName.localeCompare("H3")==0)) {
				tag = "B"; bOpenTag = true; bCloseTag = true; }
			else if (obj.nodeName.localeCompare("B")==0) 	{bOpenTag = true; bCloseTag = true;}
			else if (obj.nodeName.localeCompare("I")==0) 	{bOpenTag = true; bCloseTag = true;}
			else if (obj.nodeName.localeCompare("U")==0) 	{bOpenTag = true; bCloseTag = true;}
			else if (obj.nodeName.localeCompare("SUP")==0) 	{bOpenTag = true; bCloseTag = true;}
			else if (obj.nodeName.localeCompare("SUB")==0) 	{bOpenTag = true; bCloseTag = true;}
			else if (obj.nodeName.localeCompare("BR")==0) 	{bOpenTag = true; bCloseTag = false;}
			else if (obj.nodeName.localeCompare("UL")==0)	{bOpenTag = true; bCloseTag = true;}
			else if (obj.nodeName.localeCompare("OL")==0) 	{bOpenTag = true; bCloseTag = true;}
			else if (obj.nodeName.localeCompare("LI")==0) 	{bOpenTag = true; bCloseTag = true;}
			else if (obj.nodeName.localeCompare("DIV")==0) 	{bOpenTag = true; bCloseTag = true;}
			else if (obj.nodeName.localeCompare("P")==0) 	{bOpenTag = true; bCloseTag = true;}
			else if (obj.nodeName.localeCompare("BLOCKQUOTE")==0) {bOpenTag = true; bCloseTag = true;}
			
			if (bOpenTag) planeaFormatTextarea.str += "<" + tag + ">";
			obj.childNodes.forEach(planeaFormatTextarea.planeaFormatChild);
			if (bCloseTag) planeaFormatTextarea.str += "</" + tag + ">";
		}
	},
	planeaFormatBeforePaste:function(e){
		var pastedText = undefined;
		if (window.clipboardData && window.clipboardData.getData) { //IE
			pastedText = window.clipboardData.getData('Html');
			if (pastedText.length == 0) {
				pastedText = window.clipboardData.getData('Text');
			}
		} else {
			pastedText = e.clipboardData.getData('text/html');
			if (pastedText.length == 0) {
				pastedText = e.clipboardData.getData('text');
			}
		}
		var iEndStr = pastedText.search("</html>");
		if (iEndStr > 0) { //Remove garbage from MSOffice
			pastedText = pastedText.substring(0, iEndStr+7);
		}
		var html = document.createElement( 'html' ); html.innerHTML = pastedText;
		var body = html.getElementsByTagName( 'body' )[0];
		planeaFormatTextarea.str = "";
		body.childNodes.forEach(planeaFormatTextarea.planeaFormatChild);
		e.preventDefault();
		var strFmt = planeaFormatTextarea.str.replace(/[\f\r\n]/g," ");
		strFmt.replace(/^\s+/g, '');
		document.execCommand('insertHTML', false, strFmt);		
		return false;
	},	
	planeaFormatText:function(strIn) {
		//Append <br> for each new line to ensure backward compatibility
		var strFmt = strIn.replace(/[\f\r\n]/g,"<br>");
		//Remove all unsupported html tags by PLANEA
		var html = document.createElement( 'html' ); html.innerHTML = strFmt;
		var body = html.getElementsByTagName( 'body' )[0];
		planeaFormatTextarea.str = "";
		body.childNodes.forEach(planeaFormatTextarea.planeaFormatChild);
		return planeaFormatTextarea.str;
	},
	textAreaById: function(idName){
		var editor = nicEditors.findEditor(idName);
		editor.editorContain.addEventListener("paste",planeaFormatTextarea.planeaFormatBeforePaste);
		editor.editorContain.addEventListener("input",planeaFormatTextarea.planeaFormatModify);
		editor.setContent( planeaFormatTextarea.planeaFormatText( editor.getContent() ) );
	},
	allTextAreas: function(){
		var neditors = nicEditors.editors.length;
		for(var i=0; i<neditors; i++) {
			var editor = nicEditors.editors[i].nicInstances[0];
			editor.editorContain.addEventListener("paste",planeaFormatTextarea.planeaFormatBeforePaste);
			editor.editorContain.addEventListener("input",planeaFormatTextarea.planeaFormatModify);
			editor.setContent( planeaFormatTextarea.planeaFormatText( editor.getContent() ) );
		}
	}
};

