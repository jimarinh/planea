<?php
	require('planea_basics.php');  
	$planea = new planea();
	$conn = $planea->openConnection();
	$PlanID = $_GET["PlanID"];
	$SemName = $_GET["SemName"];
	$Action = $_GET["Action"];
	
	if ($Action == "check") {	//Check if pending evaluations from previous semesters
		$retval = 0;
		$sql = "SELECT ID FROM eval_courses WHERE PlanID=".$PlanID." AND State=0 AND Semester!='".$SemName."'";
		$result = $planea->conn->query($sql);
		if ($result->num_rows>0) { 
			$retval = 1; 
		} else {
			$sql = "SELECT ID FROM eval_areas WHERE PlanID=".$PlanID." AND State=0 AND Semester!='".$SemName."'";
			$result = $planea->conn->query($sql);
			if ($result->num_rows>0) { 
				$retval = 1; 
			}			
		}
		echo $retval;
	}
	
	if ($Action == "remove") {	//Remove all pending evaluations from previous semesters
		$sql = "DELETE FROM eval_courses WHERE PlanID=".$PlanID." AND State=0 AND Semester!='".$SemName."'";
		$result = $planea->conn->query($sql);
		
		$sql = "DELETE FROM eval_areas WHERE PlanID=".$PlanID." AND State=0 AND Semester!='".$SemName."'";
		$result = $planea->conn->query($sql);
	}
	
	$planea->closeConnection();
?>