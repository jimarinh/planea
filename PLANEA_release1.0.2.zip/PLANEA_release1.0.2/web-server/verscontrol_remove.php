<?php
require('planea_basics.php'); 

function approveLastVersion($CourseKeyID, $conn)
{
	$sql = "SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID." ORDER BY Version DESC";
	$result = $conn->query($sql);
	$row = $result->fetch_assoc();
	$sql = "UPDATE courses_general SET EstadoVersion=".planea::syllStateApproved.",VisVersion=1 WHERE ID=".$row["ID"];
	$result = $conn->query($sql);
	echo "Sin embargo, la última versión pasa a ser la versión vigente.";
} 

$planea = new planea();
$conn = $planea->openConnection();	
$CourseID =  $_GET["ID"];
$CourseKeyID =  $_GET["CourseKeyID"];

//Verifica que haya más de una versión del curso para poder eliminarla
$sql = "SELECT ID FROM courses_general WHERE CourseKeyID=" . $CourseKeyID;
$result = $planea->conn->query($sql);
if ($result->num_rows>1) {
	//Borra todas referencias en las tablas, excepto la tabla general
	$sql = "DELETE FROM courses_personal_skills WHERE CourseID=".$CourseID;
	$result = $conn->query($sql); 
	$sql = "DELETE FROM courses_interpersonal_skills WHERE CourseID=".$CourseID;
	$result = $conn->query($sql); 
	$sql = "DELETE FROM courses_cdio_skills WHERE CourseID=".$CourseID;
	$result = $conn->query($sql);
	$sql = "DELETE FROM courses_ilos WHERE CourseID=".$CourseID;
	$result = $conn->query($sql);	
	$sql = "DELETE FROM courses_reqs WHERE CourseID=".$CourseID;
	$result = $conn->query($sql); 
	$sql = "DELETE FROM courses_contents WHERE CourseID=".$CourseID;
	$result = $conn->query($sql); 
	$sql = "DELETE FROM rubrics_assoc WHERE CourseID=".$CourseID;
	$result = $conn->query($sql); 
	$planea->purgeNotUsedRubrics();
	$sql = "DELETE FROM teacher_howtos WHERE CourseID=".$CourseID;
	$result = $conn->query($sql);
	$sql = "DELETE FROM teacher_actassoc WHERE ActID IN (SELECT ID FROM teacher_activities WHERE CourseID=".$CourseID.")";
	$result = $conn->query($sql);
	$sql = "DELETE FROM teacher_activities WHERE CourseID=".$CourseID;
	$result = $conn->query($sql);
	$sql = "DELETE FROM users_assignments WHERE courseID=".$CourseID;
	$result = $conn->query($sql); 
	
	//Captura información del estado de la versión al eliminar
	$sql = "SELECT EstadoVersion,Version,VisVersion,Nombre FROM courses_general WHERE ID=".$CourseID;
	$result = $conn->query($sql);
	$row = $result->fetch_assoc();
	$verState = $row["EstadoVersion"]; 
	$bVisible = $row["VisVersion"];
	echo "La versión ".$row["Version"]." del curso ".$row["Nombre"]." ha sido eliminada exitosamente.";
	//Borra la entrada de la tabla general
	$sql = "DELETE FROM courses_general WHERE ID=".$CourseID;
	$result = $conn->query($sql);
	//Configura el estado de las versiones restantes
	if ($verState==planea::syllStateOpened) {
		if ($bVisible==true) {
			$sql = "SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID." AND EstadoVersion=".planea::syllStateApproved;
			$result = $conn->query($sql);
			if ($result->num_rows>0) {
				$row = $result->fetch_assoc();
				$sql = "UPDATE courses_general SET VisVersion=1 WHERE ID=".$row["ID"];
				$result = $conn->query($sql);
			} else {
				approveLastVersion($CourseKeyID, $conn);
			}
		}	
	}
	if ($verState==planea::syllStateApproved) {
		if ($bVisible==true) {
			approveLastVersion($CourseKeyID, $conn);
		}
	}
	
} else {
	echo "ERROR: No puede eliminarse la versión dado a que el curso solamente tiene una versión. Si desea eliminar el curso escoga la opción \"Eliminar\"";
}
$planea->closeConnection();
?>