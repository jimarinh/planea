<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script>
		function exportCreditsTable() {
			var xhttp = new XMLHttpRequest();
			var PlanID = document.getElementById("PlanID").value;
			if (PlanID==0) return;
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					tableToExcel(this.responseText,'Creditos');
				}
			}
			xhttp.open("GET", "stats_exportcredits.php?PlanID="+PlanID, true);
			xhttp.send();	
		}
		var tableToExcel = (function() {
			var uri = 'data:application/vnd.ms-excel;base64,'
				, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
				, base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
				, format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
			return function(tableHTML, name) {
				var ctx = {worksheet: name || 'Worksheet', table: tableHTML}
				window.location.href = uri + base64(format(template, ctx))
			}
		})()
	</script>
</head>

<body>

<?php  
	require('planea_logosbar.php');
	$helptopic = "coord-stats";
	require('planea_statisticsbar.php');
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();  
?>	

<form class="planeaForm" action="statistics.php" method="POST">
	Plan:
	<select name="PlanID" id="PlanID">
	<?php $planea->showStudyPlan($_SESSION["DefaultPlan"]); ?>
	</select>
	<br> <br>
		
	<table class="planning">
	<tr>
	  <td style="width:50%">Requisitos</td>
	  <td><input type="submit" value="Malla curricular" formaction="stats_viewreqs.php"> &nbsp; <input type="submit" value="Tabla de requisitos" formaction="stats_viewreqstable.php"></td>
	</tr>
	<tr>
	   <td>Áreas/Núcleos Temáticos</td>
	   <td><input type="submit" value="Visualizar/modificar" formaction="stats_viewareas.php"></td>
	</tr>
	<tr>
	  <td>Currículo Integrado (Integración de las habilidades en el currículo)</td>
	  <td>
	    <input type="submit" value="Habilidades vs. Cursos" formaction="stats_viewskills.php"> &nbsp;
		<input type="submit" value="RAPs Programa vs. RAPs Cursos" formaction="stats_viewprogILOs.php"> &nbsp;
		<input type="submit" value="Categorías vs. RAPs Cursos" formaction="stats_viewcategoryILOs.php"> 
	  </td>
	</tr>
	<tr>
	  <td>Créditos académicos y horas de trabajo en el currículo</td>
	  <td><input type="submit" value="Visualizar/modificar" formaction="stats_viewcredits.php"> &nbsp;
	  <button type="button" onClick="exportCreditsTable()">Exportar a Excel</button></td>
	</tr>
	</table>
	
	
</form> 

<?php $planea->closeConnection(); ?>

</body>
</html>
