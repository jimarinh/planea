<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
</head>

<body>

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	//Check for credentials
	if ($_SESSION["RoleID"]!=planea::roleAdmin) {
		exit("<p><font color=\"red\">No tiene permiso para acceder a esta sección</font><p>");
	}
?>

	<script>
	function createStudyPlan() {
		document.getElementById("planInfo").style.display = "inline";
		document.getElementById("newBtn").style.display = "none";
		document.getElementById("studyPlanTable").style.display = "none";
		document.getElementById("createBtn").style.display = "inline";
		document.getElementById("cancelBtn").style.display = "inline";
		document.getElementById("PlanID").value = -1;
	}
	function editStudyPlan(planID) {
		document.getElementById("planInfo").style.display = "inline";
		document.getElementById("newBtn").style.display = "none";
		document.getElementById("studyPlanTable").style.display = "none";
		document.getElementById("saveBtn").style.display = "inline";
		document.getElementById("cancelBtn").style.display = "inline";
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				var obj = JSON.parse(this.responseText);
				document.getElementById("Code").value = obj.Code;
				document.getElementById("Faculty").value = obj.Faculty;
				document.getElementById("Program").value = obj.Program;
				document.getElementById("Description").value = obj.Description;
				var CatSets = document.getElementById("CatSetID").options;
				for(pos=0;pos<CatSets.length;pos++) {
					if (CatSets[pos].value == obj.CatSetID) {
						document.getElementById("CatSetID").selectedIndex = pos;
						break;
					}
				}
				var ILOSets = document.getElementById("ILOSetID").options;
				for(pos=0;pos<ILOSets.length;pos++) {
					if (ILOSets[pos].value == obj.ILOSetID) {
						document.getElementById("ILOSetID").selectedIndex = pos;
						break;
					}
				}
				var Template = document.getElementById("Template").options;
				for(pos=0;pos<Template.length;pos++) {
					if (Template[pos].value == obj.Template) {
						document.getElementById("Template").selectedIndex = pos;
						break;
					}
				}
				document.getElementById("PlanID").value = obj.ID;
			}
		}
		xhttp.open("GET", "study_plan_edit.php?planID="+planID, true);
		xhttp.send();	
	}
	</script>

<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="#">Planes de Estudio</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#admin-studyplan" target="PLANEA-help">?</a></li>
</ul>


<?php  
	$planea = new planea();
	$conn = $planea->openConnection();
	if ( isset($_POST["Code"]) && !empty($_POST["Code"]) ) {
		if ($_POST["PlanID"]==-1) { //Create study_plan
			$sql = "INSERT INTO study_plan (Code,Faculty,Program,Description,ILOSetID,CatSetID,Template) 
				VALUES ('" . $_POST["Code"] . "', '" . $_POST["Faculty"] . "', '" . 
					$_POST["Program"] . "', '". $_POST["Description"] . "', ".
					$_POST["ILOSetID"]. ", ". $_POST["CatSetID"].", '" . $_POST["Template"] . "')";
		} else { //Modify study_plan
			$sql = "UPDATE study_plan SET Code='" . $_POST["Code"] . "', Faculty='" . $_POST["Faculty"]. 
					"', Program='" . $_POST["Program"]."', Description='" . $_POST["Description"] . 
					"', ILOSetID=".$_POST["ILOSetID"]. ", CatSetID=".$_POST["CatSetID"]. ", Template='".$_POST["Template"]. "' ".
					" WHERE ID=".$_POST["PlanID"];					
		}	
		$result = $conn->query($sql);	
	}
?>


<form class="planeaForm" action="study_plan.php" method="POST">
	<div id="planInfo" style="display:none">
		Código: <input type="text" id="Code" name="Code" size=10> <br> <br>
		Facultad: <input type="text" id="Faculty" name="Faculty" size=30> <br> <br>
		Programa: <input type="text" id="Program" name="Program" size=30>  <br> <br>
		Descripción: <input type="text" id="Description" name="Description" size=30> <br> <br>
		Categorización de los Cursos: 
		<select id="CatSetID" name="CatSetID">
		<?php 
			$planea->showCourseCatCustomizableList(); 
		?>
		</select>
		<br> <br>
		Categorización de los RAPs: 
		<select id="ILOSetID" name="ILOSetID">
		<?php 
			$planea->showRAPCustomizableList(); 
		?>
		</select>
		<br> <br>
		Pantilla para generación de PDFs: 
		<select id="Template" name="Template">
		<option value="">Seleccione uno...</option>
		<?php 
			$dir = "templates/";
			if (is_dir($dir)){						
				if ($dh = opendir($dir)){
					while (($file = readdir($dh)) !== false){
						if (is_file($dir.$file)) {
							$fileExt = strtolower(pathinfo($file,PATHINFO_EXTENSION));
							if ($fileExt == "xml") {
								echo "<option value=\"".$file."\">".$file."</option>\n";
							}
						}
					}
					closedir($dh);
				}
			}
		?>
		</select>
		<br> <br>
	</div>
	<input type="submit" id="createBtn" value="Crear" style="display:none">
	<input type="submit" id="saveBtn" value="Guardar" style="display:none">
	<input type="button" id="cancelBtn" onClick="window.location='study_plan.php'" value="Cancelar" style="display:none">
	<input type="button" id="newBtn" onClick="createStudyPlan()" value="*Crear Nuevo Plan de Estudios">
	<input type="number" id="PlanID" name="PlanID" size=10 style="visibility:hidden" value="-1"> 
</form>

<form class="planeaForm" id="studyPlanTable" action="#" method="POST">
	<table>
	<tr><th>Código</th><th>Facultad</th><th>Programa</th><th>Descripción</th><th></th></tr>
	<?php $planea->showStudyPlanList(); ?>
	</table>
</form>

<?php $planea->closeConnection(); ?>

</body>
</html>
