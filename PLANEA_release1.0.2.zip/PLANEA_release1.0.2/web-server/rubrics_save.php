<?php
require('planea_basics.php');
if ($_POST["RubricID"] != -1) {
	$planea = new planea();
	$planea->openConnection(); 
	$planea->saveRubric();
	$planea->closeConnection();
}
?>