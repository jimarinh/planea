<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "INSERT INTO ilo_program(PlanID, Value, Position) VALUES ('".$_GET["PlanID"]."','".$_GET["name"]."','".$_GET["pos"]."')";
$result = $planea->conn->query($sql);
if ($result == true) {
	echo $planea->conn->insert_id;
}
$planea->closeConnection();
?>