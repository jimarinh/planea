<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script>
		function exportTable(tableName) {
			tableToExcel(tableName,'Areas');
		}
		var tableToExcel = (function() {
			var uri = 'data:application/vnd.ms-excel;base64,'
				, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
				, base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
				, format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
			return function(table, name) {
				if (!table.nodeType) table = document.getElementById(table)
				var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
				window.location.href = uri + base64(format(template, ctx))
			}
		})()
	</script>
</head>

<body>
<?php  
	require('planea_logosbar.php');
	$helptopic = "coord-stats-areas";
	require('planea_statisticsbar.php');
	require('planea_basics.php');  
	$planea = new planea();
	$conn = $planea->openConnection();
	
	if (isset($_POST["PlanID"])) {
		$PlanID = $_POST["PlanID"];
	}
	if (isset($_GET["PlanID"])) {
		$PlanID = $_GET["PlanID"];
	}
	if (!isset($PlanID)) exit(0);
	if (isset($_GET["showElectiveChk"])) {
		$bShowElectives = $_GET["showElectiveChk"];
	} else {
		$bShowElectives = true;
	}	
?>

<div class="planeaForm">
<input name="showElectiveChk" type="checkbox" 
  onchange="location.href='stats_viewareas.php?PlanID=<?php echo $PlanID?>&showElectiveChk=<?php echo !$bShowElectives;?>'" <?php if ($bShowElectives) echo "checked"; ?>>
  Considerar electivas &nbsp; 
</div> 	

<div class="planeaForm">
<button  onclick="exportTable('tableAreas')" type="button">Exportar</button><br><br>
<table id="tableAreas" >
  <tr>
    <th>Área/Núcleo Temático</th>
    <th>Número de espacios</th> 
    <th>Número de créditos</th>
  </tr>
  <?php 
	$areas = array();
	$area_count = 0;
	$sql = "SELECT NucleoTematico,COUNT(ID),SUM(NumeroCreditos) FROM courses_general 
			WHERE PlanID=". $PlanID." AND VisVersion=1 ";
	if (!$bShowElectives) {
		$sql = $sql."AND CourseKeyID NOT IN (SELECT CourseID FROM courses_elective) ";		
	}
	$sql = $sql."GROUP BY NucleoTematico";
	$result = $conn->query($sql);
	if ($result->num_rows>0) {
		while( $row_area = $result->fetch_assoc() ) {
			$area_name = $row_area["NucleoTematico"];
			$areas[ $area_count ] = $area_name;
			if ( empty($area_name) ) { $area_name = "(Sin definir)"; }
			echo "<tr><td><a href=\"#".$area_count."\">".$area_name."</a></td><td align=\"center\">".$row_area["COUNT(ID)"]."</td><td align=\"center\">".$row_area["SUM(NumeroCreditos)"]."</td></tr>\n";			
			$area_count++;
		}
	}
  ?>
</table>
</div>
<div class="planeaForm">
<button  onclick="exportTable('tableDetailedAreas')" type="button">Exportar</button>
<div id="tableDetailedAreas">
<?php
	for ($i=0; $i<$area_count; $i++) {
		$area_name = $areas[$i];
		if ( !isset($area_name) ) { 		//Empty areas are shown in two different groups since SQL SELECT GROUP reports NULL and empty areas as different rows
			$area_name = "(Sin definir)"; 
			$area_search = " NucleoTematico IS NULL";
		} else if (empty($area_name)) {
			$area_name = "(Sin definir)"; 
			$area_search = " NucleoTematico=''";
		} else {
			$area_search = "NucleoTematico='".$area_name."'";
		}
		
		echo "<h3 id=\"".$i."\">".$area_name."</h3>\n";
		echo "<table><tr><th>No.</th><th>Espacio académico</th><th>Créditos</th><th></th></tr>\n";
		$sql = "SELECT Nombre,NumeroCreditos,ID,CourseKeyID FROM courses_general 
				WHERE PlanID=". $PlanID." AND VisVersion=1 AND ".$area_search;
		if (!$bShowElectives) {
			$sql = $sql." AND CourseKeyID NOT IN (SELECT CourseID FROM courses_elective) ";		
		}
		$sql = $sql." ORDER BY Nombre";
		$result = $conn->query($sql);
		if ($result->num_rows>0) {
			$count = 1;
			while( $row_course = $result->fetch_assoc() ) {
				echo "<tr><td>".$count."</td><td>".$row_course["Nombre"]."</td><td align=\"center\">".$row_course["NumeroCreditos"]."</td><td>";
				echo "<button class=\"button btn_edit\" type=\"button\" onclick=\"location.href='view_syllabus.php?CourseKeyID=".$row_course["CourseKeyID"]."&ID=".$row_course["ID"]."'\"></button>";
				echo "</td></tr>\n";			
				$count++;
			}
		}
		echo "</table>\n";
	}
	$planea->closeConnection();
?>  
</div>
</div>
</body>
</html>
