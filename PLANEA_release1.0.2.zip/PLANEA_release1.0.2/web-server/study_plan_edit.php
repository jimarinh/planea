<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "SELECT * FROM study_plan WHERE ID=" . $_GET["planID"];
$result = $planea->conn->query($sql);
$row = $result->fetch_assoc();
header('Content-type: application/json');
echo json_encode($row);
$planea->closeConnection();
?>