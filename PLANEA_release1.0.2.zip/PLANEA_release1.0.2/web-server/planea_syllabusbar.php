<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="syllabus.php">Sílabos</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#<?php echo $helptopic;?>" target="PLANEA-help">?</a></li>
</ul>