<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "DELETE FROM users WHERE ID=" . $_GET["removeID"];
$planea->conn->query($sql);
$sql = "DELETE FROM users_assignments WHERE userID=" . $_GET["removeID"];
$planea->conn->query($sql);
$sql = "DELETE FROM users_coordinators WHERE userID=" . $_GET["removeID"];
$planea->conn->query($sql);
$sql = "DELETE FROM eval_courses WHERE UserID=" . $_GET["removeID"]." AND State=0";
$planea->conn->query($sql);
$sql = "UPDATE eval_courses SET UserID=1 WHERE UserID=". $_GET["removeID"]." AND State=1";
$planea->conn->query($sql);
$sql = "DELETE FROM eval_areas WHERE UserID=" . $_GET["removeID"]." AND State=0";
$planea->conn->query($sql);
$sql = "UPDATE eval_areas SET UserID=1 WHERE UserID=". $_GET["removeID"]." AND State=1";
$planea->conn->query($sql);
$sql = "UPDATE teacher_activities SET UserID=1 WHERE UserID=". $_GET["removeID"];
$planea->conn->query($sql);
$planea->closeConnection();
?>