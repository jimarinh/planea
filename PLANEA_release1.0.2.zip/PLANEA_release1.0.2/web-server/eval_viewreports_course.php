<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "SELECT * FROM eval_courses WHERE ID=" . $_GET["reportID"];
$result = $planea->conn->query($sql);
$row = $result->fetch_assoc();
header('Content-type: application/json');
$row["UnknownPrevSkills"] = $row["UnknownPrevSkills"];
$row["UncoveredTopics"] = $row["UncoveredTopics"];
$row["IrrelevantTopics"] = $row["IrrelevantTopics"];
$row["StudentProblems"] = $row["StudentProblems"];
$row["SuccessfulExp"] = $row["SuccessfulExp"];
$row["UnsuccessfulExp"] = $row["UnsuccessfulExp"];
$row["ImprovMeasures"] = $row["ImprovMeasures"];
echo json_encode($row);
$planea->closeConnection();
?>
