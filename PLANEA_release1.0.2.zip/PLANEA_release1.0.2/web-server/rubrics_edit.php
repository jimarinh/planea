<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<style>
	textarea  
	{  
		font-family:"Helvetica", Helvetica, sansserif;  
		font-size: 14px;
	}
	</style>
	<script>	
	function setModifiedFlag() { window.onbeforeunload = function() { return true; }; }
	function clearModifiedFlag() { window.onbeforeunload = null; return true; }

	function changeNewRubricType() {
		var rubricType = document.querySelector('input[name="newRubrictype"]:checked').value;
		document.getElementById("newNumCriteriaPanel").style.display = (rubricType==1) ? "block":"none";
		document.getElementById("newNumLevelsAnalytic").style.display = (rubricType==1) ? "inline":"none";
		document.getElementById("newNumLevelsHolistic").style.display = (rubricType!=1) ? "inline":"none";
	}
	function verifyNewRubric() {
		if (newRubricName.value.length==0) {
			alert("Debe especificar un nombre para la rúbrica");
			return false;
		}
		return true; 
	}
	function updateArrowBtns() {
		var btnup, btndn, pos, starpos;
		var items = document.getElementById("RubricTable").getElementsByTagName("tr");
		if (RubricType.value == 1) startpos = 2; else startpos = 1;
		for(pos=startpos;pos<items.length;pos++) {
			//Hide "Up" button for the first data row
			btnup = items[pos].getElementsByClassName("button btn_up");
			if (btnup.length>0) { btnup[0].style.display = (pos==startpos) ? "none" : "inline"; }
			//Hide "Down" button for the last data row
			btndn = items[pos].getElementsByClassName("button btn_down"); 
			if (btndn.length>0) { btndn[0].style.display = (pos==items.length-1) ? "none" : "inline"; }
			//Set the value of the "Pos" widget to reflect the position of the data row
			posinput = items[pos].getElementsByTagName("input");
			if (posinput.length>0) { posinput[0].value = pos-startpos+1; }
			//Set numeric values to each entry depending on the rubric type
			if (RubricType.value == 2) { //Holistic rubric
				var labelHolistic = items[pos].getElementsByTagName("label");
				if (labelHolistic.length>0) { labelHolistic[0].innerHTML = items.length - pos; }
			}
			if (RubricType.value == 3) { //Holistic rubric with descriptors by level 
				var cellValue = items[pos].getElementsByTagName("textarea");
				var labelsHolistic = items[pos].getElementsByTagName("label");	
				if (cellValue.length>0) { 
					var str = cellValue[0].value;
					for (i=0; i<labelsHolistic.length; i++) {					
						if (i+1 >= pos) {
							labelsHolistic[i].innerHTML = str.replace(/[\n]/g,"<br>"); 
						} else {
							labelsHolistic[i].innerHTML = ""; 
						}
					}
				}
			}
		}
	}
	function moveItem(Id, dir) {
		var tr1   = document.getElementById("row"+Id);
		if (dir == -1) { tr1.parentNode.insertBefore(tr1, tr1.previousSibling); } else { tr1.parentNode.insertBefore(tr1.nextSibling, tr1); }
		setModifiedFlag();
		updateArrowBtns();
	}
	function removeItem(Id) {	
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				var tr = document.getElementById("row"+Id);
				tr.parentNode.removeChild(tr);
				setModifiedFlag();
				updateArrowBtns();	
			}
		}
		xhttp.open("GET", "rubrics_removeentry.php?entryID="+Id, true);
		xhttp.send();
	}
	function updateInputListeners() {
		var ta = editRubric.getElementsByTagName("textarea");
		for(i=0; i<ta.length; i++) {
			ta[i].addEventListener("input", setModifiedFlag);
		}
	}
	function addEntry(RubricID) {	
		var items 	= document.getElementById("RubricTable").getElementsByTagName("tr");
		var position= items.length;
		var str = "";
		if (RubricType.value == 1) position--;
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				if (this.responseText.length>0) {
					var entryID = parseInt(this.responseText);
					var table = document.getElementById("RubricTable").getElementsByTagName("table");
					var tr_new = table[0].insertRow(-1); 
					var btn1 = "<button class=\"button btn_up\" type=\"button\" onclick=\"moveItem("+entryID+",-1)\"></button>";
					var btn2 = "<button class=\"button btn_down\" type=\"button\" onclick=\"moveItem("+entryID+",1)\"></button>"; 
					var btn3 = "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeItem("+entryID+")\"></button>"; 	
					var btn4 = "<input id=\"pos"+entryID+"\" name=\"pos"+entryID+"\" size=1 style=\"display:none\">";
					switch (parseInt(RubricType.value)) {
						case 1:
							str = "<th align=\"center\"><textarea name=\"Criteria"+entryID+"\" rows=2></textarea></th>\n";
							for(i=NumLevels.value;i>=1;i--) {
								str = str+"<td align=\"center\"><textarea name=\"cell"+(entryID*10+parseInt(i))+"\" rows=2></textarea></td>\n";
							}						
							break;
						case 2:
							str = "<th align=\"center\"><label>1</label></th><td><textarea name=\"cell"+entryID+"1\" rows=3 cols=60></textarea></td>\n";
							break;
						case 3:
							for(i=1;i<=NumLevels.value;i++) {								
								if (i == NumLevels.value) {											
									str = str+"<td align=\"center\"><textarea name=\"cell"+(entryID*10+1)+"\" rows=3 onblur=\"holisticCellUpdate()\"></textarea></td>\n";
								} else {
									str = str+"<td align=\"center\"><label></label></td>"; 
								}						
							}
							break;
					}
					tr_new.innerHTML = str+"<td>"+btn4+btn3+btn1+btn2+"</td>\n";
					tr_new.id = "row"+entryID;
					updateArrowBtns();
					updateInputListeners();
				}
			}
		}	
		xhttp.open("GET", "rubrics_addentry.php?RubricID="+RubricID+"&pos="+position, true);
		xhttp.send();
	}
	function holisticCellUpdate() {
		updateArrowBtns();
	}
	function changeNumLevels(RubricID) {
		var r;
		if (NumLevels.value < OldNumLevels.value) {
			r = confirm("El nivel o los niveles más altos se eliminarán.\n"+
					"Sin embargo, la información puede ser recuperada volviendo a seleccionar el número de niveles anterior a esta acción.\n"+
					"¿Desea continuar?"); 
		} else {
			r = confirm("Ha seleccionado aumentar el número de niveles, por lo que la información de los niveles más bajos se conservará.\n"+
					"¿Desea continuar?"); 
		}
		if (r == true) {
			document.getElementById("editRubric").submit();
		}
	}
	function changeRubricType(RubricID) {
		var r=false;
		var e = document.getElementById("RubricType");
		if (e.selectedIndex == -1) {
			return null;
		}
		switch (parseInt(e.options[e.selectedIndex].value)) {
			case 1:
				r = confirm("Advertencia: La información contenida en la rúbrica será usada como la información del nivel de desempeño más bajo.\n"+
					"Esta acción se puede deshacer seleccionando de nuevo el tipo original de la rúbrica.\n"+
					"¿Desea continuar?"); 
				break;
			case 2:
			case 3:
				r = confirm("Advertencia: Al modificar la estructura de la rúbrica se empleará solamente la información de uno de los niveles de desempeño.\n"+
					"Esta acción se puede deshacer seleccionando de nuevo el tipo original de la rúbrica.\n"+
					"¿Desea continuar?"); 
				break;
		}
		if (r == true) {
			document.getElementById("editRubric").submit();
		}
	}
	function autoSave() {
		var xhttp = new XMLHttpRequest();
		var formData = new FormData();
		serializeForPOST(editRubric, formData);
		xhttp.open("POST", "rubrics_save.php", true);
		xhttp.send(formData);
	}
	window.onload = function(){
		updateInputListeners();
		updateArrowBtns();
		setInterval("autoSave()", 60000);
	}
	</script>
	<script>
		var serializeForPOST = function (form, formData) {
			// Loop through each field in the form
			for (var i = 0; i < form.elements.length; i++) {
				var field = form.elements[i];
				// Don't serialize fields without a name, submits, buttons, file and reset inputs, and disabled fields
				if (!field.name || field.disabled || field.type === 'file' || field.type === 'reset' || field.type === 'submit' || field.type === 'button') continue;
				// If a multi-select, get all selections
				if (field.type === 'select-multiple') {
					for (var n = 0; n < field.options.length; n++) {
						if (!field.options[n].selected) continue;
						formData.append(field.name, field.options[n].value);
					}
				}
				// Convert field data to a query string
				else if ((field.type !== 'checkbox' && field.type !== 'radio') || field.checked) {
					formData.append(field.name, field.value);
				}
			}
		};
	</script>
</head>

<body>

<?php  
	require('planea_logosbar.php');
	$backurl = "#";
	if ( isset($_GET["backurl"]) ) {
		$backurl = $_GET["backurl"]; 
	}
	if ( isset($_POST["backurl"]) ) {
		$backurl = $_POST["backurl"]; 
	}

	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	$RubricID = -1;
	$RubricType = -1;
	$NumLevels = 0;
	$bNewRubric = true;
	
	$PlanID = 0;
	if ( isset($_GET["PlanID"]) ) { //New rubric associated to PlanID
		$PlanID = $_GET["PlanID"];
	}
	if ( isset($_POST["PlanID"]) ) {
		$PlanID = $_POST["PlanID"];
	}
	$CourseID = 0;
	if ( isset($_GET["CourseID"]) ) { //New rubric associated to CourseID	
		$CourseID = $_GET["CourseID"];
	}
	if ( isset($_POST["CourseID"]) ) {
		$CourseID = $_POST["CourseID"];
	}	
		
	$ActivityID = 0;
	if ( isset($_GET["ActID"]) ) { //New rubric associated to ActivityID
		$ActivityID = $_GET["ActID"];
	}
	if ( isset($_POST["ActID"]) ) { 
		$ActivityID = $_POST["ActID"];
	}
	
	if ( $ActivityID!=0 ) { //check permissions to edit
		$bPermission = $planea->checkPermission( $_SESSION["RoleID"], $_SESSION["UserID"], $CourseID, hexdec("8000") );
	} else { 
		$bPermission = $planea->checkPermission( $_SESSION["RoleID"], $_SESSION["UserID"], $CourseID, 64 );
	}
	if ( !$bPermission ) {
		exit("<p><font color=\"red\">No tiene permiso para acceder a esta sección</font><p>");
	}

	if ( isset($_GET["RubricID"]) ) { //Edit a rubric ID
		$RubricID = $_GET["RubricID"];
		$sql = "SELECT * FROM rubrics_general WHERE ID=".$RubricID;
		$result = $conn->query($sql);
		$row_desc = $result->fetch_assoc();
		$RubricType = $row_desc["Type"];
		$NumLevels = $row_desc["NumLevels"];
		$RubricName = $row_desc["Name"];
		$RubricDescription = $row_desc["Description"];
		$bNewRubric = false;
	}
	//Click on "Next" button when creating a new rubric
	if ( isset($_POST["newRubrictype"]) ) {
		$scope = 0;
		$ActivityType = 0;
		if ( ($CourseID!=0) && ($ActivityID==0))  { $scope = 1; }
		if ( ($CourseID!=0) && ($ActivityID!=0))  { $scope = 2; $ActivityType = 4; }
		$RubricType = $_POST["newRubrictype"];
		$RubricName = $_POST["newRubricName"];
		$RubricDescription = "";
		$bLevelDescription = false;
		$sql_levels = "";
		if ($RubricType == 1) {
			$NumLevels = $_POST["newNumLevelsAnalytic"];
			if ($NumLevels>4) { 
				switch($NumLevels) {
					case 5: $sql_levels = "'Necesita mejorar','Principiante','Aceptable','Proficiente'"; break;
					case 6: $sql_levels = "'Insatisfactorio','En desarrollo','Satisfactorio','Excepcional'"; break;
					case 7: $sql_levels = "'Necesita mejorar','En desarrollo','Suficiente','Sobre el promedio'"; break;
				}
				$NumLevels=4;
				$bLevelDescription = true;
			}	
		} else {
			$NumLevels = $_POST["newNumLevelsHolistic"];
		}
		$NewNumLevels = $NumLevels;
		if ($RubricType==2) { 
			$NewNumLevels = 1; 
		}
		$sql = "INSERT INTO rubrics_general (Name,Type,NumLevels,Scope) 
				VALUES ('".$RubricName."',".$RubricType.",".$NewNumLevels.",".$scope.")";
		$result = $conn->query($sql);
		if ($result == true) {
			$RubricID = $conn->insert_id;
			//Insert description of levels
			if (!$bLevelDescription) {
				$sql = "INSERT INTO rubrics_entries(RubricID,Position) VALUES (".$RubricID.",0)";				
			} else {
				$sql = "INSERT INTO rubrics_entries(RubricID,DescLevel1,DescLevel2,DescLevel3,DescLevel4,Position) 
						VALUES (".$RubricID.",".$sql_levels.",0)";
			}
			$conn->query($sql);
			//Insert criteria rows when apply
			$numrows = 0;
			switch($RubricType) {
				case 1: if (isset($_POST["newNumCriteria"])) { 
					$numrows = $_POST["newNumCriteria"]; }; 
					break;
				case 2: $numrows = $NumLevels; 
					break; 
				case 3: $numrows = 1; 
					break; 
			}
			for($i=1;$i<=$numrows;$i++) {
				$sql = "INSERT INTO rubrics_entries(RubricID,Position) VALUES (".$RubricID.",".$i.")";
				$conn->query($sql);			
			}
			if ( ($PlanID !=0) || ($CourseID !=0) ) {
				$sql = "INSERT INTO rubrics_assoc (RubricID,PlanID,CourseID,RapSkillID,RapSkillType) 
						VALUES (".$RubricID.",".$PlanID.",".$CourseID.",".$ActivityID.",".$ActivityType.")";
						$result = $conn->query($sql);
			}
		}
		$bNewRubric = false;
	}
	//Save rubric configuration...
	if ( isset($_POST["RubricID"]) ) { 
		$RubricID = $_POST["RubricID"];
		$RubricType = $_POST["RubricType"];
		$NumLevels = $_POST["NumLevels"];
		$RubricName = $_POST["RubricName"];
		$RubricDescription = $_POST["RubricDescription"];
		$planea->saveRubric();
		$bNewRubric = false;
	}
?>


<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="<?php echo $backurl;?>">Regresar</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#teacher-rubrics-<?php if ($bNewRubric) echo "new"; else echo "edit";?>" target="PLANEA-help">?</a></li>
</ul>


<form class="planeaForm" id="newRubric" action="rubrics_edit.php" method="POST" 
	onsubmit="return verifyNewRubric()"
	<?php if (!$bNewRubric) echo "style=\"display:none\"";?>>
	<p> 
	Seleccione el tipo de rúbrica, el número de niveles de desempeño y el número de criterios (solo para la rúbrica analítica).
	</p>
	<ul>
	<li><b>Rúbrica Analítica:</b> Rúbrica de dos dimensiones que permite realizar la evaluación usando múltiples criterios. 
		En esta rúbrica se hacen explícitos los niveles de desempeño y los criterios de evaluación. 
		</li> 
	<li><b>Rúbrica Holística:</b> Rúbrica de una dimensión, con un único criterio, en la que el desempeño se evalúa 
		con base en descriptores para cada nivel de desempeño.</li>
	</ul>
	<br>
	<table>
	<tr>
		<td>
			<input type="radio" name="newRubrictype" value=1 onchange="changeNewRubricType()" checked>
			Rúbrica analítica
			<br>
			<img src="images/rubrics-analytic.png" alt="Rúbrica Analítica" style="width:150px">		
		</td>
	</tr><tr>
		<td>
			<input type="radio" name="newRubrictype" value=2 onchange="changeNewRubricType()">
			Rúbrica holística con descriptores generales
			<br>
			<img src="images/rubrics-holistic1.png" alt="Rúbrica Holística 1" style="width:150px">
		</td>
	</tr><tr>
		<td>
			<input type="radio" name="newRubrictype" value=3 onchange="changeNewRubricType()">
			Rúbrica holística con descriptores por nivel
			<br>
			<img src="images/rubrics-holistic2.png" alt="Rúbrica Holística 2" style="width:150px">
		</td>
	</tr>
	</table>
	<br><br>
	Nombre de la rúbrica: <input type="text" id="newRubricName" name="newRubricName" size=100> 
	<br><br>
	Niveles de desempeño: 
	<select id="newNumLevelsAnalytic" name="newNumLevelsAnalytic">
		<option value=1 selected>1</option>
		<option value=2>2</option>
		<option value=3>3</option>
		<option value=4>4</option>	
		<option value=5>Proficiente/Aceptable/Principiante/Necesita mejorar</option>
		<option value=6>Excepcional/Satisfactorio/En desarrollo/Insatisfactorio</option>
		<option value=7>Sobre el promedio/Suficiente/En desarrollo/Necesita mejorar</option>		
	</select>
	<select id="newNumLevelsHolistic" name="newNumLevelsHolistic" style="display:none">
		<option value=1 selected>1</option>
		<option value=2>2</option>
		<option value=3>3</option>
		<option value=4>4</option>	
	</select>
	<br><br>
	<div id="newNumCriteriaPanel">
		Número de criterios: <input type="number" id="newNumCriteria" name="newNumCriteria" min=1 max=10>
	</div>
	<br>
	<input type="submit" value="Continuar">
	<input type="number" name="PlanID" style="display:none" value="<?php echo $PlanID; ?>">
	<input type="number" name="CourseID" style="display:none" value="<?php echo $CourseID; ?>">
	<input type="number" name="ActID" style="display:none" value="<?php echo $ActivityID; ?>">
	<input name="backurl" style="display:none" value="<?php echo $backurl; ?>">
</form>


<form class="planeaForm" id="editRubric" action="rubrics_edit.php" method="POST" onsubmit="return clearModifiedFlag()" 
	<?php if ($bNewRubric) echo "style=\"display:none\"";?>>
	Nombre de la rúbrica: <input type="text" name="RubricName" size=100 value="<?php echo $RubricName; ?>" oninput="setModifiedFlag()">  
	<br><br>
	Descripción: <br>
	<textarea name="RubricDescription" rows=3 cols=110><?php echo $RubricDescription; ?></textarea>	
	<br><br>
	Tipo de rúbrica:
	<select id="RubricType" name="RubricType" onchange="changeRubricType(<?php echo $RubricID; ?>)">
		<option value=1 <?php if ($RubricType==1) echo "selected";?>>Rúbrica analítica</option>
		<option value=2 <?php if ($RubricType==2) echo "selected";?>>Rúbrica holística con descriptores generales</option>
		<option value=3 <?php if ($RubricType==3) echo "selected";?>>Rúbrica holística con descriptores por nivel</option>	
	</select>
	<br><br>
	<div id="NumLevelsFrame" <?php if ($RubricType==2) echo "style=\"display:none\"";?>>
	Niveles de desempeño:
	<select id="NumLevels" name="NumLevels" onchange="changeNumLevels(<?php echo $RubricID; ?>)">
		<option value=1 <?php if ($NumLevels==1) echo "selected";?>>1</option>
		<option value=2 <?php if ($NumLevels==2) echo "selected";?>>2</option>
		<option value=3 <?php if ($NumLevels==3) echo "selected";?>>3</option>
		<option value=4 <?php if ($NumLevels==4) echo "selected";?>>4</option>	
	</select>
	</div>
	<br><br>
	<div id="RubricTable">
	<?php $planea->showRubric($RubricID,false); ?>
	</div>
	<br>
	<input type="submit" value="Guardar">
	<input type="number" name="RubricID" style="display:none" value="<?php echo $RubricID; ?>">
	<input type="number" name="OldNumLevels" id="OldNumLevels" style="display:none" value="<?php echo $NumLevels; ?>">
	<input type="number" name="OldRubricType" id="OldRubricType" style="display:none" value="<?php echo $RubricType; ?>">
	<input type="number" name="PlanID" style="display:none" value="<?php echo $PlanID; ?>">
	<input type="number" name="CourseID" style="display:none" value="<?php echo $CourseID; ?>">
	<input type="number" name="ActID" style="display:none" value="<?php echo $ActivityID; ?>">
	<input name="backurl" style="display:none" value="<?php echo $backurl; ?>">
</form>

<?php $planea->closeConnection(); ?>

</body>
</html>