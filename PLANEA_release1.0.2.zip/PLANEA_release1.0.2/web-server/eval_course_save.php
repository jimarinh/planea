<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();  
$userID = $_POST["UserID"];
unset($_POST["UserID"]);
$planea->saveEvalReportByCourse($userID, 0);
$planea->closeConnection();
?>

