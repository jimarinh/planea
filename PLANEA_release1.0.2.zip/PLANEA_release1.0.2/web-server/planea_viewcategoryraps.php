<?php  
	require('planea_basics.php');

	function displayCoursesvsRAPs( $conn, $report_title, $planID, $showElectives, $showTooltip )
	{	
		//Pone el título de la página
		$strheading = "<h2>" . $report_title . "</h2>";
	  
		//Captura el listado de cursos
		if ($showElectives) 
			$sql = "SELECT ID,Semestre,Nombre FROM courses_general 
					WHERE PlanID=".$planID." AND VisVersion=1 ORDER BY Semestre, Nombre";
		else
			$sql = "SELECT ID,Semestre,Nombre FROM courses_general 
					WHERE PlanID=".$planID." AND VisVersion=1 AND CourseKeyID NOT IN (SELECT CourseID FROM courses_elective) ORDER BY Semestre, Nombre";
		
		$result_courses = $conn->query($sql);
		$ncourses = $result_courses->num_rows;
	  
		//Captura el listado de RAPs
		$sql = "SELECT ilo_categories.* FROM ilo_categories INNER JOIN study_plan
				ON ilo_categories.SetID = study_plan.ILOSetID WHERE study_plan.ID=".$planID." ORDER BY Position";

		$result_categoryrap  = $conn->query($sql);
		$nraps = $result_categoryrap->num_rows;
				
		if ($nraps==0) {
			$strheading = $strheading."<p class=\"warningbox\">
				<b>¡Advertencia!</b> No se han asignado categorías institucionales de RAPs al plan de estudios</p>\n";
		}
		
		//Pone el listado de categorías institucionales de RAPs 
		$strheading = $strheading. "<p><small>";
		for ($i = 0; $i<$nraps; $i++) {	
			$categoryrap = $result_categoryrap->fetch_assoc();
			$strheading = $strheading. $categoryrap["Position"].". ".$categoryrap["Value"]."<br>\n";
		}
		$strheading = $strheading. "</small></p>\n";
		
		//Pone el encabezado con el listado de categorías
		$result_categoryrap->data_seek(0);
		$strtable = "<table id=\"RapTb\" style=\"width:100%\"> <tr>\n<th>Sem</th><th>Curso</th>\n";
		$nraps_n2 = 0;
		$instraps_list = array();
		$instraps_names = array();
		while( $categoryrap = $result_categoryrap->fetch_assoc() ) {
			$strtable = $strtable. "<th>".$categoryrap["Position"]."</th>\n";
			$instraps_list[$nraps_n2] = $categoryrap["ID"];
			$instraps_names[$nraps_n2] = $categoryrap["Position"].". ".$categoryrap["Value"];
			$nraps_n2++;
		}
		$strtable = $strtable. "</tr>\n";
		
		$courseID = 0;
		//Por cada curso, busca los RAPs asociados y los ubica en la tabla
		for($i = 0; $i < $ncourses; $i++) {
			//Limpia las banderas 
			$courseRaps = array();
			for ($j = 0; $j<$nraps_n2; $j++) {
				$courseRaps[$j] = 0;
			}
				
			//Captura la información del curso
			$course = $result_courses->fetch_assoc();
		
			//Captura los RAPs para dicho curso
			$sql = "SELECT * FROM courses_ilos WHERE CourseID=" . $course["ID"] ." ORDER BY Position";
			$result_categoryrapcourse  = $conn->query($sql);
			
			while( $categoryrapinfo = $result_categoryrapcourse->fetch_assoc() ) {
				$categorycatID_check  = $categoryrapinfo["CategoryID"]; 
				for ($j = 0; $j<$nraps_n2; $j++) {	
					$categorycatID = $instraps_list[$j];
					if ( $categorycatID_check == $categorycatID ) {
						$courseRaps[$j]=1;
					}
				}
			}
		
			$strtable = $strtable. "<tr> <td><small>" . $course["Semestre"] . "</small></td> <td><small>" . $course["Nombre"] . "</small></td> \n";
			for ($j = 0; $j<$nraps_n2; $j++)
			{	
				$info = "";
				if ( $courseRaps[$j] == 1 ) { 
					$info = $info . "X"; 
				} else {
					$info = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
				}
				if ($showTooltip) 
					$strtable = $strtable. "<td style=\"text-align:center\"><div class=\"tooltip\"><small>". $info. "</small><span class=\"tooltiptext\">".$instraps_names[$j]."</span></div></td>\n";
				else 
					$strtable = $strtable. "<td style=\"text-align:center\"><small>". $info. "</small></td>\n";
			}
			$strtable = $strtable. "</tr>\n";
		}
		$strtable = $strtable. "</table>";  
		echo $strheading.$strtable;
	}

	
	function displayRAPCoursesvsCategories( $conn, $report_title, $planID, $showElectives, $catID )
	{	
		//Pone el título de la página
		$strheading = "<h2>" . $report_title . "</h2>";
	  
		//Captura el listado de RAPs
		$sql = "SELECT ilo_categories.* FROM ilo_categories INNER JOIN study_plan
				ON ilo_categories.SetID = study_plan.ILOSetID WHERE study_plan.ID=".$planID." ORDER BY Position";
		$result_categoryrap  = $conn->query($sql);
		$nraps = $result_categoryrap->num_rows;
		if ($nraps==0) {
			$strheading = $strheading."<p class=\"warningbox\">
				<b>¡Advertencia!</b> No se han asignado categorías institucionales de RAPs al plan de estudios</p>\n";
		}
		
		//Pone el listado de categorías institucionales de RAPs
		$strheading = $strheading."<select id=\"rapSelection\" onchange=\"changeRAP()\">";
		$strheading = $strheading. "<option value=0>[Escoja una Categoría...]</option>";
		for ($i = 0; $i<$nraps; $i++) {	
			$categoryrap = $result_categoryrap->fetch_assoc();
			$strheading = $strheading. "<option value=\"".$categoryrap["ID"]."\"";
			if ($categoryrap["ID"]==$catID) { $strheading = $strheading." selected"; }
			$strheading = $strheading.">".$categoryrap["Position"].". ".$categoryrap["Value"]."</option>\n";
		}
		$strheading = $strheading. "</select><br><br>\n";
		
		if ($catID == 0) {
			echo $strheading;
			return;
		}
		
		//Captura el RAPS de curso asociados a cada categoría institucional
		if ($showElectives) 
			$sql = "SELECT courses_general.ID,courses_general.Semestre,courses_general.Nombre,courses_ilos.CategoryID,courses_ilos.ProgramILOID,courses_ilos.Text,courses_ilos.Position FROM courses_ilos 
					INNER JOIN courses_general ON courses_ilos.CourseID = courses_general.ID 
					WHERE courses_general.PlanID=".$planID." AND courses_general.VisVersion=1 AND courses_ilos.CategoryID=".$catID." ORDER BY Semestre, Nombre";
		else
			$sql = "SELECT courses_general.ID,courses_general.Semestre,courses_general.Nombre,courses_ilos.CategoryID,courses_ilos.ProgramILOID,courses_ilos.Text,courses_ilos.Position FROM courses_ilos 
					INNER JOIN courses_general ON courses_ilos.CourseID = courses_general.ID 
					WHERE courses_general.PlanID=".$planID." AND courses_general.VisVersion=1 
					AND CourseKeyID NOT IN (SELECT CourseID FROM courses_elective) AND courses_ilos.CategoryID=".$catID." ORDER BY Semestre, Nombre";
		
		$result_courses = $conn->query($sql);
		$ncourses = $result_courses->num_rows;
	  
		//Pone el encabezado de la Tabla
		$strtable = "<table id=\"RapTb\" style=\"width:100%\"> <tr>\n<th>Sem</th><th>Curso</th><th>RAPs del Curso</th></tr>\n";
		$courseID = 0;
		
		//Pone cada RAP de curso asociado a cada categoría
		for($i = 0; $i < $ncourses; $i++) {	
			//Captura la información del curso
			$course = $result_courses->fetch_assoc();
		
			if ($course["ID"]!=$courseID) {
				$strtable = $strtable. "<tr> <td><small>" . $course["Semestre"] . "</small></td> <td><small>" . $course["Nombre"] . "</small></td> \n";
				$courseID = $course["ID"];
			} else {
				$strtable = $strtable. "<tr> <td></td> <td></td> \n";
			}
			$strtable = $strtable. "<td><small>". $course["Position"].". ".$course["Text"]. "</small></td>\n";
			$strtable = $strtable. "</tr>\n";
		}
		$strtable = $strtable. "</table>";  
		echo $strheading.$strtable;
	}
	
	
	function displayCoursesWithNoAssociation( $conn, $report_title, $planID, $showElectives )
	{	
		//Pone el título de la página
		$strheading = "<h2>" . $report_title . "</h2>";
	  
		//Verifica si hay categorías asociadas al plan de estudios
		$sql = "SELECT ilo_categories.* FROM ilo_categories INNER JOIN study_plan
				ON ilo_categories.SetID = study_plan.ILOSetID WHERE study_plan.ID=".$planID." ORDER BY Position";
		$result_categoryrap  = $conn->query($sql);
		$nraps = $result_categoryrap->num_rows;
		if ($nraps==0) {
			$strheading = $strheading."<p class=\"warningbox\">
				<b>¡Advertencia!</b> No se han asignado categorías institucionales de RAPs al plan de estudios</p>\n";
		}  
	  
		//Captura los RAPS de curso que no tienen asociada categoría
		if ($showElectives) 
			$sql = "SELECT courses_general.ID,courses_general.Semestre,courses_general.Nombre,courses_ilos.CategoryID,courses_ilos.ProgramILOID,courses_ilos.Text,courses_ilos.Position FROM courses_ilos 
					INNER JOIN courses_general ON courses_ilos.CourseID = courses_general.ID 
					WHERE courses_general.PlanID=".$planID." AND courses_general.VisVersion=1 AND courses_ilos.CategoryID=0 ORDER BY Semestre, Nombre";
		else
			$sql = "SELECT courses_general.ID,courses_general.Semestre,courses_general.Nombre,courses_ilos.CategoryID,courses_ilos.ProgramILOID,courses_ilos.Text,courses_ilos.Position FROM courses_ilos 
					INNER JOIN courses_general ON courses_ilos.CourseID = courses_general.ID 
					WHERE courses_general.PlanID=".$planID." AND courses_general.VisVersion=1 
					AND CourseKeyID NOT IN (SELECT CourseID FROM courses_elective) AND courses_ilos.CategoryID=0 ORDER BY Semestre, Nombre";
		
		$result_courses = $conn->query($sql);
		$ncourses = $result_courses->num_rows;
	  
		//Pone el encabezado de la Tabla
		$strtable = "<table id=\"RapTb\" style=\"width:100%\"> <tr>\n<th>Sem</th><th>Curso</th><th>RAPs del Curso</th></tr>\n";
		$courseID = 0;
		
		//Pone cada RAP de curso que no tiene asociado categoría
		for($i = 0; $i < $ncourses; $i++) {	
			//Captura la información del curso
			$course = $result_courses->fetch_assoc();
		
			if ($course["ID"]!=$courseID) {
				$strtable = $strtable. "<tr> <td><small>" . $course["Semestre"] . "</small></td> <td><small>" . $course["Nombre"] . "</small></td> \n";
				$courseID = $course["ID"];
			} else {
				$strtable = $strtable. "<tr> <td></td> <td></td> \n";
			}
			$strtable = $strtable. "<td><small>". $course["Position"].". ".$course["Text"]. "</small></td>\n";
			$strtable = $strtable. "</tr>\n";
		}
		$strtable = $strtable. "</table>";  
		echo $strheading.$strtable;
	}
	
	
	$planea = new planea();
	$conn = $planea->openConnection();
	if ( $_GET["reportID"] == 1) {
		//Visualiza el reporte de cursos vs categorías institucionales de RAPs
		displayCoursesvsRAPs( $conn, "Cursos vs. categorías institucionales de RAPs", $_GET["PlanID"], $_GET["showElect"]=="true", $_GET["showTooltip"]=="true" );
	}
	if ( $_GET["reportID"] == 2) {
		//Visualiza el reporte de RAPs de curso vs categorías
		displayRAPCoursesvsCategories( $conn, "RAPs de cursos vs. categorías institucionales de RAPs ", $_GET["PlanID"], $_GET["showElect"]=="true", $_GET["catID"] );
	}
	if ( $_GET["reportID"] == 3) {
		//Visualiza el reporte de cursos sin categorías asociadas
		displayCoursesWithNoAssociation( $conn, "RAPs de cursos sin asociar categoría institucional de RAP", $_GET["PlanID"], $_GET["showElect"]=="true");
	}
	$planea->closeConnection();
?>