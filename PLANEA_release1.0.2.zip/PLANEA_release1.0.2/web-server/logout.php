<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="ISO-8859-1">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
</head>

<body>

<?php  
	require('planea_logosbar.php');
	session_unset(); 
	session_destroy(); 
?>
<p>Ha cerrado exitosamente la sesión</p>
<p><a href="login.php">Ingresar de nuevo</a></p>
</body>
</html>
