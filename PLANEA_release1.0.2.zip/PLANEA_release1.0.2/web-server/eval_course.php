<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<style>
	textarea  
	{  
		font-family:"Helvetica", Helvetica, sansserif;  
		font-size: 16px;
		color: darkblue;
	}
	</style>
	<script>
	function noComments(Id) {
		var c = document.getElementById("chk"+Id);
		var e = document.getElementById("evalText"+Id);
		if (c.checked) {
			e.value = "";
			e.style = "display:none";
		} else {
			e.style = "width: 100%;";
		}
	}
	function updateFailedStudents() {
		var nstudents = document.getElementById("NStudents").value;
		var nfailedstudents = document.getElementById("NFailedStudents").value;
		if (nfailedstudents > nstudents) alert("El número de estudiantes que reprueban no puede ser superior al número de estudiantes");
		setModifiedFlag();
	}
	function updateArea(userID, semesterName) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				submittedAreaReportsList.innerHTML = this.responseText;
				if (this.responseText.length==0) {
					submittedAreaReports.style = "display:none";
				} else {
					submittedAreaReports.style = "display:block";
				}
			}
		};
		xhttp.open("GET", "planea_getsubmitted_areareports.php?UserID="+userID+"&Semester="+semesterName, true);
		xhttp.send();
	}
	function changeSemester(userID) {
		var e = document.getElementById("SemesterID");
		if (e.selectedIndex == -1)
			return null;
		var semesterName = e.options[e.selectedIndex].text;
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				submittedReportsList.innerHTML = this.responseText;
				evalForm.style = "display:none";
				updateArea(userID, semesterName);
			}
		};
		xhttp.open("GET", "planea_getsubmitted_evalreports.php?UserID="+userID+"&Semester="+semesterName, true);
		xhttp.send();	
	}
	function autoSave(userID) {
		var xhttp = new XMLHttpRequest();
		var formData = new FormData();
		serializeForPOST(evalForm, formData);
		formData.append("UserID", userID);
		xhttp.open("POST", "eval_course_save.php", true);
		xhttp.send(formData);
	}
	</script>
	<script>
		function setModifiedFlag() { window.onbeforeunload = function() { return true; }; }
		function clearModifiedFlag() { window.onbeforeunload = null; return true; }
		var serializeForPOST = function (form, formData) {
			// Loop through each field in the form
			for (var i = 0; i < form.elements.length; i++) {
				var field = form.elements[i];
				// Don't serialize fields without a name, submits, buttons, file and reset inputs, and disabled fields
				if (!field.name || field.disabled || field.type === 'file' || field.type === 'reset' || field.type === 'submit' || field.type === 'button') continue;
				// If a multi-select, get all selections
				if (field.type === 'select-multiple') {
					for (var n = 0; n < field.options.length; n++) {
						if (!field.options[n].selected) continue;
						formData.append(field.name, field.options[n].value);
					}
				}
				// Convert field data to a query string
				else if ((field.type !== 'checkbox' && field.type !== 'radio') || field.checked) {
					formData.append(field.name, field.value);
				}
			}
		};
	</script>
</head>

<body>


<?php  
	require('planea_logosbar.php');
?>


<?php
require('planea_basics.php');
$planea = new planea();
$conn = $planea->openConnection();  
$displayForm = false;
$CourseName = "";
$SemesterName = "";
$NStudents = 0;
$NFailedStudents = 0;
$UnknownPrevSkills = "";
$UncoveredTopics = "";
$IrrelevantTopics = "";
$StudentProblems = "";
$SuccessfulExp = "";
$UnsuccessfulExp = "";
$ImprovMeasures = "";
$State = 1;
$EvalID = -1;

if ($_SESSION["RoleID"]==planea::roleUser) {
	//If course is opened for evaluation...
	if (isset($_GET["ID"]) && isset($_GET["SemesterID"])) {
		$displayForm = true;
		$SemesterName = $_GET["SemesterID"];
		$EvalID = $_GET["ID"];
		echo "<script>window.onload = function() { setInterval(\"autoSave(".$_SESSION["UserID"].")\", 60000); };</script>";
	}
	//If click on save report...
	if (isset($_POST["BtnAction"])) {
		if ($_POST["BtnAction"] == "Guardar") {
			$State = 0; 
			$displayForm = true;
		} else {
			$State = 1;
			$displayForm = false;
		}
		unset($_POST["BtnAction"]);
		$EvalID = $_POST["ID"];
		$planea->saveEvalReportByCourse($_SESSION["UserID"], $State);
	}
	if ($displayForm) {
		$sql = "SELECT courses_plan.Nombre, eval_courses.* 
				FROM eval_courses JOIN courses_plan ON eval_courses.CourseKeyID = courses_plan.ID 
				WHERE eval_courses.ID = ".$EvalID;
		$result = $conn->query($sql);
		if ($result->num_rows > 0)  {  
			$row = $result->fetch_assoc();	
			$CourseName = $row["Nombre"];
			$NStudents = $row["NStudents"];
			$NFailedStudents = $row["NFailedStudents"];
			$UnknownPrevSkills = $row["UnknownPrevSkills"];
			$UncoveredTopics = $row["UncoveredTopics"];
			$IrrelevantTopics = $row["IrrelevantTopics"];
			$StudentProblems = $row["StudentProblems"];
			$SuccessfulExp = $row["SuccessfulExp"];
			$UnsuccessfulExp = $row["UnsuccessfulExp"];
			$ImprovMeasures = $row["ImprovMeasures"];
			$State = $row["State"];
		}
	}
}
?>


<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="eval_course.php">Evaluación Curricular</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#teacher-eval<?php if ($displayForm) { echo "-course"; } ?>" target="PLANEA-help">?</a></li>
</ul>


<div <?php if ($displayForm) { echo "style=\"display:none\""; } ?>>

<div class="planeaForm">
	<p>Mis espacios académicos <b>pendientes</b> para evaluar: </p>
	<ul>
	<?php $planea->showUserEvalReports( $_SESSION["UserID"] ); ?>
	</ul>
</div>

<div class="planeaForm">
	<p>Mis áreas como colaborador que están <b>pendientes</b> por ingresar evaluación: </p>
	<ul>
	<?php echo $planea->showCollaboratorEvalReports( $_SESSION["UserID"] ); ?>
	</ul>
</div>

<div class="planeaForm">
	<p>Mis reportes de evaluación <b>enviados</b> el semestre 
	<select id="SemesterID" name="SemesterID" onchange="changeSemester(<?php echo $_SESSION["UserID"]; ?>)">
	<?php 
		$SemesterName = $planea->showSemesterList( $SemesterName ); 
	?>
	</select></p>
	<ul id="submittedReportsList">
	<?php $planea->showUserSubmittedEvalReports( $_SESSION["UserID"], $SemesterName ); ?>
	</ul>
	<?php $strAreaReports = $planea->showCollaboratorSubmittedEvalReports( $_SESSION["UserID"], $SemesterName ); ?>
	<div <?php if (empty($strAreaReports)) { echo "style=\"display:none\""; } ?> id="submittedAreaReports">Como colaborador de área o núcleo temático:
	<ul id="submittedAreaReportsList">
	<?php echo $strAreaReports; ?>
	</ul>
	</div>
</div>

</div>

<form class="planeaForm" id="evalForm" action="eval_course.php" method="POST" onsubmit="return clearModifiedFlag();" <?php if (!$displayForm) { echo "style=\"display:none\""; } ?>>
<b>Curso</b>: <?php echo $CourseName; ?>  &nbsp;  <b>Semestre</b>: <?php echo $SemesterName; ?> <br> <br>
<b>Número de estudiantes</b>: <input type="number" id="NStudents" name="NStudents" min=1 max=200 value="<?php echo $NStudents; ?>" onchange="updateFailedStudents()"> &nbsp; 
<b>Número de estudiantes que <u>reprueban</u></b>: <input type="number" id="NFailedStudents" name="NFailedStudents" min=0 max=200 value="<?php echo $NFailedStudents; ?>" onchange="updateFailedStudents()"> <br> <br>
<div <?php if ($State==1) { echo "style=\"display:none\""; } ?>><i>Para las siguientes preguntas, marque la casilla sí la pregunta no aplica o no tiene comentarios al respecto</i> <br> <br> </div>

<b>¿Qué conocimientos o habilidades <u>previas</u> se esperaba de los estudiantes y tenían deficiencias?</b>: 
<br><div <?php if ($State==1) { echo "style=\"display:none\""; } ?>><input type="checkbox" id="chk1" onchange="noComments(1)">No aplica/Sin comentarios</div>
<textarea id="evalText1" name="UnknownPrevSkills" rows=6 style="width: 100%;" onchange="setModifiedFlag()" <?php if ($State==1) { echo "readonly"; } ?>><?php echo $UnknownPrevSkills; ?></textarea> <br> <br>

<b>¿Qué temas o unidades de aprendizaje del curso <u>no alcanzó</u> a cubrir en el desarrollo del semestre?</b>: 
<br><div <?php if ($State==1) { echo "style=\"display:none\""; } ?>><input type="checkbox" id="chk2" onchange="noComments(2)">No aplica/Sin comentarios</div>
<textarea id="evalText2" name="UncoveredTopics" rows=6 style="width: 100%;" onchange="setModifiedFlag()" <?php if ($State==1) { echo "readonly"; } ?>><?php echo $UncoveredTopics; ?></textarea> <br> <br>

<b>¿Qué temas o unidades de aprendizaje del curso considera que son <u>irrelevantes</u> y se podrían suprimir del sílabo?</b>: 
<br><div <?php if ($State==1) { echo "style=\"display:none\""; } ?>><input type="checkbox" id="chk3" onchange="noComments(3)">No aplica/Sin comentarios</div>
<textarea id="evalText3" name="IrrelevantTopics" rows=6 style="width: 100%;" onchange="setModifiedFlag()" <?php if ($State==1) { echo "readonly"; } ?>><?php echo $IrrelevantTopics; ?></textarea> <br> <br>

<b>¿Qué <u>deficiencias de los estudiantes</u> encontró para el desarrollo del curso?</b>: 
<br><div <?php if ($State==1) { echo "style=\"display:none\""; } ?>><input type="checkbox" id="chk4" onchange="noComments(4)">No aplica/Sin comentarios</div>
<textarea id="evalText4" name="StudentProblems" rows=6 style="width: 100%;" onchange="setModifiedFlag()" <?php if ($State==1) { echo "readonly"; } ?>><?php echo $StudentProblems; ?></textarea> <br> <br>

<b>¿Qué experiencias <u>exitosas</u> tuvo en el desarrollo del curso?</b>: 
<br><div <?php if ($State==1) { echo "style=\"display:none\""; } ?>><input type="checkbox" id="chk5" onchange="noComments(5)">No aplica/Sin comentarios</div>
<textarea id="evalText5" name="SuccessfulExp" rows=6 style="width: 100%;" onchange="setModifiedFlag()" <?php if ($State==1) { echo "readonly"; } ?>><?php echo $SuccessfulExp; ?></textarea> <br> <br>

<b>¿Qué experiencias <u>no exitosas</u> tuvo en el desarrollo del curso?</b>: 
<br><div <?php if ($State==1) { echo "style=\"display:none\""; } ?>><input type="checkbox" id="chk6" onchange="noComments(6)">No aplica/Sin comentarios</div>
<textarea id="evalText6" name="UnsuccessfulExp" rows=6 style="width: 100%;" onchange="setModifiedFlag()" <?php if ($State==1) { echo "readonly"; } ?>><?php echo $UnsuccessfulExp; ?></textarea> <br> <br>

<b>¿Qué <u>acciones de mejora</u> sugiere para el desarrollo del curso el próximo semestre o algún cambio en el sílabo del curso?</b>: 
<br><div <?php if ($State==1) { echo "style=\"display:none\""; } ?>><input type="checkbox" id="chk7" onchange="noComments(7)">No aplica/Sin comentarios</div>
<textarea id="evalText7" name="ImprovMeasures" rows=6 style="width: 100%;" onchange="setModifiedFlag()" <?php if ($State==1) { echo "readonly"; } ?>><?php echo $ImprovMeasures; ?></textarea> <br> <br>

<input type="text" name="ID" value="<?php echo $EvalID ?>" style="display:none">
<input type="submit" name="BtnAction" value="Guardar" <?php if ($State==1) { echo "style=\"display:none\""; } ?>>
&nbsp; &nbsp;
<input type="submit" name="BtnAction" value="Guardar & Enviar Evaluación" <?php if ($State==1) { echo "style=\"display:none\""; } ?>>
</form>

<?php $planea->closeConnection(); ?>

</body>
</html>
