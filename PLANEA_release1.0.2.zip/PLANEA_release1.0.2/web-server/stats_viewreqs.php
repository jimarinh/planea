<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script type="text/javascript" language="javascript" src="stats_viewreqs.js"></script> 
	<script>
		var compactview = true;
		var canvas = null;
		var zoomScale = 1.0;
		var courses = [];
		var reqs = [];
		var electives = [];
		var xprev = 0, yprev = 0, tx = 0, ty = 0;
		var bScrolling = false;
		function renderReqs() {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var obj = JSON.parse(this.responseText);
					courses = obj.Courses;
					reqs = obj.Reqs;
					electives = obj.Electives;
					canvas = document.getElementById("myCanvas");
					renderCourseDependencies(canvas, courses, reqs, electives, zoomScale, 0, 0);
				}
			};
			xhttp.open("GET", "stats_viewreqs_load.php?PlanID="+
				<?php if (isset($_POST["PlanID"])) echo $_POST["PlanID"]; else echo "0"; ?>+
				"&showElect="+document.getElementById("showElectiveChk").checked, true);
			xhttp.send();
		}
		function changeViewStyle() {
			var e = document.getElementById("viewStyle");
			if (e.selectedIndex == -1) {
				return null;
			}
			var value = parseInt(e.options[e.selectedIndex].value);
			switch(value) {
				case 1: compactview = true; break;
				case 2: compactview = false; break;
			}
			tx = 0; ty = 0;
			renderCourseDependencies(canvas, courses, reqs, electives, zoomScale, 0, 0);
		}
		function zoomIn() {
			zoomScale *= 1.2;
			tx = 0; ty = 0;
			renderCourseDependencies(canvas, courses, reqs, electives, zoomScale, 0, 0);
		}
		function zoomOut() {
			zoomScale *= 0.8;
			tx = 0; ty = 0;
			renderCourseDependencies(canvas, courses, reqs, electives, zoomScale, 0, 0);
		}
		function mouseDown(e) {
			xprev = e.clientX;
			yprev = e.clientY;
			bScrolling = true;
		}
		function mouseUp(e) {
			bScrolling = false;
		}
		function mouseMove(e) {
			if ( bScrolling ) {
				tx += e.clientX - xprev;
				ty += e.clientY - yprev;
				xprev = e.clientX;	
				yprev = e.clientY;
				renderCourseDependencies(canvas, courses, reqs, electives, zoomScale, tx, ty);
			}
		}
		window.onload = function(){
			renderReqs();
		}
	</script>
</head>

<body>
<?php  
	require('planea_logosbar.php');
	$helptopic = "coord-stats-reqs";
	require('planea_statisticsbar.php');
?>

<div class="planeaForm">
Estilo de la visualización: <select id="viewStyle" onchange="changeViewStyle()">
	<option value="1" selected>Compacta</option>
	<option value="2">Ampliada</option>
</select> &nbsp; 
<input id="showElectiveChk" type="checkbox" value=0 onchange="renderReqs()">Mostrar electivas en forma desagregada&nbsp; &nbsp; 
Zoom <button class="button btn_fancy" onclick="zoomIn()" type="button">+</button> <button class="button btn_fancy" onclick="zoomOut()" type="button">-</button>
</div> 	
<div class="planeaForm" onmousedown="mouseDown(event)" onmouseup="mouseUp(event)" onmousemove="mouseMove(event)">
	<canvas id="myCanvas">El navegador no soporta Canvas HTML5
</canvas> 
</div>  
</body>
</html>
