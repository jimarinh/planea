<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
if (isset($_GET["UserID"]) && isset($_GET["SemesterID"])) {
	$planea->showAvailableRubricAssocItem( $_GET["RubricID"], 4, $_GET["CourseID"], $_GET["SemesterID"], $_GET["UserID"] );
} else {
	$planea->showAvailableRubricAssociations($_GET["RubricID"], $_GET["CourseID"]);
}
$planea->closeConnection();
?>