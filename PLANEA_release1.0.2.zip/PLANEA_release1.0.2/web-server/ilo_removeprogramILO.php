<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
//Check if Program RAP could be removed...
$sql = "SELECT ID FROM courses_ilos WHERE ProgramILOID=".$_GET["iloID"];
$result = $planea->conn->query($sql);
if ($result->num_rows > 0) {
	echo "0";
} else {
	$sql = "DELETE FROM ilo_program WHERE ID=".$_GET["iloID"];
	$result = $planea->conn->query($sql);
	echo "1"; 
}
$planea->closeConnection();
?>