<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<style>
		textarea  
		{  
			font-family:"Courier", Courier, sansserif;  
			font-size: 14px;
			width:100%;
		}
	</style>	
</head>

<body onload="configurePanels()">

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	//Check for credentials
	if ($_SESSION["RoleID"]!=planea::roleAdmin) {
		exit("<p><font color=\"red\">No tiene permiso para acceder a esta sección</font><p>");
	}
?>

	<script>
	function setModifiedFlag() { window.onbeforeunload = function() { return true; }; }
	function clearModifiedFlag() { window.onbeforeunload = null; return true; }
	function uploadFile() {
		if (fileToUpload.value.length>0) {
			//Obtiene el nombre base de la plantilla, para verificar si existe
			var str  = fileToUpload.value;
			str = str.replace(/\\/g,'/');
			var base = str.substring(str.lastIndexOf('/') + 1); 	
			//Verifica si existe la plantilla
			items = templateList.getElementsByTagName("td");
			var bExist = false;
			var i;
			for (i=0; i<items.length; i++) {
				if (items[i].innerText==base) {
					bExist = true;
					break;
				}
			}
			//Si existe, pregunta si desea reemplazarlo
			if (bExist) {
				var r = confirm("Una plantilla con el mismo nombre ya ha sido subida. ¿Desea reemplazar la plantilla?");
				if (r == false) {
					return false;
				}
			}	
			formUpload.submit();
			return true;		
		} 
		return false;
	}
	function goRemoveTemplate(templateFile, rowID) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {		
				var x = document.getElementById("row"+rowID);
				templateList.deleteRow(x.rowIndex);
			}
		}
		xhttp.open("GET", "templates_remove.php?template="+templateFile, true);
		xhttp.send();
	}
	function removeTemplate(templateFile, rowID) {
		var r = confirm("¿Está seguro que quiere eliminar el archivo?");
		if (r == true) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					if (this.responseText=="1") {
						var r = confirm("La plantilla está siendo usada por algún sílabo.\n"+
							"Si la elimina, el PDF del sílabo será generado con una plantilla "+
							"por defecto o no podrá ser generado correctamente.\n\n ¿Desea eliminar la plantilla?");
						if (r == false) {
							return false;
						}
					}
					goRemoveTemplate(templateFile, rowID);
				}
			}
			xhttp.open("GET", "templates_checkusage.php?template="+templateFile, true);
			xhttp.send();
		}
	}
	function editTemplate(templateFile) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {		
				templateContents.value = this.responseText;
				document.getElementById("formPreview").style.display = "none";
				document.getElementById("formUpload").style.display = "none";
				document.getElementById("formEditTemplate").style.display = "block";
				messageStr.style.display = "none";
				templateID.value = templateFile;
			}
		}
		xhttp.open("GET", "templates/"+templateFile, true);
		xhttp.send();
	}
	function cancelEditTemplate() {
		document.getElementById("formPreview").style.display = "block";
		document.getElementById("formUpload").style.display = "block";
		document.getElementById("formEditTemplate").style.display = "none";
	}
	
	function previewTemplate(action) {
		switch (action) {
			case 1: //Previsualizar
				formPreview.submit();
				break;
			case 2: //Cancelar
				previewPanel.style.display = "none";
				break;
		}
	}
	function viewTemplate(templateFile) {
		templatePreviewID.value = templateFile;
		sectionPlanOkPrev.style.display = "none";
		sectionCourseOkPrev.style.display = "none";	
		document.getElementById("ListOfStudyPlansPrev").selectedIndex = 0;
		previewPanel.style.display = "block";
	}
	
	function viewUsageTemplate(templateFile) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				tableToExcel(this.responseText,'UsoPlantilla');
			}
		}
		xhttp.open("GET", "templates_viewusage.php?template="+templateFile, true);
		xhttp.send();	
	}
	var tableToExcel = (function() {
		var uri = 'data:application/vnd.ms-excel;base64,'
			, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
			, base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
			, format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
		return function(tableHTML, name) {
			var ctx = {worksheet: name || 'Worksheet', table: tableHTML}
			window.location.href = uri + base64(format(template, ctx))
		}
	})()
	
	
	function associateTemplate(templateFile) {
		templateAssocID.value = templateFile;
		sectionPlanOkAssoc.style.display = "none";
		sectionCourseOkAssoc.style.display = "none";
		sectionAssocActions.style.display = "block";
		sectionAssocSyllabus.style.display = "none";
		messageStr.style.display = "none";
		document.getElementById("ListOfStudyPlansAssoc").selectedIndex = 0;
		associatePanel.style.display = "block";
	}
	
	function assocTemplate(action) {
		var bAssocOk = false;
		var actType = "";
		switch(action) {
			case 1: //Asociar a todas las versiones de los sílabos del plan de estudios
				bAssocOk = true; actType = "all";
				break;
			case 2: //Asociar solo a las versiones vigentes y borradores del plan de estudios
				bAssocOk = true; actType = "validAndDrafts";
				break;
			case 3: //Asociar solo a las versiones en borrador del plan de estudios
				bAssocOk = true; actType = "drafts";
				break;
			case 4: //Asociar a solo una versión de un sílabo del plan de estudios
				sectionAssocActions.style.display = "none";
				sectionAssocSyllabus.style.display = "block";
				break;
			case 5: //Asocia la plantilla a solo una versión del syllabus 
				bAssocOk = true; actType = "syllabus";
				break;
			case 6: //Cancelar
				associatePanel.style.display = "none";
				break;
		}
		if (bAssocOk) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {		
					messageStr.innerHTML = "Se fijaron correctamente toda las plantillas.";
					messageStr.style.display = "block";
					associatePanel.style.display = "none";
				}
			}
			xhttp.open("GET", "templates_association.php?Plan="+ListOfStudyPlansAssoc.value+
						"&CourseID="+ListOfVersionsAssoc.value+
						"&template="+templateAssocID.value+"&action="+actType, true);
			xhttp.send();
		}
	}
	

	function configurePanels() {
		previewPanel.style.display = "none";
		associatePanel.style.display = "none";
		var span = document.getElementsByClassName("close");
		span[0].onclick = function() { previewPanel.style.display = "none"; }
		span[1].onclick = function() { associatePanel.style.display = "none"; }
		window.onclick = function(event) {
			if (event.target == previewPanel) {
				previewPanel.style.display = "none";
			}
			if (event.target == associatePanel) {
				associatePanel.style.display = "none";
			}
		}
	}

	//Funciones usadas para volcar la información del plan de estudios, cursos y versiones de curso
	//usadas durante la previsualización y asociación de plantillas.
	function changePlan(action) {
		var e = document.getElementById("ListOfStudyPlans"+action);
		if (e.selectedIndex == -1) {
			return null;
		}
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("ListOfCourses"+action).innerHTML = "<option value=\"\">Seleccione uno...</option>"+this.responseText;
				document.getElementById("sectionPlanOk"+action).style.display = "block";
			}
		};
		xhttp.open("GET", "planea_loadcourses.php?plan="+e.value+"&state=plan", true);
		xhttp.send();
	}
	function changeCourse(action) {
		var e = document.getElementById("ListOfCourses"+action);
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				var e = document.getElementById("ListOfVersions"+action);
				e.innerHTML = this.responseText;
				document.getElementById("sectionVersionOk"+action).style = "display:inline-block";
				document.getElementById("sectionPleaseWait"+action).style = "display:none";
				document.getElementById("sectionCourseOk"+action).style.display = "block";
			}
		};
		document.getElementById("sectionVersionOk"+action).style = "display:none";
		document.getElementById("sectionPleaseWait"+action).style = "display:inline-block";	
		xhttp.open("GET", "planea_loadversionslist.php?courseID="+e.value+"&roleID=1", true);
		xhttp.send();	
	}
	</script>

<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="syllabus_templates.php">Plantillas de Sílabos</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#admin-templates" target="PLANEA-help">?</a></li>
</ul>


<?php  
	$planea = new planea();
	$conn = $planea->openConnection();
	//Check for file upload...
	if (isset($_FILES["fileToUpload"])) {
		$target_dir 	= "templates/";
		$target_file 	= $target_dir . basename($_FILES["fileToUpload"]["name"]);
				
		$uploadOk 		= true;
		$fileExt 		= strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		if ($fileExt!="xml") {
			//Si el archivo no es una plantilla, permite subir solo imágenes
			if(getimagesize($_FILES["fileToUpload"]["tmp_name"])===false) {
				echo "<p class=\"warningbox\">Solo se permiten plantillas en formato XML o imágenes de soporte a las plantillas.</p>";
				$uploadOk = false;
			}
		} 
		if ($uploadOk) {
			if (!move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				echo "<p class=\"warningbox\">Advertencia: La plantilla no puedo ser subida.</p>";
			}
		}
	}
	//If Save template...
	if (isset($_POST["templateContents"])) {
		$tfile = fopen("templates/".$_POST["templateID"], "w") or die("No se puede modificar la plantilla!");
		fwrite($tfile, $_POST["templateContents"]);
		fclose($tfile);
	}
?>


<p class="warningbox" style="display:none" id="messageStr"></p> 


<form class="planeaForm" id="formPreview" action="viewpdf_syllabus.php" method="GET" target="_blank">
	<p style="font-size:small"> 
	Utilice esta sección para subir, modificar, previsualizar, y asociar las plantillas que se emplean para la generación de los PDFs de los sílabos. También puede subir imágenes que sirvan de soporte a las plantllas.<br>
	<br>
	En el módulo <b>Planes de Estudio</b> puede asociar la plantilla que se utilizará por defecto para los cursos a los que no se ha asociado una plantilla.
	</p> 	
	
<div id="previewPanel" class="modal" style="display:none">
  <!-- Modal content -->
  <div class="modal-content">
  <div  class="modal-header">
    <span  class="close">&times;</span >
    <h2 >Previsualización de la plantilla</h2 >
  </div>
  <div  class="modal-body">
    <p>Seleccione un plan de estudios, curso, y versión del curso al cual se le aplicará la plantilla.</p>
	Plan: 
	<select id="ListOfStudyPlansPrev" name="PlanID" onchange="changePlan('Prev')">
		<option value="">Seleccione uno...</option>
		<?php 
			$planea->showStudyPlan(); 
		?>
	</select>
	<br><br>
	<div id="sectionPlanOkPrev" style="display:none">
		Espacio Académico:
		<select id="ListOfCoursesPrev" onchange="changeCourse('Prev')">
		<option value="">Seleccione uno...</option>
		</select>  
		<br><br>
		<div id="sectionCourseOkPrev" style="display:none">	
			Versión:
			<div id="sectionPleaseWaitPrev" style="display:none">
				<img src="images\load.gif" alt="Por favor espere..." height="20" width="20">
			</div>
			<div id="sectionVersionOkPrev" style="display:none">
				<select id="ListOfVersionsPrev" name="ID"></select>	
				&nbsp;
				<button type="button" onclick="previewTemplate(1)">Previsualizar</button>
			</div>
			<br><br>
		</div>
	</div>
	<button type="button" onclick="previewTemplate(2)">Cancelar</button>
</div>
</div>
</div>
<input type="text" id="templatePreviewID" name="template" size=10 style="visibility:hidden">
</form>


<form id="formUpload" class="planeaForm" action="syllabus_templates.php" method="post" enctype="multipart/form-data" onsubmit="return uploadFile();">
	<table id="templateList">
		<?php 
			//Visualiza los archivos de plantilla disponibles en la carpeta "templates"
			$dir = "templates/";
			if (is_dir($dir)){
				echo "<tr><th>Plantilla</th><th></th></tr>";						
				if ($dh = opendir($dir)){
					$nrow = 1;
					while (($file = readdir($dh)) !== false){
						if (is_file($dir.$file)) {
							echo "<tr id=\"row".$nrow."\"><td>".$file."</td><td>\n";
							echo "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeTemplate('".$file."', ".$nrow.")\"></button>\n"; 
							$fileExt = strtolower(pathinfo($file,PATHINFO_EXTENSION));
							if ($fileExt=="xml")
							{
								echo "<button class=\"button btn_edit\" type=\"button\" onclick=\"editTemplate('".$file."')\"></button>\n"; 
								echo "<a href=\"templates/".$file."\" download><div class=\"button btn_download\" style=\"display:inline-block\"></div></a>\n"; 
								echo "<button class=\"button btn_view\" type=\"button\" onclick=\"viewTemplate('".$file."')\"></button>\n"; 
								echo "&nbsp;<button type=\"button\" onclick=\"viewUsageTemplate('".$file."')\">Exportar uso</button>\n"; 
								echo "&nbsp;<button type=\"button\" onclick=\"associateTemplate('".$file."')\">Asociar</button>\n"; 
							}
							echo "</td></tr>\n";
							$nrow++;
						}
					}
					closedir($dh);
				}
			}
		?>
	</table>
	<br>
	
	Subir archivo (XML, PNG, JPG): <input type="file" accept=".xml,image/*" name="fileToUpload" id="fileToUpload">
	<button class="button btn_fancy" onclick="uploadFile();" type="button">Subir<img src="images/btn_add1.png"> </button>
</form>


<form id="formEditTemplate" class="planeaForm" action="syllabus_templates.php" method="post" style="display:none" onsubmit="return clearModifiedFlag()">
	<textarea id="templateContents" name="templateContents" rows=25 onchange="setModifiedFlag()"></textarea>
	<br>
	<input type="submit" value="Guardar"> &nbsp; 
	<button type="button" onclick="cancelEditTemplate()">Cancelar</button>
		
	<button type="button" onclick="window.open('doc/planea_templates.html', '_blank');" style="float: right;">Ayuda</button>
				
	<input type="text" id="templateID" name="templateID" size=10 style="visibility:hidden">
</form>


<div id="associatePanel" class="modal" style="display:none">
  <!-- Modal content -->
  <div class="modal-content">
  <div  class="modal-header">
    <span  class="close">&times;</span >
    <h2 >Asociación de la plantilla</h2 >
  </div>
  <div  class="modal-body">
    <p>Seleccione un plan de estudios o curso y versión del curso, al cual se le asociará la plantilla.</p>
	Plan: 
	<select id="ListOfStudyPlansAssoc" onchange="changePlan('Assoc')">
		<option value="">Seleccione uno...</option>
		<?php 
			$planea->showStudyPlan(); 
		?>
	</select>
	<br><br>
	<div id="sectionPlanOkAssoc" style="display:none">
		<div id="sectionAssocActions">
			<button type="button" onclick="assocTemplate(1)">Asociar a todas las versiones de los sílabos del plan de estudios</button><br><br>
			<button type="button" onclick="assocTemplate(2)">Asociar solo a las versiones vigentes y borradores del plan de estudios</button><br><br>
			<button type="button" onclick="assocTemplate(3)">Asociar solo a las versiones en borrador del plan de estudios</button><br><br>
			<button type="button" onclick="assocTemplate(4)">Asociar a solo una versión de un sílabo del plan de estudios</button><br><br>
		</div>
		<div id="sectionAssocSyllabus" style="display:none">
			Espacio Académico a Asociar:
			<select id="ListOfCoursesAssoc" onchange="changeCourse('Assoc')">
			<option value="">Seleccione uno...</option>
			</select>  
			<br><br>
			<div id="sectionCourseOkAssoc" style="display:none">	
				Versión:
				<div id="sectionPleaseWaitAssoc" style="display:none">
					<img src="images\load.gif" alt="Por favor espere..." height="20" width="20">
				</div>
				<div id="sectionVersionOkAssoc" style="display:none">
					<select id="ListOfVersionsAssoc"></select>	
					&nbsp;
					<button type="button" onclick="assocTemplate(5)">Asociar plantilla</button>
				</div>
			</div>
			<br>
		</div>
	</div>
	<button type="button" onclick="assocTemplate(6)">Cancelar</button>
	<input type="text" id="templateAssocID" size=10 style="visibility:hidden">
</div>
</div>
</div>


<?php $planea->closeConnection(); ?>

</body>
</html>
