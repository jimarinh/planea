<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
if (isset($_GET["Text"])) {
	$res["VerbID"] = -1;
	$res["VerbName"] = "";
	$text = strtoupper($_GET["Text"]);
	$text = ($_GET["Text"]);
	$sql = "SELECT ID,VerbName FROM verb_list";
	$result = $planea->conn->query($sql);			
	if ($result->num_rows > 0)  {
		while($row_verb = $result->fetch_assoc()) {
			$verbstart = strtok($row_verb["VerbName"], " ");
			$is = stripos($text, $planea->conjugateVerb($verbstart));
			if ($is!==false) {
				$res["VerbName"] = $row_verb["VerbName"];
				$res["VerbID"] = $row_verb["ID"];
				break;
			}
		}
	}
	header('Content-type: application/json');
	echo json_encode($res);	
}
$planea->closeConnection();
?>
