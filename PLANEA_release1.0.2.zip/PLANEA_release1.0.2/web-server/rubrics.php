<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<style>
	textarea  
	{  
		font-family:"Helvetica", Helvetica, sansserif;  
		font-size: 14px;
	}
	</style>
</head>

<body onload="configurePanel()">

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	//Check for credentials
	if ($_SESSION["RoleID"]!=planea::roleCoord) {
		exit("<p><font color=\"red\">No tiene permiso para acceder a esta sección</font><p>");
	}
?>

	<script>	
	function verifyStudyPlan() {
		var e = document.getElementById("ListOfStudyPlans");
		if (e.selectedIndex == -1) {
			return false;
		}
		return true; 
	}
	function removeRubric(RubricID) {
		var r = confirm("Esta acción eliminará la rúbrica definitivamente (no se puede deshacer).\n"+
					"Además, esta rúbrica desaparecerá de todos los cursos que la tengan asociada.\n"+
					"¿Desea continuar?"); 
		if (r == true) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var item = document.getElementById("rub"+RubricID);
					item.parentNode.removeChild(item);
				}
			}
			xhttp.open("GET", "rubrics_remove.php?RubricID="+RubricID, true);
			xhttp.send();
		}
	}
	function duplicateRubric(RubricID, PlanID) {
		var r = confirm("¿Está seguro que desea crear un duplicado de esta rúbrica?"); 
		if (r == true) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var div = document.createElement("DIV");
					div.innerHTML = this.responseText;
					var item = document.getElementById("rub"+RubricID);
					item.parentNode.insertBefore(div.childNodes[0], item.nextSibling);	
				}
			}
			xhttp.open("GET", "rubrics_duplicate.php?RubricID="+RubricID+"&PlanID="+PlanID, true);
			xhttp.send();
		}
	}
	function viewRubricUsage(RubricID) {	
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				if ( this.responseText.length>0 ) { 
					usageList.innerHTML = this.responseText; 
				} else {
					usageList.innerHTML = "Ninguno";
				}
				usagePanel.style.display = "block";
			}
		}	
		xhttp.open("GET", "rubrics_usage.php?RubricID="+RubricID, true);
		xhttp.send();
	}
	function closePanel() {
		usagePanel.style.display = "none";
	}
	function configurePanel() {
		usagePanel.style.display = "none";
		var span = document.getElementsByClassName("close")[0];
		span.onclick = function() { usagePanel.style.display = "none"; }
		window.onclick = function(event) {
			if (event.target == usagePanel) {
				usagePanel.style.display = "none";
			}
		}
	}
	</script>


<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="rubrics.php">Rúbricas del plan de estudios</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#coord-rubrics" target="PLANEA-help">?</a></li>
</ul>


<?php  
	$planea = new planea();
	$conn = $planea->openConnection();

	$PlanID = 0;
	$bSudyPlanOk = false;
	if ( isset($_POST["PlanID"]) ) { //If PlanID is not set, open form to choose one.
		$PlanID = $_POST["PlanID"];
		$bSudyPlanOk = true;
	} 
	if ( isset($_GET["PlanID"]) ) { 
		$PlanID = $_GET["PlanID"];
		$bSudyPlanOk = true;
	}
?>

<form class="planeaForm" id="chooseStudyPlan" action="rubrics.php" method="POST" 
	onsubmit="return verifyStudyPlan()"
	<?php if ($bSudyPlanOk) echo "style=\"display:none\"";?>>
	<p> 
	Seleccione el plan de estudios al que se le asignarán las rúbricas.
	</p>
	<select id="ListOfStudyPlans" name="PlanID">
	<?php 
		if ( !$bSudyPlanOk ) {			
			$defaultPlan = $_SESSION["DefaultPlan"];
			if ($_SESSION["RoleID"]==planea::roleCoord) 
				$defaultPlan = $planea->showStudyPlan($defaultPlan,false,$_SESSION["UserID"]); 
			else 
				$planea->showStudyPlan($defaultPlan); 
		} else {
			$planea->showStudyPlan($PlanID);
		}
	?>
	</select>
	<br> 
	<br>
	<input type="submit" value="Continuar">
</form>

<div <?php if (!$bSudyPlanOk) echo "style=\"display:none\"";?>>
	<div class="planeaForm">
		<button onclick="window.open('rubrics_edit.php?PlanID=<?php echo $PlanID; ?>&backurl=rubrics.php?PlanID=<?php echo $PlanID; ?>','_self')">*Nueva Rúbrica</button>
	</div>
	<div id="ListOfRubrics">
		<?php $planea->showRubricsByPlan( $PlanID ); ?>
	</div>
	
	<div id="usagePanel" class="modal">
	  <!-- Modal content -->
	  <div class="modal-content">
	  <div  class="modal-header">
		<span  class="close">&times;</span >
		<h2 >Uso de la rúbrica</h2 >
	  </div>
	  <div  class="modal-body">
		<p>Cursos donde está siendo usada la rúbrica: </p>
		<p id="usageList"></p>
		<button type="button" onclick="closePanel()">Cerrar</button>
	  </div>
	</div>
	</div>
</div>

<?php $planea->closeConnection(); ?>

</body>
</html>