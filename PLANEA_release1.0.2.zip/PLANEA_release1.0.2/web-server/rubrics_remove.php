<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();

//Remove all associations where rubric is being used.
$sql = "DELETE FROM rubrics_assoc WHERE RubricID=".$_GET["RubricID"];
$result = $planea->conn->query($sql);

//Remove all rubric entries.
$sql = "DELETE FROM rubrics_entries WHERE RubricID=".$_GET["RubricID"];
$result = $planea->conn->query($sql);

//Remove rubric specification
$sql = "DELETE FROM rubrics_general WHERE ID=".$_GET["RubricID"];
$result = $planea->conn->query($sql);

$planea->closeConnection();
?>