<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
</head>

<body>
<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection(); 
	if (!isset($_GET["Area"])) { $AreaName = null; } else { $AreaName = $_GET["Area"];}
	$planea->showAllEvalReports( $_GET["PlanID"], $_GET["SemName"], $AreaName );
	$planea->closeConnection();
?> 	
</body>
</html>