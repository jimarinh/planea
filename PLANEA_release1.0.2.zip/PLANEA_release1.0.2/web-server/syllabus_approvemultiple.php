<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script>
		var bCheck = true;
		function checkAllCourses() {
			var checkboxes = document.querySelectorAll('input[type="checkbox"]');
			for (var i = 0; i < checkboxes.length; i++) {
				checkboxes[i].checked = bCheck;
			}
			bCheck = !bCheck;
		}
		function validateDate() {
			var re = /^\d{4}\-\d{1,2}\-\d{1,2}$/;
			if( (versionDate.value == '') || (versionDate.value != '' && !versionDate.value.match(re)) ) {
				messageStr.innerHTML="Especifique una fecha válida";
				messageStr.style = "display:inline";
				return false;
			}
			return true;
		}
	</script>
</head>

<body>

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	//Check for credentials
	if ($_SESSION["RoleID"]!=planea::roleCoord) {
		exit("<p><font color=\"red\">No tiene permiso para acceder a esta sección</font><p>");
	}
	$helptopic = "coord-version-control";
	require('planea_syllabusbar.php');
	if (!isset($_GET["PlanID"])) exit(0);
?>

<?php
$planea = new planea();
$conn = $planea->openConnection();  
//Si es la primera vez que se carga, captura el ID del plan	
if (isset($_POST["PlanID"])) {
	$PlanID = $_POST["PlanID"];
}
//Si se invoca para aprobación
if (isset($_POST["dummy"])) {
	$count = 0;
	foreach ($_POST as $key=>$value) {
		$eType    = substr ($key, 0, 3);  
		if (($eType=="chk") && ($value==true)) {
			$CourseID = substr ($key, 3);
			
			$sql = "SELECT CourseKeyID FROM courses_general WHERE ID=".$CourseID;
			$result = $conn->query($sql);
			$row = $result->fetch_assoc();
			$CourseKeyID = $row["CourseKeyID"];
	
			$sql = "UPDATE courses_general SET EstadoVersion=".planea::syllStateDisabled.",VisVersion=0 WHERE CourseKeyID=".$CourseKeyID;
			$result = $conn->query($sql); 
			$sql = "UPDATE courses_general SET EstadoVersion=".planea::syllStateApproved.",VisVersion=1,FechaVersion='".$_POST["versionDate"].
					"',VersionAnotacion='".$_POST["versionAnotacion"]."',VersionResponsable='".$_POST["versionResponsable"]."' WHERE ID=".$CourseID;
			$result = $conn->query($sql); 
			//Remove assignment as collaborator
			$sql = "DELETE FROM users_assignments WHERE courseID=".$CourseID;
			$result = $conn->query($sql);
			//Update assignment as teacher
			$sql = "UPDATE users_assignments SET courseID=".$CourseID." WHERE courseID IN 
					(SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID." AND VisVersion=0)";
			$result = $conn->query($sql); 
			$count++; 
		}
	}
}
?>

<p class="warningbox" style="display:<?php if (isset($count)) echo "inline"; else echo "none"; ?> id="messageStr">
<?php if (isset($count)) { if ($count==1) echo "Aprobado 1 curso existosamente"; else echo "Aprobados ".$count." cursos exitosamente"; } ?>
</p> 

<form class="planeaForm" action="syllabus_approvemultiple.php" onsubmit="return validateDate()" method="POST">
<p>
	Fecha <input name="versionDate" id="versionDate" type="date"> &nbsp;
	Anotación <input name="versionAnotacion" type="text"> &nbsp;
	Responsable <input name="versionResponsable" type="text"> &nbsp;
</p>
<p>Los siguientes sílabos están en modo "borrador". Marque los sílabos a aprobar. <input type="submit" value="Aprobar"> </p>
<table id="tableCourses">
	<tr><th><a href="#" onclick="checkAllCourses()" style="font-size:small">Marcar/desmarcar</a></th><th>Curso</th> </tr>
	<?php 
		$planea->showCourseListByVersionState2($PlanID,"Opened");
	?>
</table>
<input style="display:none" type="number" name="PlanID" value="<?php echo $PlanID; ?>">
<input style="display:none" type="number" name="dummy" value="0">
</form>   

<?php $planea->closeConnection(); ?>

</body>
</html>
