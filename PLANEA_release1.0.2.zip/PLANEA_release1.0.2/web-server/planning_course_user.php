<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
</head>

<body onload="configurePanels()">

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();  
	if ($_SESSION["RoleID"]!=planea::roleUser) {
		exit("Seleccione el rol Docente");
	}
?>

<script>
	function changeSemester(userID) {
		var e = document.getElementById("SemesterID");
		if (e.selectedIndex == -1)
			return null;
		var semesterName = e.options[e.selectedIndex].text;
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				planningCourses.innerHTML = this.responseText;
			}
		};
		xhttp.open("GET", "planning_course_go.php?action=loadUserList&UserID="+userID+"&SemesterID="+semesterName, true);
		xhttp.send();			
	}
		
	function openImportPanel() {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				if (this.responseText.length == 0) {
					targetImport.innerHTML = "<option value=0 selected>No existen cursos que importar</option>";	
				} else {
					targetImport.innerHTML = "<option value=0 selected>Seleccione curso destino...</option>"+this.responseText;
				}
				importStep1.style.display = "block";
				importStep2.style.display = "none";
				importStep3.style.display = "none";
				importPanel.style.display = "block";
			}
		}	
		xhttp.open("GET", "planning_course_dupgo.php?action=getTarget&UserID="+UserID.value, true);
		xhttp.send();
	}
	
	function viewImportSources(type) {
		if (type=="equal") { importEqCourses.checked = true; }
		var e = document.getElementById("targetImport");
		var CourseID = e.options[e.selectedIndex].value;
		if (CourseID > 0) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					if (this.responseText.length == 0) {
						sourceImport.innerHTML = "<option value=0 selected>No existen cursos que importar</option>";
						nextButton.style.display = "none";
					} else {
						sourceImport.innerHTML = "<option value=0 selected>Seleccione curso origen...</option>"+this.responseText;
						nextButton.style.display = "inline";
					}
					importStep2.style.display = "block";
					importStep3.style.display = "none";
				}
			}	
			xhttp.open("GET", "planning_course_dupgo.php?action=getSource&UserID="+UserID.value+
						"&CourseID="+CourseID+"&type="+type, true);
			xhttp.send();	
		}
	}
	
	var TargetCourseID;
	var SourceCourseID;
	var SemesterID;
	
	function importGetIDs() {
		var e = document.getElementById("targetImport");
		TargetCourseID = e.options[e.selectedIndex].value;
		if (TargetCourseID==0) return false;
		
		var e = document.getElementById("sourceImport");
		var val = e.options[e.selectedIndex].value;
		if (val==0) return false;
	
		var strs = val.split(",");
		SourceCourseID = parseInt(strs[0]);
		SemesterID = strs[1];
		return true;
	}
	
	function importSelection() {
		if (!importGetIDs()) 
			return;
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				var obj = JSON.parse(this.responseText);
				importActsList.innerHTML = obj.Acts;
				importRubsList.innerHTML = obj.Rubs;
				
				var bEqual = (TargetCourseID == SourceCourseID);			
				importHowTos.disabled = !bEqual;
				
				importAll.checked = false;
				importHowTos.checked = false;
				importActs.checked = false;
				importRubs.checked = false;
				importGenRubs.checked = false;
				
				importStep1.style.display = "none";
				importStep2.style.display = "none";
				importStep3.style.display = "block";
			}
		}	
		xhttp.open("GET", "planning_course_dupgo.php?action=getSections&UserID="+UserID.value+
					"&TargetID="+TargetCourseID+"&SourceID="+SourceCourseID+"&SemesterID="+SemesterID, true);
		xhttp.send();
	}
	
	function importChecks(type) {
		var flag;
		var items;
		var bEqual = (TargetCourseID == SourceCourseID);
		switch (type) {
			case 'all':
				flag = importAll.checked;
				importHowTos.checked = flag & bEqual;
				importActs.checked = flag;
				importRubs.checked = flag;
				importGenRubs.checked = flag;
				items = importActsList.getElementsByTagName("input");
				for(var i=0; i<items.length; i++) {
					items[i].checked = flag;
				}
				items = importRubsList.getElementsByTagName("input");
				for(var i=0; i<items.length; i++) {
					items[i].checked = flag;
				}
				break;
				
			case 'acts':
				flag = importActs.checked;
				items = importActsList.getElementsByTagName("input");
				for(var i=0; i<items.length; i++) {
					items[i].checked = flag;
				}
				break;
				
			case 'rubs':
				flag = importRubs.checked;
				items = importRubsList.getElementsByTagName("input");
				for(var i=0; i<items.length; i++) {
					items[i].checked = flag;
				}
				break;
		}
	}
	
	function importGo() {
		if (!importGetIDs()) 
			return;
		
		//Serialize the checkboxes & lists
		var qStr = "";
		if (importHowTos.checked) {
			qStr = "&howtos=1";
		}
		
		var chks = importActsList.getElementsByTagName("input");
		var selects = importActsList.getElementsByTagName("select");
		var val = 0;
		for(i=0; i<chks.length; i++) {
			if (chks[i].checked) {
				if (selects.length>0) {
					var e = selects[i];
					if (e.selectedIndex == -1) continue;
					val = e.options[e.selectedIndex].value;
				} 
				qStr += "&"+chks[i].id+"="+val;
			}
		}
		
		if (importGenRubs.checked) {
			qStr += "&grubs=1";
		}
		
		var chks = importRubsList.getElementsByTagName("input");
		var selects = importRubsList.getElementsByTagName("select");
		var val = 0;
		for(i=0; i<chks.length; i++) {
			if (chks[i].checked) {
				if (selects.length>0) {
					var e = selects[i];
					if (e.selectedIndex == -1) continue;
					val = e.options[e.selectedIndex].value;
				} 
				qStr += "&"+chks[i].id+"="+val;
			}
		}	
		if (qStr.length == 0) {
			importPanel.style.display = "none";
			return;
		}
		//Perform importation
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				importPanel.style.display = "none";
				location.reload();
			}
		};
		xhttp.open("GET", "planning_course_dupgo.php?action=import&UserID="+UserID.value+"&TargetID="+TargetCourseID+
					"&SourceID="+SourceCourseID+"&SemesterID="+SemesterID+qStr, true);
		xhttp.send();
	}
	
	function importCancel() {
		importPanel.style.display = "none";
	}
	
	function configurePanels() {
		importPanel.style.display = "none";
		var span = document.getElementsByClassName("close");
		span[0].onclick = function() { importPanel.style.display = "none"; }
		window.onclick = function(event) {
			if (event.target == importPanel) {
				importPanel.style.display = "none";
			}
		}
	}
</script>
	

<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="#">Planeación de Cursos</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#teacher-planning" target="PLANEA-help">?</a></li>
</ul>

<div class="planeaForm">
<p>Mis espacios académicos: </p>
	<?php $planea->showUserAssignmentList( $_SESSION["UserID"], "planning_course_howtos", 1 ); ?>
	<button type="button" onclick="openImportPanel()">Asistente para importación...</button>
</div>

<div class="planeaForm">
	<p>Mis planeaciones de curso en el semestre 
	<select id="SemesterID" name="SemesterID" onchange="changeSemester(<?php echo $_SESSION["UserID"]; ?>)">
	<?php 
		$SemesterName = $planea->showSemesterList( $SemesterName ); 
	?>
	</select></p>
	<ul id="planningCourses">
		<?php $planea->showPlanningCoursesByUser( $_SESSION["UserID"], $SemesterName ); ?>
	</ul>
</div>


<div id="importPanel" class="modal">
<!-- Modal content -->
  <div class="modal-content">
	  <div  class="modal-header">
		<span  class="close">&times;</span >
		<h2 >Importar planeación</h2 >
	  </div>
	  <div  class="modal-body">
		<div id="importStep1">
			<p><b>Curso destino</b> (sobre el cual se realizará la importación):</p>
			&nbsp; <select id="targetImport" onchange="viewImportSources('equal')"></select>	
		</div>
		<div id="importStep2" style="display:none">
			<p><b>Curso origen</b> (del que se importará la información):</p> 
			&nbsp; <label><input type="radio" id="importEqCourses" name="importFilter" value=1 onclick="viewImportSources('equal')" checked>El mismo curso</label>
			&nbsp; <label><input type="radio" id="importAllCourses" name="importFilter" value=2 onclick="viewImportSources('all')">Todos los cursos</label>
			<br/><br/>
			&nbsp; <select id="sourceImport"> </select>
			&nbsp; <button type="button" id="nextButton" onclick="importSelection()">Siguiente</button>	
			&nbsp; <button type="button" onclick="importCancel()">Cancelar</button>			
		</div>
		<div id="importStep3" style="display:none">
			<p>Seleccione los elementos a importar:</p>
			<input type="checkbox" id="importAll" onchange="importChecks('all')">
			<label for="importAll">Importar todo</label><br/><br/>
			<input type="checkbox" id="importHowTos" onchange="importChecks('howtos')">
			<label for="importHowTos">Preguntas asociadas a RAPs</label><br/><br/>
			<input type="checkbox" id="importActs" onchange="importChecks('acts')">
			<label for="importActs">Actividades</label>
			<table id="importActsList"></table><br/>
			<input type="checkbox" id="importGenRubs" onchange="importChecks('grubs')">
			<label for="importGenRubs">Rúbricas genéricas</label><br/><br/>
			<input type="checkbox" id="importRubs" onchange="importChecks('rubs')">
			<label for="importRubs">Rúbricas del docente</label>
			<table id="importRubsList"></table><br/>
			<button type="button" onclick="importGo()" >Importar</button> 
			&nbsp;<button type="button" onclick="importCancel()">Cancelar</button>
		</div>
		<br/>
	  </div>
	</div>
</div>

<input style="display:none" type="number" id="UserID" name="UserID" value="<?php echo $_SESSION["UserID"]; ?>">

<?php $planea->closeConnection(); ?>

</body>
</html>
