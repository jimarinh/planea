<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	//Check if RAP Set could be removed...
	$sql = "SELECT Code FROM study_plan WHERE ILOSetID=".$_GET["setID"];
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		echo "0";
	} else {		
		//Remueve todas las entradas en la tabla de tabla de RAPs que hacen referencia
		//a todos las categorías del conjunto que será removido.
		$sql = "UPDATE courses_ilos SET CategoryID=0 WHERE ID IN 
					(SELECT ID FROM courses_ilos WHERE CategoryID IN 
						(SELECT ID FROM ilo_categories WHERE SetID=".$_GET["setID"]."))";
		$result = $conn->query($sql);
		
		//Elimina las categorías
		$sql = "DELETE FROM ilo_categories WHERE SetID=".$_GET["setID"];
		$result = $conn->query($sql);
		
		//Elimina el conjunto
		$sql = "DELETE FROM ilo_sets WHERE ID=".$_GET["setID"];
		$result = $conn->query($sql);
		echo "1";
	}
	$planea->closeConnection();
?>