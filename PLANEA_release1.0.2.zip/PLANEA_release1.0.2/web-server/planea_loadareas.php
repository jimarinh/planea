<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection(); 
	$planea->showAreasListByPlan( $_GET["PlanID"] );
	$planea->closeConnection();
?>