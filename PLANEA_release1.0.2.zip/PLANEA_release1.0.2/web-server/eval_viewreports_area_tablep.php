<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection(); 
	$ret = $planea->showEvalReportPercentByArea( $_GET["PlanID"], $_GET["SemName"], $_GET["Area"] );
	if ($ret != null) {
		header('Content-type: application/json');
		echo $ret;
	}
	$planea->closeConnection();
?>