<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "INSERT INTO rubrics_entries(RubricID, Position) VALUES ('".$_GET["RubricID"]."','".$_GET["pos"]."')";
$result = $planea->conn->query($sql);
if ($result == true) {
	echo $planea->conn->insert_id;
}
$planea->closeConnection();
?>