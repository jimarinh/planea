//========================================
//PLANEA Module for Rendering Activities
//========================================


//Variables for rendering and user actions
//========================================

var raps = [];				//ILOs boxes information
var acts = [];				//Activity boxes information
var arrows = [];			//Arrow boxes information
var dispHowTo = true;		//flag to display ILO HowTos 
var dispDesc = true;		//flag to display Activity Description
var dispSkills = true;		//flag to display Activity Skills

var canvas = null;			//Canvas object to render the activities
var ctx = null;				//Context for drawing
var renderWidth = 0;		//Computed width after rendering
var tx = 0, ty = 0;			//Viewer offset. Changed when scrolling
var bScrolling = 0;			//Auxiliary variables for scrolling action
var xprev = 0, yprev = 0; 	
var selObject = null;		//Current selected object by the mouse pointer
var bLinking = false;		//Auxiliary variables for linking action
var selRap = null;
var bPanelActive = false;

//Functions to render the activity boxes
//========================================

function startRender(c, praps, pacts, dHowTos, dDesc, dSkills) {
	canvas = c;
	ctx = canvas.getContext("2d");
	raps = praps;
	acts = pacts;
	arrows = [];
	dispHowTo = dHowTos;
	dispDesc = dDesc;
	dispSkills = dSkills;	
	window.addEventListener('keyup',keyUp,false);
}

function renderActivities(maxwidth, zoomScale, tx, ty)
{
	var positions = computePositions(maxwidth);
	canvas.width = maxwidth*zoomScale;
	canvas.height = (positions.maxh+10)*zoomScale;
	ctx.scale(zoomScale, zoomScale);
	ctx.translate(tx,ty);
	drawArrows();
	drawBoxes(dispHowTo); 
}

function computePositions(maxwidth)
{
	var positions = computeBoxPositions(maxwidth, dispHowTo, dispDesc, dispSkills);
	computeArrows();
	renderWidth = maxwidth;
	return positions;
}

function resetView()
{
	tx = 0; ty = 0;
}

function measureTextBox( str, maxw )
{
	var hrow   = 15;
	var j, k, w;
	var nrows  		= -1;
	var strRows 	= [];
	var widthRows 	= [];
	var ret;
		
	//split the string into rows according to line breaks "<br>"
	var rows = str.split("<br>");
	for (k=0; k<rows.length; k++) {
		var words  = rows[k].split(" ");
		var widths = [];		
		nrows++;
		
		//compute the width for each word
		for(j=0; j<words.length; j++) {
			widths[j] = ctx.measureText(words[j]).width;
		}
			
		//compute the number of rows, and the width for each row
		str = "";
		w   = 0;
		for(j=0; j<widths.length; j++)
		{
			if (w+widths[j]+5 > maxw) 
			{
				strRows[nrows] = str;
				widthRows[nrows] = w;
				str = "";
				w   = 0;
				nrows++;
			}
			w += widths[j]+5;
			str = str + " " + words[j];
		}
		strRows[nrows] = str;
		widthRows[nrows] = w;
	}
	
	//Calcula el alto máximo del cajón
	maxh = strRows.length*hrow+10;
	ret = {maxw:maxw, maxh:maxh, hrow:hrow, strRows:strRows, widthRows:widthRows};
	return ret;
}

function computeHeightBoxRap(rap, maxw, dispHowTo)
{
	var maxh;
	//Compute the height of the box to display RAP and HowTo
	boxRap = measureTextBox( rap.Text, maxw-10 );
	maxh = boxRap.maxh + (boxRap.hrow/2);
	rap.boxRap = boxRap;
	if (dispHowTo) {
		if (rap.HowTo.length>0) {
			boxHowTo = measureTextBox( rap.HowTo, maxw-10 );
			maxh += boxHowTo.maxh;
			rap.boxHowTo = boxHowTo;
		}
	}
	rap.width  = maxw;
	rap.height = maxh;
	rap.x = 0;
	rap.y = 0;
}

function computeHeightBoxAct(act, maxw, dispDesc, dispSkills)
{
	var maxh;
	var maxwhd = ctx.measureText("HD:"+act.HD).width;
	var maxwhi = ctx.measureText("HI:"+act.HI).width;
	var maxwh  = (maxwhd > maxwhi ? maxwhd : maxwhi)+10;
	var str;
	
	//Compute the height of the box to display the Activities
	boxName = measureTextBox( act.Name, maxw-maxwh-10 );
	maxh = boxName.maxh + (boxName.hrow/2);
	if (dispDesc) {
		str = act.Desc.replace(/\n/g,"<br>");
	} else {
		str = "";
	}
	boxDesc = measureTextBox( str, maxw-maxwh-10 );
	maxh += boxDesc.maxh;
	if (act.TopicText.length>0) {
		boxTopic = measureTextBox( "Contenidos: "+act.TopicText, maxw-10 );
		maxh += boxTopic.maxh;
	} else {
		boxTopic = measureTextBox( "", maxw-10 );
		boxTopic.maxh=0; 
	}	
	if ( dispSkills && (act.SkillSet.length>0) ) {
		boxSkills = measureTextBox( "Habilidades:<br>"+act.SkillSet, maxw-10 );
		maxh += boxSkills.maxh; 
	} else { 
		boxSkills = measureTextBox( "", maxw-10 );
		boxSkills.maxh=0; 
	}
	act.boxName = boxName;
	act.boxDesc = boxDesc;
	act.boxTopic = boxTopic;
	act.boxSkills = boxSkills;
	act.width  = maxw;
	act.height = maxh;
	act.x = 0;
	act.y = 0;
}

function computeBoxPositions(maxw, dispHowTo, dispDesc, dispSkills)
{
	var ypos_t, yp;
	var i, j;
	var hrow;
	var vSpaceRap;
	var vSpaceAct;
	var positions;
	
	ctx.font = "14px Arial";
	//compute box heights and spaces between boxes
	for (i=0; i<acts.length; i++) {
		computeHeightBoxAct(acts[i], Math.trunc(maxw*0.6), dispDesc, dispSkills);
	}
	for (i=0; i<raps.length; i++) {
		computeHeightBoxRap(raps[i], Math.trunc(maxw*0.3), dispHowTo);
	}
	//Assign positions to the boxes
	hrow = raps[0].boxRap.hrow;
	ypos_t = 0;
	for(i=0; i<raps.length; i++) 
	{
		//compute the height of the activities associated to the ILO[i]
		var maxhg = 0;
		var nrapsg = 0;
		for(j=0; j<acts.length; j++) 
		{
			if (raps[i].ID == acts[j].AssocRaps[0]) {
				maxhg += acts[j].height;
				nrapsg++;
			}
		}
		//compute vertical space for ILO and activity boxes
		if  ( (maxhg+(nrapsg-1)*hrow) > raps[i].height) {
			rowHeight = maxhg + nrapsg*hrow;
			vSpaceRap = (rowHeight - raps[i].height)/2;
			vSpaceAct = hrow;
		} else {
			rowHeight = raps[i].height + hrow;
			vSpaceRap = hrow/2;
			vSpaceAct = nrapsg>0 ? (rowHeight - maxhg)/nrapsg : 0; 
		}
		//assign positions to boxes related to the ILO
		raps[i].x = 15;
		raps[i].y = ypos_t + vSpaceRap;
		yp = ypos_t + vSpaceAct/2;
		for(j=0; j<acts.length; j++) 
		{
			if (raps[i].ID == acts[j].AssocRaps[0]) {
				acts[j].x = Math.trunc(maxw*0.4)-10;
				acts[j].y = yp;
				yp += acts[j].height+vSpaceAct;
			}
		}
		ypos_t += rowHeight;
	}
	//Assign positions to the activities with no ILOs dependencies (if any is a bug)
	for(j=0; j<acts.length; j++) 
	{
		if (acts[j].AssocRaps.length==0) {
			ypos_t += hrow/2;
			acts[j].x = Math.trunc(maxw*0.4)-10;
			acts[j].y = ypos_t;
			ypos_t += acts[j].height+hrow/2;
		}
	}	
	positions = {maxw:maxw, maxh:ypos_t};
	return positions;
}

function findRap( ID )
{
	for (i=0; i<raps.length; i++)
	{
		if ( raps[i].ID == ID ) {
			return i;
		}
	}
	return -1;
}

function computeArrows() 
{
	var i, j, ri;
	var xi, yi, xf, yf;
	var narrow = 0;
	var nraps;
	arrows = [];
	for(i=0; i<acts.length; i++) 
	{
		xf = acts[i].x;
		yf = acts[i].y+(acts[i].height/2);
		nraps = acts[i].AssocRaps.length;
		for (j=0; j<nraps; j++) 
		{
			ri = findRap(acts[i].AssocRaps[j]);
			xi = raps[ri].x+raps[ri].width;
			yi = raps[ri].y+(raps[ri].height/2);
			var arrow = {rapID:raps[ri].ID, actID:acts[i].ID, canremove:(nraps>1), xi:xi, yi:yi, xf:xf, yf:yf};
			arrows[narrow] = arrow;
			narrow++;
		}
	}
}

function drawText( tm, xpos_t, ypos_t, align )
{
	var j;
	var dx=0;
	ypos_t += tm.hrow + (tm.maxh - tm.strRows.length*tm.hrow)/2;	
	for(j=0; j<tm.strRows.length; j++)
	{
		if (align==1) { dx = (tm.maxw - tm.widthRows[j])/2; }
		ctx.fillText(tm.strRows[j], xpos_t+dx, ypos_t);
		ypos_t += tm.hrow;
	}
}	

var rapBoxColorStroke = ["#9BBB59", "#D99694", "#BE8351", "#BE8351", "#575CBD"];
var rapBoxColorFill   = ["#CCE9AD", "#F0D1CC", "#E2C7B0", "#DCD5A4", "#C9C3EF"];

function drawBoxes( dispHowTo  )
{
	var i, xpos_t, ypos_t, hrow;
	
	//draw ILOs boxes
	ctx.lineWidth = 1;
	for (i=0; i<raps.length; i++) {
		xpos_t = raps[i].x;
		ypos_t = raps[i].y;
		w = raps[i].width;
		h = raps[i].height;
		ctx.fillStyle = rapBoxColorFill[i % 5];
		ctx.strokeStyle = rapBoxColorStroke[i % 5];
		ctx.fillRect(xpos_t,ypos_t,w,h);
		ctx.strokeRect(xpos_t,ypos_t,w,h);
	
		ctx.fillStyle = "#000000";
		ctx.strokeStyle = "#000000";
		ctx.font = "14px Arial";
		drawText( raps[i].boxRap, xpos_t, ypos_t, 1);
		if (dispHowTo && (raps[i].HowTo.length>0)) { 
			ypos_t += raps[i].boxRap.maxh;
			ctx.font = "13px Arial";
			drawText( raps[i].boxHowTo, xpos_t, ypos_t, 0);
		}	
	}
	
	//draw activity boxes
	for (i=0; i<acts.length; i++) {
		xpos_t = acts[i].x;
		ypos_t = acts[i].y;
		wb = acts[i].width;
		hb = acts[i].height;
		ctx.fillStyle = rapBoxColorFill[4];
		ctx.strokeStyle = rapBoxColorStroke[4];
		ctx.strokeRect(xpos_t, ypos_t, wb, hb);
		
		w = acts[i].boxName.maxw;
		h = acts[i].boxName.maxh + acts[i].boxDesc.maxh;
		ctx.fillRect(xpos_t, ypos_t, w, h);
		ctx.strokeRect(xpos_t, ypos_t, w, h);
		xh = xpos_t+w;
		wh = wb-w;
		ctx.strokeRect(xh, ypos_t, wh, acts[i].boxName.maxh);
		ctx.strokeRect(xh, ypos_t+acts[i].boxName.maxh, wh, acts[i].boxDesc.maxh);
		
		ctx.fillStyle = "#000000";
		ctx.strokeStyle = "#000000";
		ctx.font = "bold 14px Arial";
		drawText( acts[i].boxName, xpos_t, ypos_t, 0);	
		
		ctx.font = "14px Arial";
		ctx.fillText("HD:"+acts[i].HD, xh+5, ypos_t+acts[i].boxName.hrow);
		
		ypos_t+=acts[i].boxName.maxh;
		drawText( acts[i].boxDesc, xpos_t, ypos_t, 0);
		ctx.fillText("HI:"+acts[i].HI, xh+5, ypos_t+acts[i].boxName.hrow);
		
		ypos_t+=acts[i].boxDesc.maxh;
		drawText( acts[i].boxTopic, xpos_t, ypos_t, 0);
		ypos_t+=acts[i].boxTopic.maxh;
		drawText( acts[i].boxSkills, xpos_t, ypos_t, 0);
	}
	
	//draw add activity buttons
	hrow = raps[0].boxRap.hrow*0.7;
	ctx.fillStyle = "#FFFFFF";
	ctx.strokeStyle = "#7F7F7F";
	for(i=0; i<raps.length; i++) 
	{
		var xpos_t = raps[i].x+raps[i].width;
		var ypos_t = raps[i].y+raps[i].height/2;
		ctx.beginPath();
		ctx.lineWidth = 2;
		ctx.arc(xpos_t, ypos_t, hrow, 0, 2 * Math.PI);
		ctx.fill();
		hrow-=3;
		ctx.moveTo(xpos_t,ypos_t-hrow);
		ctx.lineTo(xpos_t,ypos_t+hrow);
		ctx.moveTo(xpos_t-hrow,ypos_t);
		ctx.lineTo(xpos_t+hrow,ypos_t);
		hrow+=3;
		ctx.stroke();
	}
}

function drawArrows()
{
	var i;
	for(i=0; i<arrows.length; i++) 
	{
		ctx.beginPath();
		ctx.strokeStyle = "#7F7F7F";
		ctx.lineWidth = 2;
		ctx.moveTo(arrows[i].xi, arrows[i].yi);
		ctx.lineTo(arrows[i].xf, arrows[i].yf);
		ctx.stroke();
	}
}

//Functions for user actions
//======================================

function findElementXY(xmouse, ymouse)
{
	var i;
	var hrow = raps[0].boxRap.hrow;
	
	//check if add activity button is selected
	for(i=0; i<raps.length; i++)
	{
		var xpos_t = raps[i].x+raps[i].width;
		var ypos_t = raps[i].y+raps[i].height/2;
		var dist = Math.sqrt(Math.pow(xmouse-xpos_t,2)+Math.pow(ymouse-ypos_t,2));
		if ( dist <= hrow  ) {
			sel = {type:1,e:raps[i],x:xpos_t,y:ypos_t,r:hrow};
			return sel;
		}
	}
	//check if an arrow is selected
	for(i=0; i<arrows.length; i++)
	{
		var x1 = arrows[i].xi;
		var y1 = arrows[i].yi;
		var x2 = arrows[i].xf;
		var y2 = arrows[i].yf;
		var n  = Math.abs((y2-y1)*xmouse-(x2-x1)*ymouse+x2*y1-y2*x1);
		var d  =  Math.sqrt(Math.pow(y2-y1,2)+Math.pow(x2-x1,2));
		var dist = n/d;
		if ( dist <= 5  ) {
			sel = {type:2,e:arrows[i],x1:x1,y1:y1,x2:x2,y2:y2};
			return sel;
		}
	}
	
	//check if ILO is selected
	for(i=0; i<raps.length; i++)
	{
		if ( (xmouse>raps[i].x) && (xmouse<raps[i].x+raps[i].width) &&
			 (ymouse>raps[i].y) && (ymouse<raps[i].y+raps[i].height) ) {
			sel = {type:3,e:raps[i],x:raps[i].x-5,y:raps[i].y-5,w:raps[i].width+10,h:raps[i].height+10};
			return sel;
		}
	}
	//check if activity is selected
	for(i=0; i<acts.length; i++)
	{
		if ( (xmouse>acts[i].x) && (xmouse<acts[i].x+acts[i].width) &&
			 (ymouse>acts[i].y) && (ymouse<acts[i].y+acts[i].height) ) {
			sel = {type:4,e:acts[i],x:acts[i].x-5,y:acts[i].y-5,w:acts[i].width+10,h:acts[i].height+10};
			return sel;
		}
	}
	return null;
}


function existsLink(rapID, actID) 
{
	var i, j;
	var nraps;
	for(i=0; i<acts.length; i++) 
	{
		if (acts[i].ID==actID) {
			nraps = acts[i].AssocRaps.length;
			for (j=0; j<nraps; j++) 
			{
				if (acts[i].AssocRaps[j]==rapID)
					return true;
			}
			return false;
		}
	}
	return false;
}


function addArrow(rapID, actID)
{
	var i;
	for(i=0; i<acts.length; i++) 
	{
		if (acts[i].ID == actID) 
		{
			acts[i].AssocRaps.push(rapID);
		}
	}
	computePositions(renderWidth);
}


function removeActBox(actID)
{
	var i;
	for(i=0; i<acts.length; i++) 
	{
		if (acts[i].ID == actID) 
		{
			acts.splice(i,1);
		}
	}
	computePositions(renderWidth);
}

function removeArrow(rapID, actID) 
{
	var i, j;
	for(i=0; i<acts.length; i++) 
	{
		if (acts[i].ID == actID) 
		{
			for (j=0; j<acts[i].AssocRaps.length; j++) 
			{
				if (acts[i].AssocRaps[j] == rapID) 
				{
					acts[i].AssocRaps.splice(j,1);
					break;
				}
			}
		}
	}
	computePositions(renderWidth);
}

function findElementEvent(e) {
	var rect = canvas.getBoundingClientRect();
	var el = findElementXY((e.clientX-rect.left)/zoomScale-tx, (e.clientY-rect.top)/zoomScale-ty);
	return el;
}

function redraw() 
{
	ctx.clearRect(0, 0, canvas.width, canvas.height);
	drawArrows();
	drawBoxes(dispHowTo); 
}

function drawSelectionBox(e) 
{
	if (e==null) return;
	ctx.lineWidth = 4;
	ctx.strokeStyle = "#FF0000";
	switch(e.type) {
		case 1:
			ctx.beginPath();
			ctx.arc(e.x, e.y, e.r, 0, 2 * Math.PI);
			ctx.stroke();
			break;
		case 2:
			ctx.beginPath();
			ctx.moveTo(e.x1, e.y1);
			ctx.lineTo(e.x2, e.y2);
			ctx.stroke();
			break;
		case 3:
		case 4:
			ctx.beginPath();
			ctx.strokeRect(e.x, e.y, e.w, e.h);
			ctx.stroke();
			break;
	}
}

function setPanelStatus(bStatus)
{
	bPanelActive = bStatus;
}

function setCursor(cursorStyle) {
	if (canvas.style) canvas.style.cursor=cursorStyle;
}

function mouseDown(e) {
	xprev = e.clientX;
	yprev = e.clientY;
	bScrolling = 1;
	setCursor("all-scroll");
}

function mouseUp(e) 
{
	if (bScrolling == 2) {
		bScrolling = 0;
		if (bLinking) setCursor("crosshair"); else setCursor("default");
		return;
	}
	if (bScrolling == 1) {
		setCursor("all-scroll");
	}
	bScrolling = 0;
	var el = findElementEvent(e);
	if (el!=null) {
		switch(el.type) {
			case 1: //insert activity
				insertActivity(el.e);
				redraw();
				break;
			case 2: //nothing
				break;
			case 3: //start linking
				selRap = el;
				bLinking = true;
				setCursor("crosshair");
				break;
			case 4: 
				if (bLinking) { //link ILO and activity
					bLinking=false;
					setCursor("default");
					if (!existsLink(selRap.e.ID, el.e.ID)) { linkActivity(selRap.e.ID, el.e.ID); }
					selRap=null;
				} else { //edit activity
					editActivity(el.e);
				}
				redraw();
				break;
		}
	} else {
		if (bLinking) { //cancel linking ILO and activity
			bLinking=false;
			setCursor("default");
			selRap=null;
			redraw();
		}
	}
	selObject = el;
}

function mouseMove(e) {
	if ( bScrolling > 0) {
		if ( bScrolling == 1) {
			bScrolling = 2;
			setCursor("all-scroll");
		}
		tx += e.clientX - xprev;
		ty += e.clientY - yprev;
		xprev = e.clientX;	
		yprev = e.clientY;
		renderActivities(computeWidth(), zoomScale, tx, ty);
	} else { 
		var el = findElementEvent(e);
		if ((el!=null) || (selObject!=null)) {
			if ((el!=null) && (selObject==null)) { 
				if (!bLinking || (el.type==4)) { redraw(); drawSelectionBox(el); } else { el=null; }
			} else if ((el==null) && (selObject!=null)) {
				redraw();
			} else {
				if ((el.type != selObject.type)||(el.e!=selObject.e)) {
					if (!bLinking || (el.type==4)) { redraw(); drawSelectionBox(el); } else { el=null; }
				}
			}
		}
		selObject = el;
		if (bLinking) {
			drawSelectionBox(selRap);
			if ((selObject!=null)&&(selObject.type==4)) {
				ctx.lineWidth = 4;
				ctx.strokeStyle = "#FF0000";
				ctx.beginPath();
				ctx.moveTo(selRap.e.x+selRap.e.width+5, selRap.e.y+selRap.e.height/2);
				ctx.lineTo(selObject.e.x-5, selObject.e.y+selObject.e.height/2);
				ctx.stroke();
			}
		}
	}
}

function keyUp(e)
{
	if ( (e.key == "Escape") && bLinking ) {
		//cancel linking
		bLinking=false;
		setCursor("default");
		selRap=null;
		redraw();
	}
	if ( (e.key == "Delete") && (selObject!=null) && !bPanelActive ) {
		//remove link
		if ((selObject.type==2) && (selObject.e.canremove) ) {
			removeLink(selObject.e.rapID, selObject.e.actID);
		}
		//remove activity
		if (selObject.type==4) {
			removeActivity(selObject.e.ID);
		}
	}
}