<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	
	switch($_GET["action"])
	{
		case "all": 
			$sql = "UPDATE study_plan SET Template='".$_GET["template"]."' WHERE ID=".$_GET["Plan"];
			$result = $conn->query($sql);
			$sql = "UPDATE courses_general SET Template='".$_GET["template"]."' WHERE PlanID=".$_GET["Plan"];
			break;
		
		case "validAndDrafts":
			$sql = "UPDATE courses_general SET Template='".$_GET["template"]."' WHERE PlanID=".$_GET["Plan"]." AND (EstadoVersion=1 OR EstadoVersion=2)";
			break;
		
		case "drafts":
			$sql = "UPDATE courses_general SET Template='".$_GET["template"]."' WHERE PlanID=".$_GET["Plan"]." AND EstadoVersion=1";
			break;
			
		case "syllabus":
			$sql = "UPDATE courses_general SET Template='".$_GET["template"]."' WHERE ID=".$_GET["CourseID"];
			break;
	}
	$result = $conn->query($sql);
	$planea->closeConnection();
?>