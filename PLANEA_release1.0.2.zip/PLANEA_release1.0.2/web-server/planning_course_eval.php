<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<style>
		textarea  
		{  
			font-family:"Helvetica", Helvetica, sansserif;  
			font-size: 14px;
			width:100%;
		}
	</style>
</head>

<body onload="configure()">

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();  
	if ($_SESSION["RoleID"]!=planea::roleUser) {
		exit("Seleccione el rol Docente");
	}
	
	$CourseID 	= $_GET["ID"];
	$SemesterID = isset($_GET["SemesterID"]) ? $_GET["SemesterID"] : $planea->getDefaultSemester();
	$UserID = $_SESSION["UserID"];
	
	$sql = "SELECT Nombre,PlanID FROM courses_general WHERE ID=" . $CourseID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$CourseName = $row["Nombre"]."(".$SemesterID.")";
	$Action = 4;
?>
	<script type="text/javascript" language="javascript" src="planning_course.js"></script>	
	<script>
		//Functions to configure the working environment
		//-------------------------------------------------
		function configurePanels() {
			EvaluationPanel.style.display = "none";
			var span = document.getElementsByClassName("close");
			span[0].onclick = function() { EvaluationPanel.style.display = "none"; }
			var span = document.getElementsByClassName("close-gray");
			span[0].onclick = function() { RubricViewerPanel.style.display = "none"; }
			window.onclick = function(event) {
				if (event.target == RubricViewerPanel) {
					RubricViewerPanel.style.display = "none";
				}
			}
		}
		function configure() {
			configurePanels();
		}
	</script>
	

<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="planning_course_user.php">Planeación de Cursos</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#teacher-planning4" target="PLANEA-help">?</a></li>
</ul>

<ul class="navbar"> 
<li>
	<a <?php if ($Action==1) echo "class=\"active\""; ?> href="planning_course_howtos.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 1: Preguntas</a>
</li>
<li>
	<a <?php if ($Action==2) echo "class=\"active\""; ?> href="planning_course_activities.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 2: Actividades</a>
</li>
<li>
	<a <?php if ($Action==3) echo "class=\"active\""; ?> href="planning_course_schedule.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 3: Cronograma</a>
</li>
<li>
	<a <?php if ($Action==4) echo "class=\"active\""; ?> href="planning_course_eval.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 4: Evaluación</a>
</li>
<li>
	<a <?php if ($Action==5) echo "class=\"active\""; ?> href="planning_course_rubrics.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 5: Rúbricas
	</a>
</li>
<li>
	<a <?php if ($Action==6) echo "class=\"active\""; ?> href="planning_course_summary.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Resumen
	</a>
</li>
<li><a href="view_syllabus.php<?php echo "?ID=".$CourseID;?>"> <?php echo $CourseName; ?> </a></li>
</ul>


<!-- FORM FOR SETTING EVALUATION -->

<div id="step4" style="display:<?php echo ($Action==4) ? "block" : "none"; ?>">
	<div class="planeaForm">
		<small><p>En esta sección se definen las estrategias de evaluación para cada una de las actividades.
		Igualmente, puede asociar rúbricas para la evaluación de las actividades. 
		Las rúbricas las puede configurar en la pestaña 5.
		</p></small>
	</div>
	<div class="planeaForm">
		<?php 
			$planea->showPlanningCourseActivityTable( $CourseID, $SemesterID, $UserID, true, "E", "E" );		
		?>
	</div>
	<div id="EvaluationPanel" class="modal" style="display:none">
	  <!-- Modal content -->
	  <div class="modal-content">
	  <div  class="modal-header">
		<span  class="close">&times;</span >
		<h2 >Estategias de evaluación para la actividad</h2 >
	  </div>
	  <div  class="modal-body">
		<div id="evalPanelStep1" style="display:none"> 
			<p>Con base en el verbo principal del resultado de aprendizaje
				"<i><font color="green"><span id="evalRapText"></span></font></i>", éste se ha clasificado como un RAP de 
				<select id="evalCat" onchange="evalChangeVerb()">
					<option value=1>conocimiento/disciplinar</option>
					<option value=2>razonamiento</option>
					<option value=3>creatividad/síntesis</option>
					<option value=4>habilidad/proceso/procedimiento</option>
					<option value=5>actitud</option>
				</select> y se recomiendan las siguientes estrategias de evaluación:</p>	
			<div id="suggestEval1" style = "display:none">
				<!-- Suggested activities for "Disciplinary/knowledge" category -->
				<input type="radio" name="strategyVal" value="Mapas conceptuales">Mapas conceptuales<br>
				<input type="radio" name="strategyVal" value="Paper de un minuto">Paper de un minuto<br>
				<input type="radio" name="strategyVal" value="Gobbets">Gobbets<br>
				<input type="radio" name="strategyVal" value="Autoevaluación">Autoevaluación<br>
				<input type="radio" name="strategyVal" value="Evaluación por pares">Evaluación por pares<br>
				<input type="radio" name="strategyVal" value="Diagramas de Venn">Diagramas de Venn<br>
				<input type="radio" name="strategyVal" value="Examen con respuestas cortas">Examen con respuestas cortas<br>
				<input type="radio" name="strategyVal" value="Examen con pregunas de múltiple respuesta">Examen con pregunas de múltiple respuesta<br>
				<input type="radio" name="strategyVal" value="Examen con preguntas ordenadas por resultado">Examen con preguntas ordenadas por resultado<br>
			</div>	
			<div id="suggestEval2" style="display:none">
				<!-- Suggested activities for "Reasoning" category -->
				<input type="radio" name="strategyVal" value="Argumentación">Argumentación<br>
				<input type="radio" name="strategyVal" value="Esquemas de codificación">Esquemas de codificación<br>
				<input type="radio" name="strategyVal" value="Solución de problemas evaluados por rúbricas">Solución de problemas evaluados por rúbricas<br>
				<input type="radio" name="strategyVal" value="Ensayos">Ensayos<br>
				<input type="radio" name="strategyVal" value="Problemas construidos por estudiantes">Problemas construidos por estudiantes<br>
			</div>
			<div id="suggestEval3" style="display:none">
				<!-- Suggested activities for "Creativity/Synthesis" category -->
				<input type="radio" name="strategyVal" value="Portafolio o bitácora">Portafolio o bitácora<br>
				<input type="radio" name="strategyVal" value="Reportes">Reportes<br>
				<input type="radio" name="strategyVal" value="Presentación oral">Presentación oral<br>
				<input type="radio" name="strategyVal" value="Presentación tipo poster">Presentación tipo poster<br>
				<input type="radio" name="strategyVal" value="Bitácora de reflexión">Bitácora de reflexión<br>
			</div>
			<div id="suggestEval4" style="display:none">
				<!-- Suggested activities for "Skill/Process/Procedure" category -->
				<input type="radio" name="strategyVal" value="Observación de productos, procesos, o desempeño evaluados con rúbrica">Observación de productos, procesos, o desempeño evaluados con rúbrica<br>
				<input type="radio" name="strategyVal" value="Reportes">Reportes<br>
			</div>
			<div id="suggestEval5" style = "display:none">
				<!-- Suggested activities for "Attitude" category -->
				<input type="radio" name="strategyVal" value="Autoevaluación">Autoevaluación<br>
				<input type="radio" name="strategyVal" value="Bitácora de reflexión">Bitácora de reflexión<br>
				<input type="radio" name="strategyVal" value="Portfolio">Portfolio<br>			
			</div>			
			<input type="radio" name="strategyVal" value="other" checked>Otra...<br><br>
			<button type="button" onclick="evalSetStrategy()">Siguiente</button>
			&nbsp; &nbsp; <button type="button" onclick="evalCancel()">Cancelar</button> <br> <br>
		</div>
		<div id="evalPanelStep2" style="display:none"> 
			<p>Con base en el sílabo del curso, los RAPs y habilidades asociadas, 
			se recomiendan las siguientes rúbricas. Marque todas aquellas las que requiera 
			para la actividad, o ninguna si no aplica.</p>
			Mostrar <input type="radio" name="filterRubs" value="sugg" onchange="evalLoadRubricTable('SuggRubs')" checked>rúbricas sugeridas / 
					<input type="radio" name="filterRubs" value="all" onchange="evalLoadRubricTable('SuggRubs')">todas las rúbricas del sílabo<br>
			<div id="evalSuggRubs"></div> <br>
			<button type="button" onclick="evalAppendRubrics('evalSuggRubs',true)">Siguiente</button>
			&nbsp; &nbsp; <button type="button" onclick="evalCancel()">Cancelar</button><br><br>
		</div>
		<div id="evalPanelStep3" style="display:none"> 
			<p>Describa la estrategia de la evaluación y de ser necesario asocie o remueva rúbricas. Recuerde que no todas las actividades se pueden evaluar con rúbricas.</p>
			<b><u>Descripción de la estrategia</u></b> <br>
			<textarea id="evalText" rows=3 cols=50></textarea> <br>
			<button type="button" onclick="evalStrategyAssistant()">Asistente para estrategias...</button><br><br>
			<b><u>Rúbricas asociadas para evaluar la actividad</u></b> <br>
			<div id="evalActRubs"></div>
			<button type="button" onclick="evalSuggRubsAssistant()">Asociar una rúbrica del sílabo...</button> &nbsp; 
			<button type="button" onclick="evalGenRubsAssistant()">Asociar una rúbrica general...</button>&nbsp; 
			<button type="button" onclick="evalNewRubric()">Crear una rúbrica...</button><br><br>
			<button type="button" onclick="evalSave()">Guardar</button>
			&nbsp; &nbsp; <button type="button" onclick="evalCancel()">Cancelar</button><br><br>
		</div>
		<div id="evalPanelStep4" style="display:none"> 
			<p>A continuación se muestran todas las rúbricas genéricas del plan de estudios que se pueden asociar a la actividad. Marque aquellas que aplique y de clic en el botón "Asociar".</p>
			<div id="evalGenRubs"></div> <br> <br>
			<button type="button" onclick="evalAppendRubrics('evalGenRubs',false)">Asociar</button>
			&nbsp; &nbsp; <button type="button" onclick="evalCancel()">Cancelar</button><br><br>
		</div>
	   </div>
	  </div>
	</div>	
	<input id="evalActID" name="evalActID" style="display:none">
	
	<div id="RubricViewerPanel" class="modal" style="display:none">
	  <!-- Modal content -->
	  <div class="modal-content">
	  <div  class="modal-body">
		<span  class="close-gray">&times;</span >
		<small><div id="RubricViewer"></div></small>
	   </div>
	  </div>
	</div>	
	
</div>

<?php $planea->closeConnection(); ?>

</body>
</html>
