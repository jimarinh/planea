function renderCourseDependencies(c, courses, reqs, electives, zoomScale, tx, ty)
{
	var ctx = c.getContext("2d");
	courses = resetCourses(courses);
	var positions = computeBoxPositions(ctx, courses, reqs);
	c.width = positions.xpos[positions.xpos.length-1]+positions.maxw+10;
	c.height = positions.ypos[positions.ypos.length-1]+positions.maxh+10;
	ctx.scale(zoomScale, zoomScale);
	ctx.translate(tx,ty);
	drawTitles( ctx, positions );
	drawBoxes( ctx, courses, electives, positions ); 
	reqs = sortDependencies( courses, reqs );
	drawArrows( ctx, courses, reqs, positions );
}
	

function maxNumberSemesters( courses )
{
	var i;
	var maxsem = 0;	
	//Determina el número máximo de semestres
	for (i=0; i<courses.length; i++)
	{
		if ( courses[i].Sem > maxsem ) {
			maxsem = courses[i].Sem;
		}
	}
	return maxsem;
}

function maxNumberRows( courses )
{
	var i;
	var maxrow = 0;	
	//Determina el número máximo de semestres
	for (i=0; i<courses.length; i++)
	{
		if ( courses[i].Row  > maxrow ) {
			maxrow = courses[i].Row;
		}
	}
	return maxrow;
}


function hasDependency( ID, reqs )
{
	var i;
	for (i=0; i<reqs.length; i++) {
		if (reqs[i].E == ID) {
			return true;
		}
	}
	return false;
}

function findPostReq( ID, reqs )
{
	var i;
	for (i=0; i<reqs.length; i++) {
		if (reqs[i].R == ID) {
			return reqs[i].E;
		}
	}
	return -1;
}

function findPreReq( ID, reqs )
{
	var i;
	for (i=0; i<reqs.length; i++) {
		if (reqs[i].E == ID) {
			return reqs[i].R;
		}
	}
	return -1;
}

function getNumReqs( ID, reqs )
{
	var i, n=0;
	for (i=0; i<reqs.length; i++) {
		if (reqs[i].E == ID) {
			n++;
		}
	}
	return n;
}


function findCourse( courses, ID )
{
	for (i=0; i<courses.length; i++)
	{
		if ( courses[i].ID == ID ) {
			return i;
		}
	}
	return -1;
}

function replaceCluster( courses, orgcluster, tarcluster )
{
	var j;
	for (j=0; j<courses.length; j++)
	{
		if (courses[j].C == orgcluster) {
			courses[j].C = tarcluster;
		}
	}
}			


function placeCourseBySem( courses, reqs )
{
	/*var i;
	var isem;
	var row = [];
	//Asigna una fila a cada curso
	for (i=0; i<20; i++) {
		row[i] = 0;
	}
	for (i=0; i<courses.length; i++)
	{
		isem = courses[i].Sem-1;
		courses[i].Row = row[isem];
		row[isem]++;
	}
	*/

	var i, isem, icluster, tcluster, R;
	var clusterw = [];
	var ncluster = 0;
	var maxsem = maxNumberSemesters( courses );
	var maxrow;
	var row = [];
	
	//Asigna el cluster a cada curso comenzando desde el último semestre.
	for (isem=maxsem; isem>=1; isem--) {
		for (i=courses.length-1; i>=0; i--)
		{
			if (courses[i].Sem == isem) {
				R = findPostReq( courses[i].ID, reqs );
				//Hereda el cluster del curso del cual es requisito, 
				//en caso contrario crea un nuevo cluster si el curso tiene dependencias
				//y si no tiene lo pone en el cluster de cursos independientes (cluster 0)
				if ( R != -1 ) {
					courses[i].C = courses[ findCourse(courses,R) ].C;
					clusterw[courses[i].C]++;
				}
				else {
					if ( hasDependency(courses[i].ID, reqs) ) {
						ncluster++;
						courses[i].C = ncluster;
						clusterw[ncluster] = 1;
					} else {
						courses[i].C = 0;
					}
				}
			}
		}	
	}
	
	//Combina los clusters cuando un cluster tiene muy pocos cursos 
	for(icluster=1; icluster<=ncluster; icluster++) {
		if (clusterw[icluster]<=3) {
			for (i=0; i<courses.length; i++)
			{
				if (courses[i].C == icluster) {
					R = findPreReq( courses[i].ID, reqs );
					if (R!=-1) {
						CIdx=findCourse(courses,R);
						if (CIdx!=-1) {
							tcluster = courses[CIdx].C;
							if (icluster != tcluster) {
								//Reemplaza el cluster
								replaceCluster(courses, icluster, tcluster);
								//clusterw[tcluster] += clusterw[icluster];						
							}
						}
					}
				}		
			}
		}
	}	
	
	//Inicializa el contador de número de cursos por semestre
	for (i=0; i<maxsem; i++) {
		row[i] = 0;
	}
	
	//Asigna la fila a cada curso basado en el cluster
	for(icluster=ncluster; icluster>=0; icluster--) {
		
		if (!compactview) {
			maxrow = 0;
			for(i=0; i<maxsem; i++) {
				if (row[i]>maxrow) {
					maxrow = row[i];
				}
			}
			for(i=0; i<maxsem; i++) {
				row[i] = maxrow;
			}
		}

		for (i=0; i<courses.length; i++)
		{
			if (courses[i].C == icluster) {
				isem = courses[i].Sem-1;
				courses[i].Row = row[isem];
				row[isem]++;
			}
		}
	}
}


function computeSpaces( courses, reqs )
{
	var maxsem;
	var maxrow;
	var rowspaces = [];
	var colspaces = [];
	var alloccolspaces_left = [];
	var alloccolspaces_right = [];
	var allocrowspaces = [];
	var i, source_idx, target_idx;
	var source;
	var target;
	var spaces;
	
	//Inicializa las matrices que indican cuántos espacios extra hay
	//que añadir para trazar adecuadamente las líneas
	maxsem = maxNumberSemesters( courses );
	maxrow = maxNumberRows( courses );
	for(i=0; i<maxsem; i++) {
		colspaces[i] = 0;
		alloccolspaces_left[i] = 0;
	}
	for(i=0; i<maxrow; i++) {
		rowspaces[i] = 0;
		allocrowspaces[i] = 0;
	}

	//Determina el número de espacios a adicionar por cada columna y fila
	for (i=0; i<reqs.length; i++)
	{
		source_idx = findCourse( courses, reqs[i].R );
		target_idx = findCourse( courses, reqs[i].E );
		if ( source_idx == -1 ) {
			if ( target_idx != -1 ) {
				target = courses[target_idx];
				alert("El espacio académico '"+target.Name+"' tiene un requisito que no existe, o tiene un requisito que es una asignatura electiva y '"+target.Name+"' no ha sido definida como electiva. (Error R"+reqs[i].R+")"); 
			}
			else {
				alert( "Requisito "+ reqs[i].R + " no existe");
			}
			continue;
		}
		if ( target_idx == -1 ) {
			alert( "Espacio "+ reqs[i].E + " no existe");
			continue;
		}
		
		source = courses[source_idx];
		target = courses[target_idx];
		
		courses[source_idx].NO++;
		colspaces[source.Sem-1]++;
		
		courses[target_idx].NI++;
		if (target.Sem>1) { 
			colspaces[target.Sem-2]++ 
		}
		
		//Cuando los semestres no son consecutivos debe insertar una fila para poder trazar las lineas adecuadamente
		if ( Math.abs(source.Sem-target.Sem)>1 ) 
		{
			if(source.Row > target.Row) {
				rowspaces[target.Row]++;
			}
			if(source.Row <= target.Row) {
				rowspaces[source.Row]++;
			}
		}
	}
	
	for(i=0; i<maxsem; i++) {
		alloccolspaces_right[i] = colspaces[i] ;
	}
	
	spaces = {colspaces:colspaces, rowspaces:rowspaces, alloccolspaces_left:alloccolspaces_left, alloccolspaces_right:alloccolspaces_right, allocrowspaces:allocrowspaces};
	return spaces;
}


function measureTextCourse( ctx, str, maxw, maxh )
{
	var words  = str.split(" ");
	var widths = [];
	var hrow   = 15;
	var j, w, h;
	var nrows  		= 0;
	var strRows 	= [];
	var widthRows 	= [];
	var ret;
	
	//Calcula el ancho de cada palabra
	for(j=0; j<words.length; j++)
	{
		widths[j] = ctx.measureText(words[j]).width;
	}
	
	//Determina el ancho máximo del cajón
	for(j=0; j<widths.length; j++)
	{
		if (widths[j]+10 > maxw) {
			maxw = widths[j]+10;
		}
	}
	
	//Determina el número de filas y calcula el ancho de cada fila
	str = "";
	w   = 0;
	for(j=0; j<widths.length; j++)
	{
		if (w+widths[j]+5 > maxw) 
		{
			strRows[nrows] = str;
			widthRows[nrows] = w;
			str = "";
			w   = 0;
			nrows++;
		}
		w += widths[j]+5;
		str = str + " " + words[j];
	}
	strRows[nrows] = str;
	widthRows[nrows] = w;
	
	//Calcula el alto máximo del cajón
	h = strRows.length*hrow+10;
	if (h > maxh)
	{
		maxh = h;
	}
	
	ret = {maxw:maxw, maxh:maxh, hrow:hrow, strRows:strRows, widthRows:widthRows};
	return ret;
}


function computeBoxPositions(ctx, courses, reqs)
{
	var xpos = [];
	var ypos = [];
	var xpos_t, ypos_t;
	var i;
	var maxw = 100;
	var maxh = 50;
	var positions;

	placeCourseBySem( courses, reqs );
	spaces = computeSpaces( courses, reqs );
	maxsem = maxNumberSemesters( courses );
	maxrow = maxNumberRows( courses );

	ctx.font = "14px Arial";
	for (i=0; i<courses.length; i++)
	{
		tm = measureTextCourse( ctx, courses[i].Name, maxw, maxh );
		maxw = tm.maxw;
		maxh = tm.maxh;
	}

	xpos_t = 1;
	for( i = 0; i<maxsem; i++)
	{
		xpos[i] = xpos_t;
		xpos_t  += maxw+10 + spaces.colspaces[i]*10;
	}

	ypos_t = 30;
	for( i = 0; i<=maxrow; i++)
	{
		ypos[i] = ypos_t;
		ypos_t  += maxh+10 + spaces.rowspaces[i]*10;
	}
	
	positions = {xpos:xpos, ypos:ypos, maxw:maxw, maxh:maxh};
	return positions;
}


function resetCourses(courses)
{
	for (var i=0; i<courses.length; i++)
	{
		courses[i].Row=0;
		courses[i].C=0;
		courses[i].NO=0;
		courses[i].AO=0;
		courses[i].NI=0;
		courses[i].AI=0;
	}
	return courses;
}

function drawTitles( ctx, positions )
{
	var i;
	var xpos = positions.xpos;
	var maxw = positions.maxw;
	
	ctx.font = "14px Arial";
	for (i=0; i<xpos.length; i++)
	{		
		ctx.fillStyle = "#F0F0F0";
		ctx.fillRect(xpos[i],1,maxw,21);
		ctx.strokeRect(xpos[i],1,maxw,21);
		
		ctx.fillStyle = "#000000";
		ctx.strokeStyle = "#000000";
		ctx.textAlign = "center";
		ctx.fillText("SEMESTRE "+(i+1), xpos[i]+maxw/2, 18);
		ctx.textAlign = "left";
	}
}

function drawTextCourse( ctx, tm, xpos_t, ypos_t )
{
	var j;
	var dx;
	ypos_t += tm.hrow + (tm.maxh - tm.strRows.length*tm.hrow)/2;	
	for(j=0; j<tm.strRows.length; j++)
	{
		dx = (tm.maxw - tm.widthRows[j])/2;
		ctx.fillText(tm.strRows[j], xpos_t+dx, ypos_t);
		ypos_t += tm.hrow;
	}
}	

function isElective(electives, ID) {
	var i;
	for (i=0; i<electives.length; i++) {	
		if (electives[i].ID == ID) 
			return true;
	}
	return false;
}

function drawBoxes( ctx, courses, electives, positions )
{
	var i, xpos_t, ypos_t;
	var tm;
	var xpos = positions.xpos;
	var ypos = positions.ypos;
	var maxw = positions.maxw;
	var maxh = positions.maxh;
	
	ctx.font = "14px Arial";
	for (i=0; i<courses.length; i++) {
		xpos_t = xpos[ courses[i].Sem-1 ];
		ypos_t = ypos[ courses[i].Row ];
		if (isElective(electives, courses[i].ID)) {
			ctx.fillStyle = "#F03FF0";
		} else {
			ctx.fillStyle = "#F0F0F0";
		}
		ctx.fillRect(xpos_t,ypos_t,maxw,maxh);
		ctx.strokeRect(xpos_t,ypos_t,maxw,maxh);
		
		ctx.fillStyle = "#000000";
		ctx.strokeStyle = "#000000";
		tm = measureTextCourse( ctx, courses[i].Name, maxw, maxh );
		drawTextCourse(ctx, tm, xpos_t, ypos_t);
	}
}


function sortDependencies( courses, reqs )
{
	var j, k, idx;
	var nReqsCourse;
	var nNewReqs = 0;
	var newReqs = [];
	for(j=0; j<courses.length; j++) {
		//Cuenta el número de dependencias
		reqsCourse = [];
		row = courses[j].Row;
		sem = courses[j].Sem;
		nReqsCourse = 0;
		for(k=0; k<reqs.length; k++) {
			if (reqs[k].E==courses[j].ID) {
				idx = findCourse( courses, reqs[k].R );
				reqsCourse[nReqsCourse] = {Idx:k, DRow:courses[idx].Row - row, DSem:courses[idx].Sem - sem};
				nReqsCourse++;
			}
		}
		//Ordena los requisitos
		if (nReqsCourse>=2) {		
			reqsCourse.sort(function(a, b){if (a.DRow != b.DRow) return a.DRow - b.DRow; else return b.DSem - a.DSem;});	
		}
		for(k=0; k<reqsCourse.length; k++) {
			newReqs[nNewReqs] = reqs[reqsCourse[k].Idx];
			nNewReqs++;
		}
	}
	return newReqs;
}



function drawArrows( ctx, courses, reqs, positions )
{
	var j, source_idx, target_idx;
	var xpos_t, ypos_t, xposprev_t, yposprev_t;
	var source, target;
	var xpos = positions.xpos;
	var ypos = positions.ypos;
	var maxw = positions.maxw;
	var maxh = positions.maxh;	
	
	//Tramos 1,3,5: Siempre
	//Tramos 2: Si hay más de un semestre de diferencia
	//Tramo  4: Siempre, para permitir que un curso tenga varios requisitos.
	//	+----+			+----+
	//	|    |-(1)-+	|    |
	//	+----+	   |	+----+
	//			  (2)
	//			   +--(3)-------+
	//						    |
	//						   (4)
	//					+----+	|		+----+
	//					|    |	+(5)----|    |
	//					+----+			+----+

	for (j=0; j<reqs.length; j++)
	{
		source_idx = findCourse( courses, reqs[j].R );
		target_idx = findCourse( courses, reqs[j].E );
		if ( (source_idx == -1) || (target_idx == -1) ) {
			continue;
		}
		source = courses[source_idx];
		target = courses[target_idx];
		
		//Muestra la dependencia en color rojo, ya que es un error 
		//tener dependencias con cursos del mismo semestre o posteriores
		ctx.beginPath();
		if ( target.Sem <= source.Sem ) {
			ctx.strokeStyle = "#FF0000";
		} else {
			ctx.strokeStyle = "#000000";
		}

		//Tramo 1
		courses[source_idx].AO++;
		xpos_t = xpos[ source.Sem-1 ] + maxw;
		ypos_t = ypos[ source.Row ] + (maxh/(source.NO+1))*courses[source_idx].AO;
		if ( source.Row > target.Row ) ypos_t+=3; //Evita que se crucen líneas cuando las flechas van a un bloque superior
		
		ctx.moveTo(xpos_t, ypos_t);
		spaces.alloccolspaces_left[source.Sem-1]++;
		xpos_t += 10*spaces.alloccolspaces_left[source.Sem-1];
		ctx.lineTo(xpos_t-5, ypos_t);
		xposprev_t = xpos_t;
		yposprev_t = ypos_t;
				
//	ctx.font = "10px Arial"
//	ctx.fillStyle = "#000000";
//	ctx.strokeStyle = "#000000";
//	ctx.textAlign = "left";
//	ctx.fillText(j, xpos_t, ypos_t);
	
		//Tramo 2
		if ( Math.abs(source.Sem-target.Sem)>1 )
		{
			if (source.Row > target.Row)
			{
				spaces.allocrowspaces[target.Row]++;
				ypos_t = ypos[target.Row]+maxh+spaces.allocrowspaces[target.Row]*10;
			}
			else
			{
				spaces.allocrowspaces[source.Row]++;
				ypos_t = ypos[source.Row]+maxh+spaces.allocrowspaces[source.Row]*10;
			}
			
			if (ypos_t > yposprev_t) {
				ctx.arcTo(xpos_t, yposprev_t, xpos_t, yposprev_t+5,5);
				ctx.lineTo(xpos_t, ypos_t-5);
				if (target.Sem > source.Sem) {
					ctx.arcTo(xpos_t, ypos_t, xpos_t+5,ypos_t,5);				
				} else {
					ctx.arcTo(xpos_t, ypos_t, xpos_t-5, ypos_t,5);
				}
			} else {
				ctx.arcTo(xpos_t, yposprev_t, xpos_t, yposprev_t-5,5);
				ctx.lineTo(xpos_t, ypos_t+5);
				if (target.Sem > source.Sem) {
					ctx.arcTo(xpos_t, ypos_t, xpos_t+5, ypos_t,5);
				} else {
					ctx.arcTo(xpos_t, ypos_t, xpos_t-5, ypos_t,5);
				}
			}
		}
		
		//Tramo 3
		if (target.Sem>=2) {
			xpos_t = xpos[target.Sem-2] + maxw + spaces.alloccolspaces_right[target.Sem-2]*10;
			spaces.alloccolspaces_right[target.Sem-2]--;
		} 
		else
		{
			xpos_t = 0;
		}
		ctx.lineTo(xpos_t-5, ypos_t);
		xposprev_t = xpos_t;
		yposprev_t = ypos_t;
			
		//Tramo 4
		courses[target_idx].AI++;
		ypos_t = ypos[target.Row]+(maxh/(target.NI+1))*courses[target_idx].AI;
		if ( source.Row > target.Row ) ypos_t+=4; //Evita que se crucen líneas cuando las flechas van a un bloque superior
		
		if (yposprev_t != ypos_t) {
			if (ypos_t > yposprev_t) {
				ctx.arcTo(xpos_t, yposprev_t, xpos_t, yposprev_t+5,5);
				ctx.lineTo(xpos_t, ypos_t-5);
				if (target.Sem > source.Sem) {
					ctx.arcTo(xpos_t, ypos_t, xpos_t+5,ypos_t,5);				
				} else {
					ctx.arcTo(xpos_t, ypos_t, xpos_t-5, ypos_t,5);
				}
			} else {
				ctx.arcTo(xpos_t, yposprev_t, xpos_t, yposprev_t-5,5);
				ctx.lineTo(xpos_t, ypos_t+5);
				if (target.Sem > source.Sem) {
					ctx.arcTo(xpos_t, ypos_t, xpos_t+5, ypos_t,5);
				} else {
					ctx.arcTo(xpos_t, ypos_t, xpos_t-5, ypos_t,5);
				}
			}
		}
		
		//Tramo 5
		xpos_t = xpos[target.Sem-1];
		ctx.lineTo(xpos_t,ypos_t);
		ctx.stroke();
		
		//Flecha
		ctx.beginPath();
		ctx.moveTo(xpos_t-5,ypos_t-5);
		ctx.lineTo(xpos_t,ypos_t);
		ctx.lineTo(xpos_t-5,ypos_t+5);
		ctx.stroke();
	}
}
