<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$skillType = $_GET["skillType"];
switch ($skillType) {
    case "P":
        $databasename = "personal_skills";
		$rubricSkillType = 1;
        break;
    case "I":
        $databasename = "interpersonal_skills";
        $rubricSkillType = 2;
		break;
    case "C":
        $databasename = "cdio_skills";
		$rubricSkillType = 3;
        break;
}
$sql = "DELETE FROM courses_".$databasename." WHERE ID=" . $_GET["removeID"];
$planea->conn->query($sql);
$sql = "DELETE FROM rubrics_assoc WHERE RapSkillID=".$_GET["removeID"]." AND RapSkillType=".$rubricSkillType;
$planea->conn->query($sql);
$sql = "DELETE FROM teacher_actassoc WHERE RapSkillID=".$_GET["removeID"]." AND RapSkillType=".$rubricSkillType;
$planea->conn->query($sql);
$planea->closeConnection();
?>