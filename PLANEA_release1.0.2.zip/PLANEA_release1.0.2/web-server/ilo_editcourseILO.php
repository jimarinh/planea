<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "SELECT * FROM courses_ilos WHERE ID=".$_GET["iloID"];
$result = $planea->conn->query($sql);
$row = $result->fetch_assoc();
header('Content-type: application/json');
$row["Text"] = $row["Text"];
echo json_encode($row);
$planea->closeConnection();
?>