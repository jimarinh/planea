<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$CourseID = $_GET["courseID"];	
$sql = "SELECT * FROM courses_contents WHERE CourseID=" . $CourseID;
$result = $planea->conn->query($sql);
$topicNumber = $result->num_rows+1; 
$sql = "INSERT INTO courses_contents (CourseID,TopicNumber) VALUES (" . $CourseID . ",".$topicNumber.")";
if ($planea->conn->query($sql)==TRUE) {
	$last_id = $planea->conn->insert_id;
	$sql = "SELECT * FROM courses_contents WHERE ID=" . $last_id;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$planea->showUnit($CourseID, $topicNumber, $topicNumber, $row, true);
}
$planea->closeConnection();
?>