<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$CourseID = $_GET["courseID"];
$topicID = $_GET["topicID"];
$dir = $_GET["dir"];

$sql = "SELECT * FROM courses_contents WHERE ID=" . $topicID;
$result = $planea->conn->query($sql);
$row = $result->fetch_assoc();
$currentPos = $row["TopicNumber"];
$newPos = $currentPos+$dir;

$sql = "UPDATE courses_contents SET TopicNumber=". $currentPos ." WHERE CourseID=" . $CourseID ." AND TopicNumber=".$newPos;
$planea->conn->query($sql);

$sql = "UPDATE courses_contents SET TopicNumber=". $newPos ." WHERE ID=" . $topicID;
$planea->conn->query($sql);

$planea->closeConnection();
?>