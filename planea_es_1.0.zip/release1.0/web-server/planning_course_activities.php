<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<style>
		textarea  
		{  
			font-family:"Helvetica", Helvetica, sansserif;  
			font-size: 14px;
			width:100%;
		}
	</style>
	<script type="text/javascript" language="javascript" src="planning_course_activities.js"></script>	
	<script>
		var dispHowTo = true;
		var dispDesc = true;
		var dispSkills = true;
		var zoomScale = 1.0;
		
		function computeWidth() {
			var clientWidth = 	Math.trunc(parseFloat(window.getComputedStyle(viewer).width)-
								 parseFloat(window.getComputedStyle(viewer, null).getPropertyValue('padding-left'))-
								 parseFloat(window.getComputedStyle(viewer, null).getPropertyValue('padding-right')));						
			return clientWidth;
		}
		
		function renderActs() {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var obj = JSON.parse(this.responseText);
					startRender(document.getElementById("myCanvas"), obj.Raps, obj.Acts, dispHowTo, dispDesc, dispSkills); 
					renderActivities( computeWidth(), zoomScale, 0, 0);
				}
			};
			xhttp.open("GET", "planning_course_loadact.php?CourseID="+CourseID.value+"&UserID="+UserID.value+"&SemesterID="+SemesterID.value, true);
			xhttp.send();
		}
		
		function changeViewStyle() {
			dispHowTo = document.getElementById("showHowTo").checked;
			dispDesc  = document.getElementById("showDesc").checked;
			dispSkills = document.getElementById("showSkills").checked;
			resetView();
			renderActivities(computeWidth(), zoomScale, 0, 0);
		}
		function zoomIn() {
			zoomScale *= 1.2;
			resetView();
			renderActivities(computeWidth(), zoomScale, 0, 0);
		}
		function zoomOut() {
			zoomScale *= 0.8;
			resetView();
			renderActivities(computeWidth(), zoomScale, 0, 0);
		}
		
		function configurePanels() {
			InsertActPanel.style.display = "none";
			EditActPanel.style.display = "none";
			setPanelStatus(false);
			var span = document.getElementsByClassName("close");
			span[0].onclick = function() { InsertActPanel.style.display = "none"; setPanelStatus(false); }
			span[1].onclick = function() { EditActPanel.style.display = "none"; setPanelStatus(false); }
		}
		
		//Action management for InsertActPanel
		function insertActivityAccept() { //insert
			var activityName = document.querySelector('input[name="activityVal"]:checked').value;
			if (activityName=="other") activityName = "";
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					InsertActPanel.style.display = "none";
					setPanelStatus(false); 
					renderActs();
					editActivity({ID:this.responseText, Name:activityName, Desc:"", HD:0, HI:0});
				}
			};
			xhttp.open("GET", "planning_course_actgo.php?action=insertAct&RapID="
					+insertActRapID.value+"&Name="+activityName+
					"&CourseID="+CourseID.value+"&UserID="+UserID.value+"&SemesterID="+SemesterID.value, true);
			xhttp.send();
		}
		function insertActivityCancel() { //cancel
			InsertActPanel.style.display = "none";
			setPanelStatus(false); 
		}
		function insertActivityChangeVerb() { //change verb category
			var e = document.getElementById("insertActCat");
			var VerbCat = e.options[e.selectedIndex].value;
			for(i=1; i<=5; i++) {
				document.getElementById("suggestAct"+i).style = (VerbCat == i) ? "display:block" : "display:none";
			}			
		}		
		function insertActivity(rap) //Callback when user click on the insert activity button
		{	
			//Set values in the Insert Activity Panel
			insertActRapID.value = rap.ID;
			insertActRapText.innerText = rap.Text;
			//Display the suggested activities according to ILO verb
			var rapCat = document.getElementById("insertActCat").options;
			for(pos=0;pos<rapCat.length;pos++) {
				if (rapCat[pos].value == rap.VerbCat) {
					document.getElementById("insertActCat").selectedIndex = pos;
					break;
				}
			}
			for(i=1; i<=5; i++) {
				document.getElementById("suggestAct"+i).style = (rap.VerbCat == i) ? "display:block" : "display:none";
			}
			var ops = document.getElementsByName("activityVal");
			ops[ops.length-1].checked = true;
			//Display Insert Activity Panel
			InsertActPanel.style.display = "block";
			setPanelStatus(true);
		}

		
		var topicValues = null;
		
		function editActivityChangeTopic()
		{
			var e = document.getElementById("editActTopic");
			if (e.selectedIndex<=0) { editActTopicVal.innerHTML = ""; return; }
			editActTopicVal.innerHTML = topicValues[e.selectedIndex-1];
		}
		
		function editActivityViewTopic()
		{
			editActTopicVal.style.display = editActDispTopic.checked ? "block" : "none";
		}
		
		//Action management for EditActPanel
		function editActivityGo(action) 
		{
			var serialize = function (form) {
				// Setup our serialized data
				var serialized = [];
				// Loop through each field in the form
				for (var i = 0; i < form.elements.length; i++) {
					var field = form.elements[i];
					// Don't serialize fields without a name, submits, buttons, file and reset inputs, and disabled fields
					if (!field.name || field.disabled || field.type === 'file' || field.type === 'reset' || field.type === 'submit' || field.type === 'button') continue;
					// If a multi-select, get all selections
					if (field.type === 'select-multiple') {
						for (var n = 0; n < field.options.length; n++) {
							if (!field.options[n].selected) continue;
							serialized.push(encodeURIComponent(field.name) + "=" + encodeURIComponent(field.options[n].value));
						}
					}
					// Convert field data to a query string
					else if ((field.type !== 'checkbox' && field.type !== 'radio') || field.checked) {
						serialized.push(encodeURIComponent(field.name) + "=" + encodeURIComponent(field.value));
					}
				}
				return serialized.join('&');
			};
			
			if (action==1) { //insert
				var serializedForm = serialize(editActForm);
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						EditActPanel.style.display = "none";
						setPanelStatus(false);
						renderActs();
					}
				};
				xhttp.open("GET", "planning_course_actgo.php?"+serializedForm, true);
				xhttp.send();
			}
			
			if (action==2) { //cancel
				EditActPanel.style.display = "none";
				setPanelStatus(false);
			}
		}
		
		function editActivity(act)
		{
			//Set values in the Edit Activity Panel
			editActID.value 	= act.ID;
			editActName.value 	= act.Name;
			editActDesc.value 	= act.Desc;
			editActHD.value 	= act.HD;
			editActHI.value 	= act.HI;
			//Get the topics and skill information
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var obj = JSON.parse(this.responseText);
					editActTopic.innerHTML = obj.TopicNames; 
					editActSkills.innerHTML = obj.Skills;
					topicValues = obj.TopicContents;
					editActDispTopic.checked = false;
					editActTopicVal.style.display = "none";
					editActivityChangeTopic();
					EditActPanel.style.display = "block";
					setPanelStatus(true);
				}
			};
			xhttp.open("GET", "planning_course_actgo.php?action=getActInfo&ActID="+act.ID+
				"&CourseID="+CourseID.value+"&UserID="+UserID.value+"&SemesterID="+SemesterID.value, true);
			xhttp.send();
		}
		
		function removeActivity(actID)
		{
			var r = confirm("¿Desea eliminar la actividad?"); 
			if (r == true) {				
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						removeActBox(actID);
						redraw();
					}
				};
				xhttp.open("GET", "planning_course_actgo.php?action=removeAct&ActID="+actID+
					"&CourseID="+CourseID.value+"&UserID="+UserID.value+"&SemesterID="+SemesterID.value, true);
				xhttp.send();
			}
		}
		
		function linkActivity(rapID, actID)
		{
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					addArrow(rapID, actID);
					redraw();
				}
			};
			xhttp.open("GET", "planning_course_actgo.php?action=addLink&ActID="+actID+"&RapID="+rapID+
				"&CourseID="+CourseID.value+"&UserID="+UserID.value+"&SemesterID="+SemesterID.value, true);
			xhttp.send();
		}
		function removeLink(rapID, actID)
		{
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					removeArrow(rapID, actID);
					redraw();
				}
			};
			xhttp.open("GET", "planning_course_actgo.php?action=removeLink&ActID="+actID+"&RapID="+rapID+
				"&CourseID="+CourseID.value+"&UserID="+UserID.value+"&SemesterID="+SemesterID.value, true);
			xhttp.send();
		}
	
		function configure()
		{
			configurePanels();
			renderActs();
		}
	</script>
</head>

<body onload="configure()">

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();  
	
	if ($_SESSION["RoleID"]!=planea::roleUser) {
		exit("Seleccione el rol Docente");
	}
	
	$CourseID 	= $_GET["ID"];
	$SemesterID = isset($_GET["SemesterID"]) ? $_GET["SemesterID"] : $planea->getDefaultSemester();
	$UserID = $_SESSION["UserID"];
	
	$sql = "SELECT Nombre FROM courses_general WHERE ID=" . $CourseID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$CourseName = $row["Nombre"]."(".$SemesterID.")";
	$Action = 2;
?>


<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="planning_course_user.php">Planeación de Cursos</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#teacher-planning2" target="PLANEA-help">?</a></li>
</ul>

<ul class="navbar"> 
<li>
	<a <?php if ($Action==1) echo "class=\"active\""; ?> href="planning_course_howtos.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 1: Preguntas</a>
</li>
<li>
	<a <?php if ($Action==2) echo "class=\"active\""; ?> href="planning_course_activities.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 2: Actividades</a>
</li>
<li>
	<a <?php if ($Action==3) echo "class=\"active\""; ?> href="planning_course_schedule.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 3: Cronograma</a>
</li>
<li>
	<a <?php if ($Action==4) echo "class=\"active\""; ?> href="planning_course_eval.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 4: Evaluación</a>
</li>
<li>
	<a <?php if ($Action==5) echo "class=\"active\""; ?> href="planning_course_rubrics.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Paso 5: Rúbricas
	</a>
</li>
<li>
	<a <?php if ($Action==6) echo "class=\"active\""; ?> href="planning_course_summary.php<?php echo "?ID=".$CourseID."&SemesterID=".$SemesterID; ?>">
	Resumen
	</a>
</li>
<li><a href="view_syllabus.php<?php echo "?ID=".$CourseID;?>"> <?php echo $CourseName; ?> </a></li>
</ul>


<div class="planeaForm">
<small><p>Adicione las actividades para cada uno de los RAPs dando clic en el botón &oplus; de cada RAP. 
	Una misma actividad puede asociarse a varios RAPs, para ello de clic en el RAP al vincular y 
	luego clic sobre la actividad a enlazar. Las actividades y enlaces resaltados pueden eliminarse 
	con la tecla suprimir.
</p></small>
<input id="showHowTo" type="checkbox" value=0 onchange="changeViewStyle()" checked>Mostrar <u>cómos</u> de cada RAP&nbsp; &nbsp; 
<input id="showDesc" type="checkbox" value=0 onchange="changeViewStyle()" checked>Mostrar descripción de actividades&nbsp; &nbsp; 
<input id="showSkills" type="checkbox" value=0 onchange="changeViewStyle()" checked>Mostrar habilidades &nbsp; &nbsp; 
Zoom <button class="button btn_fancy" onclick="zoomIn()" type="button">+</button> <button class="button btn_fancy" onclick="zoomOut()" type="button">-</button>
</div> 	
<div id="viewer" class="planeaForm" onmousedown="mouseDown(event)" onmouseup="mouseUp(event)" onmousemove="mouseMove(event)">
	<canvas id="myCanvas">El navegador no soporta Canvas HTML5
</canvas> 
</div> 

<form id="insertActForm">
	<div id="InsertActPanel" class="modal" style="display:none">
	  <!-- Modal content -->
	  <div class="modal-content">
	  <div  class="modal-header">
		<span  class="close">&times;</span >
		<h2 >Adicionar actividad</h2 >
	  </div>
	  <div  class="modal-body">
		<p>Con base en el verbo principal del resultado de aprendizaje
			"<i><font color="green"><span id="insertActRapText"></span></font></i>", éste se ha clasificado como un RAP de 
			<select id="insertActCat" onchange="insertActivityChangeVerb()">
				<option value=1>conocimiento/disciplinar</option>
				<option value=2>razonamiento</option>
				<option value=3>creatividad/síntesis</option>
				<option value=4>habilidad/proceso/procedimiento</option>
				<option value=5>actitud</option>
			</select> y se recomiendan las siguientes actividades:</p>	
		<div id="suggestAct1" style = "display:none">
			<!-- Suggested activities for "Disciplinary/knowledge" category -->
			<input type="radio" name="activityVal" value="Mapas conceptuales">Mapas conceptuales<br>
			<input type="radio" name="activityVal" value="Paper de un minuto">Paper de un minuto<br>
			<input type="radio" name="activityVal" value="Galería de exposiciones">Galería de exposiciones<br>
			<input type="radio" name="activityVal" value="Toma de notas">Toma de notas<br>
			<input type="radio" name="activityVal" value="Grupo de expertos">Grupo de expertos<br>
			<input type="radio" name="activityVal" value="Pensar individual, compartir en parejas, discutir en cuadrado">Pensar individual, compartir en parejas, discutir en cuadrado<br>
			<input type="radio" name="activityVal" value="Clase magistral con ejercicios transversales">Clase magistral con ejercicios transversales<br>
		</div>	
		<div id="suggestAct2" style="display:none">
			<!-- Suggested activities for "Reasoning" category -->
			<input type="radio" name="activityVal" value="Taller">Taller<br>
			<input type="radio" name="activityVal" value="Solución de problemas">Solución de problemas<br>
			<input type="radio" name="activityVal" value="Preguntas conceptuales">Preguntas conceptuales<br>
			<input type="radio" name="activityVal" value="Mapa conceptual en grupo">Mapa conceptual en grupo<br>
			<input type="radio" name="activityVal" value="Analogía">Analogía<br>
			<input type="radio" name="activityVal" value="Simulación">Simulación<br>
			<input type="radio" name="activityVal" value="Estudio de caso">Estudio de caso<br>
			<input type="radio" name="activityVal" value="Diseño de problemas">Diseño de problemas<br>
		</div>
		<div id="suggestAct3" style="display:none">
			<!-- Suggested activities for "Creativity/Synthesis" category -->
			<input type="radio" name="activityVal" value="Diseñar un experimento">Diseñar un experimento<br>
			<input type="radio" name="activityVal" value="Lluvia de ideas para concebir soluciones">Lluvia de ideas para concebir soluciones<br>
			<input type="radio" name="activityVal" value="Proyecto de diseño/implementación">Proyecto de diseño/implementación<br>
		</div>
		<div id="suggestAct4" style="display:none">
			<!-- Suggested activities for "Skill/Process/Procedure" category -->
			<input type="radio" name="activityVal" value="Demostración">Demostración<br>
			<input type="radio" name="activityVal" value="Laboratorio">Laboratorio<br>
			<input type="radio" name="activityVal" value="Simulaciones">Simulaciones<br>
			<input type="radio" name="activityVal" value="Aprendizaje basado en problemas">Aprendizaje basado en problemas<br>
		</div>
		<div id="suggestAct5" style = "display:none">
			<!-- Suggested activities for "Attitude" category -->
			<input type="radio" name="activityVal" value="Tutoría/mentoring">Tutoría/mentoring<br>
			<input type="radio" name="activityVal" value="Apendizaje colaborativa">Apendizaje colaborativa<br>
			<input type="radio" name="activityVal" value="Proyecto de diseño/implementación">Proyecto de diseño/implementación<br>
			<input type="radio" name="activityVal" value="Aprendizaje de servicio">Aprendizaje de servicio<br>
		</div>			
		<input type="radio" name="activityVal" value="other" checked>Otra...<br><br>
		<button type="button" onclick="insertActivityAccept()">Siguiente</button> &nbsp; &nbsp;
		<button type="button" onclick="insertActivityCancel()">Cancelar</button> <br> <br>
	  </div>
	  </div>
	</div>
	
	<input id="insertActRapID" name="insertActRapID" style="display:none">
</form>


<form id="editActForm">
	<div id="EditActPanel" class="modal" style="display:none">
	  <!-- Modal content -->
	  <div class="modal-content">
	  <div  class="modal-header">
		<span  class="close">&times;</span >
		<h2 >Editar actividad</h2 >
	  </div>
	  <div  class="modal-body">
		<p>Amplíe la descripción de la actividad (se sugiere escribirla en términos de qué hace el estudiante y qué hace el docente). Igualmente, puede asociarle temas y habilidades.</p>
		<u>Nombre de la actividad</u>: <input type="text" id="editActName" name="Name" size=100 style="width: 100%;"></input> <br><br>
		<u>Descripción</u>: <br>
		<textarea id="editActDesc" name="Description" rows=3 cols=50 ></textarea>
		<br><br>
		<u>Tiempo en horas</u>: 
		En clase <input type="number" id="editActHD" name="HD" min=0 max=100 style="width: 2.5em;" >
		independientes <input type="number" id="editActHI" name="HI" min=0 max=100 style="width: 2.5em;">
		<br><br>
		<b><u>Tema asociado:</u></b> <br>
		<select id="editActTopic" name="TopicID" onchange="editActivityChangeTopic()"></select> &nbsp; 
		<input type="checkbox" id="editActDispTopic" onchange="editActivityViewTopic()"> Visualizar el tema completo
		<small><p id="editActTopicVal" style="display:none"></p></small>
		<br>
		<div id="editActSkills"></div>		
		<button type="button" onclick="editActivityGo(1)">Guardar</button> &nbsp; &nbsp;
		<button type="button" onclick="editActivityGo(2)">Cancelar</button> <br> <br>
	  </div>
	  </div>
	</div>
	
	<input id="editActID" name="editActID" style="display:none">
	<input id="CourseID" name="CourseID" style="display:none" value=<?php echo $CourseID;?>>
	<input id="UserID" name="UserID" style="display:none" value=<?php echo $UserID;?>>
	<input id="SemesterID" name="SemesterID" style="display:none" value="<?php echo $SemesterID;?>">
	<input name="action" style="display:none" value="editAct">
</form>


<?php $planea->closeConnection(); ?>
 
</body>
</html>
