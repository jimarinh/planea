<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
</head>

<body>

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	//Check for credentials
	if ($_SESSION["RoleID"]!=planea::roleCoord) {
		exit("<p><font color=\"red\">No tiene permiso para acceder a esta sección</font><p>");
	}
	$helptopic = "coord-electives";
	require('planea_syllabusbar.php');
?>

	<script>
		function viewNewCategoryInfo() {
			document.getElementById("categoryInfo").style.display = "inline";
			document.getElementById("newBtn").style.display = "inline";
			document.getElementById("saveBtn").style.display = "none";
			document.getElementById("categoryList").style.display = "none";
			document.getElementById("verifyMesg").style.display = "none";
		}
		function newCategory(planID) {
			var xhttp = new XMLHttpRequest();
			var n = document.getElementById("CategoryName");
			var c = document.getElementById("Credits");
			var s = document.getElementById("Semester");
			var f = document.getElementById("ForceSemester");
			if (c.value.length == 0) c.value = "0";
			if (s.value.length == 0) s.value = "0";
			document.getElementById("categoryInfo").style.display = "none";
			document.getElementById("categoryList").style.display = "inline";
			document.getElementById("verifyMesg").style.display = "none";
			if (n.value) {
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						document.getElementById("categoryTable").innerHTML = this.responseText;
						updateCategoryList(planID);
					}
				};			
				xhttp.open("GET", "planea_electivecat.php?name="+n.value+"&plan="+planID+"&c="+c.value+"&s="+s.value+"&f="+f.checked, true);
				xhttp.send();
			}
		}
		function editCategory(catID) {
			var xhttp = new XMLHttpRequest();
			document.getElementById("categoryInfo").style.display = "inline";
			document.getElementById("newBtn").style.display = "none";
			document.getElementById("saveBtn").style.display = "inline";
			document.getElementById("categoryList").style.display = "none";
			document.getElementById("verifyMesg").style.display = "none";
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var obj = JSON.parse(this.responseText);
					document.getElementById("CategoryName").value = obj.CategoryName;
					document.getElementById("Credits").value = obj.Credits;
					document.getElementById("Semester").value = obj.Semester;
					document.getElementById("ForceSemester").checked = (obj.ForceSemester==1);
					document.getElementById("CatID").value = obj.ID;
				}
			}
			xhttp.open("GET", "syllabus_electives_edit.php?catID="+catID, true);
			xhttp.send();
		}
		function saveCategory(planID) {
			var xhttp = new XMLHttpRequest();
			var n = document.getElementById("CategoryName");
			var c = document.getElementById("Credits");
			var s = document.getElementById("Semester");
			var f = document.getElementById("ForceSemester");
			var CatID = document.getElementById("CatID").value;
			document.getElementById("categoryInfo").style.display = "none";
			document.getElementById("categoryList").style.display = "inline";
			document.getElementById("verifyMesg").style.display = "none";
			if (n.value) {
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						document.getElementById("categoryTable").innerHTML = this.responseText;
						updateCategoryList(planID);
						updateElectiveList(planID);
					}
				};			
				xhttp.open("GET", "planea_electivecat.php?name="+n.value+"&CatID="+CatID+"&plan="+planID+"&c="+c.value+"&s="+s.value+"&f="+f.checked, true);
				xhttp.send();
			}
		}
		function removeCategory(catID,catName,planID) {
			var xhttp = new XMLHttpRequest();
			var r = confirm("¿Desea eliminar la categoría '" + catName + "'?");
			if (r == true) {	
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						document.getElementById("categoryTable").innerHTML = this.responseText;
						updateCategoryList(planID);
						updateElectiveList(planID);
					}
				};
				xhttp.open("GET", "planea_removeelectivecat.php?CatID="+catID+"&plan="+planID, true);
				xhttp.send();
			}
		}
		function updateCategoryList(planID) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("newElectiveCat").innerHTML = this.responseText;
				}
			};
			xhttp.open("GET", "planea_getelectivecatlist.php?plan="+planID, true);
			xhttp.send();
		}
		function addElective(planID) {
			var xhttp = new XMLHttpRequest();
			var CatID = document.getElementById("newElectiveCat").value;
			var CourseID = document.getElementById("newElectiveCourse").value;
			if (CatID == 0) { alert("Debe escoger primero una categoría de electivas"); return;}
			if (CourseID == 0) { alert("Debe escoger primero el curso que será una electiva"); return;}
			document.getElementById("verifyMesg").style.display = "none";
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					if (this.responseText.startsWith("ERROR:")) {
						alert(this.responseText);
					} else {
						document.getElementById("electiveTable").innerHTML = this.responseText;
					}
				}
			};			
			xhttp.open("GET", "planea_addelective.php?CatID="+CatID+"&plan="+planID+"&CourseID="+CourseID, true);
			xhttp.send();
		}
		function removeElective(electiveID,planID) {
			var xhttp = new XMLHttpRequest();
			document.getElementById("verifyMesg").style.display = "none";
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("electiveTable").innerHTML = this.responseText;
				}
			};			
			xhttp.open("GET", "planea_removeelective.php?ElectiveID="+electiveID+"&plan="+planID, true);
			xhttp.send();
		}
		function updateElectiveList(planID) {
			var xhttp = new XMLHttpRequest();
			document.getElementById("verifyMesg").style.display = "none";
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("electiveTable").innerHTML = this.responseText;
				}
			};			
			xhttp.open("GET", "planea_getelectivelist.php?plan="+planID, true);
			xhttp.send();
		}
		function verifyElectives(planID) {
			var xhttp = new XMLHttpRequest();
			document.getElementById("verifyMesg").style.display = "none";
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					if (this.responseText.length>0) {
						document.getElementById("verifyMesg").innerHTML = this.responseText;
						document.getElementById("verifyMesg").style.display = "inline";
					}
				}
			};			
			xhttp.open("GET", "planea_verifyelectives.php?plan="+planID, true);
			xhttp.send();	
		}
	</script>
	
<?php
$planea = new planea();
$conn = $planea->openConnection();  
?>

<h2>Electivas para el Plan <?php 
	$sql = "SELECT * FROM study_plan WHERE ID=". $_GET["PlanID"];
	$result = $conn->query($sql);
	$row = $result->fetch_assoc();
	echo $row["Code"]." (".$row["Description"].")";
?>
</h2>

<div class="planeaForm">
<b>Categorías de Electivas</b> <br><br>
<div id="categoryInfo" style="display:none">
	Nombre: <input type="text" id="CategoryName" size=30> 
	Créditos <input type="number" id="Credits" min=1 max=20 value=0> &nbsp;
	Semestre <input type="number" id="Semester" min=1 max=20 value=0> <br>
	<input type="checkbox" id="ForceSemester" value=1 checked>Imponer semestre para los cursos en la categoría &nbsp;
	<input type="number" id="CatID" value=-1 style="display:none">
	<button type="button" id="newBtn" onclick="newCategory(<?php echo $_GET["PlanID"]; ?>)" style="display:none">Crear</button>
	<button type="button" id="saveBtn" onclick="saveCategory(<?php echo $_GET["PlanID"]; ?>)" style="display:none">Guardar</button>
	<button type="button" onclick="window.location='syllabus_electives.php?PlanID=<?php echo $_GET["PlanID"]; ?>'">Cancelar</button>
</div>
<div id="categoryList">
	<table id="categoryTable">
	<?php $planea->showElectiveCategories($_GET["PlanID"]); ?>
	</table>
	<br>
	<button type="button" class="button btn_fancy" onclick="viewNewCategoryInfo()">Nueva Categoría <img src="images/btn_add1.png"> </button>				
</div>
</div>

<div class="planeaForm">
<b>Electivas</b> &nbsp; &nbsp; <button type="button" id="verifyBtn" onclick="verifyElectives(<?php echo $_GET["PlanID"]; ?>)">Verificar consistencia</button> 
<br><p class="warningbox" id="verifyMesg" style="display:none"></p><br>
	<table id="electiveTable">
	<?php $planea->showElectives($_GET["PlanID"]); ?>
	</table>
	<br>
	<select id="newElectiveCat"><?php $planea->showElectiveCategoryList($_GET["PlanID"]); ?></select>
	<select id="newElectiveCourse">
	<option value=0>--[Escoga el curso]--</option>
	<?php $planea->showCourseListByPlan($_GET["PlanID"]); ?>
	</select>
	<button type="button" class="button btn_fancy" onclick="addElective(<?php echo $_GET["PlanID"]; ?>)">Nueva Electiva <img src="images/btn_add1.png"> </button>				
</div>

<?php $planea->closeConnection(); ?>

</body>
</html>
