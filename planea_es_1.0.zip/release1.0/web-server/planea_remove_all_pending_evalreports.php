<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	$sql = "DELETE FROM eval_courses WHERE PlanID=".$_GET["PlanID"]." AND Semester='".$_GET["Semester"]."' AND State=0";
	$result = $conn->query($sql);
	$planea->showEvalReportListByCourse($_GET["PlanID"],  $_GET["Semester"], 0);
	$planea->closeConnection();
?>