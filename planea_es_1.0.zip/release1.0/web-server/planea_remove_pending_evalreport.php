<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	$sql = "SELECT PlanID,Semester FROM eval_courses WHERE ID=".$_GET["ReportID"];
	$result = $conn->query($sql);
	$row = $result->fetch_assoc();
	$sql = "DELETE FROM eval_courses WHERE ID=".$_GET["ReportID"];
	$result = $conn->query($sql);
	$planea->showEvalReportListByCourse($row["PlanID"],  $row["Semester"], 0);
	$planea->closeConnection();
?>