<?php  
	require('planea_basics.php');

	function displayCoursesvsRAPs( $conn, $report_title, $planID, $showElectives, $showTooltip )
	{	
		//Pone el título de la página
		$strheading = "<h2>" . $report_title . "</h2>";
	  
		//Captura el listado de cursos
		if ($showElectives) 
			$sql = "SELECT ID,Semestre,Nombre FROM courses_general 
					WHERE PlanID=".$planID." AND VisVersion=1 ORDER BY Semestre, Nombre";
		else
			$sql = "SELECT ID,Semestre,Nombre FROM courses_general 
					WHERE PlanID=".$planID." AND VisVersion=1 AND CourseKeyID NOT IN (SELECT CourseID FROM courses_elective) ORDER BY Semestre, Nombre";
		
		$result_courses = $conn->query($sql);
		$ncourses = $result_courses->num_rows;
	  
		//Captura el listado de RAPs
		$sql = "SELECT * FROM ilo_program WHERE PlanID=".$planID." ORDER BY Position";
		$result_prograp  = $conn->query($sql);
		$nraps = $result_prograp->num_rows;

		//Pone el listado de RAPs de Programa
		$strheading = $strheading. "<p><small>";
		for ($i = 0; $i<$nraps; $i++) {	
			$prograp = $result_prograp->fetch_assoc();
			$strheading = $strheading. $prograp["Position"].". ".$prograp["Value"]."<br>\n";
		}
		$strheading = $strheading. "</small></p>\n";
		
		//Pone el encabezado con el listado de RAPs de Programa
		$result_prograp->data_seek(0);
		$strtable = "<table id=\"RapTb\" style=\"width:100%\"> <tr>\n<th>Sem</th><th>Curso</th>\n";
		$nraps_n2 = 0;
		$prograps_list = array();
		$prograps_names = array();
		while( $prograp = $result_prograp->fetch_assoc() ) {
			$strtable = $strtable. "<th>".$prograp["Position"]."</th>\n";
			$prograps_list[$nraps_n2] = $prograp["ID"];
			$prograps_names[$nraps_n2] = $prograp["Position"].". ".$prograp["Value"];
			$nraps_n2++;
		}
		$strtable = $strtable. "</tr>\n";
		
		$courseID = 0;
		//Por cada curso, busca los RAPs asociados y los ubica en la tabla
		for($i = 0; $i < $ncourses; $i++) {
			//Limpia las banderas
			$courseRaps = array();
			for ($j = 0; $j<$nraps_n2; $j++) {
				$courseRaps[$j] = 0;
			}
				
			//Captura la información del curso
			$course = $result_courses->fetch_assoc();
		
			//Captura los RAPs para dicho curso
			$sql = "SELECT * FROM courses_ilos WHERE CourseID=" . $course["ID"] ." ORDER BY Position";
			$result_prograpcourse  = $conn->query($sql);
			
			while( $prograpinfo = $result_prograpcourse->fetch_assoc() ) {
				$prograpID_check  = $prograpinfo["ProgramILOID"]; 
				for ($j = 0; $j<$nraps_n2; $j++) {	
					$prograpID = $prograps_list[$j];
					if ( $prograpID_check == $prograpID ) {
						$courseRaps[$j]=1;
					}
				}
			}
		
			$strtable = $strtable. "<tr> <td><small>" . $course["Semestre"] . "</small></td> <td><small>" . $course["Nombre"] . "</small></td> \n";
			for ($j = 0; $j<$nraps_n2; $j++)
			{	
				$info = "";
				if ( $courseRaps[$j] == 1 ) { 
					$info = $info . "X"; 
				} else {
					$info = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
				}
				if ($showTooltip) 
					$strtable = $strtable. "<td style=\"text-align:center\"><div class=\"tooltip\"><small>". $info. "</small><span class=\"tooltiptext\">".$prograps_names[$j]."</span></div></td>\n";
				else 
					$strtable = $strtable. "<td style=\"text-align:center\"><small>". $info. "</small></td>\n";
			}
			$strtable = $strtable. "</tr>\n";
		}
		$strtable = $strtable. "</table>";  
		echo $strheading.$strtable;
	}

	
	function displayRAPCoursesvsProgRAPs( $conn, $report_title, $planID, $showElectives, $rapID )
	{	
		//Pone el título de la página
		$strheading = "<h2>" . $report_title . "</h2>";
	  
		//Captura el listado de RAPs
		$sql = "SELECT * FROM ilo_program WHERE PlanID=".$planID." ORDER BY Position";
		$result_prograp  = $conn->query($sql);
		$nraps = $result_prograp->num_rows;

		//Pone el listado de RAPs de Programa
		$strheading = $strheading."<select id=\"rapSelection\" onchange=\"changeRAP()\">";
		$strheading = $strheading. "<option value=0>[Escoja un RAP de Programa...]</option>";
		for ($i = 0; $i<$nraps; $i++) {	
			$prograp = $result_prograp->fetch_assoc();
			$strheading = $strheading. "<option value=\"".$prograp["ID"]."\"";
			if ($prograp["ID"]==$rapID) { $strheading = $strheading." selected"; }
			$strheading = $strheading.">".$prograp["Position"].". ".$prograp["Value"]."</option>\n";
		}
		$strheading = $strheading. "</select><br><br>\n";
		
		if ($rapID == 0) {
			echo $strheading;
			return;
		}
		
		//Captura el RAPS de curso asociados al RAP de Programa
		if ($showElectives) 
			$sql = "SELECT courses_general.ID,courses_general.Semestre,courses_general.Nombre,courses_ilos.CategoryID,courses_ilos.ProgramILOID,courses_ilos.Text,courses_ilos.Position FROM courses_ilos 
					INNER JOIN courses_general ON courses_ilos.CourseID = courses_general.ID 
					WHERE courses_general.PlanID=".$planID." AND courses_general.VisVersion=1 AND courses_ilos.ProgramILOID=".$rapID." ORDER BY Semestre, Nombre";
		else
			$sql = "SELECT courses_general.ID,courses_general.Semestre,courses_general.Nombre,courses_ilos.CategoryID,courses_ilos.ProgramILOID,courses_ilos.Text,courses_ilos.Position FROM courses_ilos 
					INNER JOIN courses_general ON courses_ilos.CourseID = courses_general.ID 
					WHERE courses_general.PlanID=".$planID." AND courses_general.VisVersion=1 
					AND CourseKeyID NOT IN (SELECT CourseID FROM courses_elective) AND courses_ilos.ProgramILOID=".$rapID." ORDER BY Semestre, Nombre";
		
		$result_courses = $conn->query($sql);
		$ncourses = $result_courses->num_rows;
	  
		//Pone el encabezado de la Tabla
		$strtable = "<table id=\"RapTb\" style=\"width:100%\"> <tr>\n<th>Sem</th><th>Curso</th><th>RAPs del Curso</th></tr>\n";
		$courseID = 0;
		
		//Pone cada RAP de curso asociado al RAP del Programa
		for($i = 0; $i < $ncourses; $i++) {	
			//Captura la información del curso
			$course = $result_courses->fetch_assoc();
		
			if ($course["ID"]!=$courseID) {
				$strtable = $strtable. "<tr> <td><small>" . $course["Semestre"] . "</small></td> <td><small>" . $course["Nombre"] . "</small></td> \n";
				$courseID = $course["ID"];
			} else {
				$strtable = $strtable. "<tr> <td></td> <td></td> \n";
			}
			$strtable = $strtable. "<td><small>". $course["Position"].". ".$course["Text"]. "</small></td>\n";
			$strtable = $strtable. "</tr>\n";
		}
		$strtable = $strtable. "</table>";  
		echo $strheading.$strtable;
	}
	
	
	function displayCoursesWithNoAssociation( $conn, $report_title, $planID, $showElectives )
	{	
		//Pone el título de la página
		$strheading = "<h2>" . $report_title . "</h2>";
	  
		//Captura los RAPS de curso que no tienen asociados RAP de Programa
		if ($showElectives) 
			$sql = "SELECT courses_general.ID,courses_general.Semestre,courses_general.Nombre,courses_ilos.CategoryID,courses_ilos.ProgramILOID,courses_ilos.Text,courses_ilos.Position FROM courses_ilos 
					INNER JOIN courses_general ON courses_ilos.CourseID = courses_general.ID 
					WHERE courses_general.PlanID=".$planID." AND courses_general.VisVersion=1 AND courses_ilos.ProgramILOID=0 ORDER BY Semestre, Nombre";
		else
			$sql = "SELECT courses_general.ID,courses_general.Semestre,courses_general.Nombre,courses_ilos.CategoryID,courses_ilos.ProgramILOID,courses_ilos.Text,courses_ilos.Position FROM courses_ilos 
					INNER JOIN courses_general ON courses_ilos.CourseID = courses_general.ID 
					WHERE courses_general.PlanID=".$planID." AND courses_general.VisVersion=1 
					AND CourseKeyID NOT IN (SELECT CourseID FROM courses_elective) AND courses_ilos.ProgramILOID=0 ORDER BY Semestre, Nombre";
		
		$result_courses = $conn->query($sql);
		$ncourses = $result_courses->num_rows;
	  
		//Pone el encabezado de la Tabla
		$strtable = "<table id=\"RapTb\" style=\"width:100%\"> <tr>\n<th>Sem</th><th>Curso</th><th>RAPs del Curso</th></tr>\n";
		$courseID = 0;
		
		//Pone cada RAP de curso que no tiene asociado un RAP del Programa
		for($i = 0; $i < $ncourses; $i++) {	
			//Captura la información del curso
			$course = $result_courses->fetch_assoc();
		
			if ($course["ID"]!=$courseID) {
				$strtable = $strtable. "<tr> <td><small>" . $course["Semestre"] . "</small></td> <td><small>" . $course["Nombre"] . "</small></td> \n";
				$courseID = $course["ID"];
			} else {
				$strtable = $strtable. "<tr> <td></td> <td></td> \n";
			}
			$strtable = $strtable. "<td><small>". $course["Position"].". ".$course["Text"]. "</small></td>\n";
			$strtable = $strtable. "</tr>\n";
		}
		$strtable = $strtable. "</table>";  
		echo $strheading.$strtable;
	}
	
	
	$planea = new planea();
	$conn = $planea->openConnection();
	if ( $_GET["reportID"] == 1) {
		//Visualiza el reporte de cursos vs RAPs de Programa	
		displayCoursesvsRAPs( $conn, "Cursos vs. RAPs de programa", $_GET["PlanID"], $_GET["showElect"]=="true", $_GET["showTooltip"]=="true" );
	}
	if ( $_GET["reportID"] == 2) {
		//Visualiza el reporte de RAPs de curso vs RAPs de Programa
		displayRAPCoursesvsProgRAPs( $conn, "RAPs de cursos vs. RAPs de programa", $_GET["PlanID"], $_GET["showElect"]=="true", $_GET["rapID"] );
	}
	if ( $_GET["reportID"] == 3) {
		//Visualiza el reporte de cursos sin RAPs de Programa Asociados
		displayCoursesWithNoAssociation( $conn, "RAPs de cursos sin asociar RAPs de programa", $_GET["PlanID"], $_GET["showElect"]=="true");
	}
	$planea->closeConnection();
?>