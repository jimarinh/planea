<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
//Check if the association is unique. In this case, the association is not removed from the Database, but SkillID is set to zero
$sql = "SELECT ID FROM rubrics_assoc WHERE RubricID=".$_GET["RubricID"]." AND CourseID=".$_GET["CourseID"];
$result = $planea->conn->query($sql);
if ($result->num_rows==1) {
	$sql = "UPDATE rubrics_assoc SET RapSkillID=0,RapSkillType=0 WHERE ID=".$_GET["AssocID"];
} else {
	//Remove association between rubric and ILO/Skill
	$sql = "DELETE FROM rubrics_assoc WHERE ID=".$_GET["AssocID"];
}
$result = $planea->conn->query($sql);
$planea->closeConnection();
?>