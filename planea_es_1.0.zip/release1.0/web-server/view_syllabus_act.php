<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">	
</head>

<body>

<?php  
	require('planea_basics.php');
	require('planea_logosbar.php');
	$helptopic = "teacher-syllabusmeth";
	require('planea_syllabusbar.php');
		
	$planea = new planea();
	$conn = $planea->openConnection();
	if (isset($_GET["ID"])) {
		$CourseID = $_GET["ID"];
	}
	if (isset($_POST["Metodologia"])) {
		$CourseID = $_POST["CourseID"];
		//Si se da clic en el botón Guardar, almacena la información en la base de datos
		foreach ($_POST as $key=>$value) {
			$sql = "UPDATE courses_general SET ". $key . "='". $value ."' WHERE ID=" . $CourseID;
			$conn->query($sql);
		}
	}
	$sql = "SELECT * FROM courses_general WHERE ID=" . $CourseID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$CourseName = $planea->showCourseTitle($row);
	$canModify = $planea->checkPermission( $_SESSION["RoleID"], $_SESSION["UserID"], $CourseID, 8 );
	$coursebar_opt = 4;
	require('planea_coursebar.php');
?>


<form class="planeaForm" id="mainForm" action="view_syllabus_act.php" onsubmit="return clearModifiedFlag()" method="POST">

<script type="text/javascript" src="planea_formattextarea.js"></script> 
<script type="text/javascript" src="nicEdit.js"></script> 
<script type="text/javascript">
  bkLib.onDomLoaded(function() {
		nicEditors.allTextAreas({buttonList : ['bold','italic','underline','subscript','superscript','ol','ul','indent','outdent']});
		planeaFormatTextarea.allTextAreas();
	});
</script> 

<b>Metodología</b> 
<p style="font-size:x-small">Deben enunciarse procesos metodológicos variados y participativos. Se recuerdan algunos:
Actividades de exploración de conocimientos previos, de profundización, 
de aplicación y consolidación, de refuerzo y ampliación, de evaluación y autoevaluación. 
Actividades grupales y de contacto con el medio. Sesiones de trabajo cooperativo, simulaciones y modelado,
 proyectos de clase, talleres de lectura y de escritura. Método mayeútico, formas grupales de interacción 
 oral, trabajo con guías. Tutorías virtuales y diversas formas de e-learning y b-learning. 
 Instrucción directa, clase magistral, conferencias, seminarios. Proyectos de investigación</p>
<textarea name="Metodologia" rows=16 style="width: 100%;"><?php echo $row["Metodologia"]; ?></textarea><br>

<input style="display:none" type="number" name="CourseID" value="<?php echo $row["ID"]; ?>">

<?php 
	if ($canModify) { 
		echo "<input type=\"submit\" value=\"Guardar\">"; 
	}
	$planea->closeConnection();	
?>
<input type="submit" formaction="syllabus.php" value="Cancelar"> 
</form>  

</body>
</html>
