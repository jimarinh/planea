<?php 
	class statsSem {	
		public $HT_sem;
		public $HP_sem;
		public $HTP_sem;
		public $HI_sem;
		public $HA_sem;
		public $EC_sem;
		public $C_sem;
		public $Total_credits;
		function __construct() { $this->Total_credits = 0; }
	}
	
	class electiveCat {
		public $ID;
		public $Name;
		public $Credits;
		public $Semester;
		function __construct($id,$name,$credits,$semester) {
			$this->ID = $id;
			$this->Name = $name;
			$this->Credits = $credits;
			$this->Semester = $semester;
		}
	}

	function parseValue($val)
	{
		if ($val == null) {
			return 0;
		}
		return $val;			
	}
	
	function parseChecked($val)
	{
		if ($val==1) { 
			return "1 checked"; 
		}
		return "1";
	}
	
	function parseCheckedReadonly($val)
	{
		if ($val==1) { 
			return "X"; 
		}
		return "";
	}
	
	function parseCourseType($val)
	{
		$ret = "<option value=\"Teórico\""; if ( $val == "Teórico")  { $ret = $ret." selected"; }  $ret = $ret.">Teórico</option>";
		$ret = $ret."<option value=\"Práctico\""; if ( $val == "Práctico")  { $ret = $ret." selected"; }  $ret = $ret.">Práctico</option>";
		$ret = $ret."<option value=\"Teórico-Práctico\""; if ( $val == "Teórico-Práctico")  { $ret = $ret." selected"; }  $ret = $ret.">Teórico-Práctico</option>";
		return $ret;		
	}	
	
	function parseTableHead($stats_sem)
	{
		echo "<table>
			  <tr>
				<th>Espacio Académico</th>
				<th>Modalidad</th>
				<th>Validable</th>
				<th>Habilitable</th>						
				<th>H.Teóricas</th>		
				<th>H.Prácticas</th>
				<th>H.Teór.-Prác.</th>
				<th>H.Ind.</th>
				<th>H.Asesoría</th>
				<th>Estimado Créditos</th>
				<th>Créditos</th>	
			  </tr>";	
		
		$stats_sem->HT_sem = 0;
		$stats_sem->HP_sem = 0;
		$stats_sem->HTP_sem = 0;
		$stats_sem->HI_sem = 0;
		$stats_sem->HA_sem = 0;
		$stats_sem->EC_sem = 0;
		$stats_sem->C_sem = 0;	
	}
	
	function parseCourse($row, $stats_sem, $canModify)
	{
		$id = $row["ID"];	
		$HT_c  = parseValue($row["HorasTeoricas"]);
		$HP_c  = parseValue($row["HorasPracticas"]);
		$HTP_c = parseValue($row["HorasTeoricoPracticas"]);
		$HI_c  = parseValue($row["HorasIndependientes"]);
		$HA_c  = parseValue($row["HorasAsesoria"]);
		$C_c   = parseValue($row["NumeroCreditos"]);
		$EC_c  = (($HT_c + $HP_c + $HTP_c + $HI_c + $HA_c)*16.0)/48.0;
		if (!$canModify) { 
			echo "<tr>
				<td>".$row["Nombre"]."</td>
				<td>".$row["Naturaleza"]."</td>		
				<td align=\"center\">".parseCheckedReadonly($row["Habilitable"])."</td>		
				<td align=\"center\">".parseCheckedReadonly($row["Validable"])."</td>		
				<td align=\"center\">".$HT_c."</td>		
				<td align=\"center\">".$HP_c."</td>		
				<td align=\"center\">".$HTP_c."</td>		
				<td align=\"center\">".$HI_c."</td>
				<td align=\"center\">".$HA_c."</td>				
				<td align=\"center\">".$EC_c."</td>		
				<td align=\"center\">".$C_c."</td>		
			 </tr>";		 
		} else {
			echo "<tr>
				<td>".$row["Nombre"]."</td>
				<td><select name=\"M".$id."\">".parseCourseType($row["Naturaleza"])."</select></td>		
				<td align=\"center\"><input name=\"HAB".$id."\" type=\"checkbox\" value=".parseChecked($row["Habilitable"])."></td>		
				<td align=\"center\"><input name=\"V".$id."\" type=\"checkbox\" value=".parseChecked($row["Validable"])."></td>		
				<td align=\"center\"><input id=\"HT".$id."\" name=\"HT".$id."\" type=\"number\" style=\"width: 2.5em;\" value=".$HT_c." min=0 max=10 onchange=\"updateCredits(".$id.")\"></td>		
				<td align=\"center\"><input id=\"HP".$id."\" name=\"HP".$id."\" type=\"number\" style=\"width: 2.5em;\" value=".$HP_c." min=0 max=10 onchange=\"updateCredits(".$id.")\"></td>		
				<td align=\"center\"><input id=\"HTP".$id."\" name=\"HTP".$id."\" type=\"number\" style=\"width: 2.5em;\" value=".$HTP_c." min=0 max=10 onchange=\"updateCredits(".$id.")\"></td>		
				<td align=\"center\"><input id=\"HI".$id."\" name=\"HI".$id."\" type=\"number\" style=\"width: 2.5em;\" value=".$HI_c." min=0 max=10 onchange=\"updateCredits(".$id.")\"></td>
				<td align=\"center\"><input id=\"HA".$id."\" name=\"HA".$id."\" type=\"number\" style=\"width: 2.5em;\" value=".$HA_c." min=0 max=10 onchange=\"updateCredits(".$id.")\"></td>				
				<td align=\"center\"><input id=\"EC".$id."\" size=5 style=\"width: 2.5em;\" onchange=\"updateCredits(".$id.")\" min=0 max=10 readonly></td>		
				<td align=\"center\"><input id=\"C".$id."\" name=\"C".$id."\" type=\"number\" style=\"width: 2.5em;\" value=".$C_c." min=0 max=10 onchange=\"updateCredits(".$id.")\"></td>		
			 </tr>";		
		}
		$stats_sem->HT_sem += $HT_c;
		$stats_sem->HP_sem += $HP_c;
		$stats_sem->HTP_sem += $HTP_c;
		$stats_sem->HI_sem += $HI_c;
		$stats_sem->HA_sem += $HA_c;
		$stats_sem->EC_sem += $EC_c;
		$stats_sem->C_sem += $C_c;
	}
	
	function parseSubTotalSemester($sem, $electiveCats, $planea, $stats_sem, $canModify)
	{
		//Visualiza las categorías de electivas si existen
		for ($i = 0; $i<count($electiveCats); $i++) {
			if ( $electiveCats[$i]->Semester == $sem ) {
				$id = $electiveCats[$i]->ID;			
				if (!$canModify) {
					$sql = "SELECT courses_general.* FROM courses_general JOIN courses_elective ON courses_elective.CourseID = courses_general.CourseKeyID ".
							"WHERE courses_elective.CategoryID = ".$electiveCats[$i]->ID." AND courses_general.VisVersion=1 ORDER BY courses_general.Nombre";	
					$result = $planea->conn->query($sql);
					if ($result->num_rows) {
						$row = $result->fetch_assoc();
						$HT_c  = parseValue($row["HorasTeoricas"]);
						$HP_c  = parseValue($row["HorasPracticas"]);
						$HTP_c = parseValue($row["HorasTeoricoPracticas"]);
						$HI_c  = parseValue($row["HorasIndependientes"]);
						$HA_c  = parseValue($row["HorasAsesoria"]);
						$C_c  = parseValue($row["NumeroCreditos"]);
						$EC_c  = (($HT_c + $HP_c + $HTP_c + $HI_c + $HA_c)*16.0)/48.0;
					} else {
						$HT_c  = 0;
						$HP_c  = 0;
						$HTP_c = 0;
						$HI_c  = 0;
						$HA_c  = 0;
						$C_c   = 0;
						$EC_c  = 0;		
					}
					$stats_sem->HT_sem += $HT_c;
					$stats_sem->HP_sem += $HP_c;
					$stats_sem->HTP_sem += $HTP_c;
					$stats_sem->HI_sem += $HI_c;
					$stats_sem->HA_sem += $HA_c;
					$stats_sem->EC_sem += $EC_c;
					$stats_sem->C_sem += $C_c;
					echo "<tr>
						<td><a href=\"#Elective".$id."\">".$electiveCats[$i]->Name."</a></td>
						<td></td><td></td><td></td>		
						<td align=\"center\">".$HT_c."</td>		
						<td align=\"center\">".$HP_c."</td>		
						<td align=\"center\">".$HTP_c."</td>		
						<td align=\"center\">".$HI_c."</td>
						<td align=\"center\">".$HA_c."</td>				
						<td align=\"center\">".$EC_c."</td>		
						<td align=\"center\">".$electiveCats[$i]->Credits."</td>		
					 </tr>";
				}
				else {
					echo "<tr>
						<td><a href=\"#Elective".$id."\">".$electiveCats[$i]->Name."</a></td>
						<td></td><td></td><td></td>		
						<td align=\"center\"><input id=\"ElHT".$id."\" type=\"number\" style=\"width: 2.5em;\" value=0 min=0 max=10 readonly></td>		
						<td align=\"center\"><input id=\"ElHP".$id."\" type=\"number\" style=\"width: 2.5em;\" value=0 min=0 max=10 readonly></td>		
						<td align=\"center\"><input id=\"ElHTP".$id."\" type=\"number\" style=\"width: 2.5em;\" value=0 min=0 max=10 readonly></td>		
						<td align=\"center\"><input id=\"ElHI".$id."\" type=\"number\" style=\"width: 2.5em;\" value=0 min=0 max=10 readonly></td>
						<td align=\"center\"><input id=\"ElHA".$id."\" type=\"number\" style=\"width: 2.5em;\" value=0 min=0 max=10 readonly></td>				
						<td align=\"center\"><input id=\"ElEC".$id."\" type=\"number\" style=\"width: 2.5em;\" value=0 min=0 max=10 readonly></td>		
						<td align=\"center\"><input id=\"ElC".$id."\"  type=\"number\" style=\"width: 2.5em;\" value=".$electiveCats[$i]->Credits." min=0 max=10 readonly></td>		
					 </tr>";
				}
			}
		}
		//Cierra la tabla
		if (!$canModify) {
			echo "<tr>
				<td><b>Total Semestre</b></td>
				<td></td>
				<td></td>
				<td></td>
				<td align=\"center\">".$stats_sem->HT_sem."</td>		
				<td align=\"center\">".$stats_sem->HP_sem."</td>
				<td align=\"center\">".$stats_sem->HTP_sem."</td>
				<td align=\"center\">".$stats_sem->HI_sem."</td>
				<td align=\"center\">".$stats_sem->HA_sem."</td>
				<td align=\"center\">".$stats_sem->EC_sem."</td>
				<td align=\"center\">".$stats_sem->C_sem."</td>
			  </tr>
			</table>";	
		} else {
			echo "<tr>
				<td><b>Total Semestre</b></td>
				<td></td>
				<td></td>
				<td></td>
				<td align=\"center\"><input id=\"HTS".$sem."\" size=5 style=\"width: 2.5em;\" readonly></td>		
				<td align=\"center\"><input id=\"HPS".$sem."\" size=5 style=\"width: 2.5em;\" readonly></td>
				<td align=\"center\"><input id=\"HTPS".$sem."\" size=5 style=\"width: 2.5em;\" readonly></td>
				<td align=\"center\"><input id=\"HIS".$sem."\" size=5 style=\"width: 2.5em;\" readonly></td>
				<td align=\"center\"><input id=\"HAS".$sem."\" size=5 style=\"width: 2.5em;\" readonly></td>
				<td align=\"center\"><input id=\"ECS".$sem."\" size=5 style=\"width: 2.5em;\" readonly></td>
				<td align=\"center\"><input id=\"CS".$sem."\" size=5 style=\"width: 2.5em;\"readonly></td>
			  </tr>
			</table>";	
		}
	}
	
	function renderCreditTable( $planID, $planea, $canModify )
	{
		//Captura los cursos electivos
		$sql = "SELECT * FROM courses_electivecats WHERE PlanID = ".$planID." ORDER BY CategoryName";   	   
		$result = $planea->conn->query($sql);
		$electiveCats = array();
		if ($result->num_rows > 0)  {
			for ($i = 0; $i<$result->num_rows; $i++) 
			{
				$row = $result->fetch_assoc();
				$electiveCats[$i] = new electiveCat($row["ID"],$row["CategoryName"],$row["Credits"],$row["Semester"]);
			}		
		}

		//Procesa los cursos que no son electivos y establece links a las categorías de cursos electivos
		$sql = "SELECT * FROM courses_general WHERE CourseKeyID NOT IN (SELECT CourseID FROM courses_elective) AND PlanID = ".$planID." AND VisVersion=1 ORDER BY Semestre";
		
		$result = $planea->conn->query($sql);
		$nrows = $result->num_rows; 
		if ($nrows > 0) 
		{
			//Muestra las tablas con las horas y créditos	
			$stats_sem = new statsSem;
			$sem = -1;
			$vars = "";
			$courses = "";
			while($row = $result->fetch_assoc()) 
			{			
				if ($row["Semestre"] != $sem) {
					//Al cambiar el semestre pone la fila de resultados parciales
					if ($sem != -1) {
						parseSubTotalSemester($sem, $electiveCats, $planea, $stats_sem, $canModify);
					}
					$sem = $row["Semestre"];				
					echo "<h2>Semestre ".$sem."</h2>\n";
					parseTableHead($stats_sem);			
				}
				$id = $row["ID"];		
				parseCourse($row, $stats_sem, $canModify);
				$stats_sem->Total_credits += $row["NumeroCreditos"];
				//Genera la información para JavaScript
				$vars = $vars."var E".$id."={ID:".$id.",Sem:".$sem.",Ig:0};\n";
				$courses = $courses."E".$id.",";			
			}		
			parseSubTotalSemester($sem, $electiveCats, $planea, $stats_sem, $canModify);
		}

		//Visualiza los cursos electivos
		$elective_vars = "";
		$electives = "";
		for ($i = 0; $i<count($electiveCats); $i++) 
		{
			$sql = "SELECT courses_general.* FROM courses_general JOIN courses_elective ON courses_elective.CourseID = courses_general.CourseKeyID ".
					"WHERE courses_elective.CategoryID = ".$electiveCats[$i]->ID." AND courses_general.VisVersion=1 ORDER BY courses_general.Nombre";	
			$result = $planea->conn->query($sql);
			$nrows = $result->num_rows; 
			$stats_sem->Total_credits += $electiveCats[$i]->Credits;
			if ($nrows > 0) 
			{
				//Muestra las tablas con las horas y créditos	
				echo "<h2 id=Elective". $electiveCats[$i]->ID. ">". $electiveCats[$i]->Name."</h2>\n";
				parseTableHead($stats_sem);
				$ignore = 0;
				while($row = $result->fetch_assoc()) 
				{			
					$id = $row["ID"];
					parseCourse($row, $stats_sem, $canModify);
					//Genera la información para JavaScript
					$vars = $vars."var E".$id."={ID:".$id.",Sem:".$row["Semestre"].",Ig:".$ignore."};\n";
					$courses = $courses."E".$id.",";
					if ($ignore == 0) { 
						$elective_vars = $elective_vars."var El".$id."={ID:".$id.",cat:".$electiveCats[$i]->ID."};\n";
						$electives = $electives."El".$id.",";
					}
					$ignore = 1;
				}
				echo "</table>";		
			}
		}
		
		//Pone el número de créditos totales
		echo "<h2 id=\"TotalCredits\">Total Créditos del Programa: ".$stats_sem->Total_credits."</h2>\n";
		
		//Incluye el script con la información para manejar los eventos	
		echo "<script>\n".$vars."var courses = [".$courses."];\n".$elective_vars."var electives= [".$electives."];\n</script>\n";
	}
?>