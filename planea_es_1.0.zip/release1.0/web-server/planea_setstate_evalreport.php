<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	$sql = "UPDATE eval_courses SET State=". $_GET["State"]. " WHERE ID=".$_GET["ReportID"];
	$result = $conn->query($sql);
	$planea->closeConnection();
?>