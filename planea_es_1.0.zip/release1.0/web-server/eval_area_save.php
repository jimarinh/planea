<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();  

$sql = "SELECT * FROM semesters WHERE ID=".$_POST["SemesterID"];
$result = $planea->conn->query($sql);
$row = $result->fetch_assoc();
$semesterName = $row["SemesterName"];

$planea->saveEvalReportByArea($_POST["PlanID"], $_POST["AreaID"], $semesterName, $_POST["UserID"], 0);
$planea->closeConnection();
?>

