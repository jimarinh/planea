<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<style>
	textarea  
	{  
		font-family:"Helvetica", Helvetica, sansserif;  
		font-size: 14px;
	}
	</style>	
</head>

<body>

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	//Check for credentials
	if ($_SESSION["RoleID"]!=planea::roleAdmin) {
		exit("<p><font color=\"red\">No tiene permiso para acceder a esta sección</font><p>");
	}
?>

	<script>
	function setModifiedFlag() { window.onbeforeunload = function() { return true; }; }
	function clearModifiedFlag() { window.onbeforeunload = null; return true; }
	function createRAPCategorySet() {
		document.getElementById("newSetInfo").style.display = "block";
		document.getElementById("setList").style.display = "none";
		document.getElementById("setConfiguration").style.display = "none";
	}
	function removeRAPSet(setID) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				//If set was removed successfully...
				if (this.responseText=="1") {					
					var x = document.getElementById("row"+setID);
					var tableObj = document.getElementById("rapSets");
					tableObj.deleteRow(x.rowIndex);
				} else {
					alert("El conjunto no puede ser removido porque está siendo usado por algún plan de estudios");
				}
			}
		}
		xhttp.open("GET", "ilo_remove_set.php?setID="+setID, true);
		xhttp.send();
	}
	function editRAPSet(setID) {
		document.getElementById("newSetInfo").style.display = "none";
		document.getElementById("setList").style.display = "none";
		document.getElementById("setConfiguration").style.display = "block";
		rapSetID.value = setID;
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				var obj = JSON.parse(this.responseText);
				document.getElementById("Name").value = obj.Name;
				document.getElementById("Description").value = obj.Description;
				document.getElementById("rapCategories").innerHTML = obj.Table;
				updateArrowBtns();
			}
		}
		xhttp.open("GET", "ilo_edit_set.php?setID="+setID, true);
		xhttp.send();
	}
	function updateArrowBtns() {
		var btnup, btndn, pos;
		var items = document.getElementById("rapCategories").getElementsByTagName("tr");
		for(pos=0;pos<items.length;pos++) {
			btnup = items[pos].getElementsByClassName("button btn_up");
			btnup[0].style.display = (pos==0) ? "none" : "inline";
			btndn = items[pos].getElementsByClassName("button btn_down");
			btndn[0].style.display = (pos==items.length-1) ? "none" : "inline";
			posinput = items[pos].getElementsByTagName("input");
			posinput[0].value = pos+1;
		}	
	}
	function moveItem(Id, dir) {
		var tr1   = document.getElementById("cat"+Id);
		if (dir == -1) { tr1.parentNode.insertBefore(tr1, tr1.previousSibling); } else { tr1.parentNode.insertBefore(tr1.nextSibling, tr1); }
		setModifiedFlag();
		updateArrowBtns();
	}
	function removeItem(Id) {		
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				//If category was removed successfully...
				if (this.responseText=="1") {					
					var tr = document.getElementById("cat"+Id);
					tr.parentNode.removeChild(tr);
					setModifiedFlag();
					updateArrowBtns();
				} else {
					alert("La categoría no puede ser removida porque está siendo usado por algún curso de un plan de estudios");
				}
			}
		}
		xhttp.open("GET", "ilo_removecategory.php?catID="+Id, true);
		xhttp.send();
	}
	function addRAPCategory() {	
		var catName = NewCategory.value;
		var setID 	= rapSetID.value;
		var items = document.getElementById("rapCategories").getElementsByTagName("tr");
		var position = items.length+1;
		if (catName.length>0)
		{ 
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					if (this.responseText.length>0) {
						var catID = this.responseText;
						var table = document.getElementById("rapCategories").getElementsByTagName("table");
						var tr_new = table[0].insertRow(-1); 
						var btn1 = "<button class=\"button btn_up\" type=\"button\" onclick=\"moveItem("+catID+",-1)\"></button>";
						var btn2 = "<button class=\"button btn_down\" type=\"button\" onclick=\"moveItem("+catID+",1)\"></button>"; 
						var btn3 = "<button class=\"button btn_remove\" type=\"button\" onclick=\"removeItem("+catID+")\"></button>"; 	
						var btn4 = "<input id=\"pos"+catID+"\" name=\"pos"+catID+"\" size=1 readonly>";
						tr_new.innerHTML = "<td>"+btn4+"</td><td><textarea name=\"txt"+catID+"\" rows=1 style=\"width: 100%;\" onchange=\"setModifiedFlag()\">"+catName+"</textarea></td><td>"+btn3+btn1+btn2+"</td>";
						tr_new.id = "cat"+catID;
						updateArrowBtns();
						NewCategory.value = "";
					}
				}
			}	
			xhttp.open("GET", "ilo_addcategory.php?setID="+setID+"&catName="+catName+"&pos="+position, true);
			xhttp.send();
		}
	}
	</script>

<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="ilo_categories.php">Categorías Institucionales de RAPs</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#admin-RAPs" target="PLANEA-help">?</a></li>
</ul>


<?php  
	$planea = new planea();
	$conn = $planea->openConnection();
	//Create new set...
	if ( isset($_POST["NewName"]) && !empty($_POST["NewName"]) ) { //Create set
		$sql = "INSERT INTO ilo_sets (SetName,Description) VALUES ('" . $_POST["NewName"] . "', '". $_POST["NewDescription"] . "')";
		$result = $conn->query($sql);	
	}
	//Save categories in the set...
	if ( isset($_POST["rapSetID"]) ) {
		$sql = "UPDATE ilo_sets SET SetName='" . $_POST["Name"] . "',Description='". $_POST["Description"] . "' WHERE ID=".$_POST["rapSetID"];
		$result = $conn->query($sql);		
		foreach ($_POST as $key=>$value) {
			if (substr($key,0,3) == "txt") {	
				$id = substr($key,3);
				$sql = "UPDATE ilo_categories SET Value='". $value . "', Position=". $_POST["pos".$id] ." WHERE ID=".$id;
				$conn->query($sql);
			}
		}
	}
?>


<form class="planeaForm" action="ilo_categories.php" method="POST" id="newSetInfo" style="display:none">
	Nombre del conjunto: <input type="text" id="NewName" name="NewName" size=30> &nbsp; &nbsp;
	Descripción: <input type="text" id="NewDescription" name="NewDescription" size=30> 
	<input type="submit" value="Crear">
	<input type="button" onClick="window.location='ilo_categories.php'" value="Cancelar">
</form>

<div class="planeaForm" id="setList">
	<p style="font-size:small"> 
	Utilice esta sección para definir el conjunto de categorías a las que deben ser asociados los diferentes 
	Resultados de Aprendizaje (RAPs) de cada curso según la normativa institucional. <br>
	Si la normativa actual cambia, cree una nueva entrada en lugar de modificar la configuración vigente, 
	pues esto generaría una destrucción de la consistencia en la estructura de todos los sílabos. 
	<br> <br>
	El botón <img src="images/btn_edit.png" alt="BtnEdit" style="width:12px"> le permite configurar las categorías del conjunto. 
	No utilice el botón <img src="images/btn_remove.png" alt="BtnRemove" style="width:12px"> si ya existen planes de estudio configurados con dicha normativa. 
	<br> <br>
	En el módulo <b>Planes de Estudio</b> puede asociar la reglamentación a cada plan de estudio.</p> 
	
	<table id="rapSets">
		<?php $planea->showRAPCustomizableSets(); ?>
	</table>
	
	<input type="button" onClick="createRAPCategorySet()" value="*Crear Nuevo Conjunto de Categorías">
</div>

<form class="planeaForm" id="setConfiguration" action="ilo_categories.php" method="POST" onsubmit="return clearModifiedFlag()" style="display:none">
	Nombre del conjunto: <input type="text" id="Name" name="Name" size=30 onchange="setModifiedFlag()"> &nbsp; &nbsp;
	Descripción: <input type="text" id="Description" name="Description" size=30 onchange="setModifiedFlag()">
	<br> <br>
	<b><u>Categorías</u></b>
	<div id="rapCategories">
	</div>
	<br>
	<input type="text" id="NewCategory" size=50>
	<button class="button btn_fancy" onclick="addRAPCategory()" type="button">Añadir Categoría <img src="images/btn_add1.png"> </button>
	<br> <br>
	<input type="submit" value="Guardar">
	<input type="number" id="rapSetID" name="rapSetID" size=10 style="visibility:hidden" value="-1">
</form>

<?php $planea->closeConnection(); ?>

</body>
</html>
