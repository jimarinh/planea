<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
</head>

<body>

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	//Check credentials
	if ($_SESSION["RoleID"]!=planea::roleAdmin) {
		exit("<p><font color=\"red\">No tiene permiso para acceder a esta sección</font><p>");
	}
?>

	<script>
	function removeUser(userID,name) {
		var r = confirm("¿Desea eliminar el usuario '"+name+"'?");
		if (r == true) {
			var xhttp = new XMLHttpRequest();
			var x = document.getElementById("row"+userID);
			var tableObj = document.getElementById("usersTable");
			tableObj.deleteRow(x.rowIndex);
			xhttp.open("GET", "planea_removeuser.php?removeID="+userID, true);
			xhttp.send();
		}
	}
	function resetPassword(userID) {
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET", "planea_resetpassword.php?userID="+userID, true);
		xhttp.send();
		alert("La nueva contraseña ha sido fijada al número de cédula");
	}
	function viewNewUserInfo() {
		document.getElementById("newUserBtn").style.display = "none";
		document.getElementById("exportUsersBtn").style.display = "none";
		document.getElementById("usersList").style.display = "none";
		document.getElementById("cancelBtn").style.display = "inline";
		document.getElementById("userInfo").style.display = "inline";
		document.getElementById("createUserBtn").style.display = "inline";			
	}
	function editUser(userID) {	
		document.getElementById("newUserBtn").style.display = "none";
		document.getElementById("exportUsersBtn").style.display = "none";
		document.getElementById("modifyUserBtn").style.display = "inline";
		document.getElementById("usersList").style.display = "none";
		document.getElementById("chkAdmin").style.display = "inline";
		document.getElementById("cancelBtn").style.display = "inline";
		document.getElementById("userInfo").style.display = "inline";
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				var obj = JSON.parse(this.responseText);
				document.getElementById("Name").value = obj.name;
				document.getElementById("CountryID").value = obj.countryID;
				document.getElementById("Email").value = obj.email;
				document.getElementById("PlanID").value = obj.defaultPlan;
				document.getElementById("UserID").value = obj.ID;
				document.getElementById("RoleID").value = obj.role;
				if (obj.role.search("A")!=-1) {
					document.getElementById("chkAdminBox").checked = true;	
				} else {
					document.getElementById("chkAdminBox").checked = false;
				}
			}
		}
		xhttp.open("GET", "user_edit.php?userID="+userID, true);
		xhttp.send();	
	}
	function searchUser(filter) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("usersTable").innerHTML = this.responseText;	
			}
		}
		xhttp.open("GET", "planea_searchuser.php?filter="+filter, true);
		xhttp.send();	
	}
	function searchUserByName() {
		searchUser(document.getElementById("nameFilter").value);	
	}
	function searchUserByCountryID() {
		searchUser(document.getElementById("countryIDFilter").value);	
	}
	function exportTable() {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				var tableObj = document.getElementById("usersTable");
				tableObj.innerHTML = this.responseText;
				tableToExcel('usersTable','Usuarios');
				tableObj.innerHTML = "";
			}
		};
		xhttp.open("GET", "planea_searchuser.php?filter=", true);
		xhttp.send();
	}
	var tableToExcel = (function() {
		var uri = 'data:application/vnd.ms-excel;base64,'
			, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
			, base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
			, format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
		return function(table, name) {
			if (!table.nodeType) table = document.getElementById(table)
			var ctx = {worksheet: name || 'Worksheet', table: table.innerHTML}
			window.location.href = uri + base64(format(template, ctx))
		}
	})()
	</script>

<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="#">Administrar Usuarios</a></li>
<li><a href="users_coordinators.php">Definir Coordinadores</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#admin-users" target="PLANEA-help">?</a></li>
</ul>


<?php  
	$planea = new planea();
	$conn = $planea->openConnection();
	if ( isset($_POST["Name"]) && !empty($_POST["Name"]) ) {
		if ($_POST["UserID"]==-1) { //Create user
			$sql = "INSERT INTO users (name,countryID,email,role,password,defaultPlan) 
						VALUES ('" . $_POST["Name"] . "', '" . $_POST["CountryID"] . "','" . 
							$_POST["Email"] . "','D','" . password_hash($_POST["CountryID"],PASSWORD_DEFAULT) . "','" . 
							$_POST["PlanID"] . "')";
		} else { //Modify user
			$role = $_POST["RoleID"];
			if( isset($_POST["chkAdminBox"]) ) {
				$role = str_replace("A","",$role)."A";
			} else {
				$role = str_replace("A","",$role);
			}
			$sql = "UPDATE users SET name='" . $_POST["Name"] . "', countryID='" . $_POST["CountryID"] . "', email='" . $_POST["Email"] . "', role='".$role."', defaultPlan='" .$_POST["PlanID"] . "' WHERE ID=". $_POST["UserID"];
		}
		$result = $conn->query($sql);
	}
?>

<form class="planeaForm" action="users.php" method="POST">
	<div id="userInfo" style="display:none">
		Nombre: <input type="text" id="Name" name="Name" size=50> <br> <br>
		Cédula: <input type="text" id="CountryID" name="CountryID" size=50> <br> <br>
		email: <input type="email" id="Email" name="Email" size=50> <br> <br>
		Plan de estudios asignado:
		<select id="PlanID" name="PlanID">
		<?php $planea->showStudyPlan(0,true); ?>	
		</select>
		<input type="number" id="UserID" name="UserID" size=10 style="visibility:hidden" value="-1"> 
		<br> <br>
		<div id="chkAdmin" style="visibility:none"> <input type="checkbox" id="chkAdminBox" name="chkAdminBox">Administrador
		<input type="text" id="RoleID" name="RoleID" size=10 style="visibility:hidden">
		<br> <br>
		</div> 
	</div>
	<input type="submit" id="createUserBtn" value="Crear" style="display:none">
	<input type="submit" id="modifyUserBtn" value="Guardar" style="display:none">
	<input type="button" id="cancelBtn" onClick="window.location='users.php'" value="Cancelar" style="display:none">
	<button type="button" id="newUserBtn" onClick="viewNewUserInfo()">*Crear Nuevo Usuario</button> 
	<button type="button" id="exportUsersBtn" onclick="exportTable()" >Exportar</button>
</form>

<div class="planeaForm" id="usersList">
	Buscar por nombre:  <input type="search" id="nameFilter" onChange="searchUserByName()" size=20> &nbsp;
	Buscar por cédula:  <input type="search" id="countryIDFilter" onChange="searchUserByCountryID()" size=10> 
	<input type="submit" value="Buscar" style="display:none"> <br> 
	<p style="font-size:small">Para mostrar usuarios escriba algún patrón de texto y presione Enter. Si escribe un espacio " " se mostrarán todos los usuarios.</p> <br>
	<table id="usersTable">
	</table>
</div>


<?php $planea->closeConnection(); ?>

</body>
</html>
