<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "SELECT ID FROM courses_general WHERE CourseKeyID=" . $_GET["CourseKeyID"];
$result = $planea->conn->query($sql);
if ($result->num_rows>1) {
	$flags=2;	
} else {
	$flags=0;
}
$sql = "SELECT EstadoVersion FROM courses_general WHERE ID=" . $_GET["CourseID"];
$result = $planea->conn->query($sql);
$row = $result->fetch_assoc();
if ($row["EstadoVersion"]==planea::syllStateDisabled) { $flags += 4; }
if ($row["EstadoVersion"]==planea::syllStateOpened)   { $flags += 1; }
if ($row["EstadoVersion"]==planea::syllStateApproved) { $flags += 12; }
echo $flags;
$planea->closeConnection();
?>