<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script>		
		var tableToExcel = (function() {
			var uri = 'data:application/vnd.ms-excel;base64,'
				, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
				, base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
				, format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
			return function(tableHTML, name) {
				var ctx = {worksheet: name || 'Worksheet', table: tableHTML}
				window.location.href = uri + base64(format(template, ctx))
			}
		})()
	</script>
</head>

<?php  
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection(); 

	require('planea_logosbar.php');
	$subMenuName = "Reporte de conclusiones";
	
	//Check for credentials
	if ($_SESSION["RoleID"]!=planea::roleCoord) {
		exit("<p><font color=\"red\">No tiene permiso para acceder a esta sección</font><p>");
	}
	
	$helptopic = "coord-eval"; 
	require('planea_evalcoordbar.php');
?>

<body onload="enableSections()">
<h3>Programa: <i><?php echo $planName; ?></i> &nbsp; Semestre: <i><?php echo $semesterName;?></i> </h3>

<div class="planeaForm">
<button type="button" onClick="tableToExcel(getElementById('reportForm').innerHTML,'reports')">Exportar Reporte Resumen a Excel</button>
</div>

<div class="planeaForm" id="reportForm">
<h3>Reporte resumen</h3>
<div id="cT1">
<b>Deficiencias de los estudiantes en conocimientos o habilidades previas</b>  
<table id="T1">
<?php $iView1 = $planea->showEvalReportByTopic( $PlanID, $semesterName, "UnknownPrevSkills" ); ?>
</table> <br> 
</div>
<div id="cT2">
<b>Temas no cubiertos en el desarrollo del semestre</b> 
<table id="T2">
<?php $iView2 = $planea->showEvalReportByTopic( $PlanID, $semesterName, "UncoveredTopics" ); ?>
</table> <br>
</div>
<div id="cT3">
<b>Temas irrelevantes y se podrían suprimir del sílabo</b> 
<table id="T3">
<?php $iView3 = $planea->showEvalReportByTopic( $PlanID, $semesterName, "IrrelevantTopics" ); ?>
</table> <br>
</div>
<div id="cT4">
<b>Problemas de los estudiantes para el desarrollo del curso</b>
<table id="T4">
<?php $iView4 = $planea->showEvalReportByTopic( $PlanID, $semesterName, "StudentProblems" ); ?>
</table> <br>
</div>
<div id="cT5">
<b>Experiencias <u>exitosas</u> en el desarrollo del curso</b> 
<table id="T5">
<?php $iView5 = $planea->showEvalReportByTopic( $PlanID, $semesterName, "SuccessfulExp" ); ?>
</table> <br>
</div>
<div id="cT6">
<b>Experiencias <u>no exitosas</u> en el desarrollo del curso</b>
<table id="T6">
<?php $iView6 = $planea->showEvalReportByTopic( $PlanID, $semesterName, "UnsuccessfulExp" ); ?>
</table> <br>
</div>
<div id="cT7">
<b >Acciones de mejora para el próximo semestre o cambio en el sílabo</b>
<table id="T7">
<?php $iView7 = $planea->showEvalReportByTopic( $PlanID, $semesterName, "ImprovMeasures" ); ?>
</table> <br>
</div>

</div>

<script>
	function enableSections() {
		document.getElementById("cT1").style = "display:<?php if ($iView1) echo "inline"; else echo "none"; ?>";
		document.getElementById("cT2").style = "display:<?php if ($iView2) echo "inline"; else echo "none"; ?>";
		document.getElementById("cT3").style = "display:<?php if ($iView3) echo "inline"; else echo "none"; ?>";
		document.getElementById("cT4").style = "display:<?php if ($iView4) echo "inline"; else echo "none"; ?>";
		document.getElementById("cT5").style = "display:<?php if ($iView5) echo "inline"; else echo "none"; ?>";
		document.getElementById("cT6").style = "display:<?php if ($iView6) echo "inline"; else echo "none"; ?>";
		document.getElementById("cT7").style = "display:<?php if ($iView7) echo "inline"; else echo "none"; ?>";
	}
</script>

<?php $planea->closeConnection(); ?>

</body>
</html>
