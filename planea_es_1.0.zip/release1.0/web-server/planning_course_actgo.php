<?php 
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();

$action 	= $_GET["action"];
$CourseID 	= isset($_GET["CourseID"]) ? $_GET["CourseID"] : 0;
$UserID 	= isset($_GET["UserID"]) ? $_GET["UserID"] : 0;
$Semester 	= isset($_GET["SemesterID"]) ? $_GET["SemesterID"] : 0;

if ($action=="insertAct") //insert activity
{
	//get the position for the new activity
	$sql = "SELECT Position FROM teacher_activities WHERE CourseID=".$CourseID.
		" AND UserID=".$UserID." AND Semester='".$Semester."' ORDER BY Position DESC";
	$result = $planea->conn->query($sql);
	if ($result->num_rows > 0) {
		$row = $result->fetch_assoc();
		$pos = $row["Position"]+1;
	} else {
		$pos = 1; 
	}
	//Get the planID required to insert the activity
	$sql = "SELECT PlanID FROM courses_general WHERE ID=".$CourseID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$PlanID = $row["PlanID"];
	//Insert the activity
	$sql = "INSERT INTO teacher_activities(PlanID, CourseID, UserID, Semester, Position, Name) 
			VALUES (".$PlanID.",".$CourseID.",".$UserID.",'".$Semester."',".$pos.",'".$_GET["Name"]."')";
	$result = $planea->conn->query($sql);
	$last_id = $planea->conn->insert_id;
	echo $last_id;
	//Insert association to the ILO
	$sql="INSERT INTO teacher_actassoc(ActID,RapSkillID,RapSkillType) VALUES(".$last_id.",".$_GET["RapID"].",0)";
	$result = $planea->conn->query($sql);
}

if ($action=="getActInfo") 
{	
	//Get activity information
	$ActID = $_GET["ActID"];
	$sql = "SELECT TopicID FROM teacher_activities WHERE ID=".$ActID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$topicID = $row["TopicID"];
	//get course contents
	$sql = "SELECT * FROM courses_contents WHERE CourseID=".$CourseID." ORDER BY TopicNumber";
	$result = $planea->conn->query($sql);
	$topicNames = array();
	$topicContents = array();
	array_push($topicNames, "<option value=0>Seleccione un tema...</option>");
	while( $row = $result->fetch_assoc() ){
		array_push($topicNames, "<option value=".$row["ID"].($row["ID"]==$topicID?" selected":"").">".$row["TopicNumber"].". ".$row["TopicName"]."</option>");
		array_push($topicContents, $row["Contents"]);
	}
	//get skills	
	$Ret = $planea->showAssocRAPSkillsToPlanningCourse( 1, $CourseID, $Semester, $UserID, $ActID ); $SkillStr = $Ret["str"]; 
	$Ret = $planea->showAssocRAPSkillsToPlanningCourse( 2, $CourseID, $Semester, $UserID, $ActID ); $SkillStr = $SkillStr.$Ret["str"]; 
	$Ret = $planea->showAssocRAPSkillsToPlanningCourse( 3, $CourseID, $Semester, $UserID, $ActID ); $SkillStr = $SkillStr.$Ret["str"]; 
	
	header('Content-type: application/json');
	$json_data = array();
	$json_data["TopicNames"] = $topicNames;
	$json_data["TopicContents"] = $topicContents;
	$json_data["Skills"] = $SkillStr;
	echo json_encode($json_data);
}

if ($action == "editAct") 
{
	//update general information for the activity 
	$ActID = $_GET["editActID"];	
	$sql = "UPDATE teacher_activities SET Name='".$_GET["Name"]."', Description='".$_GET["Description"].
				"', HD=".$_GET["HD"].", HI=".$_GET["HI"].", TopicID=".$_GET["TopicID"]." WHERE ID=". $ActID;
	$planea->conn->query($sql);
	//update the skills association for the activity
	$strSkillsID[1] = "";
	$strSkillsID[2] = "";
	$strSkillsID[3] = "";
	foreach ($_GET as $key=>$value) {
		if (substr($key,0,3)=="chk") {
			$skillID = substr($key,3,strlen($key)-4);
			$typeID = $key[strlen($key)-1];
			
			$sql = "SELECT ID FROM teacher_actassoc WHERE ActID=".$ActID." AND RapSkillID=".$skillID." AND RapSkillType=".$typeID;
			$result = $planea->conn->query($sql);
			if ($result->num_rows==0) {
				$sql = "INSERT INTO teacher_actassoc (ActID,RapSkillID,RapSkillType) VALUES (".$ActID.",".$skillID.",".$typeID.")";
				$result = $planea->conn->query($sql);
			}
			if (strlen($strSkillsID[$typeID])!=0) $strSkillsID[$typeID] = $strSkillsID[$typeID] . ",";
			$strSkillsID[$typeID] = $strSkillsID[$typeID] . $skillID;
		}
	}
	for ($typeID=1; $typeID<=3; $typeID++) { 
		if (strlen($strSkillsID[$typeID])>0) {
			$sql = "DELETE FROM teacher_actassoc WHERE ActID=".$ActID." AND RapSkillType=".$typeID." AND RapSkillID NOT IN (".$strSkillsID[$typeID].")";
		} else {
			$sql = "DELETE FROM teacher_actassoc WHERE ActID=".$ActID." AND RapSkillType=".$typeID;
		}
		$result = $planea->conn->query($sql);
	}
}
	
if ($action == "removeAct") 
{
	//update general information for the activity 
	$ActID = $_GET["ActID"];
	$sql = "DELETE FROM teacher_activities WHERE ID=".$ActID;
	$result = $planea->conn->query($sql);
	$sql = "DELETE FROM teacher_actassoc WHERE ActID=".$ActID;
	$result = $planea->conn->query($sql);
	$sql = "DELETE FROM rubrics_assoc WHERE RapSkillID=".$ActID." AND RapSkillType=4";
	$result = $planea->conn->query($sql);
	$planea->purgeNotUsedRubrics();
}

if ($action == "addLink") 
{
	//update general information for the activity 
	$ActID = $_GET["ActID"];
	$RapID = $_GET["RapID"];
	$sql = "INSERT INTO teacher_actassoc (ActID,RapSkillID,RapSkillType) VALUES (".$ActID.",".$RapID.",0)";
	$result = $planea->conn->query($sql);
}

if ($action == "removeLink") 
{
	//update general information for the activity 
	$ActID = $_GET["ActID"];
	$RapID = $_GET["RapID"];
	$sql = "DELETE FROM teacher_actassoc WHERE ActID=".$ActID." AND RapSkillID=".$RapID." AND RapSkillType=0";
	$result = $planea->conn->query($sql);
}

$planea->closeConnection();
?>