<?php  
	require('planea_basics.php');

	function displayAnalysisLevel3( $conn, $skills_title, $skills_table, $planID, $showElectives, $showTooltip )
	{
		//Pone el título de la página
		echo "<h2>" . $skills_title . "</h2>";
	  
		//Captura el listado de cursos
		if ($showElectives) 
			$sql = "SELECT ID, Nombre, Semestre FROM courses_general WHERE PlanID=".$planID." AND VisVersion=1 ORDER BY Semestre, Nombre";
		else
			$sql = "SELECT ID, Nombre, Semestre FROM courses_general WHERE CourseKeyID NOT IN (SELECT CourseID FROM courses_elective) AND PlanID = ".$planID." AND VisVersion=1 ORDER BY Semestre, Nombre";
			
		$result_courses = $conn->query($sql);
		$ncourses = $result_courses->num_rows;
	  
		//Captura el listado de habilidades de nivel 3
		$sql = "SELECT * FROM cdiosyllabus_" . $skills_table;
		$result_skill  = $conn->query($sql);
		$nskills = $result_skill->num_rows;

		//Pone el listado de habilidades de nivel 3
		echo "<p><small>";
		for ($i = 0; $i<$nskills; $i++) {	
			$skill = $result_skill->fetch_assoc();
			echo $skill["ref_syllabus"].". ".$skill["description"]."<br>\n";
		}
		echo "</small></p>\n";
		
		//Pone el encabezado con el listado de habilidades de nivel 3
		$result_skill->data_seek(0);
		echo "<table id=\"skTb\" style=\"width:100%\"> <tr><th>Sem</th><th>Curso</th>\n";
		$nskills_n3 = 0;
		$skills_list = array();
		$skills_names = array();
		for ($i = 0; $i<$nskills; $i++) {	
			$skill = $result_skill->fetch_assoc();
			if ($skill["level"]==3) {
				echo "<th>".$skill["ref_syllabus"]."</th>\n";
				$skills_list[$nskills_n3] = $skill["ID"];
				$skills_names[$nskills_n3] = $skill["ref_syllabus"].". ".$skill["description"];
				$nskills_n3++;
			}
		}
		echo "</tr>\n";
			
		//Por cada curso busca las habilidades relacionadas y las ubica indicando la información sobre introduce, enseña y utiliza
		for($i = 0; $i < $ncourses; $i++) {
			$course = $result_courses->fetch_assoc();
		
			//Captura las habilidades para dicho curso    
			$sql = "SELECT * FROM courses_".$skills_table." WHERE CourseID=" . $course["ID"] ." ORDER BY SkillID";
			$result_skillcourse  = $conn->query($sql);
			
			if ($result_skillcourse->num_rows>0) { 
				$skillinfo = $result_skillcourse->fetch_assoc(); 
			} else {
				$skillinfo = array("SkillID"=>"-1");
			}
			
			echo "<tr> <td><small>" . $course["Semestre"] . "</small></td><td><small>" . $course["Nombre"] . "</small></td> \n";
			for ($j = 0; $j<$nskills_n3; $j++) {	
				$info = "";
				if ( $skillinfo["SkillID"] == $skills_list[$j] ) {
					if ( $skillinfo["Introduce"]==1 ) { $info = $info . "I "; }
					if ( $skillinfo["Teach"]==1 ) { $info = $info . "E "; }
					if ( $skillinfo["Utilize"]==1 ) { $info = $info . "U"; }	
					$skillinfo = $result_skillcourse->fetch_assoc(); 
				}
				if (empty($info)) $info = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
				if ($showTooltip) 
					echo "<td><small><div class=\"tooltip\">". $info. "</small><span class=\"tooltiptext\">".$skills_names[$j]."</span></div></td>\n";
				else 
					echo "<td><small>". $info. "</small></td>\n";				
			}
			echo "</tr>\n";
		}
		echo "</table>";   
	}

	$planea = new planea();
	$conn = $planea->openConnection();
	if ( $_GET["skill"] == "personal") {
		//Visualiza las habilidades Personales (Nivel 3)
		displayAnalysisLevel3( $conn, "Habilidades Personales", "personal_skills", $_GET["PlanID"], $_GET["showElect"]=="true", $_GET["showTooltip"]=="true" );
	}
	if ( $_GET["skill"] == "interpersonal") {
		//Visualiza las habilidades Interpersonales (Nivel 3)
		displayAnalysisLevel3( $conn, "Habilidades Interpersonales", "interpersonal_skills", $_GET["PlanID"], $_GET["showElect"]=="true", $_GET["showTooltip"]=="true");
	}
	if ( $_GET["skill"] == "cdio") {
		//Visualiza las habilidades CDIO (Nivel 3)
		displayAnalysisLevel3( $conn, "Habilidades CDIO", "cdio_skills", $_GET["PlanID"], $_GET["showElect"]=="true", $_GET["showTooltip"]=="true" );
	}
	$planea->closeConnection();
?>