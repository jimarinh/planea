<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script type="text/javascript" language="javascript" src="stats_viewcredits.js"></script>  
	<script>
		window.onload = function(){
			updateAll();
		}
	</script>
</head>

<body>
<?php  
	require('planea_basics.php');
	require('planea_logosbar.php');
	$helptopic = "coord-stats-credits";
	require('planea_statisticsbar.php');
	
	$planea = new planea();
	$conn = $planea->openConnection(); 
	
	if (isset($_POST["dummy"])) {
		//Si se da clic en el botón Guardar, almacena la información en la base de datos		
		$sql = "SELECT ID FROM courses_general WHERE PlanID=".$_POST["PlanID"]." AND VisVersion=1";
		$result = $planea->conn->query($sql);
		$nrows = $result->num_rows; 
		if ($nrows > 0) 
		{
			while($row = $result->fetch_assoc()) 
			{
				$id = $row["ID"];	
				if (isset($_POST["HAB".$id])) $hab = 1; else $hab=0;
				if (isset($_POST["V".$id])) $v = 1; else $v=0;
				
				$sql = "UPDATE courses_general " .  
					"SET HorasTeoricas='" . $_POST["HT".$id] . "'," .
					"HorasPracticas='" . $_POST["HP".$id] . "'," .
					"HorasTeoricoPracticas='" . $_POST["HTP".$id] . "'," .
					"HorasAsesoria='" . $_POST["HA".$id] . "'," .
					"HorasIndependientes='" . $_POST["HI".$id] . "'," .
					"NumeroCreditos='" . $_POST["C".$id] . "'," .
					"Habilitable='" . $hab . "'," .
					"Validable='" . $v . "'," .
					"Naturaleza='" . $_POST["M".$id] . "' " .
					"WHERE ID=" . $id;			
				$planea->conn->query($sql);
			}
		}
	}	
?>

<form class="planeaForm" action="stats_viewcredits.php" method="POST">
<?php 
	require('stats_viewcredits_table.php');

	$canModify = false;
	if ( $_SESSION["RoleID"]!=planea::roleUser ) {
		if ( (($_SESSION["RoleID"]==planea::roleCoord)) || ($_SESSION["RoleID"]==planea::roleAdmin) )   {
			$canModify = true;
		}
	}
	
	$planID = $_POST["PlanID"];
	renderCreditTable( $planID, $planea, $canModify );
	
	$planea->closeConnection();

	if ( $canModify ) {
		echo "<input type=\"submit\" value=\"Guardar\">";
	}
?>
<input style="visibility:hidden" type="number" name="PlanID" value=<?php if (isset($_POST["PlanID"])) echo $_POST["PlanID"]; else echo "0"; ?>>
<input style="visibility:hidden" type="number" name="dummy" value="0">
</form>
</body>
</html>