<?php
require('planea_basics.php');  
$planea = new planea();
$conn = $planea->openConnection();	
$CourseID =  $_GET["ID"];
$CourseKeyID =  $_GET["CourseKeyID"];
$sql = "SELECT EstadoVersion,Version,Nombre FROM courses_general WHERE ID=" . $CourseID; 
$result = $conn->query($sql); 
$row = $result->fetch_assoc();
if ($row["EstadoVersion"]==planea::syllStateApproved) { 
	//Averigua si no hay otra versión abierta
	$sql = "SELECT ID FROM courses_general WHERE CourseKeyID=".$CourseKeyID." AND EstadoVersion=".planea::syllStateOpened." AND NOT ID=".$CourseID;
	$result = $conn->query($sql); 
	if ($result->num_rows == 0)  {
		$sql = "UPDATE courses_general SET VisVersion=0 WHERE CourseKeyID=".$CourseKeyID;
		$result = $conn->query($sql); 
		$sql = "UPDATE courses_general SET EstadoVersion=".planea::syllStateOpened.",VisVersion=1 WHERE ID=".$CourseID;
		$result = $conn->query($sql); 
		echo "La versión ".$row["Version"]." del curso ".$row["Nombre"]." ha pasado exitosamente al estado de Borrador";
	} else {
		echo "ERROR: No pueden existir dos versiones como borradores, por favor apruebe o remueva la versión que actualmente se encuentra como borrador antes de ejecutar esta acción.";
	}
} else if ($row["EstadoVersion"]==planea::syllStateDisabled) {
	echo "ERROR: No se puede abrir como borrador una versión antigua. Debe crear una nueva versión a partir de la versión antigua";
}	

$planea->closeConnection();
?>