<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script>
	var autoNumberingValue=1;
	var autoNumberingFirstId=-1;
	var autoNumberingLastId=-1;
	function autoNumeringTopic(obj) {
		if (obj.nodeType==1) {
			var id = obj.id.substr(4);
			if(autoNumberingFirstId==-1) { autoNumberingFirstId = id; }
			autoNumberingLastId = id;
			document.getElementById("NumTopic"+id).value=autoNumberingValue;
			document.getElementById("BtnUp"+id).style.display = "inline";
			document.getElementById("BtnDn"+id).style.display = "inline";
			autoNumberingValue++;
		}
	}
	function autoNumeringTopics() {
		var conceptualConts = document.getElementById("ConceptualConts");
		autoNumberingValue=1;
		autoNumberingFirstId = -1;
		autoNumberingLastId  = -1;
		conceptualConts.childNodes.forEach(autoNumeringTopic);
		if(autoNumberingFirstId!=-1) {
			document.getElementById("BtnUp"+autoNumberingFirstId).style.display = "none";
		}
		if(autoNumberingLastId!=-1) {
			document.getElementById("BtnDn"+autoNumberingLastId).style.display = "none";
		}
	}
	function removeTopic(courseID,topicID) {
		var r = confirm("¿Desea eliminar la unidad temática?");
		if (r == true) {		
			var xhttp = new XMLHttpRequest();
			var conceptualConts = document.getElementById("ConceptualConts");
			var removeUnit = document.getElementById("Unit"+topicID);
			conceptualConts.removeChild(removeUnit);	
			autoNumeringTopics();
			xhttp.open("GET", "planea_removetopic.php?removeID="+topicID+"&courseID="+courseID, true);
			xhttp.send();
		}
	}
	function addTopic(courseID) {				
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				var conceptualConts = document.getElementById("ConceptualConts");
				var newUnit = document.createElement("DIV");
				var ss = this.responseText.indexOf("\"")+1;
				var es = this.responseText.indexOf("\"",ss);
				var idname = this.responseText.substring(ss, es);
				var idunit = idname.substr(4);
				newUnit.innerHTML = this.responseText;
				newUnit.id = idname;
				conceptualConts.appendChild(newUnit);
				new nicEditor({buttonList : ['bold','italic','underline','subscript','superscript','ol','ul','indent','outdent']}).panelInstance("Contents"+idunit);
				planeaFormatTextarea.textAreaById("Contents"+idunit);
				autoNumeringTopics();
			}
		};
		xhttp.open("GET", "planea_addtopic.php?courseID="+courseID, true);
		xhttp.send();		
	}
	function moveTopic(courseID,topicID,direction) {				
		var xhttp = new XMLHttpRequest();
		var conceptualConts = document.getElementById("ConceptualConts");
		var moveUnit = document.getElementById("Unit"+topicID);
		if (direction==1) {
			conceptualConts.insertBefore( moveUnit.nextSibling, moveUnit );
		} else {
			conceptualConts.insertBefore( moveUnit, moveUnit.previousSibling );
		}	
		autoNumeringTopics();
		xhttp.open("GET", "planea_movetopic.php?courseID="+courseID+"&topicID="+topicID+"&dir="+direction, true);
		xhttp.send();		
	}
	var nTotalWeeks=0;
	function analyzeWeeksUnit(obj) {
		if (obj.nodeType==1) {
			var id = obj.id.substr(4);
			var weeks = parseFloat(document.getElementById("Weeks"+id).value);
			if (isNaN(weeks)) weeks = 0;
			nTotalWeeks += weeks;
		}
	}
	function analyzeWeeks() {
		var numWeeks = 16;
		var conceptualConts = document.getElementById("ConceptualConts");
		nTotalWeeks=0;
		conceptualConts.childNodes.forEach(analyzeWeeksUnit);
		if (nTotalWeeks>numWeeks) {
			alert("¡El número de semanas totales ("+nTotalWeeks+") es superior al máximo permitido de "+numWeeks+"!");
		}
	}
	</script>	
</head>

<body>

<?php  
	require('planea_basics.php');
	require('planea_logosbar.php');
	$helptopic = "teacher-syllabuscont";
	require('planea_syllabusbar.php');
		
	$planea = new planea();
	$conn = $planea->openConnection();
	if (isset($_GET["ID"])) {
		$CourseID = $_GET["ID"];
	}
	if (isset($_POST["ContenidosProcedimentales"])) {
		$CourseID = $_POST["CourseID"];
		//Si se da clic en el botón Guardar, almacena la información en la base de datos
		$sql = "UPDATE courses_general SET ContenidosProcedimentales='". $_POST["ContenidosProcedimentales"] ."' WHERE ID=" . $CourseID;
		$conn->query($sql);
		$sql = "UPDATE courses_general SET ContenidosActitudinales='". $_POST["ContenidosActitudinales"] ."' WHERE ID=" . $CourseID;
		$conn->query($sql);
		$planea->saveContents($CourseID);
	}
	$sql = "SELECT * FROM courses_general WHERE ID=" . $CourseID;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$CourseName = $planea->showCourseTitle($row);
	$canModify = $planea->checkPermission( $_SESSION["RoleID"], $_SESSION["UserID"], $CourseID, 32 );
	$coursebar_opt = 6;
	require('planea_coursebar.php');
?>


<form class="planeaForm" id="mainForm" action="view_syllabus_cont.php" onsubmit="return clearModifiedFlag()" method="POST">

<script type="text/javascript" src="planea_formattextarea.js"></script> 
<script type="text/javascript" src="nicEdit.js"></script>
<script type="text/javascript">
  bkLib.onDomLoaded(function() {
		nicEditors.allTextAreas({buttonList : ['bold','italic','underline','subscript','superscript','ol','ul','indent','outdent']});
		planeaFormatTextarea.allTextAreas();
		analyzeWeeks();
	});
</script>  



<b>Contenidos Conceptuales</b> 
<br><br>	
<div id="courseContents">   
<?php 
	$planea->showContents($CourseID, $canModify );
?>
</div>
<button class="button btn_fancy" <?php if (!$canModify) { echo "style=\"visibility:hidden\""; } ?> onclick="addTopic(<?php echo $CourseID. ",".$canModify ?>)" type="button">Añadir Unidad <img src="images/btn_add1.png"> </button>				
<br> <br>

<b>Contenidos Procedimentales</b> <br>
<textarea name="ContenidosProcedimentales" rows=5 style="width: 100%;"><?php echo $row["ContenidosProcedimentales"]; ?></textarea><br><br>

<b>Contenidos Actitudinales</b><br>
<textarea name="ContenidosActitudinales" rows=5 style="width: 100%;"><?php echo $row["ContenidosActitudinales"]; ?></textarea><br><br>

<input style="display:none" type="number" name="CourseID" value="<?php echo $row["ID"]; ?>">

<?php 
	if ($canModify) { 
		echo "<input type=\"submit\" value=\"Guardar\">"; 
	}
	$planea->closeConnection();	
?>
<input type="submit" formaction="syllabus.php" value="Cancelar"> 
</form>  

</body>
</html>
