<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
</head>

<body>

<?php  
	require('planea_logosbar.php');
?>

<ul class="navbar navbar-help"> 
<li><a href="login.php">Inicio</a></li>
<li><a class="active" href="#">Perfil de usuario</a></li>
<li><a href="logout.php">Salir</a></li>
<li><a href="doc/planea_userguide.html#general-profile" target="PLANEA-help">?</a></li>
</ul>


<?php  
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	
	//Modify user settings 
	if (isset($_POST["Name"])) {
		$sql = "UPDATE users SET name='" . $_POST["Name"] . "',countryID='".$_POST["CC"]."',defaultPlan='".$_POST["IDPlan"]."' WHERE ID=".$_SESSION["UserID"];
		$result = $conn->query($sql);
		$_SESSION["DefaultPlan"] = $_POST["IDPlan"];
	} 
	//Modify the password
	if ( isset($_POST["CurrentPass"]) ) {
		$sql = "SELECT password FROM users WHERE ID=".$_SESSION["UserID"];
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();
		if ( password_verify( $_POST["CurrentPass"], $row["password"] ) ){
			if ( (strlen($_POST["NewPass1"])>0) && (strcmp($_POST["NewPass1"],$_POST["NewPass2"])==0) ) {
				$sql = "UPDATE users SET password='" . password_hash($_POST["NewPass1"],PASSWORD_DEFAULT)."' WHERE ID=".$_SESSION["UserID"];
				$result = $conn->query($sql);
			} else {
				echo "<p class=\"warning\">Las contraseñas nuevas no coinciden</p>";
			}
		} else
		{
			echo "<p class=\"warning\">La contraseña ingresada es incorrecta</p>";
		}			
	}
	//Get current user settings
	$sql = "SELECT * FROM users WHERE ID=".$_SESSION["UserID"];
	$result = $conn->query($sql);
	$row = $result->fetch_assoc();
	$_SESSION["UserName"] = $row["name"];
?>


<form class="planeaForm" action="profile.php" method="POST">
	email: <?php echo $row["email"] ?> <br> <br>
	Nombre: <input type="text" name="Name" value="<?php echo $row["name"] ?>" size=50> <br> <br>
	Cédula: <input type="text" name="CC" value="<?php echo $row["countryID"] ?>" size=50> <br> <br>
	Plan de estudios asignado:
	<select name="IDPlan">
	<?php $planea->showStudyPlan($row["defaultPlan"],true); $planea->closeConnection(); ?>	
	</select>
	<br> <br>
	<input type="submit" value="Modificar información">
</form>

<form class="planeaForm" action="profile.php" method="POST">
	Contraseña actual: <input type="password" name="CurrentPass" size=12> <br> <br>
	Nueva contraseña: <input type="password" name="NewPass1" size=12> <br> <br>
	Confirmar contraseña: <input type="password" name="NewPass2" size=12> <br> <br>
	<input type="submit" value="Modificar contraseña">
</form>


</body>
</html>
