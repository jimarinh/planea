<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" type="text/css" href="planea.css">
	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<style>
		.custom-combobox {
			position: relative;
			display: inline-block;
		}
		.custom-combobox-toggle {
			position: absolute;
			top: 0;
			bottom: 0;
			margin-left: -32px;
			padding: 0;
		}
		.custom-combobox-input {
			margin: 0;
			padding: 3px 6px;
		}
		.custom-overflow {
			height: 200px;
		}
		.ui-autocomplete {
			max-height: 300px;
			overflow-y: auto;
			overflow-x: hidden;
			padding-right: 20px;
		}
	</style>
</head>

<body>

<?php  
	require('planea_logosbar.php');
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();  
	if ($_SESSION["RoleID"]!=planea::roleCoord) {
		exit("Seleccione el rol Coordinador");
	}
	$helptopic = "coord-eval";
	require('planea_evalcoordbar.php');
?>

	<script src="combobox_search.js"></script>
	<script>
	  $( function() { 
		$("#ListOfUsers").combobox();
		} );
	</script>
	<script>
		function updateCollaboratorTable(PlanID) {
			var s = document.getElementById("SemesterID");
			if (s.selectedIndex==-1) return;
			var xhttp = new XMLHttpRequest();
			var SemName = s.options[s.selectedIndex].text;
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("areaCollaborators").innerHTML = this.responseText;
				}
			};
			xhttp.open("GET", "planea_viewareacollaborator.php?PlanID="+PlanID+"&SemName="+SemName, true);
			xhttp.send();
		}
		function updateReportStatistics() {
			var xhttp = new XMLHttpRequest();
			var e = document.getElementById("SemesterID");
			if (e.selectedIndex==-1) return;
			var SemName = e.options[e.selectedIndex].text;
			var p = document.getElementById("ListOfStudyPlans");
			if (p.selectedIndex == -1) return;
			var PlanID = p.options[p.selectedIndex].value;	
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var obj = JSON.parse(this.responseText);
					document.getElementById("numCourseReportsDone").innerHTML = obj.nCRDone; 
					document.getElementById("numCourseReportsPend").innerHTML = obj.nCRPend;
					document.getElementById("numAreaReportsDone").innerHTML = obj.nARDone; 
					document.getElementById("numAreaReportsPend").innerHTML = obj.nARPend; 
				}
			};
			xhttp.open("GET", "eval_viewreports_stats.php?PlanID="+PlanID+"&SemName="+SemName, true);
			xhttp.send();
		}
		function changePlan() {
			var e = document.getElementById("ListOfStudyPlans");
			if (e.selectedIndex == -1) {
				return null;
			}
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("AreaName").innerHTML = this.responseText;
					updateCollaboratorTable(e.value);
					updateReportStatistics();
				}
			};
			xhttp.open("GET", "planea_loadareas.php?PlanID="+e.value, true);
			xhttp.send();
		}
		function changeSemester() {
			var e = document.getElementById("ListOfStudyPlans");
			if (e.selectedIndex == -1) {
				return null;
			}
			updateCollaboratorTable(e.value);
			updateReportStatistics();
		}
		
		function viewNewSemesterInfo() {
			document.getElementById("newSemesterInfo").style.display = "inline";
			document.getElementById("newSemesterButton").style.display = "none";
		}
		function cancelNewSemesterInfo() {
			document.getElementById("newSemesterInfo").style.display = "none";
			document.getElementById("newSemesterButton").style.display = "inline";
		}
		function newSemesterInfo() {
			var xhttp = new XMLHttpRequest();
			var e = document.getElementById("newSemesterName");
			document.getElementById("newSemesterInfo").style.display = "none";
			document.getElementById("newSemesterButton").style.display = "inline";
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("SemesterID").innerHTML = this.responseText;
					document.getElementById("areaCollaborators").innerHTML = "";
					updateReportStatistics();
				}
			};
			xhttp.open("GET", "planea_newsemester.php?SemName="+e.value, true);		
			xhttp.send();
		}
		
		function removePendEvalPrevSemesters(PlanID, SemName) {
			var xhttp = new XMLHttpRequest();
			xhttp.open("GET", "eval_checklasteval.php?PlanID="+PlanID+"&SemName="+SemName+"&Action=remove", true);	
			xhttp.send();
		}
		function checkPendEvalPrevSemesters(PlanID, SemName) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					if (this.responseText == "1") {
						var r = confirm("Hay solicitudes de evaluación pendientes de semestres anteriores.\n¿Desea eliminar estas solicitudes para evitar confusión en los colaboradores?");
						if (r == true) {
							removePendEvalPrevSemesters(PlanID, SemName);
						}
					}
				}
			};
			xhttp.open("GET", "eval_checklasteval.php?PlanID="+PlanID+"&SemName="+SemName+"&Action=check", true);	
			xhttp.send();
		}
		function startEvalOfSemester() {
			var xhttp = new XMLHttpRequest();
			var e = document.getElementById("SemesterID");
			if (e.selectedIndex==-1) return;
			var SemName = e.options[e.selectedIndex].text;
			var p = document.getElementById("ListOfStudyPlans");
			if (p.selectedIndex == -1) return;
			var PlanID = p.options[p.selectedIndex].value;
			checkPendEvalPrevSemesters(PlanID, SemName);
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					alert(this.responseText);
					updateReportStatistics();
				}
			};
			xhttp.open("GET", "planea_starteval.php?PlanID="+PlanID+"&SemName="+SemName, true);	
			xhttp.send();
		}		
		function assignCollaborator() {
			var xhttp = new XMLHttpRequest();
			var e = document.getElementById("SemesterID");
			if (e.selectedIndex==-1) return;
			var SemName = e.options[e.selectedIndex].text;
			var p = document.getElementById("ListOfStudyPlans");
			if (p.selectedIndex == -1) return;
			var PlanID = p.options[p.selectedIndex].value;
			var u = document.getElementById("ListOfUsers");
			if (u.selectedIndex == -1) return;
			var userID = u.options[u.selectedIndex].value;
			var a = document.getElementById("AreaName");
			if (a.selectedIndex == -1) return;
			var area = a.options[a.selectedIndex].text;
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("areaCollaborators").innerHTML = this.responseText;
					updateReportStatistics();
				}
			};
			xhttp.open("GET", "planea_assignareacollaborator.php?PlanID="+PlanID+"&SemName="+SemName+"&UserID="+userID+"&AreaName="+encodeURIComponent(area), true);	
			xhttp.send();
		}

		function removeAreaCollaborator(Id) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("areaCollaborators").innerHTML = this.responseText;
				}
			};
			xhttp.open("GET", "planea_removeareacollaborator.php?ID="+Id, true);	
			xhttp.send();
		}
		
		function viewAreaReports(dispMode) {
			if (dispMode==1) { 
				dispAreaMode.value = "Done"; 
			} else {
				dispAreaMode.value = "Pend"; 
			}
			viewReportsForm.submit();
		}
		
		window.onload=function(){
			updateReportStatistics();	
		}
	</script>

<div class="planeaForm">
	<p style="font-size:small">Para el proceso de evaluación curricular: </p>
	<ol style="font-size:small"><li>Asigne los docentes responsables de la evaluación en el módulo <b>Definir Responsables</b> -> <b>Asignar Docentes</b>. Regrese a la pantalla principal de ser necesario.</li>
	<li>Seleccione el plan de estudios y de clic en el botón <b>Iniciar evaluaciones del semestre</b>. Debe hacer esto por cada plan de estudios.</li>
	<li>Asigne los colaboradores encargados de generar los reportes de evaluación del área.</li>
	<li>Puede revisar en este módulo los reportes diligenciados y cuales quedan pendientes.</li>
	</ol>
	<p style="font-size:small">Si una vez iniciado el proceso de ingreso de evaluaciones olvidó asignar algún curso y/o docente, lo puede hacer y volver a iniciar las evaluaciones. Esta acción solamente iniciará el proceso de evaluación a los nuevos cursos asignados. </p>
</div>

<form class="planeaForm" id="viewReportsForm" action="eval_viewreports_area.php" method="GET">
Semestre: 
<select id="SemesterID" name="SemesterID" onchange="changeSemester()">
<?php 
	$defaultSem = $planea->showSemesterList(); 
?>
</select>

<div id="newSemesterInfo" style="display:none">
	&nbsp;Nombre del semestre: <input type="text" id="newSemesterName" size=20>
	<button type="button" onclick="newSemesterInfo()">Crear Semestre</button>  &nbsp;
	<button type="button" onclick="cancelNewSemesterInfo()">Cancelar</button>
</div>
<button type="button" id="newSemesterButton" onclick="viewNewSemesterInfo()">*Nuevo Semestre</button>
<br> <br>
Plan:
<select id="ListOfStudyPlans" name="PlanID" onchange="changePlan()">
<?php 
	$defaultPlan = $_SESSION["DefaultPlan"];
	if ($_SESSION["RoleID"]==planea::roleCoord) $defaultPlan = $planea->showStudyPlan($defaultPlan,false,$_SESSION["UserID"]); 
	else $planea->showStudyPlan($defaultPlan); 
?>
</select>
&nbsp;
<button type="button" onclick="startEvalOfSemester()">Iniciar evaluaciones del semestre para este plan</button> 
<br> <br>

<table class="rubrics">
<tr><th></th><th>Completos</th><th>Incompletos</th></tr>
<tr>
	<td>Reportes de evaluación de curso</td>
	<td><div id="numCourseReportsDone"></div><input type="submit" formaction="eval_viewreports_done.php" value="Visualizar"></td>
	<td><div id="numCourseReportsPend"></div><input type="submit" formaction="eval_viewreports_pending.php" value="Visualizar"></td>
</tr>
<tr>
	<td>Reportes de evaluación de área</td>
	<td><div id="numAreaReportsDone"></div><button type="button" onclick="viewAreaReports(1)">Visualizar</button></td>
	<td><div id="numAreaReportsPend"></div><button type="button" onclick="viewAreaReports(2)">Visualizar</button></td>
</tr>
<tr><td>Reporte final con conclusiones</td><td colspan="2"><input type="submit" formaction="eval_viewreports_final.php" value="Visualizar"></td></tr>
</table>
<input type="text" id="dispAreaMode" name="disp" value="All" style="display:none">
</form>  





<div class="planeaForm">
<b>Asignación de colaboradores para evaluación de áreas:</b><br><br>

Área/Núcleo Temático: 
<select id="AreaName" name="AreaName">
<?php 
	$planea->showAreasListByPlan($defaultPlan );
?>
</select>
&nbsp;
Usuario: <select id="ListOfUsers" name="userID">
	<option value="">Seleccione uno...</option>
	<?php $planea->showUserList(); ?>
</select> 
&nbsp;
<button type="button" onclick="assignCollaborator()">Asignar</button> <br><br>
<table id="areaCollaborators">
<?php 
	$planea->showAreaCollaboratorsForEval($defaultPlan,$defaultSem);
?>
</table>
</div>

<?php $planea->closeConnection(); ?>

</body>
</html>
