<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$CourseID = $_GET["courseID"];	
$skillType = $_GET["skillType"];
switch ($skillType) {
    case "P":
        $databasename = "personal_skills";
        break;
    case "I":
        $databasename = "interpersonal_skills";
        break;
    case "C":
        $databasename = "cdio_skills";
        break;
}
$sql = "INSERT INTO courses_".$databasename." (CourseID,SkillID) VALUES ('" . $CourseID . "', '". $_GET["skillID"]. "')";
if ($planea->conn->query($sql)==TRUE) {
	$last_id = $planea->conn->insert_id;
	$sql = "SELECT * FROM courses_".$databasename." WHERE ID=" . $last_id;
	$result = $planea->conn->query($sql);
	$row = $result->fetch_assoc();
	$planea->showSkill( $CourseID, $skillType, $databasename, $row, true );
}
$planea->closeConnection();
?>
