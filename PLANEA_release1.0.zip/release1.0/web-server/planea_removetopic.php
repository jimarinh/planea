<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$CourseID = $_GET["courseID"];	
$sql = "DELETE FROM courses_contents WHERE ID=" . $_GET["removeID"];
$planea->conn->query($sql);
$sql = "UPDATE teacher_activities SET TopicID=0 WHERE TopicID=". $_GET["removeID"];
$planea->conn->query($sql);
$sql = "SELECT * FROM courses_contents WHERE CourseID=" . $CourseID . " ORDER BY TopicNumber";
$result = $planea->conn->query($sql);
$topicNumber = 1;
while($row = $result->fetch_assoc()) {
	$sql = "UPDATE courses_contents SET TopicNumber='" . $topicNumber . "' WHERE ID=" . $row["ID"];
	$planea->conn->query($sql);
	$topicNumber++;
}
$planea->closeConnection();
?>