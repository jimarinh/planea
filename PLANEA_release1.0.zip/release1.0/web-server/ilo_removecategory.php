<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
//Check if RAP Category could be removed...
$sql = "SELECT ID FROM courses_ilos WHERE CategoryID=".$_GET["catID"];
$result = $planea->conn->query($sql);
if ($result->num_rows > 0) {
	echo "0";
} else {
	$sql = "DELETE FROM ilo_categories WHERE ID=".$_GET["catID"];
	$result = $planea->conn->query($sql);
	echo "1"; 
}
$planea->closeConnection();
?>