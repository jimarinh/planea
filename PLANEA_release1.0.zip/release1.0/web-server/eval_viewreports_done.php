<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>  
	<meta charset="utf-8">
	<title>PLANEA</title>
	<link rel="stylesheet" type="text/css" href="planea.css">
	<style>
	p {
		background-color: lightgrey;
		border: 1px solid green;
		padding: 1px;
		margin: 1px;
	}
	</style>
	<script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</head>

<body>

<?php  
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection(); 

	require('planea_logosbar.php');
	$subMenuName = "Reporte por curso";
	
	//Check for credentials
	if ($_SESSION["RoleID"]!=planea::roleCoord) {
		exit("<font color=\"red\">No tiene permiso para acceder a esta sección</font>");
	}
	
	$helptopic = "coord-eval-course-done";
	require('planea_evalcoordbar.php'); 
	if ( !isset($PlanID) || !isset($SemesterID) ) exit(0);	
?>

	<script>
		function displayDiv(str, n) {
			if (str.length==0) {
				document.getElementById("cT"+n).style= "display:none";
			} else {
				document.getElementById("cT"+n).style= "display:inline";
			}
		}
		function viewReport(reportID) {
			var xhttp = new XMLHttpRequest();
			var e = document.getElementById("reportForm");
			e.style = "display:block";			
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					var obj = JSON.parse(this.responseText);
					document.getElementById("T1").innerHTML = obj.UnknownPrevSkills; displayDiv(obj.UnknownPrevSkills, 1);
					document.getElementById("T2").innerHTML = obj.UncoveredTopics; displayDiv(obj.UncoveredTopics, 2);
					document.getElementById("T3").innerHTML = obj.IrrelevantTopics; displayDiv(obj.IrrelevantTopics, 3);
					document.getElementById("T4").innerHTML = obj.StudentProblems; displayDiv(obj.StudentProblems, 4);
					document.getElementById("T5").innerHTML = obj.SuccessfulExp; displayDiv(obj.SuccessfulExp, 5);
					document.getElementById("T6").innerHTML = obj.UnsuccessfulExp; displayDiv(obj.UnsuccessfulExp, 6);
					document.getElementById("T7").innerHTML = obj.ImprovMeasures; displayDiv(obj.ImprovMeasures, 7);
					var chart = new CanvasJS.Chart("chartContainer",
					{
						title:{
							text: "Desempeño de los estudiantes"
						},
						data: [
						{
							type: "pie",
							showInLegend: true,
							toolTipContent: "{y} - #percent %",
							legendText: "{indexLabel}",
							dataPoints: [
								{ y: obj.NStudents-obj.NFailedStudents, indexLabel: "Aprobados" },
								{ y: obj.NFailedStudents, indexLabel: "Reprobados" }
							]
						}
						]
					});
					chart.render();					
				}
			};
			xhttp.open("GET", "eval_viewreports_course.php?reportID="+reportID, true);
			xhttp.send();	
		}
		function editReport(reportID) {
			var r = confirm("Esta acción devolverá el reporte al docente para realizar modificaciones. Además, el reporte pasará al estado incompleto. ¿Desea continuar?");
			if (r == true) {
				var xhttp = new XMLHttpRequest();
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						var e = document.getElementById("reportForm");
						e.style = "display:none";	
						var x = document.getElementById("row"+reportID);
						var tableObj = document.getElementById("reportsTable");
						tableObj.deleteRow(x.rowIndex);
					}
				}
				xhttp.open("GET", "planea_setstate_evalreport.php?State=0&ReportID="+reportID, true);
				xhttp.send();
			}
		}
		
		function exportReports(PlanID,SemName) {
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					tableToExcel(this.responseText,'reports');
				}
			}
			xhttp.open("GET", "eval_viewreports_exportall.php?PlanID="+PlanID+"&SemName="+encodeURIComponent(SemName), true);
			xhttp.send();	
		}
		var tableToExcel = (function() {
			var uri = 'data:application/vnd.ms-excel;base64,'
				, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>'
				, base64 = function(s) { return window.btoa(unescape(encodeURIComponent(s))) }
				, format = function(s, c) { return s.replace(/{(\w+)}/g, function(m, p) { return c[p]; }) }
			return function(tableHTML, name) {
				var ctx = {worksheet: name || 'Worksheet', table: tableHTML}
				window.location.href = uri + base64(format(template, ctx))
			}
		})()
	</script>

<h3>Programa: <i><?php echo $planName; ?></i> &nbsp; Semestre: <i><?php echo $semesterName;?></i> </h3>

<div class="planeaForm">
<button type="button" onClick="exportReports(<?php echo $_GET["PlanID"].",'".$semesterName."'";?>)">Exportar Todos los Reportes Indivuales a Excel</button> <br> <br>
<table id="reportsTable">
<?php 
	$planea->showEvalReportListByCourse($_GET["PlanID"], $semesterName, 1);
?>
</table>
</div>

<div class="planeaForm" id="reportForm" style="display:none">
<h3>Reporte Individual del Curso</h3>
<div id="chartContainer" style="height: 300px; width: 100%;"></div> 
<br> <br>
<div id="cT1">
<b>Deficiencias de los estudiantes en conocimientos o habilidades previas</b>  
<p id="T1"></p> <br>
</div>
<div id="cT2">
<b>Temas o unidades de aprendizaje no cubiertos en el desarrollo del semestre</b> 
<p id="T2"></p> <br>
</div>

<div id="cT3">
<b>Temas o unidades de aprendizaje irrelevantes que se podrían suprimir del sílabo</b> 
<p id="T3"></p> <br> 
</div>
<div id="cT4">
<b>Problemas de los estudiantes para el desarrollo del curso</b>
<p id="T4"></p> <br>
</div>
<div id="cT5">
<b>Experiencias <u>exitosas</u> en el desarrollo del curso</b> 
<p id="T5"></p> <br>
</div>
<div id="cT6">
<b>Experiencias <u>no exitosas</u> en el desarrollo del curso</b>
<p id="T6"></p> <br>
</div>
<div id="cT7">
<b >Acciones de mejora para el próximo semestre o cambio en el sílabo</b>
<p id="T7"></p> <br>
</div>
</div>

<?php $planea->closeConnection(); ?>

</body>
</html>
