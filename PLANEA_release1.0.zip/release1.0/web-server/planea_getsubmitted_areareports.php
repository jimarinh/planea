<?php 
	require('planea_basics.php');
	$planea = new planea();
	$conn = $planea->openConnection();
	echo $planea->showCollaboratorSubmittedEvalReports( $_GET["UserID"], $_GET["Semester"] );
	$planea->closeConnection();
?>