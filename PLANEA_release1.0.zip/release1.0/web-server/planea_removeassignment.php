<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "DELETE FROM users_assignments WHERE ID=" . $_GET["removeID"];
$planea->conn->query($sql);
$planea->closeConnection();
?>