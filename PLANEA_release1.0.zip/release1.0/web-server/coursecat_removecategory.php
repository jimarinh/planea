<?php
require('planea_basics.php');
$planea = new planea();
$planea->openConnection();
$sql = "DELETE FROM coursecat_values WHERE ID=".$_GET["catID"];
$result = $planea->conn->query($sql);
$planea->closeConnection();
?>